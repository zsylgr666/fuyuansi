# r8b result (frozen 2026-11-14 06:30 UTC+8)

- Build: v4/index.r8b.html, sha256 a81a5383df181db2d1a1de0c9497a62e242abca7b4c99703baa004c4056a84d4, 1,709,575 B
- Patches: v4/r8b.patch (diff -u index.r8a2 → index.r8b, 57,715 B); v4/r8b-src.patch (qa/r8b-base-src → v4/_src: pack.mjs, r8.js, r8a2-block.js, r8b.js only; no codex2 files)
- Frozen builds untouched: r8a 0dab5eb9…, r8a1 e962056e…, r8a2 2a02a2d8…

## codex2 clip audit (qa/r8-audit/run.mjs, yard/tea/market, normalised compare: file names stripped, key + position ≤1.5 m clip / ≤3 m other)
| scene | baseline H/M/L | r8b H/M/L | true new |
|---|---|---|---|
| yard | 13/16/17 | 0/0/5 | L2 (YARD-003 garden instanced walkthrough 0.13 m², 0.57 m tall; YARD-005 r8b bench-rail collider 40 % covered) |
| tea | 10/12/23 | 0/0/1 | 0 (TEA-001 = baseline TEA-009, downgraded H→L) |
| market | 5/8/15 | 0/0/5 | L5 (3 roof/decor clips 0.04–0.12 m deep; 1 near-plane camera sample in portrait and 1 in landscape) |
Totals: true new H0 M0 L7. Baseline H fixed 27/28 (YARD-001…013, MKT-001…005, TEA-001…008, TEA-010). TEA-009 is still there as L (tree trunk OBB, 0.13 m²).
Files: qa/r8b-audit/r8b-freeze2.{json,md}, ncmp-freeze2.txt

## Walk test
yard 51/51, tea 50/50, market 50/50 legs OK, 0 stuck, contacts 5/0/1. Camera: 0 fully-blocked samples; market has 1 near-plane sample per orientation (L).

## Draw calls (spawn view, r8a2 → r8b)
mobile: yard 124→123, market 144→147, tea 114→118; other scenes unchanged (plaza 167, gate 87, hall 41, zen 31, study 28, lotus 92)
land: yard 137→133, market 201→205, tea 126→129; other scenes unchanged (plaza 195, gate 93, hall 46, zen 40, study 37, lotus 100)

## Buttons (crawler H1 M20 L68 on the pre-fix build; each item handled)
- H #161 放河灯 unreachable: r6FixTeaInteracts (r6-art.js) rebuilds the tea items after fixScene, which put the item back in the river at z 12.4 and also dropped the cushion seat-facing fix. A wrapper now re-applies teaItems() (放河灯 z 9.05 / range 1.6; cushions face the table). fixScene only marks a scene fixed once it is ready, and retries from the frame loop. Verified on a direct #tea load: the prompt reads 放河灯 and the click works.
- Seat gave no feedback → a 「起身」 prompt while seated. #94/#99/#100 mounts → hitched-mount layout, cart unchanged. #121/#122 daily claim → toasts. 「← 回院子」 in the yard → toast. 🪙 close → toast 商铺已收起. #52/#118 hit areas → 44 px minimum height.
- Left as designed: #57 知道了, #101/#152 auto-switch exits, #167 意见箱 (verified with a mock), #1 ✨ (toast fade timing).

## 赏景小记 (r8b line only)
The 宜/忌 pairs are gone. Each press shows one gentle sentence per direction (an everyday suggestion or a scenery note). A BAN regex blocks 宜/忌/吉凶/运势/签; a MutationObserver replaces any raw result on later presses. r7d now reads the gameplay fengDir instead of window.fengDir, so it no longer always shows 南.

## Camera
W3.r8CameraDt is now taken from frame dt (clamped 0.001–0.05). The r8a2 "idle creep" was a harness artifact (wall-clock dt); tree trace shows 0 jumps and an idle range of 0.

## Notes
- The frozen r8a1/r8a2 builds still show raw 今日运势/吉利方位/宜/忌 on a second 赏景 press. Fixed in r8b only.
- Runtime overrides of codex2 behaviour (codex2 files not edited): r6 mounts (r6SyncMounts), r5/r6 daily claim (#r5Claim capture), r7d feng note, r6-art 放河灯 and tea seats (r6FixTeaInteracts wrapper), worldCanMove bounds, plus the tea, yard and market geometry fixes in fixScene.
- Shots: qa/r8b-shots (before/after × mobile/land × yard/tea/market × spawn/over/over2, cmp-*.png side by side, seat and mount shots).
