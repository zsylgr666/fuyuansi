/* Art pass 2 — local canvas textures and shared, WebGL1-safe garden models. */
function tgArtTexture(kind){
 const w=W3,key='art2:'+kind;if(w.materials[key])return w.materials[key];
 const c=document.createElement('canvas');c.width=c.height=128;const a=c.getContext('2d');
 a.fillStyle={stone:'#cdbf9f',path:'#e1cda5',wood:'#82553b',water:'#70b9b5',glow:'#000'}[kind]||'#cdbf9f';a.fillRect(0,0,128,128);
 if(kind==='glow'){a.clearRect(0,0,128,128);const g=a.createRadialGradient(64,64,0,64,64,64);g.addColorStop(0,'rgba(255,228,110,.8)');g.addColorStop(.5,'rgba(255,195,56,.45)');g.addColorStop(1,'rgba(255,179,35,0)');a.fillStyle=g;a.fillRect(0,0,128,128);}
 else if(kind==='water'){for(let i=0;i<22;i++){a.strokeStyle=i%2?'#b9e4cc':'#8bcec4';a.lineWidth=1.5;a.beginPath();a.ellipse((i*47)%128,(i*31)%128,12+i%9,3,0,0,Math.PI*1.5);a.stroke();}}
 else if(kind==='wood'){for(let i=0;i<8;i++){a.fillStyle=i%2?'#906043':'#a16f4c';a.fillRect(i*16+1,0,14,128);a.strokeStyle='#70462f';a.beginPath();a.moveTo(i*16+5,0);a.bezierCurveTo(i*16+12,45,i*16,85,i*16+7,128);a.stroke();}}
 else{for(let row=0;row<4;row++)for(let col=-1;col<4;col++){const x=col*43+(row%2)*21;a.fillStyle=(row+col)%2?'#d9c8a6':'#c6b594';if(kind==='path')a.fillStyle=(row+col)%2?'#e4d4b4':'#d4bc94';a.fillRect(x+2,row*32+2,39,28);a.strokeStyle='#ede1c3';a.strokeRect(x+3,row*32+3,37,26);}}
 const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=kind==='glow'?THREE.ClampToEdgeWrapping:THREE.RepeatWrapping;t.repeat.set(kind==='glow'?1:kind==='wood'?4:kind==='water'?2:12,kind==='glow'?1:kind==='wood'?4:kind==='water'?2:12);
 const m=kind==='glow'?new THREE.MeshBasicMaterial({map:t,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide,opacity:.7}):kind==='water'?new THREE.MeshPhongMaterial({map:t,color:'#9cddd1',shininess:65,transparent:true,opacity:.82}):new THREE.MeshLambertMaterial({map:t});w.materials[key]=m;return m;
}
function tgArtGeo(name){const g=W3.geometries;return g['art2:'+name]||(g['art2:'+name]=name==='leaf'?new THREE.SphereGeometry(1,8,5):name==='disc'?new THREE.PlaneGeometry(1,1):name==='ridge'?new THREE.CylinderGeometry(1,1,1,8):new THREE.SphereGeometry(1,10,7));}
function tgRidgeBeds(){
 const s=W3.spaces.yard,soil=new THREE.MeshLambertMaterial({map:tgTexture(true)});W3.materials['art2:soil']=soil;
 const ridges=[],ends=[];for(let i=0;i<12;i++){const x=3.5+(i%3)*3.3-13.5,z=-6+Math.floor(i/3)*3.5;for(const dx of [-.72,0,.72])ridges.push([x+dx,.10,z,.29,1.96,.10,Math.PI/2]);for(const dz of [-1.15,1.15])ends.push([x,.18,z+dz,2.5,.25,.12]);}
 tgInstances(s.group,tgArtGeo('ridge'),soil,ridges);tgInstances(s.group,W3.geometries.box,worldMat('#b08a60'),ends);
}
function tgCropModel(group,cropId,stage){
 const batches=new Map(),ball=tgArtGeo('leaf');
 const add=(color,x,y,z,sx,sy,sz,rx=0,ry=0,rz=0)=>{if(!batches.has(color))batches.set(color,[]);batches.get(color).push([x,y+.2,z,sx,sy,sz,rx,ry,rz]);};
 const colors={cabbage:'#b7d863',carrot:'#f4a039',tomato:'#ef6950',corn:'#ffda68',peach:'#f5a3a4',melon:'#5d9960'};
 for(const x of [-.7,.7])for(const z of [-.52,.52]){
  if(stage===0){add('#d9b97a',x,.07,z,.09,.055,.065);continue;}
  const h=stage===1?.23:cropId==='corn'?.98:cropId==='peach'?.85:cropId==='tomato'?.7:.4;
  add('#628647',x,h/2,z,.035,h/2,.035);
  const n=stage===1?2:cropId==='carrot'?5:4;for(let j=0;j<n;j++){const a=j/n*Math.PI*2;add(j%2?'#7fac50':'#91bd59',x+Math.cos(a)*.16,h*(.55+j%2*.3),z+Math.sin(a)*.16,stage===1?.15:.29,.055,cropId==='carrot'?.07:.13,0,-a,Math.cos(a)*.4);}
  if(stage<2)continue;
  if(cropId==='cabbage'){for(let j=0;j<5;j++){const a=j*2.4;add(j%2?'#9bc858':'#b7d863',x+Math.cos(a)*.12,.22,z+Math.sin(a)*.12,.23,.17,.21,0,a,.3);}add('#d5e891',x,.35,z,.16,.19,.16);}
  else if(stage===2&&cropId==='peach')add('#8db85e',x,h,z,.28,.22,.25);
  else if(stage===2&&cropId==='melon')add('#78aa52',x+.2,.12,z,.36,.065,.16,0,.5);
  else if(stage===3){if(cropId==='carrot')add(colors[cropId],x,.17,z,.12,.25,.12,0,0,.16);
   else if(cropId==='corn'){for(const side of [-1,1])add(colors[cropId],x+side*.14,.65,z,.11,.29,.1,0,0,side*.3);}
   else if(cropId==='melon'){add(colors[cropId],x,.18,z,.32,.25,.29);for(const dx of [-.12,0,.12])add('#a7c775',x+dx,.24,z+.235,.024,.14,.025,0,0,-dx);}
   else for(const side of [-1,1])add(colors[cropId]||'#ef6950',x+side*.16,h-.12,z+.12,.16,.17,.15);
  }
 }
 for(const [color,items]of batches)tgInstances(group,ball,worldMat(color),items);
 if(stage===3){
  const mat=tgArtTexture('glow');mat.opacity=1;
  const glow=new THREE.Mesh(tgArtGeo('disc'),mat);glow.rotation.x=-Math.PI/2;glow.position.y=.36;glow.scale.set(5.6,5.4,1);glow.userData.artGlow=true;group.add(glow);
  const upMat=W3.materials['art2:glowUp']||(W3.materials['art2:glowUp']=new THREE.MeshBasicMaterial({map:mat.map,color:'#ffe3a0',transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide,opacity:.85}));
  const up=new THREE.Mesh(tgArtGeo('disc'),upMat);up.position.y=1.35;up.scale.set(2.2,2.4,1);up.userData.artGlow='up';group.add(up);
 }
}
function tgArtGarden(s,name){
 const box=W3.geometries.box,ball=tgArtGeo('ball'),leaf=tgArtGeo('leaf'),grass=[],flowers=[],centers=[],trunks=[],greens=[],pink=[];
 for(let i=0;i<80;i++){const side=i%2?-1:1,z=-9+(i%20)*1.1,x=side*(2.5+Math.floor(i/20)*.33);if(name==='yard'&&side<0)continue;grass.push([x,.16,z,.055,.28,.035,0,i,.25],[x+.1,.12,z,.04,.22,.04,0,i,-.3]);if(i%3===0){flowers.push([x,.33,z,.13,.08,.13]);centers.push([x,.39,z,.045,.045,.045]);}}
 tgInstances(s.group,leaf,worldMat('#6f9751'),grass);tgInstances(s.group,ball,worldMat('#e9a3a2'),flowers);tgInstances(s.group,ball,worldMat('#ffe0a0'),centers);
 // Repeated rounded canopies enrich the existing trees, without new trunk collisions.
 for(const [x,z]of name==='plaza'?[[-12,-7],[12,-7],[-12,8],[12,10]]:[[11,-7],[13,5],[11,10]]){trunks.push([x,1.1,z,.22,2.2,.22]);for(let j=0;j<4;j++){const a=j*2.4;(j===3?pink:greens).push([x+Math.cos(a)*.7,2.4+j*.27,z+Math.sin(a)*.65,1,.8,1]);}}
 // r5: existing trees supply one canopy per location.
 const paper=[],caps=[];for(const x of [-2.6,2.6])for(const z of [-4,9]){worldBox(s,x,.18,z,.68,.3,.68,'#afa88f');worldBox(s,x,.62,z,.22,.65,.22,'#afa88f');worldBox(s,x,1.12,z,.64,.1,.64,'#afa88f');paper.push([x,1.35,z,.4,.38,.4]);caps.push([x,1.65,z,.62,.2,.62]);}
 const lamp=W3.materials['art2:paper']||(W3.materials['art2:paper']=new THREE.MeshLambertMaterial({color:'#ffe2a0',emissive:'#a96825',emissiveIntensity:.45}));tgInstances(s.group,box,lamp,paper);tgInstances(s.group,ball,worldMat('#88938a'),caps);
 tgArtStream(s,name==='yard'?9:18,name==='yard'?-4:3,name==='yard'?4:8);
}
function tgArtStream(s,x,z,length){
 const water=new THREE.Mesh(W3.geometries.box,tgArtTexture('water'));water.position.set(x,.04,z);water.scale.set(1.25,.05,length);water.receiveShadow=true;s.group.add(water);
 // Only the water is blocked; a generous transverse deck remains walkable at ground level.
 s.blocks.push({x:x-.625,X:x+.625,z:z-length/2,Z:z-1},{x:x-.625,X:x+.625,z:z+1,Z:z+length/2});
 const stones=[];for(const side of [-1,1])for(let j=0;j<length;j++)stones.push([x+side*.78,.1,z-length/2+j,.3,.2,.45,0,j]);tgInstances(s.group,tgArtGeo('ball'),worldMat('#b8b59b'),stones);
 for(let j=-4;j<=4;j++){const dx=j*.27;worldBox(s,x+dx,.12+Math.cos(j/4*Math.PI/2)*.14,z,.28,.14,1.8,'#b99562');}for(const dz of [-.9,.9]){worldBox(s,x,.5,z+dz,2.6,.09,.09,'#99754c');for(const dx of [-1.1,1.1])worldBox(s,x+dx,.32,z+dz,.1,.6,.1,'#99754c');}
}
function tgArtMonk(){
 const b=W3.body,eye=[],iris=[],blush=[],beads=[];for(const x of [-.105,.105]){eye.push([x,1.342,.297,.035,.04,.014]);iris.push([x,1.341,.309,.021,.029,.01]);blush.push([x*1.85,1.265,.258,.042,.022,.012]);}
 tgInstances(b,tgArtGeo('leaf'),worldMat('#fff8e8'),eye);tgInstances(b,tgArtGeo('leaf'),worldMat('#3d302a'),iris);tgInstances(b,tgArtGeo('leaf'),worldMat('#e7a38c'),blush);
 for(let i=0;i<13;i++){const a=i/12*Math.PI;beads.push([Math.cos(a)*.22,1.04-Math.sin(a)*.19,.29,.027,.027,.027]);}tgInstances(b,tgArtGeo('leaf'),worldMat('#68452e'),beads);
 const collar=worldMesh(b,'box','#f4d291',0,1.04,.26,.28,.06,.04);collar.rotation.z=-.2;
 const hem=new THREE.Mesh(new THREE.TorusGeometry(.33,.022,4,20),worldMat('#f4d291'));hem.rotation.x=Math.PI/2;hem.scale.y=.83;hem.position.y=.25;b.add(hem);
}
function tgArtBatch(parent){
 const batches=new Map();for(const m of parent.children){if(!m.isMesh||m.isInstancedMesh||m.geometry===W3.geometries.box)continue;const key=m.material.uuid;if(!batches.has(key))batches.set(key,[]);batches.get(key).push(m);}
 for(const list of batches.values()){if(list.length<2)continue;const geos=list.map(m=>{m.updateMatrix();return m.geometry.clone().applyMatrix4(m.matrix);});const mesh=new THREE.Mesh(mergeGeometries(geos),list[0].material);mesh.castShadow=list.some(m=>m.castShadow);mesh.receiveShadow=true;parent.add(mesh);list.forEach(m=>parent.remove(m));geos.forEach(g=>g.dispose());}
}
function tgArt2(){
 const w=W3,p=w.spaces.plaza,y=w.spaces.yard,h=w.spaces.hall;
 p.floor.material=tgArtTexture('stone');h.floor.material=tgArtTexture('wood');
 for(const s of [p,y]){for(const m of s.group.children)if(m.isMesh&&m.geometry===w.geometries.box&&m.scale.y===.04)m.material=tgArtTexture('path');tgArtGarden(s,s===p?'plaza':'yard');}
 tgRidgeBeds();tgArtMonk();
 const fence=[];for(let j=0;j<12;j++){const z=-7.7+j*1.06;fence.push([-11.7,.3,z,.07,.6,.07]);}fence.push([-11.7,.44,-1.85,.06,.06,12.3]);// r5: merged yard no longer needs the inner west fence.
 const skyColor=w.sky.geometry.attributes.color,skyPos=w.sky.geometry.attributes.position;for(let i=0;i<skyColor.count;i++){const t=THREE.MathUtils.clamp((skyPos.getY(i)+10)/80,0,1),c=new THREE.Color('#f4dfb9').lerp(new THREE.Color('#83b5d1'),t);skyColor.setXYZ(i,c.r,c.g,c.b);}skyColor.needsUpdate=true;
 // Match the original pond to the shared animated stream material and feed it from the east.
 for(const m of y.group.children)if(m.isMesh&&m.position.x===6&&m.position.z===-3&&m.scale.x===2)m.material=tgArtTexture('water');
 const feed=worldBox(y,8,.035,-3,2,.04,1,'#70b9b5');feed.material=tgArtTexture('water');/* The feed joins under the bridge: existing pond and stream bounds cover exposed water. */
 // Cloth has a shallow catenary profile; keep original stall signs and their exact wiring.
 const tassels=[];for(const [x,z]of [[-4.8,1],[4.8,1],[7,7]]){for(const m of p.group.children)if(m.isMesh&&Math.abs(m.position.x-x)<1.8&&m.position.z===z&&m.position.y===2.9){const dx=m.position.x-x;m.position.y-=.14*(1-Math.min(1,Math.abs(dx)/1.6));m.rotation.z=dx*.06;}
 for(let j=0;j<13;j++)tassels.push([x-1.5+j*.25,2.65,z+1.1,.035,.22+(j%2)*.05,.035]);worldBox(p,x,1.8,z+.82,2.65,.06,.05,'#d8ad5d');}tgInstances(p.group,w.geometries.cylinder,worldMat('#e6bf73'),tassels);
 // Softer mountain shoulders and a single instanced bank of slowly drifting clouds.
 const hills=[],clouds=[];for(let i=0;i<9;i++)hills.push([-32+i*8,1,-30,7,5+i%3,5]);tgInstances(p.group,tgArtGeo('ball'),worldMat('#a9b8a6',true),hills).castShadow=false;
 for(let i=0;i<12;i++)clouds.push([-25+i*5,12+i%3,-24-i%2*5,3, .65,1.4]);w.artClouds=tgInstances(p.group,tgArtGeo('ball'),worldMat('#f5e8cd',true),clouds);w.artClouds.castShadow=false;
 // Interior details stay behind the player and clear of the burner silhouette.
 worldBox(h,0,.036,-4.7,2.2,.025,5.1,'#a44f3e');for(const x of [-1.04,1.04])worldBox(h,x,.053,-4.7,.035,.012,5,'#d1a75c');
 const lanterns=[];for(const x of [-4.7,4.7]){for(const z of [-5,2]){worldBox(h,x,4.5,z,.035,.7,.035,'#b88c54');lanterns.push([x,3.92,z,.3,.43,.3]);}worldBox(h,x,2.8,-7.75,.45,2.4,.05,'#a64d37');worldBox(h,Math.sign(x)*5.45,1.8,-5.8,.8,.05,.8,'#c69a58');worldMesh(h.group,'ball','#789e9a',Math.sign(x)*5.45,2.18,-6,.22,.35,.22);}
 tgInstances(h.group,tgArtGeo('ball'),w.materials['art2:paper'],lanterns);
 for(const z of [-6,0,6])worldBox(h,0,5.22,z,11.8,.22,.25,'#90603f');for(const x of [-2.4,2.4])worldBox(h,x,1.22,-4.99,.08,.17,.06,'#e4bc6d');
 for(const [x,text]of [[-4.7,'书香传家'],[4.7,'家和业兴']]){const c=document.createElement('canvas');c.width=64;c.height=256;const a=c.getContext('2d');a.fillStyle='#a64d37';a.fillRect(0,0,64,256);a.strokeStyle='#dab574';a.strokeRect(5,5,54,246);a.fillStyle='#ffe0a0';a.font='bold 42px serif';a.textAlign='center';[...text].forEach((v,i)=>a.fillText(v,32,53+i*55));const m=new THREE.Mesh(tgArtGeo('disc'),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(c)}));m.scale.set(.44,2.3,1);m.position.set(x,2.8,-7.71);h.group.add(m);}
 const stems=[],blooms=[];for(const x of [-4.7,4.7])for(let i=0;i<5;i++){stems.push([Math.sign(x)*5.45+(i-2)*.08,2.5,-6,.02,.6,.02]);blooms.push([Math.sign(x)*5.45+(i-2)*.08,2.8+(i%2)*.1,-6,.13,.11,.13]);}tgInstances(h.group,w.geometries.cylinder,worldMat('#759457'),stems);tgInstances(h.group,tgArtGeo('leaf'),worldMat('#f1c5a2'),blooms);
 tgArtBatch(w.body);for(const s of [p,y,h])tgArtBatch(s.group);
 w.sun.color.set('#ffe0ad');
}
function tgAnimate(ts,dt){
 const w=W3,water=w.materials['art2:water'];if(water){water.map.offset.x=(water.map.offset.x+dt*.022)%1;water.map.offset.y=(water.map.offset.y+dt*.014)%1;}
 if(w.artClouds)w.artClouds.position.x=Math.sin(ts*.000025)*1.7;
 for(const c of w.crops){c.group.rotation.z=c.ripe?Math.sin(ts*.0018+c.group.position.x)*.025:0;for(const m of c.group.children)if(m.userData.artGlow){const p=1+Math.sin(ts*.0025+c.group.position.x)*.08;if(m.userData.artGlow==='up')m.scale.set(2.2*p,2.4*(1+(p-1)*.5),1);else m.scale.set(5.6*p,5.4*p,1);}}
 const glow=w.materials['art2:glow'];if(glow)glow.opacity=.92+Math.sin(ts*.0025)*.08;
 const up=w.materials['art2:glowUp'];if(up)up.opacity=.8+Math.sin(ts*.0025+.6)*.15;
}
