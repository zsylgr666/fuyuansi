/* audio.js · 福缘里 · 心田小院 背景音乐与音效（纯 WebAudio 程序化生成，无任何外部音频文件）
   导出 window.TG_AUDIO = {unlock, toggle, setScene, playSfx, isOn, ...}
   说明见同目录 audio.README.md。本文件独立，不修改其他模块。 */
(function(){
'use strict';
var G = typeof window !== 'undefined' ? window : this;
if (G.TG_AUDIO && G.TG_AUDIO.__v) return;           // 幂等：重复加载直接返回

var VERSION = 'audio-1';
var STORE_KEY = 'templeGarden.bgm';                  // '1' 开 / '0' 关
var OLD_MUTE_KEY = 'templeGarden.mute';              // enhance.js 的静音键，仅在没有 STORE_KEY 时参考
var MASTER_VOL = 0.42;                               // 柔和的总音量
var LOOKAHEAD = 0.45, TICK_MS = 120;                 // 前瞻调度
var MAX_VOICES = 26, SOFT_VOICES = 18;               // 同时发声上限（超过 SOFT 时跳过低优先级事件）
var XFADE = 1.1;                                     // 场景切换的 setTargetAtTime 时间常数（约 3 秒完成）
var AC = G.AudioContext || G.webkitAudioContext;

/* ---------- 五声音阶（D 宫调） ---------- */
var ROOT = 146.83; // D3
var PENTA = [0, 2, 4, 7, 9];
function degFreq(deg){ // deg: 0 = D3，每 5 级一个八度
  var o = Math.floor(deg / 5), i = ((deg % 5) + 5) % 5;
  return ROOT * Math.pow(2, o + PENTA[i] / 12);
}

/* ---------- 场景情绪 ----------
   bed：持续底噪层的目标音量；rate：事件平均间隔（秒，0 = 不出现）；
   mel：旋律参数（bpm、每拍出音概率、音区、是否琵琶式快弹） */
var MOODS = {
  gate:   {bed:{wind:.16, water:0,   stream:0,   murmur:0,   drone:.05}, rate:{bell:0,  chime:14, bird:7,  muyu:0,  drop:0,  frog:0,  clap:0},  mel:{bpm:54, p:.42, lo:2, hi:9,  harm:.18}, music:.8},
  plaza:  {bed:{wind:.08, water:0,   stream:.04, murmur:.03, drone:.035},rate:{bell:60, chime:14, bird:6,  muyu:0,  drop:0,  frog:0,  clap:0},  mel:{bpm:66, p:.55, lo:3, hi:11, harm:.12}, music:.9},
  market: {bed:{wind:.04, water:0,   stream:0,   murmur:.14, drone:0},   rate:{bell:0,  chime:20, bird:12, muyu:0,  drop:0,  frog:0,  clap:4.5},mel:{bpm:96, p:.72, lo:5, hi:13, harm:.06, fast:true}, music:1},
  yard:   {bed:{wind:.06, water:0,   stream:.05, murmur:0,   drone:.03}, rate:{bell:0,  chime:16, bird:3.5,muyu:0,  drop:9,  frog:0,  clap:0},  mel:{bpm:62, p:.5,  lo:3, hi:11, harm:.14}, music:.85},
  lotus:  {bed:{wind:.05, water:.2,  stream:.14, murmur:0,   drone:.04}, rate:{bell:0,  chime:11, bird:8,  muyu:0,  drop:1.6,frog:9,  clap:0},  mel:{bpm:50, p:.36, lo:2, hi:10, harm:.25}, music:.7},
  hall:   {bed:{wind:.05, water:0,   stream:.05, murmur:0,   drone:0},   rate:{bell:0,  chime:14, bird:8,  muyu:0,  drop:12, frog:0,  clap:0},  mel:{bpm:50, p:.36, lo:2, hi:9,  harm:.22}, music:.7},
  zen:    {bed:{wind:.06, water:.06, stream:.05, murmur:0,   drone:0},   rate:{bell:0,  chime:12, bird:10, muyu:0,  drop:8,  frog:0,  clap:0},  mel:{bpm:48, p:.28, lo:1, hi:8,  harm:.2},  music:.65},
  study:  {bed:{wind:.03, water:0,   stream:0,   murmur:0,   drone:.035},rate:{bell:0,  chime:30, bird:14, muyu:0,  drop:0,  frog:0,  clap:0},  mel:{bpm:52, p:.34, lo:1, hi:9,  harm:.2},  music:.6}
};
var ALIAS = {home:'yard', garden:'yard', shrine:'hall', temple:'hall', chanfang:'zen', pond:'lotus', square:'plaza'};
function normScene(id){ id = String(id || '').toLowerCase(); id = ALIAS[id] || id; return MOODS[id] ? id : 'plaza'; }

/* ---------- 持久化 ---------- */
function readPref(){
  try {
    var v = G.localStorage.getItem(STORE_KEY);
    if (v === '1') return true; if (v === '0') return false;
    if (G.localStorage.getItem(OLD_MUTE_KEY) === '1') return false;
  } catch (e) {}
  return true;
}
function writePref(on){ try { G.localStorage.setItem(STORE_KEY, on ? '1' : '0'); } catch (e) {} }

function rnd(a, b){ return a + Math.random() * (b - a); }
function pick(arr){ return arr[(Math.random() * arr.length) | 0]; }
function expo(mean){ return -Math.log(1 - Math.random()) * mean; }

/* =========================================================
   引擎：可用于实时 AudioContext，也可用于 OfflineAudioContext（导出样例）
   ========================================================= */
function Engine(ctx, offline){
  var E = this; E.ctx = ctx; E.offline = !!offline; E.ends = []; E.scene = 'plaza'; E.mood = MOODS.plaza;
  var sr = ctx.sampleRate;

  // 总线：music / amb / sfx → master → compressor → destination；混响用程序生成的脉冲响应
  E.master = ctx.createGain(); E.master.gain.value = 0;
  var comp = ctx.createDynamicsCompressor();
  comp.threshold.value = -16; comp.knee.value = 12; comp.ratio.value = 3; comp.attack.value = .01; comp.release.value = .3;
  E.master.connect(comp); comp.connect(ctx.destination);
  E.music = ctx.createGain(); E.music.gain.value = .9; E.music.connect(E.master);
  E.amb = ctx.createGain(); E.amb.gain.value = 1; E.amb.connect(E.master);
  E.sfx = ctx.createGain(); E.sfx.gain.value = .9; E.sfx.connect(E.master);
  E.verb = ctx.createConvolver(); E.verb.buffer = makeIR(ctx, 2.2);
  E.verbOut = ctx.createGain(); E.verbOut.gain.value = .55; E.verb.connect(E.verbOut); E.verbOut.connect(E.master);
  E.send = ctx.createGain(); E.send.gain.value = 1; E.send.connect(E.verb);

  E.noise = makeNoise(ctx, 3);
  E.strings = {}; // KS 拨弦缓存（按频率键）
  E.beds = {};
  E.next = {};
  E.melT = 0; E.melDeg = 5; E.phrase = 0;
  E.sceneMuyuT = 0;
  E.sr = sr;
}
var EP = Engine.prototype;

function makeIR(ctx, sec){
  var len = Math.floor(ctx.sampleRate * sec), b = ctx.createBuffer(2, len, ctx.sampleRate);
  for (var c = 0; c < 2; c++){
    var d = b.getChannelData(c), lp = 0;
    for (var i = 0; i < len; i++){
      var t = i / len; lp = lp * .6 + (Math.random() * 2 - 1) * .4;   // 稍暗的尾音
      d[i] = lp * Math.pow(1 - t, 3.2) * (i < 80 ? i / 80 : 1);
    }
  }
  return b;
}
function makeNoise(ctx, sec){ // 粉噪（近似），双声道略不同，循环播放
  var len = Math.floor(ctx.sampleRate * sec), b = ctx.createBuffer(2, len, ctx.sampleRate);
  for (var c = 0; c < 2; c++){
    var d = b.getChannelData(c), b0 = 0, b1 = 0, b2 = 0;
    for (var i = 0; i < len; i++){
      var w = Math.random() * 2 - 1;
      b0 = .99765 * b0 + w * .0990460; b1 = .96300 * b1 + w * .2965164; b2 = .57000 * b2 + w * 1.0526913;
      d[i] = (b0 + b1 + b2 + w * .1848) * .2;
    }
    var fade = 2000; for (var k = 0; k < fade; k++){ var a = k / fade; d[k] = d[k] * a + d[len - fade + k] * (1 - a); }
  }
  return b;
}

/* ---------- 发声计数（按结束时间统计，离线渲染同样可用） ---------- */
EP.voicesAt = function(t){
  var n = 0, keep = [], now = this.ctx.currentTime;
  for (var i = 0; i < this.ends.length; i++){ var e = this.ends[i]; if (e > now){ keep.push(e); if (e > t) n++; } }
  this.ends = keep; return n;
};
EP.claim = function(t, dur, prio){
  var n = this.voicesAt(t);
  if (n >= MAX_VOICES || (!prio && n >= SOFT_VOICES)) return false;
  this.ends.push(t + dur); return true;
};

/* ---------- 基础音色 ---------- */
// 古琴：Karplus-Strong 预计算拨弦（每个音高只算一次），播放时可带「吟猱」滑音
EP.string = function(f, decay){
  var key = Math.round(f) + ':' + decay; if (this.strings[key]) return this.strings[key];
  var ctx = this.ctx, sr = this.sr, N = Math.max(2, Math.round(sr / f)), len = Math.floor(sr * (decay > .995 ? 3.2 : 1.6));
  var b = ctx.createBuffer(1, len, sr), d = b.getChannelData(0), lp = 0, i;
  for (i = 0; i < N; i++){ lp = lp * .5 + (Math.random() * 2 - 1) * .5; d[i] = lp; }
  for (i = N; i < len; i++) d[i] = decay * .5 * (d[i - N] + d[i - N - 1 < 0 ? 0 : i - N - 1]);
  var peak = 0; for (i = 0; i < len; i++) peak = Math.max(peak, Math.abs(d[i]));
  if (peak > 0) for (i = 0; i < len; i++) d[i] /= peak;
  var out = {buf: b, rate: f / (sr / (N + .5))};
  this.strings[key] = out; return out;
};
EP.pluck = function(t, f, vol, opts){
  opts = opts || {}; var ctx = this.ctx;
  var s = this.string(f, opts.short ? .985 : .997), dur = s.buf.duration;
  if (!this.claim(t, dur, opts.prio)) return;
  var src = ctx.createBufferSource(); src.buffer = s.buf;
  var r = src.playbackRate; r.setValueAtTime(opts.slide ? s.rate * .891 : s.rate, t);
  if (opts.slide) r.exponentialRampToValueAtTime(s.rate, t + .18);           // 上滑（「上」）
  if (opts.vib){ r.setValueAtTime(s.rate, t + .5); r.linearRampToValueAtTime(s.rate * 1.012, t + .8); r.linearRampToValueAtTime(s.rate * .994, t + 1.15); r.linearRampToValueAtTime(s.rate, t + 1.5); } // 吟
  var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = opts.bright || 2400; lp.Q.value = .4;
  var body = ctx.createBiquadFilter(); body.type = 'peaking'; body.frequency.value = 220; body.gain.value = 4; body.Q.value = 1;
  var g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.setTargetAtTime(0.0001, t + dur * .55, dur * .18);
  var pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
  src.connect(lp); lp.connect(body); body.connect(g);
  var out = g; if (pan){ pan.pan.value = opts.pan || 0; g.connect(pan); out = pan; }
  out.connect(opts.bus || this.music); var sg = ctx.createGain(); sg.gain.value = opts.wet == null ? .35 : opts.wet; out.connect(sg); sg.connect(this.send);
  src.start(t); src.stop(t + dur);
};
// 正弦叠加（泛音、风铃、钟、磬共用）：partials = [[倍频, 振幅, 衰减秒], ...]
EP.partials = function(t, f, vol, partials, opts){
  opts = opts || {}; var ctx = this.ctx, longest = 0, i;
  for (i = 0; i < partials.length; i++) longest = Math.max(longest, partials[i][2]);
  if (!this.claim(t, longest * 1.2, opts.prio)) return;
  var g = ctx.createGain(); g.gain.value = vol;
  var pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null, out = g;
  if (pan){ pan.pan.value = opts.pan || 0; g.connect(pan); out = pan; }
  out.connect(opts.bus || this.amb); var sg = ctx.createGain(); sg.gain.value = opts.wet == null ? .5 : opts.wet; out.connect(sg); sg.connect(this.send);
  for (i = 0; i < partials.length; i++){
    var p = partials[i], o = ctx.createOscillator(), e = ctx.createGain();
    o.type = 'sine'; o.frequency.value = f * p[0]; if (opts.detune) o.detune.value = rnd(-opts.detune, opts.detune);
    var atk = opts.attack || .004;
    e.gain.setValueAtTime(0, t); e.gain.linearRampToValueAtTime(p[1], t + atk); e.gain.setTargetAtTime(0, t + atk, p[2] / 4.5);
    o.connect(e); e.connect(g); o.start(t); o.stop(t + p[2] * 1.2 + atk);
  }
};
EP.noiseHit = function(t, vol, freq, q, dur, opts){
  opts = opts || {}; var ctx = this.ctx;
  if (!this.claim(t, dur + .05, opts.prio)) return;
  var src = ctx.createBufferSource(); src.buffer = this.noise; src.loop = true;
  var bp = ctx.createBiquadFilter(); bp.type = opts.type || 'bandpass'; bp.frequency.value = freq; bp.Q.value = q;
  var g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + (opts.attack || .002)); g.gain.setTargetAtTime(0, t + (opts.attack || .002), dur / 4);
  src.connect(bp); bp.connect(g); g.connect(opts.bus || this.amb);
  if (opts.wet){ var sg = ctx.createGain(); sg.gain.value = opts.wet; g.connect(sg); sg.connect(this.send); }
  src.start(t, Math.random() * 2); src.stop(t + dur + .05);
};
EP.sweep = function(t, f0, f1, dur, vol, opts){ // 鸟鸣、水滴等短促滑音
  opts = opts || {}; var ctx = this.ctx;
  if (!this.claim(t, dur + .05, opts.prio)) return;
  var o = ctx.createOscillator(), g = ctx.createGain(); o.type = opts.wave || 'sine';
  o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + (opts.attack || .005)); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
  var out = g, pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null; if (pan){ pan.pan.value = opts.pan || 0; g.connect(pan); out = pan; }
  o.connect(g); out.connect(opts.bus || this.amb);
  if (opts.wet){ var sg = ctx.createGain(); sg.gain.value = opts.wet; out.connect(sg); sg.connect(this.send); }
  o.start(t); o.stop(t + dur + .02);
};

/* ---------- 乐器 ---------- */
EP.bell = function(t, big, bus, prio){ // 庭院钟（big）/ 门铃轻响
  if (big) this.partials(t, rnd(98, 104), .22, [[.5,.5,9],[1,1,8],[1.19,.5,6],[1.56,.45,5],[2,.4,4.5],[2.74,.25,3],[3,.18,2.6],[4.07,.1,1.8]], {bus: bus, wet: .7, detune: 4, prio: prio});
  else this.partials(t, rnd(510, 530), .1, [[1,1,5],[2.71,.35,2.6],[5.15,.15,1.2]], {bus: bus, wet: .6, detune: 3, attack: .006, prio: prio});
  if (big) this.noiseHit(t, .05, 400, .8, .25, {bus: bus, type: 'lowpass', wet: .3, prio: prio});
};
EP.bowl = function(t, bus, prio){ // 兼容旧键：轻柔泛音（古琴Harmonics）
  this.partials(t, rnd(440, 520), .05, [[1,1,3],[2,.2,1.4]], {bus: bus, wet: .5, detune: 4, attack: .01, prio: prio});
};
EP.muyu = function(t, vol, bus, prio){ // 兼容旧键：改奏风铃
  this.chimes(t, 3, bus, prio);
};
EP.clapper = function(t, bus){ // 梆子 / 拍板，集市节奏
  this.sweep(t, 1250, 1050, .07, .09, {bus: bus || this.music, wet: .15, attack: .001});
  this.noiseHit(t, .05, 2600, 4, .02, {bus: bus || this.music});
};
EP.chimes = function(t, n, bus, prio){
  n = n || ((Math.random() * 4 | 0) + 2);
  var base = [12, 13, 14, 15, 16, 17];
  for (var i = 0; i < n; i++){
    var tt = t + i * rnd(.08, .32);
    this.partials(tt, degFreq(pick(base)), rnd(.025, .05), [[1,1,2.4],[2.76,.3,1],[5.4,.1,.5]], {bus: bus, pan: rnd(-.6, .6), wet: .7, prio: prio});
  }
};
EP.bird = function(t){
  var kind = Math.random(), pan = rnd(-.8, .8), n, i, tt = t;
  if (kind < .5){ n = 2 + (Math.random() * 4 | 0); var f = rnd(2600, 3600);
    for (i = 0; i < n; i++){ this.sweep(tt, f, f * rnd(1.25, 1.5), rnd(.05, .09), .03, {pan: pan, wet: .3}); tt += rnd(.09, .16); } }
  else if (kind < .8){ var f2 = rnd(3200, 4200); this.sweep(tt, f2, f2 * .6, .22, .028, {pan: pan, wet: .35}); this.sweep(tt + .26, f2 * .8, f2 * 1.1, .12, .022, {pan: pan, wet: .35}); }
  else { for (i = 0; i < 6; i++){ this.sweep(tt, 4200, 3000, .035, .018, {pan: pan, wet: .3}); tt += .05; } } // 啁啾
};
EP.drop = function(t, vol){ var f = rnd(700, 1500); this.sweep(t, f, f * rnd(1.6, 2.4), rnd(.04, .08), vol || .05, {pan: rnd(-.7, .7), wet: .45}); };
EP.frog = function(t){
  var ctx = this.ctx; if (!this.claim(t, .5)) return;
  for (var k = 0; k < 2; k++){
    var tt = t + k * .28, o = ctx.createOscillator(), am = ctx.createOscillator(), amg = ctx.createGain(), bp = ctx.createBiquadFilter(), g = ctx.createGain();
    o.type = 'sawtooth'; o.frequency.setValueAtTime(rnd(110, 140), tt); am.frequency.value = 28; amg.gain.value = .5;
    bp.type = 'bandpass'; bp.frequency.value = 600; bp.Q.value = 3;
    g.gain.setValueAtTime(0, tt); g.gain.linearRampToValueAtTime(.05, tt + .02); g.gain.linearRampToValueAtTime(0, tt + .18);
    am.connect(amg); amg.connect(g.gain); o.connect(bp); bp.connect(g); g.connect(this.amb);
    o.start(tt); am.start(tt); o.stop(tt + .2); am.stop(tt + .2);
  }
};

/* ---------- 持续底噪层：风、流水、水面、人声嘈杂、低音持续音 ---------- */
EP.bed = function(name){
  var b = this.beds[name]; if (b) return b;
  var ctx = this.ctx, t = ctx.currentTime; b = {name: name, gain: ctx.createGain(), nodes: []}; b.gain.gain.value = 0;
  if (name === 'drone'){
    var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 500;
    [[73.42, 1], [110, .6], [146.83, .25], [110.6, .4]].forEach(function(p){ var o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = p[0]; g.gain.value = p[1] * .5; o.connect(g); g.connect(lp); o.start(t); b.nodes.push(o); });
    lp.connect(b.gain); b.gain.connect(this.music);
  } else {
    var src = ctx.createBufferSource(); src.buffer = this.noise; src.loop = true;
    var f = ctx.createBiquadFilter(), f2 = ctx.createBiquadFilter();
    if (name === 'wind'){ f.type = 'bandpass'; f.frequency.value = 500; f.Q.value = 1.4; f2.type = 'lowpass'; f2.frequency.value = 1400; }
    else if (name === 'stream'){ f.type = 'highpass'; f.frequency.value = 250; f2.type = 'lowpass'; f2.frequency.value = 2200; }
    else if (name === 'water'){ f.type = 'bandpass'; f.frequency.value = 900; f.Q.value = .8; f2.type = 'peaking'; f2.frequency.value = 2400; f2.gain.value = 5; }
    else { f.type = 'bandpass'; f.frequency.value = 650; f.Q.value = 1.2; f2.type = 'lowpass'; f2.frequency.value = 1500; } // murmur
    b.filter = f; b.mod = ctx.createGain(); b.mod.gain.value = 1;
    src.connect(f); f.connect(f2); f2.connect(b.mod); b.mod.connect(b.gain); b.gain.connect(this.amb);
    if (name !== 'murmur'){ var sg = ctx.createGain(); sg.gain.value = .25; b.gain.connect(sg); sg.connect(this.send); }
    src.start(t, Math.random() * 2); b.nodes.push(src);
  }
  this.beds[name] = b; return b;
};
EP.setBeds = function(mood, t, tc){
  var names = ['wind', 'water', 'stream', 'murmur', 'drone'], E = this;
  names.forEach(function(n){
    var v = mood.bed[n] || 0, b = E.beds[n];
    if (!b && v <= 0) return;
    b = E.bed(n); b.target = v;
    b.gain.gain.cancelScheduledValues(t); b.gain.gain.setValueAtTime(b.gain.gain.value, t); b.gain.gain.setTargetAtTime(v, t, tc);
  });
};
EP.releaseIdleBeds = function(){ // 目标为 0 且已经淡出的层停掉，节省 CPU
  for (var n in this.beds){ var b = this.beds[n];
    if (b.target === 0 && b.gain.gain.value < .0008){ b.nodes.forEach(function(x){ try { x.stop(); } catch (e) {} }); try { b.gain.disconnect(); } catch (e) {} delete this.beds[n]; } }
};
EP.modulateBeds = function(t){ // 慢速随机起伏（每次调度时调一次，开销极小）
  for (var n in this.beds){ var b = this.beds[n]; if (!b.mod) continue;
    if (n === 'wind'){ b.filter.frequency.setTargetAtTime(rnd(320, 900), t, 1.5); b.mod.gain.setTargetAtTime(rnd(.4, 1.3), t, 1.2); }
    else if (n === 'water'){ b.filter.frequency.setTargetAtTime(rnd(650, 1300), t, .4); b.mod.gain.setTargetAtTime(rnd(.6, 1.2), t, .3); }
    else if (n === 'murmur'){ b.mod.gain.setTargetAtTime(rnd(.5, 1.4), t, .25); b.filter.frequency.setTargetAtTime(rnd(450, 900), t, .3); }
    else if (n === 'stream'){ b.mod.gain.setTargetAtTime(rnd(.8, 1.1), t, .8); }
  }
};

/* ---------- 场景切换 ---------- */
EP.setScene = function(id, instant){
  var t = this.ctx.currentTime, m = MOODS[id] || MOODS.plaza, tc = instant ? .05 : XFADE;
  this.scene = id; this.mood = m;
  this.setBeds(m, t, tc);
  var g = this.music.gain; g.cancelScheduledValues(t); g.setValueAtTime(g.value, t);
  if (!instant){ g.setTargetAtTime(m.music * .35, t, .4); g.setTargetAtTime(m.music, t + 1.2, XFADE); } else g.setValueAtTime(m.music, t);
  // 重新安排各事件的下一次时间（错开，不会同时响）
  var start = t + (instant ? .2 : 1.4);
  for (var k in m.rate) this.next[k] = m.rate[k] ? start + rnd(.3, 1) * Math.min(m.rate[k], 6) : Infinity;
  if (id === 'gate') this.next.chime = start + .4;                 // 进里门先响一阵风铃
  this.melT = Math.max(this.melT, start); this.phrase = 0;
};

/* ---------- 旋律：五声音阶随机游走 + 乐句停顿 ---------- */
EP.melody = function(until){
  var m = this.mood.mel, beat = 60 / m.bpm;
  while (this.melT < until){
    var t = this.melT, step = beat * pick(m.fast ? [.5, .5, 1, 1, 1.5] : [1, 1, 1, 2, 2, 3]);
    this.phrase++;
    if (this.phrase > (m.fast ? 14 : 8) && Math.random() < .35){ this.phrase = 0; this.melT += beat * (m.fast ? 2 : rnd(3, 6)); continue; } // 乐句间留白
    if (Math.random() < m.p){
      var mv = pick([-2, -1, -1, 0, 1, 1, 2, 3, -3]); this.melDeg = Math.min(m.hi, Math.max(m.lo, this.melDeg + mv));
      var f = degFreq(this.melDeg), vol = rnd(.28, .42), pan = rnd(-.3, .3);
      if (Math.random() < m.harm) this.partials(t, f * 2, .06, [[1, 1, 2.6], [2, .25, 1.4]], {bus: this.music, wet: .6, pan: pan}); // 泛音
      else this.pluck(t, f, vol, {short: !!m.fast, slide: !m.fast && Math.random() < .2, vib: !m.fast && step >= beat * 2 && Math.random() < .6, pan: pan, bright: m.fast ? 3200 : 2200});
      if (!m.fast && Math.random() < .12) this.pluck(t + .01, degFreq(this.melDeg - 5), vol * .6, {pan: -pan}); // 八度和音
    }
    this.melT += step;
  }
};

/* ---------- 调度：每 TICK_MS 安排未来 LOOKAHEAD 秒内的事件 ---------- */
EP.schedule = function(until){
  var t0 = this.ctx.currentTime, m = this.mood, r = m.rate, k;
  if (this.melT < t0 - .2) this.melT = t0 + .05;
  for (k in this.next) if (this.next[k] < t0 - .2) this.next[k] = t0 + .05 + Math.random() * (r[k] || 1);
  this.melody(until);
  while (this.next.bell < until){ var tb = this.next.bell; if (m.bowl && Math.random() < .6) this.bowl(tb); else this.bell(tb, this.scene === 'gate'); this.next.bell = tb + r.bell * rnd(.75, 1.3); }
  while (this.next.chime < until){ var tc = this.next.chime; this.chimes(tc); this.next.chime = tc + expo(r.chime) + 2; }
  while (this.next.bird < until){ var tbd = this.next.bird; this.bird(tbd); this.next.bird = tbd + expo(r.bird) + .6; }
  while (this.next.drop < until){ var td = this.next.drop; this.drop(td); this.next.drop = td + expo(r.drop) + .08; }
  while (this.next.frog < until){ var tf = this.next.frog; this.frog(tf); this.next.frog = tf + expo(r.frog) + 2; }
  while (this.next.clap < until){ // 集市：一小串「梆梆—梆」
    var tcl = this.next.clap, bt = 60 / m.mel.bpm / 2; this.clapper(tcl); this.clapper(tcl + bt); this.clapper(tcl + bt * 3);
    this.next.clap = tcl + r.clap * rnd(.7, 1.4);
  }
  while (this.next.muyu < until){ // 兼容旧键：若场景仍配置 rate.muyu，改奏风铃
    var tm = this.next.muyu; this.chimes(tm, 3);
    this.sceneMuyuT++; this.next.muyu = tm + r.muyu * rnd(.97, 1.03);
    if (this.sceneMuyuT % 16 === 0) this.next.muyu += rnd(6, 12);
  }
  if (!this.offline) this.modulateBeds(t0);
};

/* ---------- 音效 ---------- */
var SFX = {
  click:   function(E, t){ E.sweep(t, 1900, 900, .035, .3, {bus: E.sfx, attack: .001, prio: 1}); E.noiseHit(t, .12, 3000, 2, .02, {bus: E.sfx, prio: 1}); },
  coin:    function(E, t){ E.partials(t, 1568, .16, [[1,1,.6],[2.76,.4,.35],[4.1,.2,.2]], {bus: E.sfx, wet: .3, prio: 1}); E.partials(t + .08, 2093, .14, [[1,1,.7],[2.76,.4,.35]], {bus: E.sfx, wet: .3, prio: 1}); },
  water:   function(E, t){ E.noiseHit(t, .2, 1800, .7, .35, {bus: E.sfx, wet: .2, prio: 1, attack: .02}); for (var i = 0; i < 4; i++){ var f = rnd(800, 1600); E.sweep(t + .05 + i * rnd(.05, .1), f, f * 2, .06, .16, {bus: E.sfx, wet: .3, prio: 1}); } },
  plant:   function(E, t){ E.sweep(t, 160, 70, .16, .18, {bus: E.sfx, prio: 1}); E.noiseHit(t, .05, 500, 1, .08, {bus: E.sfx, prio: 1}); E.pluck(t + .07, degFreq(8), .3, {bus: E.sfx, short: true, prio: 1}); },
  harvest: function(E, t){ [5, 6, 7, 8, 10].forEach(function(d, i){ E.pluck(t + i * .07, degFreq(d), .3, {bus: E.sfx, short: true, prio: 1, wet: .3}); }); E.chimes(t + .35, 3, E.sfx, 1); },
  incense: function(E, t){ E.chimes(t, 3, E.sfx, 1); },
  bell:    function(E, t){ E.bell(t, true, E.sfx, 1); },
  muyu:    function(E, t){ E.muyu(t, .3, E.sfx, 1); },
  offer:   function(E, t){ E.pluck(t, degFreq(5), .3, {bus: E.sfx, prio: 1}); E.pluck(t + .12, degFreq(7), .3, {bus: E.sfx, prio: 1}); E.chimes(t + .2, 3, E.sfx, 1); },
  chime:   function(E, t){ E.chimes(t, 4, E.sfx, 1); },
  qian:    function(E, t){ for (var i = 0; i < 9; i++) E.noiseHit(t + i * rnd(.04, .07), .5, rnd(1800, 3200), 5, .03, {bus: E.sfx, prio: 1}); }, // 摇筒轻响
  result:  function(E, t){ [5, 7, 10].forEach(function(d, i){ E.pluck(t + i * .05, degFreq(d), .28, {bus: E.sfx, prio: 1}); }); },
  unlock:  function(E, t){ [5, 6, 7, 8, 10, 12].forEach(function(d, i){ E.pluck(t + i * .08, degFreq(d), .3, {bus: E.sfx, prio: 1}); }); E.bell(t + .5, false, E.sfx, 1); E.chimes(t + .5, 4, E.sfx, 1); },
  error:   function(E, t){ E.pluck(t, degFreq(4), .25, {bus: E.sfx, short: true, prio: 1}); E.pluck(t + .12, degFreq(2), .25, {bus: E.sfx, short: true, prio: 1}); },
  pop:     function(E, t){ E.sweep(t, 500, 1200, .06, .25, {bus: E.sfx, prio: 1}); }
};
var SFX_ALIAS = {'浇水': 'water', '金币': 'coin', '收获': 'harvest', '点灯': 'incense', '上香': 'incense', '钟': 'bell', '风铃': 'chime', '摇风铃': 'muyu', '木鱼': 'muyu', '种植': 'plant', '播种': 'plant', '点击': 'click', sell: 'coin', buy: 'coin', tap: 'click', knock: 'muyu', gong: 'bell', seed: 'plant'};

/* =========================================================
   全局控制器
   ========================================================= */
var S = {ctx: null, eng: null, on: readPref(), scene: 'plaza', rawScene: null, timer: 0, unlocked: false, suspendTimer: 0, volume: 1, errors: []};
function warn(where, e){ S.errors.push(where + ': ' + (e && e.message || e)); try { console.warn('[audio] ' + where, e); } catch (_) {} }

function running(){ return !!(S.ctx && S.ctx.state === 'running'); }
function hidden(){ return typeof document !== 'undefined' && document.hidden; }
function targetVol(){ return MASTER_VOL * S.volume; }

function startTimer(){
  if (S.timer || !S.eng) return;
  var tick = function(){ try { if (running()) S.eng.schedule(S.ctx.currentTime + LOOKAHEAD); if (S.eng) S.eng.releaseIdleBeds(); } catch (e) { warn('tick', e); } };
  tick(); S.timer = setInterval(tick, TICK_MS);
}
function stopTimer(){ if (S.timer){ clearInterval(S.timer); S.timer = 0; } }

function fadeIn(){
  if (!S.eng) return; var t = S.ctx.currentTime, g = S.eng.master.gain;
  clearTimeout(S.suspendTimer);
  g.cancelScheduledValues(t); g.setValueAtTime(g.value, t); g.setTargetAtTime(targetVol(), t, .5);
}
function fadeOutAndSuspend(){
  if (!S.eng) return; var t = S.ctx.currentTime, g = S.eng.master.gain;
  g.cancelScheduledValues(t); g.setValueAtTime(g.value, t); g.setTargetAtTime(0, t, .12);
  clearTimeout(S.suspendTimer);
  S.suspendTimer = setTimeout(function(){ if ((!S.on || hidden()) && S.ctx && S.ctx.state === 'running'){ stopTimer(); S.ctx.suspend().catch(function(){}); } }, 700);
}
function resumeIfWanted(){
  if (!S.ctx || !S.on || hidden()) return;
  var p = S.ctx.state === 'running' ? null : S.ctx.resume();
  var go = function(){ fadeIn(); startTimer(); };
  if (p && p.then) p.then(go, function(){}); else go();
}

function unlock(){
  if (!AC) return false;
  try {
    if (!S.ctx) S.ctx = new AC({latencyHint: 'playback'});
    ensureEngine();                                   // 已在空闲时预热过则为空操作
    // iOS Safari：必须在用户手势里 resume，并播放一个静音 buffer
    if (S.ctx.state !== 'running') S.ctx.resume().catch(function(){});
    var b = S.ctx.createBuffer(1, 1, S.ctx.sampleRate), src = S.ctx.createBufferSource();
    src.buffer = b; src.connect(S.ctx.destination); src.start(0);
    S.unlocked = true;
    if (S.on && !hidden()){ fadeIn(); startTimer(); } else { S.eng.master.gain.value = 0; if (!S.on) fadeOutAndSuspend(); }
    return true;
  } catch (e) { warn('unlock', e); return false; }
}
/* ---------- 空闲预热：首个手势前，在浏览器空闲时先建好 AudioContext（suspended、静音）和引擎（混响 IR / 噪声 buffer），
   手势里只剩 resume + 静音 buffer，避免第一次点菜单卡 ~110 ms。声音偏好为关、页面隐藏、或不支持 WebAudio 时不预热。 */
function ensureEngine(){ if (S.ctx && !S.eng){ S.eng = new Engine(S.ctx, false); S.eng.setScene(S.scene, true); } return S.eng; }
var warmed = false;
function warmup(){
  if (warmed || !AC || S.eng || !S.on || hidden()) return; warmed = true;
  var idle = G.requestIdleCallback ? function(f){ G.requestIdleCallback(f, {timeout: 3000}); } : function(f){ setTimeout(f, 30); };
  idle(function(){
    if (S.eng) return;
    try { if (!S.ctx) S.ctx = new AC({latencyHint: 'playback'}); } catch (e) { warn('warmup ctx', e); return; }
    idle(function(){ try { ensureEngine(); } catch (e) { warn('warmup engine', e); } });  // 分两次空闲回调，单次不超过 ~65 ms
  });
}
function setOn(on){
  S.on = !!on; writePref(S.on);
  if (!S.ctx){ if (S.on) unlock(); }
  else if (S.on) resumeIfWanted(); else fadeOutAndSuspend();
  syncButtons();
  try { G.dispatchEvent(new CustomEvent('tg-audio', {detail: {on: S.on}})); } catch (e) {}
  return S.on;
}
function toggle(){ return setOn(!S.on); }
function setScene(id){
  S.rawScene = id; var n = normScene(id);
  if (n === S.scene && S.eng && S.eng.scene === n) return n;
  S.scene = n; if (S.eng) try { S.eng.setScene(n, !running()); } catch (e) { warn('setScene', e); }
  return n;
}
function playSfx(name){
  var key = SFX[name] ? name : SFX_ALIAS[name];
  if (!key) key = 'click';
  if (!S.on) return false;
  if (!S.ctx || S.ctx.state !== 'running'){ unlock(); if (!running()) { if (S.ctx && S.ctx.state === 'suspended' && !hidden()) S.ctx.resume().then(function(){ try { SFX[key](S.eng, S.ctx.currentTime + .02); } catch (e) {} }, function(){}); return false; } }
  try { SFX[key](S.eng, S.ctx.currentTime + .01); return true; } catch (e) { warn('sfx ' + key, e); return false; }
}
function setVolume(v){ S.volume = Math.max(0, Math.min(1.5, +v || 0)); if (S.on && running()) fadeIn(); return S.volume; }

/* ---------- 可选：绑定一个开关按钮（不自动绑定，避免与 enhance.js 的 #btnMute 冲突） ---------- */
var BUTTONS = [];
function syncButtons(){ BUTTONS.forEach(function(b){ try { b.el.textContent = S.on ? b.onText : b.offText; b.el.setAttribute('aria-pressed', String(!S.on)); } catch (e) {} }); }
function bindButton(el, onText, offText){
  if (typeof el === 'string') el = document.querySelector(el); if (!el) return false;
  BUTTONS.push({el: el, onText: onText || '♫', offText: offText || '静'});
  el.addEventListener('click', function(ev){ unlock(); toggle(); }); syncButtons(); return true;
}

/* ---------- 首次手势自动 unlock（一次性） ---------- */
if (typeof document !== 'undefined'){
  var EVTS = ['pointerdown', 'touchend', 'mousedown', 'keydown', 'click'];
  var onGesture = function(){ unlock(); if (running() || (S.ctx && !S.on)) EVTS.forEach(function(e){ document.removeEventListener(e, onGesture, true); }); };
  EVTS.forEach(function(e){ document.addEventListener(e, onGesture, {capture: true, passive: true}); });
  document.addEventListener('visibilitychange', function(){ if (!S.ctx) return; if (document.hidden) fadeOutAndSuspend(); else resumeIfWanted(); });
  G.addEventListener && G.addEventListener('pagehide', function(){ if (S.ctx) fadeOutAndSuspend(); });
}

/* ---------- 可选：跟随场景（包装 worldEnter；再用 hash / W3.active 轮询兜底） ---------- */
function hookWorldEnter(){
  var f = G.worldEnter;
  if (typeof f !== 'function' || f.__tgAudio) return typeof f === 'function';
  var nf = function(name){ var r = f.apply(this, arguments); try { setScene(name); } catch (e) {} return r; };
  nf.__tgAudio = true; nf.__tgAudioOrig = f;
  try { G.worldEnter = nf; } catch (e) { return false; }
  return true;
}
function currentGameScene(){
  try { if (typeof W3 !== 'undefined' && W3 && W3.active) return W3.active; } catch (e) {}  // W3 是 world3d.js 的全局 var
  try { var h = (location.hash || '').slice(1); if (h && (MOODS[h] || ALIAS[h])) return h; } catch (e) {}
  return null;
}
hookWorldEnter();
if (typeof document !== 'undefined'){
  var later = function(){ hookWorldEnter(); var s = currentGameScene(); if (s) setScene(s); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', later); else setTimeout(later, 0);
  G.addEventListener && G.addEventListener('load', later);
  G.addEventListener && G.addEventListener('load', function(){ setTimeout(warmup, 1500); });
  if (document.readyState === 'complete') setTimeout(warmup, 1500);
  G.addEventListener && G.addEventListener('hashchange', function(){ var s = currentGameScene(); if (s) setScene(s); });
  setInterval(function(){ if (!S.ctx || !S.on || hidden()) return; hookWorldEnter(); var s = currentGameScene(); if (s && normScene(s) !== S.scene) setScene(s); }, 2000); // 兜底：极轻量
}

/* ---------- 离线渲染（测试 / 导出试听样例用） ---------- */
function renderOffline(id, seconds, sampleRate){
  var OAC = G.OfflineAudioContext || G.webkitOfflineAudioContext; if (!OAC) return Promise.reject(new Error('no OfflineAudioContext'));
  seconds = seconds || 8; sampleRate = sampleRate || 44100;
  var ctx = new OAC(2, Math.ceil(seconds * sampleRate), sampleRate), E = new Engine(ctx, true);
  E.master.gain.value = MASTER_VOL; E.setScene(normScene(id), true);
  // 离线时一次性按块调度到结尾（底噪起伏也按块预排）
  for (var t = 0; t < seconds; t += .5){ E.schedule(Math.min(seconds, t + .5)); E.modulateBeds(t); }
  return ctx.startRendering();
}
function renderSfxOffline(name, seconds){
  var OAC = G.OfflineAudioContext || G.webkitOfflineAudioContext; seconds = seconds || 2.5;
  var ctx = new OAC(2, Math.ceil(seconds * 44100), 44100), E = new Engine(ctx, true); E.master.gain.value = MASTER_VOL;
  SFX[SFX[name] ? name : (SFX_ALIAS[name] || 'click')](E, .05); return ctx.startRendering();
}

G.TG_AUDIO = {
  __v: VERSION,
  unlock: unlock,
  toggle: toggle,
  setScene: setScene,
  playSfx: playSfx,
  isOn: function(){ return S.on; },
  // 额外（可选）
  setOn: setOn,
  setVolume: setVolume,
  getScene: function(){ return S.scene; },
  isRunning: running,
  bindButton: bindButton,
  scenes: Object.keys(MOODS),
  sfx: Object.keys(SFX),
  renderOffline: renderOffline,
  renderSfxOffline: renderSfxOffline,
  warmup: warmup,
  _state: S
};
})();
