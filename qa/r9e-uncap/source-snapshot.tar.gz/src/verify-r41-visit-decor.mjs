import {chromium} from '/workspace/temple-garden/node_modules/playwright-core/index.mjs';
import http from 'node:http';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const out='/tmp/codex-v4-r41',shots='/workspace/temple-garden/v4/shots';
fs.mkdirSync(out,{recursive:true});
const server=http.createServer((q,r)=>{r.setHeader('Content-Type','text/html; charset=utf-8');r.end(fs.readFileSync(new URL('../index.html',import.meta.url)));});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:390,height:844},hasTouch:true});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
async function check(label,fn){assert.ok(await page.evaluate(fn),label);console.log('PASS '+label);}
try{
 await page.goto(`http://127.0.0.1:${server.address().port}`);
 await page.waitForFunction(()=>window.W3?.player&&window.TG_CATALOG?.some(v=>v.id==='rocking-chair'));
 await check('new save has 50 coins and starter backpack',()=>S.coins===50&&S.backpack.cushion===1&&S.backpack.vase===1);
 await page.evaluate(async()=>{await go('yard',true);r3SnapshotOwnSpace();window.__own=JSON.stringify({decor:S.decor,backpack:S.backpack});window.__meshNear=(x,z)=>{const g=W3.spaces.yard.decorGroup;if(!g?.visible||!W3.spaces.yard.group.visible)return false;let found=false;g.traverse(m=>{if(!m.isMesh)return;const box=new THREE.Box3().setFromObject(m);if(box.min.x<=x+.3&&box.max.x>=x-.3&&box.min.z<=z+.3&&box.max.z>=z-.3)found=true;});return found;};});
 await page.evaluate(()=>{
  TG_VISIT={ownerId:'owner',name:'测试主人',canEdit:false,steal:true};
  S.decor.yard=[{id:'bench',x:0,z:0,rot:0,r4Migrated:true},{id:'bench',x:'3',z:'2'},{id:'unknown',x:2,z:2,rot:0}];
  S.animals=[{id:'hen',kind:'chicken'},{id:'dog',kind:'dog',pen:null},{id:'free-hen',kind:'chicken',pen:null}];
  TG_RERENDER();
 });
 await check('mid-yard showcase survives rerender and normalizes',()=>W3.active==='yard'&&S.decor.yard.length===2&&S.decor.yard[0].x===0&&S.decor.yard[0].r4Migrated&&S.decor.yard[1].rot===0&&S.decor.yard[1].x===3);
 await check('both owner benches have visible yard meshes',()=>W3.spaces.yard.decorGroup.children.length>0&&__meshNear(0,0)&&__meshNear(3,2));
 // Compare objects as serialized values, preserving starter items even when unplaced.
 await check('own backpack preserved',()=>JSON.stringify(S.backpack)===JSON.stringify(JSON.parse(__own).backpack));
 await check('animal defaults and explicit null pens',()=>S.animals[0].pen===0&&S.animals.every(a=>'pen' in a)&&S.animals[1].pen===null&&S.animals[2].pen===null);
 await page.waitForTimeout(200);
 await page.screenshot({path:out+'/visit-yard-decor.png'});
 if(fs.existsSync(shots))fs.copyFileSync(out+'/visit-yard-decor.png',shots+'/r4.1-phone-visit-yard-decor.png');
 await page.evaluate(()=>applyRemotePlayers([{id:'sitter',name:'坐客',scene:'yard',pos:{x:0,y:0,z:0},anim:'sit'}]));
 await page.waitForTimeout(100);
 await check('remote sitter and bench occupy same position',()=>{const r=W3.remotes.get('sitter');return r?.mesh.visible&&Math.abs(r.mesh.position.x)<.01&&Math.abs(r.mesh.position.z)<.01&&r.mesh.children[0].position.y===-.28&&__meshNear(0,0);});
 await page.screenshot({path:out+'/visit-remote-sit.png'});
 if(fs.existsSync(shots))fs.copyFileSync(out+'/visit-remote-sit.png',shots+'/r4.1-phone-visit-remote-sit.png');
 await page.evaluate(()=>{delete window.TG_VISIT;TG_RERENDER();});
 await check('leave restores own decor and starter backpack',()=>JSON.stringify(S.decor)===JSON.stringify(JSON.parse(__own).decor)&&JSON.stringify(S.backpack)===JSON.stringify(JSON.parse(__own).backpack)&&!S.decor.yard.some(v=>v.id==='bench'&&v.x===0&&v.z===0));
 await page.evaluate(()=>{TG_VISIT={ownerId:'family',canEdit:true};S.decor.yard=[{id:'bench',x:0,z:0,r4Migrated:true}];r3SnapshotOwnSpace();r3ApplyVisitingUI();});
 await check('family visit onset syncs without snapshot or migration',()=>S.decor.yard[0].r4Migrated&&__meshNear(0,0));
 await page.evaluate(()=>{delete window.TG_VISIT;r3ApplyVisitingUI();});
 await check('family leave restores own decor',()=>JSON.stringify(S.decor)===JSON.stringify(JSON.parse(__own).decor));
 await check('load normalization preserves safe fields and rocking chair',()=>{const d=defaultState();d.decor={yard:[{id:'rocking-chair',x:'4',z:'2'},{id:'lantern',x:2,z:3,on:true},{id:'bogus',x:0,z:0}],hall:[],zen:[],study:[]};sanitizeR3(d);return d.decor.yard.length===2&&d.decor.yard[0].rot===0&&d.decor.yard[1].on===true;});
 assert.deepEqual(errors,[]);console.log('PASS no runtime errors');
}catch(e){console.error('FAIL',e);process.exitCode=1;}finally{await browser.close();server.close();}
