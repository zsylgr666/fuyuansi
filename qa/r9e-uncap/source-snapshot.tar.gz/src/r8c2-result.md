# r8c.2 — 缘堂 restoration + remote-player plate + raw user text (built on r8c1 de2ce127, isolated src qa/r8c2/src)

Frozen: v4/index.r8c2.html  sha256 d401b494aafc2fc41482ddc1278f3fcb64743713179ebfc205631a5810842924  1,764,848 B
Patches: v4/r8c2.patch (31,179 B, diff vs index.r8c1.html), v4/r8c2-src.patch (33,950 B, qa/r8d-base-src → qa/r8c2/src)
Frozen builds unchanged (r8c1 de2ce127…, r8c a97278fe…, r8b, r8a, r8a1, r8a2).

## Hall (缘堂)
Cause: r7.js build() removed every v13 hall object; r7.js worldSyncHall hid art3 「古朴木作」 (朱漆柱/雕花窗棂/额枋/宫灯/红毯); r7c rebuilt a bare room.
Fix: r7.js stashes the removed objects (h.r7Legacy); r8c2.js re-adds them (wood floor, floor strips, 4 vermilion pillars + colliders,
lanterns, couplet boards, shelves + vases, carpet, beams, door frames + titles, 3 point lights), un-hides art3 wood style.
Not restored (owned by r7c/r8c or devotional): legacy ceiling (r8c.1 brightened ceiling kept), r3 perimeter walls (r7c/r8c walls + colliders kept),
duplicate altar table, ancestral-tablet boards/bases/text, 木鱼 + mallet, 3.3 m lotus door frame (wider than the r8c 1 m north opening).
Text only (no deletions for compliance): plaque 家和业兴 (raised/enlarged, no longer hidden by the paintings), couplets 花香满院 / 竹影临窗,
door titles = current scene names; incense burner → bronze flower planter; 木鱼 table → vase; 3 paintings are procedural canvas art (青绿山水 / 梅花 暗香疏影 / 荷花).
Clip fixes: merged parts edited per part; NE art3 pillar 5.9→5.62 (out of wall); 摇风铃 moved to (-3.05,-1.15) (was inside restored pillar);
vase stems start at the mouth; lantern cords end at lantern top; back table 4.4 m (clear of door post); couplets moved out of the north opening.
Entry view: from yard/cold load the player stands at (0,1.6) facing north, yaw 0 / pitch .15 / r 6 → altar + plaque + paintings in view (portrait & landscape).

Hall audit (qa/r8c2/audit, same tool, hall only): r8c1 H0 M0 L3 → r8c2 H0 M2 L9 (M: candle flame on candle; camera sample in the corner
lattice at (-5.5,0.75)); walk 53/53 ok, 0 stuck; cam inside 1 near 1. All-scenes quick audit: other scenes identical to r8c1.
Draw calls (freeze smoke): hall 43 portrait / 50 landscape; max of all scenes 79; 0 page errors; banned-word grep 38 = r8c1.

## Remote players (enhance.js:20 cloned the local player → my plate on friends)
r8c2b.js pre-creates each remote with TG_AVATAR.build(cfg,{plate:true}) (shared avatar geometry cache + material + plate-texture cache),
cfg from p.avatar (missing → TG_AVATAR.randomConfig(hash(id)), stable per id), name p.name, title p.title (plate draws title banner + name,
same as the local 【title】name), dispose on leave (TG_AVATAR.dispose). Walk/idle via TG_AVATAR.animate; ride/sit poses.
Test (simulated remotes, qa/r8c2/remote.mjs): r8c1 = 4 remotes each showing 「祠堂阿福」 (MY plate); r8c2 = each its own plate
(祠堂小金币【供奉达人】, 福缘寺扫地僧, 雨下e整夜 (no avatar → default), 功德主老王); dispose 2 on leave; draw calls 53 → 60 (1) → 84 (4).

## Raw user text (r7.js fillText wrapper / clean())
clean() skips [data-raw] and user slots (.tgg-row .n, .r7f-nick, .r7f-text, .tgs-dm); registered raw strings (own nickname, remote names,
tea messages) stay verbatim inside mixed system text; avatar build/update (plates) draw under r7Raw → native fillText. Tea wall and wish cards mark data-raw.
Test: nickname 「祠堂小金币」 toast 「祠堂小金币 来访，送你 5 金币」 → r8c2 「祠堂小金币 来访，送你 5 铜钱」 (r8c1: 「缘堂小铜钱 … 铜钱」);
neighbour row 「功德主老王」 verbatim (r8c1 「福缘主✨老王」); header system text 「邻居菜园 · 金币」 still → 「铜钱」.

Shots: qa/r8c2/shots/compare-{portrait,landscape}.png (v13 | r8c1 | r8c2, views main/wide/altar), individual {vp}-{view}-{tag}.png,
remote-r8c1.png / remote-r8c2.png; entry view dump-r8c2f-{portrait,landscape}.png.
