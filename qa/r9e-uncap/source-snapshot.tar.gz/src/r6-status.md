# r6 build status (for codex2 full-scene audit)

Times are Asia/Shanghai (UTC+8).

## Testable build

| | |
|---|---|
| File | `/workspace/temple-garden/v4/index.html` |
| Packed at | 2026-11-13 02:20:17 |
| Size | 1,262,748 bytes |
| sha256 | `6e641a4d0ca36c381479d29094a8a0595798ce1576b2ca4dc169da6ef3496d73` |
| Baseline | `v4/index.pre-r6.html` sha256 `231370bffa96ddd10f8c007c1404f3d040c125e1e3393dc56397e0b232e8d106` (unchanged) |
| Pack order | `animals2.js`, `audio.js`, `r5.js`, `realism.js`, `avatar.js`, `npc.js`, `teahouse-assets.js`, `mounts.js`, `r6.js` (avatar **before** npc; each file guarded with `existsSync`) |

Playwright (390×844, SwiftShader) loaded `#plaza` after this pack: `TG_AVATAR`, `TG_NPC`, and `TG_MOUNTS` are all defined (`__v: 1`). `TG_AVATAR.setPose` is a function. `TG_AVATAR.build`, `TG_NPC.placeAtStalls` / `update` / `handleTap`, and `TG_MOUNTS.build` / `mount` are present. Six market NPCs were placed. The local player has a `W3.r6Avatar`. No `[TG_AVATAR] THREE 不存在` warning. `TG_REAL` and `TG_TEA` are also defined from the current (still-in-progress) sources.

This pack inlines the current `_src/avatar.js` **verbatim**, including `setPose(rider, 'ride'|'sit'|'idle')` and the split-skirt (`buildSkirt` / 裙摆在独立部件). That source mtime is **02:19:23** (after 02:19). Pack time is 02:20:17, so this is not the early 02:10 / 02:18 build. `mounts.js` calls `setPose` automatically; r6 still also calls it when leading out / dismounting.

## Module versions (source, as packed)

| file | mtime (UTC+8) | size | sha256 |
|---|---|---:|---|
| avatar.js | 2026-11-13 **02:19:23** | 53176 | `aef322dc27dd00bdf2d0b13b23b949f6bb0e222eed4fd2d8a2bcd3153c638fdb` |
| npc.js | 2026-11-13 02:13:51 | 18586 | `395dc182ab2065d762a0dcf6786fe8109b302e783bf2b97f534688c2cc607dd8` |
| mounts.js | 2026-11-13 02:15:22 | 49777 | `f520265341ea43d50ba36ae4b6b27ca54a3b7639c04944a691f503dc9cace5d5` |
| realism.js | 2026-11-13 02:19:58 | 27212 | `6fab45404ff320f0254cc11cdc0e5045cfa7170ab77f66d3375bf683e8d75afe` |
| teahouse-assets.js | 2026-11-13 02:13:17 | 45934 | `3adcce6ab90b67110016e30cfb02660516154c7f683647937c272ce658020a49` |
| r6.js | 2026-11-13 02:20:16 | 36865 | `7ed03318145a756ded0d34f953864971d7863736565c66b8e1459aa50e535422` |

Economy tables (locked, for backend alignment): `v4/_src/r6-economy.md`.

## What is integrated (not a stub)

- **TG_AVATAR**: player model replaced via `r6ApplyAvatar()` / `TG_AVATAR.build`; walk/idle through `TG_AVATAR.animate`; 捏脸 button calls `openPanel`. Appearance is stored in `S.avatar` after `normalize`. Purchased accessories / titles / equipped live in **`S.avatarInv`** (and a `S.avatarWire` serialize string) so `normalize` cannot drop them. Riding uses `setPose('ride'|'sit')`; dismount returns to `stand`/`idle`.
- **TG_NPC**: `placeAtStalls()` after the market exists; `TG_NPC.update(dt, w.camera)` in the frame loop; `handleTap(w.ray)` runs in capture phase on `pointerup` before ground picking; `hideBubbles()` on scene enter and when a modal opens. DOM bubbles get an extra occlusion / range check (raycast camera→head against scene walls, and hide beyond 8 units) so they do not show through walls.
- **TG_MOUNTS**: r6 catalog ids map to module kinds (`ox_cart→oxcart`, `chestnut_horse→chestnut`, `white_horse→whitehorse`, `white_deer→whitedeer`, `green_ox→greenox`). `build` / `setDeco` flags / `mount` / `dismount` / `animate` / `getSeats` / `reapplyPose` are used when present. While riding, character walk-leg animation is skipped and `reapplyPose` / `setPose` keep the seat pose. Camera follow is raised (player y +0.9 so follow goes ~1.1→2.0) and radius +1.6. Hitching-post rules apply (拴马桩, 牵出/骑上, never auto-mount, indoor park at the door, re-enter yard auto-tethers). Network `mount` is non-null only while riding (`r6MountNet()`).
- **TG_TEA**: 茶会小院 uses `TG_TEA.buildCourtyard` when present (tables, chess, message wall, river lanterns); in-house courtyard is the fallback.
- **Economy / view / tea routing / lie / first-person / hall-door flush**: landed in r6 phase 1 (see `r6-economy.md` and phase-1 shots under `v4/shots/r6-phone-*.png`).

## What is still in-house, stubbed, or incomplete

- **realism.js / item 12** (王者荣耀家园 stylized-realism pass): module is packed and `TG_REAL` is defined, but r6 has not yet run a full-scene `upgradeScene` / material / lighting / vegetation pass. Treat art as **not finished**. Source is still marked in progress by 来福.
- **teahouse-assets.js**: used for the tea courtyard, but 来福 still listed it in progress; lotus-pond river lanterns / koi / wish slips / lotus-pod offerings (item 6) are not done yet.
- **Item 1**: true 3D shrine placement (raycast snap, stacking, height) — not started.
- **Item 7**: study / zen rich redecoration and sutra / meditation UX — daily merit helpers (`r6SutraComplete`, `r6ZenComplete`, `r6KoiRelease`) are wired, rooms are not yet re-dressed.
- **Item 8**: 功德阁 owned / not-owned two-column UI — not started.
- **Item 13**: full clip / texture audit (including the nine deferred Low items and visitor-yard wall-band occlusion) — not started.
- **r6.patch** is not written yet (end of all phases). In-house mount / NPC / avatar fallbacks remain in r6.js only for when a module is missing.

If avatar.js / realism.js / teahouse-assets.js change again after 02:20:17, repack with `node v4/_src/pack.mjs` and refresh the hashes in this file.

## Pack refresh 2026-11-13 02:25:25 (UTC+8)

The 02:20:17 build used an earlier realism.js. Current `v4/index.html` was packed at **02:25:25**, size 1,285,855 bytes, sha256 `34aab73588b14fdffc33e00f5003396091540dc293c1f566ed48a61f40af16c1`. It inlines the sources below verbatim (including NeutralToneMapping and `TG_REAL.install` / `applyToActive`). `index.pre-r6.html` is still `231370bffa96ddd10f8c007c1404f3d040c125e1e3393dc56397e0b232e8d106`.

| file | mtime (UTC+8) | size | sha256 |
|---|---|---:|---|
| realism.js | 2026-11-13 **02:23:25** | 27212 | `6372c473f8a3da772372979756899069d407d0eb89f1b40021b74cc20b3af1df` |
| teahouse-assets.js | 2026-11-13 02:13:17 | 45934 | `3adcce6ab90b67110016e30cfb02660516154c7f683647937c272ce658020a49` |
| avatar.js | 2026-11-13 **02:25:03** | 56858 | `006fd37f7c2bd4fd55ed9ea5c5fe9847b7f4702e3351c1b0929031835b3d7c15` |
| npc.js | 2026-11-13 02:13:51 | 18586 | `395dc182ab2065d762a0dcf6786fe8109b302e783bf2b97f534688c2cc607dd8` |
| mounts.js | 2026-11-13 02:15:22 | 49777 | `f520265341ea43d50ba36ae4b6b27ca54a3b7639c04944a691f503dc9cace5d5` |
| r6.js | 2026-11-13 02:25:25 | 56290 | `c7efedf5e159b4bd25fba35e0715381cf9424024e35da4a61246d9a537da1fe5` |

Interfaces: `realism.README.md`, `teahouse-assets.README.md` (02:24:43). Pack order unchanged (avatar before npc).

### Integration still outstanding after this pack (will land in the next r6 pass)

- Call `TG_REAL.install({upgrade:true, quality: phone ? 'low' : 'high'})` + `TG_REAL.applyToActive()` after world init (r6 currently calls `applyPreset`/`upgradeScene` by hand with `quality:'medium'`, which is not a documented quality).
- Shader warm-up: `renderer.compile` per scene preset during load (first entry compiles ~16 programs).
- Tea courtyard: stop moving `court.parts.*` and stop hardcoding interacts at (0,-4.5)/(3,-.3)/(0,4). Iterate `court.interact`; river lantern uses `court.river.release()`. Keep `lite:true` on phone.
- Message wall: `court.wall.setMessages` fed by `TG_TEAHOUSE.wall()` when present (offline still uses `S.tea.messages`; 30/day, 20s, 120 chars).
- Audit notes from the READMEs: color heuristic mismatches (`userData.tgRealSkip` / `opts.map`); sloped-roof 45° box-UV seams; bamboo collision is one AABB strip per fence segment (not per culm).
- Recheck `avatar.js` mtime before the final pack (an economy-aligned build may still arrive).

## Pack refresh 2026-11-13 02:32:57 (UTC+8) — all 5 codex2 modules final

Economy-aligned `avatar.js` is the 02:25:03 build already in tree (sha unchanged; `avatar.README.md` §经济系统 at 02:29:53). Packed `v4/index.html` at **02:32:57**, size 1,310,378 bytes, sha256 `85f21d051db1cd4d8dfe257ab6d15bcac65a302f8e181b82d8569d02b322266b`. `index.pre-r6.html` remains `231370bffa96ddd10f8c007c1404f3d040c125e1e3393dc56397e0b232e8d106`.

| file | mtime (UTC+8) | size | sha256 |
|---|---|---:|---|
| realism.js | 2026-11-13 02:23:25 | 27212 | `6372c473f8a3da772372979756899069d407d0eb89f1b40021b74cc20b3af1df` |
| teahouse-assets.js | 2026-11-13 02:13:17 | 45934 | `3adcce6ab90b67110016e30cfb02660516154c7f683647937c272ce658020a49` |
| avatar.js | 2026-11-13 **02:25:03** (final, economy-aligned) | 56858 | `006fd37f7c2bd4fd55ed9ea5c5fe9847b7f4702e3351c1b0929031835b3d7c15` |
| npc.js | 2026-11-13 02:13:51 | 18586 | `395dc182ab2065d762a0dcf6786fe8109b302e783bf2b97f534688c2cc607dd8` |
| mounts.js | 2026-11-13 02:15:22 | 49777 | `f520265341ea43d50ba36ae4b6b27ca54a3b7639c04944a691f503dc9cace5d5` |
| r6.js | 2026-11-13 02:32:18 | 66101 | `811da04d7ba48e28fa30e05ca7221dbd4278dbf842c23700f58845345801bba3` |
| r6-art.js | 2026-11-13 02:27:11 | 5991 | `e69012512e0ab2468b81866273ce054f993f3794f663599d5991367d5a689014` |
| r6-net.js | 2026-11-13 02:32:50 | 8719 | `956699394ffd1222cf86d7fff36d93bf273a145b4ee00e195573f243545a4b7b` |

Pack order: animals2, audio, r5, realism, avatar, npc, teahouse-assets, mounts, r6, **r6-art**, **r6-net** (existsSync). Backend `tg-r6.js` is **not** inlined.

### Avatar / catalog alignment landed in this pack

- Load path uses `TG_AVATAR.normalize(cfg, {checkOwned:false})` in `sanitizeR4` and `r6ApplyAvatar`. After the `tg-avatar` event, `r6RevalidateAvatar()` runs a normal `normalize` (ownership check on).
- Offline-only `TG_AVATAR_NET` stub (`__offline:true`) when the spliced backend NET is absent: `catalog` / `locked` / `titles` / `owned` match `backend/r6.sql` ids and names (`beads` 念珠 400, `hairpin` 发簪 500, `jade_pendant` 玉佩 600 / part `jade`, `cape` **云肩** 700, titles 善信/居士/修行者/功德主). Default accessories remain all `none`. Titles listed in the picker are owned-only (name is what goes in `config.title`).
- Cape product is labeled **云肩** in the merit shop, economy table, and offline catalog. `avatar.js` panel still ships the word 披风 in a couple of labels (module is frozen); `r6RelabelCape` rewrites those to 云肩 / 云肩色 when the panel or shop is opened. Item id stays `cape`.

### Also in this pack (still iterating)

- `TG_REAL.install({upgrade:true, quality: phone?low:high})` + `applyToActive` + `renderer.compile` warm-up (`r6-art.js`).
- Tea interacts rebound from `court.interact` / `court.river.release()`; wall fed by `TG_TEAHOUSE.wall()` when present (`lite:true` already in r6 build).
- `go()` queues the latest call while `switching` and drains when the fade unlocks; `TG_SCENES.teahouse` is `public:true`; `#tea` / `go('tea')` stay aliases.
- Watering `p.boost` capped at 0.25; `TG_MERIT_GET` / `TG_MERIT_ADD`; `r6EarnCoins` routes through `TG_ECON.earn` when present (`exact` for sales).

## Pack refresh 2026-11-13 02:33:15 (UTC+8) — current testable build

Codex phase 2 appended a small r6.js increment (smoke batch / study-zen wood floor) and repacked 18 seconds after 02:32:57. Sidecars and `checkOwned:false` survived. Current `v4/index.html`: **02:33:15**, size 1,310,615 bytes, sha256 `c96127e69df1e1b573d6c33e9e4179fb6088e4ed5732c942c15e2684fc7b6eab`. `index.pre-r6.html` remains `231370bffa96ddd10f8c007c1404f3d040c125e1e3393dc56397e0b232e8d106`. The five modules are unchanged (avatar.js still 02:25:03 / `006fd37f…`).

| file | mtime (UTC+8) | size | sha256 |
|---|---|---:|---|
| r6.js | 2026-11-13 02:33:15 | 66338 | `60dcdad524e88f1e982e84e5d35289de3045c069bfdc452e9f7b47af73eed3ed` |
| r6-art.js | 2026-11-13 02:27:11 | 5991 | `e69012512e0ab2468b81866273ce054f993f3794f663599d5991367d5a689014` |
| r6-net.js | 2026-11-13 02:32:50 | 8719 | `956699394ffd1222cf86d7fff36d93bf273a145b4ee00e195573f243545a4b7b` |

Playwright (390×844, SwiftShader), this pack:
- PASS avatar-pack: default acc all `none`; `normalize(...,{checkOwned:false})` keeps saved title 居士 and paid acc; offline `TG_AVATAR_NET` catalog ids/names match `backend/r6.sql` (cape=云肩, jade_pendant part=jade); `TG_SCENES.teahouse.public===true`; `TG_MERIT_GET/ADD` present; all five modules defined.
- PASS go/tea/water: `p.boost` capped at 0.25 after 3 waterings; hall→plaza first `go('plaza')` during fade lands on plaza; `go('teahouse')` enters tea; wall interact at (0, -10), chess at (5.4, -1.62), river uses `court.river.release()` (no longer the hardcoded (0,-4.5)/(3,-0.3)/(0,4) points).

## Phase 2 final build · 2026-11-13 02:39:16 (Asia/Shanghai)

This section supersedes earlier “current build” and “incomplete” entries above; all earlier phase-1 and interim build records are retained as history.

| Artifact | Value |
|---|---|
| Packed | 2026-11-13 02:39:16 |
| index.html size | 1,295,903 bytes |
| index.html sha256 | `8be5fd45130dab3d5d259bb8014ca82cd0ae6de163ea1c0f4a6ea994af887c34` |
| SAVE_KEY | `templeGarden.v1` |
| Pack order | `animals2.js`, `audio.js`, `r5.js`, `realism.js`, `avatar.js`, `npc.js`, `teahouse-assets.js`, `mounts.js`, `r6.js` — existsSync guarded |

The optional `r6-art.js` / `r6-net.js` sources appeared during this work and remain untouched, but are **not bundled**: the user explicitly locked the nine-file pack order. The intervening sidecar pack introduced an enumerable `teahouse` alias of the same tea group; the legacy visibility loop then hid tea. Restoring the required pack order restores the visible courtyard. Earlier sidecar / teahouse-alias / extra network-hook claims describe those interim builds, not this final artifact. Existing phase-1 module integration and the `normalize(...,{checkOwned:false})` source fix remain preserved.

| Packed module | mtime (Asia/Shanghai) | bytes | sha256 |
|---|---|---:|---|
| avatar.js | 2026-11-13 02:25:03 | 56858 | `006fd37f7c2bd4fd55ed9ea5c5fe9847b7f4702e3351c1b0929031835b3d7c15` |
| npc.js | 2026-11-13 02:13:51 | 18586 | `395dc182ab2065d762a0dcf6786fe8109b302e783bf2b97f534688c2cc607dd8` |
| mounts.js | 2026-11-13 02:15:22 | 49777 | `f520265341ea43d50ba36ae4b6b27ca54a3b7639c04944a691f503dc9cace5d5` |
| realism.js | 2026-11-13 02:23:25 | 27212 | `6372c473f8a3da772372979756899069d407d0eb89f1b40021b74cc20b3af1df` |
| teahouse-assets.js | 2026-11-13 02:13:17 | 45934 | `3adcce6ab90b67110016e30cfb02660516154c7f683647937c272ce658020a49` |
| r6.js | 2026-11-13 02:33:15 | 66338 | `60dcdad524e88f1e982e84e5d35289de3045c069bfdc452e9f7b47af73eed3ed` |

### Phase-2 gameplay and art delivered

- True rendered-scene placement replaces the flat planner in hall, study, zen and yard: upward-surface raycast snapping (tabletop / shelf / floor), 90° rotation, 0.1m height adjustment, selection, moving, return to backpack, red/green preview. Decor has additive `y`; old records migrate to zero. Item-volume and fixed-triangle checks reject collisions; doors, pens, fields and yard corridors remain protected. Models still route through TG_CATALOG / r3Furniture / r6 rare models. Visitor mutations are blocked.
- Visible pond panel and world interactions for koi release, seed-pod gathering, coin-toss wishes and river lanterns. Release effects animate into the water. Koi remains 2 merit × 3/day. `lotus_pod` is a real catalog offering, backpack item and altar model: 10min / 2 merit, included in the existing 40-merit offering cap. Three pods/day. Wishes cost 2 coins, lanterns 3, neither grants merit. Night lanterns use Shanghai 18:00–05:59. Economy addendum documents these choices without changing locked numbers.
- Dedicated merged study/zen furnishings replace overlapping sparse legacy desks/shelves: sutra shelves, book rows, lamps, framed scrolls, rugs, cushions, scripture desk/ink/brush, incense altar. Two-minute copying and three-minute meditation have visible countdown/progress/scripture, wooden-fish audio for zen, original daily caps, and cancellation on close/room exit.
- 功德阁 has side-by-side 「已请回 / 尚未请回」 lists at phone width. Ownership includes backpack, placed decor and S.avatarInv accessory/title unlocks. Prices remain locked; visitor access is blocked.
- TG_REAL published APIs apply warm lighting, tone mapping, fog, procedural PBR materials and mobile shadows. Shared-material static art merges preserve animated fish/water/glows. Smoke animation uses one instanced draw. No frozen module or art3 edits by this phase.
- Nine deferred Low clip items and visitor yard wall-band occlusion are addressed; details: `/tmp/codex-v4-r6/clip-status-r6.md`. Every registered doorway arrival and 16 visitor perimeter/yaw sightlines are checked.
- Fixed two existing mount-wrapper faults exposed by regression: out-of-scope `ride()` replaced with `r6IsRiding()`, and old ridden models removed from their actual parent to prevent accumulated ghost mounts. TG_MOUNTS/TG_AVATAR.setPose, hitching-post locations, indoor parking and never-auto-mount behavior remain intact.

### Verification and captures

`/tmp/codex-v4-r6/verify-r6-phase1.mjs` and `verify-r6-phase2.mjs`: Playwright, SwiftShader, 390×844. Phase 2 covers tabletop raycast/stacking, collision rejection, rotation/height, v1 save height, koi/pod caps and offering expiry cap, timed sutra/zen completions and close cancellation, merit ownership split, visitor state preservation, six market NPCs, all five module globals, no THREE-missing warning, four-yaw budgets and every doorway spawn. Test time is accelerated by shifting the session monotonic start for cap assertions; the actual UI durations remain 120s / 180s.

Phone captures refreshed under `v4/shots/`: `r6-phone-hall-place-3d.png`, all three lotus shots, study + sutra, zen + meditation, merit-owned split, art plaza and art yard. Screenshot-only requestAnimationFrame suspension stabilizes SwiftShader/native progress capture; assertions and budget measurements use the normal render loop. See `phase1-phase2.log`, `phase2-verified.log`, `perf.json`, `perf-phase2.json`, `clip-checks.json` in `/tmp/codex-v4-r6/`.

| Scene | Four-yaw calls | Peak |
|---|---|---:|
| plaza | 81, 65, 74, 66 | 81 |
| yard | 60, 45, 41, 50 | 60 |
| hall | 79, 52, 50, 53 | 79 |
| market | 69, 63, 60, 100 | 100 |
| tea | 33, 80, 41, 39 | 80 |
| lotus | 64, 51, 58, 53 | 64 |
| zen | 15, 20, 14, 16 | 20 |
| study | 12, 15, 11, 19 | 19 |
| gate | 62, 24, 34, 24 | 62 |

### Remaining limits / deferrals

No requested phase-2 gameplay item or listed Low clip item remains deferred. Hardware audio listening and real-phone GPU validation are not performed. Existing backend/family-passenger scope stays as phase 1; this phase edits no backend files. `r6.patch` is deliberately unwritten. No commit/push, protected backup overwrite, v1/v2/v3 change, or frozen module edit was performed by this phase.

## Pack refresh 2026-11-13 02:49:30 (UTC+8) — codex2 avatar/npc/mounts fixes

codex2 landed final patches in `avatar.js` (02:43:57, 云肩 in source), `npc.js` (02:46:02, Raycaster duck-type `handleTap`, built-in bubble occlusion), and `mounts.js` (02:43:57, ignore non-rider `limbs`). Current `v4/index.html`: **02:49:30**, size 1,315,966 bytes, sha256 `2299c9e25d1d9954e569d73c6622780521b76160ea228fa796128b6a31e38ecb`. `index.pre-r6.html` remains `231370bffa96ddd10f8c007c1404f3d040c125e1e3393dc56397e0b232e8d106`.

| file | mtime (UTC+8) | size | sha256 |
|---|---|---:|---|
| avatar.js | 2026-11-13 **02:43:57** | 56858 | `c8d12c0514fde62071c5d744ec79fc48c9816ca65f081b94dcf8374f2d3da208` |
| npc.js | 2026-11-13 **02:46:02** | 21643 | `ef450997321b25b9be9ae2d3f37b1f3b6dbb41a2ce75d7c19a970fc3944236e3` |
| mounts.js | 2026-11-13 **02:43:57** | 50301 | `c81d66b7552ccc954b3d4d08ff68a422a1d6d2cbf13b62eb0b58f7edc233ddf4` |
| realism.js | 2026-11-13 02:23:25 | 27212 | `6372c473f8a3da772372979756899069d407d0eb89f1b40021b74cc20b3af1df` |
| teahouse-assets.js | 2026-11-13 02:13:17 | 45934 | `3adcce6ab90b67110016e30cfb02660516154c7f683647937c272ce658020a49` |
| r6.js | 2026-11-13 02:49:30 | 65289 | `84772d31956b028e70c0bab69b41dff78cdab125fe7d89d2b64d4c98924c4fbf` |
| r6-art.js | 2026-11-13 02:47:08 | 9310 | `75c341b5617cd0a329bb975916dd7a34820c23cf4ebc0bdcd58478c568fe402a` |
| r6-net.js | 2026-11-13 02:49:17 | 8219 | `ce007944a8f9d5551080a89dd70dfd714dd93618213d9c81f4d85bf31461298a` |

### Audit follow-up in this pack

- Removed `r6RelabelCape` (avatar panel and catalog already say 云肩 / 云肩色).
- Deleted `r6NpcOcclude` / `r6Occ*` (S1-5 root cause). NPC bubbles are owned by `TG_NPC.update` (player distance via `setView({target:W3.player})`, ignores awnings, every 4 frames). No second occlusion pass.
- S1-4: dropped the `handleTap(e,camera,canvas)` workaround. Production path is `TG_NPC.handleTap(W3.ray)` now that npc.js duck-types r170 Raycasters. A hit still `stopImmediatePropagation` + `worldStop` + clears `W3.target`/`path` so the player does not walk.
- S1-2: still `M.mount(..., rider===w.body ? {limbs:w.limbs} : {})` (mounts.js also ignores foreign limbs).
- S1-3: `r6DisposeRide` uses `TG_MOUNTS.dispose` / `parent.remove` (does not dispose shared cached geometry); leftover `userData.r6Ride` children under the player are swept on sync; dismount leaves zero ride models on the player.
- S1-6: phase-1 `tgAnimate` only applies the mount speed bonus; `TG_MOUNTS.animate` runs once per frame in the integration wrapper.
- Market draw-call trim (`r6TrimMarket`) remains; tea still `lite:true`.

## Pack refresh 2026-11-13 02:51:48 (UTC+8)

`W3.spaces.teahouse` is now a non-enumerable getter for `spaces.tea`. The previous enumerable alias made `worldEnter` hide the courtyard after `go('tea')` (the `teahouse` key lost the `n===name` check). Current `v4/index.html`: **02:51:48**, size 1,316,502 bytes, sha256 `e02cf34c9e9b795bbb56ffdaefbb1aad03b2133facfcb9ac60191b0167ec4279`. `index.pre-r6.html` remains `231370bffa96ddd10f8c007c1404f3d040c125e1e3393dc56397e0b232e8d106`. r6-net.js 02:51:48, 8755 bytes, sha256 `e7e9ca39c68ba18406d6442c4e2f447402038283a9ca262e7a308d43558e61b8`. Other module hashes unchanged from the 02:49:30 table.


## Pack refresh 2026-11-13 11:08:33 (Asia/Shanghai, UTC+8)

Continuation after 02:51:48 (`e02cf34c…`). Placement HUD fix, Honor-of-Kings dress layer, r6-side elbow/knee joints, merit `TG_MERIT.spend` no-double-deduct, default accessories confirmed/forced `none`.

### Packed index
- `v4/index.html` 1,346,473 bytes, 2026-11-13 11:08:33 +0800
- sha256 `545a071a212323f6ba03b74aae3500be50a30665946b9917e4b5698e11693585`
- Pack order: animals2, audio, r5, realism, avatar, npc, teahouse-assets, mounts, r6, r6-art, r6-net, r6-joints, r6-art-hk
- `v4/index.pre-r6.html` UNCHANGED sha256 `231370bffa96ddd10f8c007c1404f3d040c125e1e3393dc56397e0b232e8d106` (1,031,123 bytes, 2026-11-13 01:55)

### Source sidecars (this pack)
| file | bytes | mtime +0800 | sha256 |
|---|---|---|---|
| r6.js | 66503 | 11:03:04 | `0c94a5369eb63e9c85d9239691cd8e48f4e4ad3271d3c1e6edeb79c3843f363a` |
| r6-art.js | 9310 | 02:47:08 | `75c341b5617cd0a329bb975916dd7a34820c23cf4ebc0bdcd58478c568fe402a` (unchanged) |
| r6-net.js | 11057 | 11:06:36 | `7d4366d2e87afed77ffa6ab5f0f0bf5a9747834328caad3d4d6d5ccee561bf0a` |
| r6-joints.js | 7515 | 11:05:29 | `7049fe25d3f7efc2a7c13a15a4b71cab760b5ee9c04328b98149746a91b6b707` |
| r6-art-hk.js | 18938 | 11:08:33 | `7a67cc4624025c4c0a93fc679dc38efe5cc990026de70d89e2ad214c02fc7587` |

### This wave
- Placement: `body.r6-placing` hides all `#app` HUD except `#view` / `#r6Placement`; header+4-button footer laid out for 390×844; no overlaps. Shot `v4/shots/r6-phone-hall-place-3d.png` (top resource pills hidden; defaults are coins 50 / merit 0 — earlier 20000/19520 was capture-script test injection only).
- Art: `r6-art-hk.js` instanced roof tiles + ridge ornaments, dougong/brackets, carved rail bays, layered grass/flowers/shrubs, vertex AO, golden-hour sun, soft shadows, Neutral tone mapping, warmer fog. Static meshes merged (gate 147 → 65).
- Joints: `r6-joints.js` wraps `TG_AVATAR.build/update/setPose/animate` with elbow/knee mid-joints (no edits to avatar.js). Walk/sit/lie/ride flex applied. Sleeve split can look ragged — see codex2 notes.
- Merit: `TG_MERIT.spend(id)` → `Promise<{ok,reason,price}>`. Handler `const r=await TG_MERIT.spend(id); if(!r.ok){toast(reason);return;}` then grants item only. Offline fallback deducts once via `TG_MERIT_ADD(-price)`.
- Avatar defaults: packed `DEF()` already `acc` all `none`; r6-net also forces `defaultConfig` / missing-`acc` normalize to all `none`. Playwright: defaultConfig + normalize({}) all none.
- Draw calls (Playwright SwiftShader, after 11:08:33 pack):

| scene | phone 390×844 | desktop 1280×800 |
|---|---|---|
| gate | 65 | 65 |
| plaza | 67 | 70 |
| market | 112 | 149 (under 150, flag) |
| yard | 68 | 77 |
| lotus | 70 | 70 |
| hall | 70 | 74 |
| zen | 23 | 24 |
| study | 14 | 18 |
| tea | 81 | 81 |

- Defaults confirmed: `S.coins=50`, `S.merit=0` (not 20000/19520).
- `v4/r6.patch` vs pre-r6: 320,071 bytes, sha256 `2d362a400de4146f22b05d81cb223e95fb2b9c39f06b4c0b49bcad21aff39679`, 2026-11-13 11:09:57 +0800


## Pack refresh 2026-11-13 13:30:24 (Asia/Shanghai, UTC+8) — r6b, no-regression fix

来福 rejected the 11:08 pack (spikes, black grass, gate wall). Fixes only; further realism deferred.

### Backups
- `v4/index.pre-r6.html` UNCHANGED sha256 `231370bffa96ddd10f8c007c1404f3d040c125e1e3393dc56397e0b232e8d106` (1,031,123 bytes, 01:55)
- `v4/index.pre-r6b.html` = rejected 11:08:33 pack, sha256 `545a071a212323f6ba03b74aae3500be50a30665946b9917e4b5698e11693585` (1,346,473 bytes)

### Packed index
- `v4/index.html` 1,338,574 bytes, 2026-11-13 13:30:24 +0800
- sha256 `2b1ec5f8f18997c0a255ea976751c3eb3b1cbce1fa8d8b41e43fd6cbfdc935b2`
- Pack order unchanged: animals2, audio, r5, realism, avatar, npc, teahouse-assets, mounts, r6, r6-art, r6-net, r6-joints, r6-art-hk
- `v4/r6b.patch` vs pre-r6b: 12,577 bytes, 13:34:35 +0800, sha256 `2e9460450638189460c63a2bee419720e84dcee3fc1ad13c037fe74a3dd1b726`

### What changed
1. **Sleeves:** `_src/r6-joints.js` is now a no-op (`version:'r6-joints-disabled'`). No TG_AVATAR wrap, no mesh split, no mid joints. Proper two-segment limbs still belong in avatar.js.
2. **Black grass:** `placeVeg()` in `r6-art-hk.js` is a no-op. Thin instanced blades are not added. Established scene flowers/shrubs untouched.
3. **Gate wall:** r6.js `worldCamera` wrap clamps the gate third-person camera to z≤13 (inside the south enclosure), scaling the boom so zoomed views stay in front of the wall and lookAt the player. Frozen camera constants unchanged.

### Draw calls (Playwright SwiftShader, 13:33 recapture)

| scene | phone 390×844 | desktop 1280×800 |
|---|---|---|
| gate | 58 | 58 |
| plaza | 60 | 63 |
| market | 99 | 131 |
| yard | 61 | 70 |
| lotus | 63 | 63 |
| hall | 68 | 72 |
| zen | 21 | 22 |
| study | 12 | 16 |
| tea | 74 | 74 |

### Shots
Before = pre-r6b (rejected 11:08), after = this pack, 390×844, 13:32–13:33 +0800:
`v4/shots/r6-phone-art-<scene>-before.png` and `v4/shots/r6-phone-art-<scene>.png` for gate, plaza, market, yard, lotus, hall, zen, study, tea.
Inspected: after has no sleeve spikes, no black grass strips, gate south wall no longer fills the lower half (cam z capped at 13). Market NPC vendor intact.

## Pack refresh 2026-11-13 14:31:38 (Asia/Shanghai, UTC+8) — r6c hotfix + r6.1 contract

来福 v12 audit (qa/r6-v12-audit.md, live d6e0634) plus mid-round r6.1 backend contract (tg-r6.js / r6.1.sql). Game _src only; backend/SQL and codex2 modules untouched.

### Backups (frozen)
- `v4/index.pre-r6.html` UNCHANGED sha256 `231370bffa96ddd10f8c007c1404f3d040c125e1e3393dc56397e0b232e8d106` (1,031,123 bytes, 01:55)
- `v4/index.pre-r6b.html` UNCHANGED sha256 `545a071a212323f6ba03b74aae3500be50a30665946b9917e4b5698e11693585` (1,346,473 bytes, 11:08:33)
- `v4/index.pre-r6c.html` = r6b 13:30:24 pack, sha256 `2b1ec5f8f18997c0a255ea976751c3eb3b1cbce1fa8d8b41e43fd6cbfdc935b2` (1,338,574 bytes)
- `v4/r6.patch` and `v4/r6b.patch` left as-is

### Packed index
- `v4/index.html` 1,350,815 bytes, 2026-11-13 14:31:38 +0800
- sha256 `d7bd2ee752249e6a559f74d228bcb296fb89c1f65bb2523b93050f0d8c6c66aa`
- Pack order unchanged: animals2, audio, r5, realism, avatar, npc, teahouse-assets, mounts, r6, r6-art, r6-net, r6-joints, r6-art-hk
- `v4/r6c.patch` vs pre-r6c: 41,216 bytes, 14:33:31 +0800, sha256 `8e4e3fde547f870c01ae536d0cd5f29c0da1d1090a14abb530f1c5645b82e454`

### Sidecar sha256 (this pack)
- r6.js `d10e3c79659338b4ca30bfef7fc048b19b920d06fe07146701439f9e84debdc8` (75,461 bytes, 14:31:38)
- r6-net.js `ba5b350af59eefb5eebe3e05ad6e699d45df4099d3b5baefd7dbbc59d0b2a07f` (14,869 bytes, 14:30:37)
- r6-art.js `75c341b5617cd0a329bb975916dd7a34820c23cf4ebc0bdcd58478c568fe402a` (unchanged since 02:47)
- r6-art-hk.js `f6f1f3dbc0e8d1ea40ca9bf9b9a91ef25b9829a75311c7bdb6d818b05194c301` (17,686 bytes, 14:20:11)
- r6-joints.js `ccc7dbc3a407cfe65fdce0b4d0aed647e81062989f2a9caed994c28721a81a68` (still disabled no-op)
- pack.mjs `6a38693d786959d0edd438cd7f0064f512bf5b560bed2b5dbdda0d765aa4d747`

### Contract (supersedes earlier spend(id, price) notes)
- Every merit purchase: `await TG_MERIT.spend(id)` only. spend() deducts via TG_MERIT_ADD(-price) and refunds on reject. Game does not deduct merit itself. Grant only if `r.ok===true`, using `r.item`. Failures `{ok:false, reason}` (poor|owned|unknown|rate|offline|busy|error|bad_req). busy = in-flight same item.
- Toasts: `toast(TG_MERIT.reasonText(r))` (pass the result object). Offline stub reasonText accepts a string or `{reason}`.
- Accessories/titles: `TG_AVATAR_NET.buy(id)` when present, else spend(id). Never both.
- Merit mounts / saddle_bell: `TG_MOUNT_NET.buy(kindOrId)` when present, else spend(id). Coin mounts stay local, then `TG_MOUNT_NET.save?.(S.mounts)`.
- H3: avatar button `onclick=()=>window.r6OpenAvatar()`; onSave `await TG_AVATAR_NET.save(wire||cfg, titleId)`.
- In-flight lock kept (`dataset.busy` + disabled + `r6Purchase` + `TG_MERIT.busy()`).
- Offline stub installed when backend TG_MERIT is absent.

### Draw calls (Playwright SwiftShader, 390×844, 14:41–14:42 +0800)

| scene | calls | triangles | space faces | SwiftShader fps (300ms) |
|---|---|---|---|---|
| gate | 62 | 26,618 | 21,934 | 35.7 |
| plaza | 61 | 36,088 | 42,234 | 7.8 |
| market | 100 | 48,828 | 58,898 | 26.6 |
| yard | 62 | 33,312 | 37,854 | 61.1 |
| lotus | 65 | 39,838 | 36,428 | 59.4 |
| hall | 68 | 10,534 | 9,898 | 38.0 |
| zen | 20 | 7,370 | 2,214 | 28.4 |
| study | 12 | 7,392 | 2,250 | 10.0 |
| tea | 68 | 37,762 | 32,560 | 15.6 |

All scenes <150. Tea tris 37,762 (was 110.9k in the v12 audit). teahouse alias remains non-enumerable. SwiftShader fps is not a phone-GPU measurement.

### Self-test (14:41–14:43 +0800)
- VM: `/tmp/codex-v4-r6c/test-contract.mjs` PASS
- Playwright (network stubbed, supabase aborted): `/tmp/codex-v4-r6c/selftest-playwright.mjs` PASS, no page errors
- H1: double-tap glazed_lamp → one `spend(['glazed_lamp'])`, button disabled during flight, grant once, merit unchanged by the game (20000)
- H2: jade_pendant and title_shanxin go through `TG_AVATAR_NET.buy(id)` only, inventory updated from `r.item`
- H3: opening the panel does not save; onSave calls `TG_AVATAR_NET.save(wire, titleId)` and toasts `尚未拥有该装扮` on `{ok:false,reason:'not_owned'}`
- M1: poor → `功德不足`; busy → `正在处理，请稍候`; no grant on failure
- M2: `TG_MOUNT_NET.buy('white_horse')` then save; donkey coins local (10000→9520), no buy(), then save; merit unchanged

### Visual shots (390×844 CSS, 780×1688 PNG, v4/shots/)
- r6c-phone-merit-shop.png
- r6c-phone-dismount.png / r6c-phone-ride-plaza.png — `#r6DismountBtn` 下马 at right:12px top:202px, camera ~8.9 m behind rider
- r6c-phone-npc4-bubble.png — 陆羽生 bubble visible (“新焙的明前龙井，客官尝一盏？”)
- r6c-phone-fp-gate.png — no canopy fill (M8)
- r6c-phone-fp-zen.png / r6c-phone-fp-study.png — walls kept, no black holes (M9)
- r6c-phone-hitch.png — donkey at post (8.8, 12.6); horse (10.8, 12.6); ox_cart (12.8, 10.2)
- r6c-phone-plaza-door.png — doorway 斗拱 at lintel (brackets placed at y=2.7)
- r6c-phone-gate-tp.png — south wall no longer fills the lower half
- r6c-phone-hall-tp.png — no sleeve spikes
- r6c-phone-tea.png — tea courtyard (interior angle still weak)

### Left open
- Tea / plaza / study SwiftShader fps under 30; needs a real-phone check (M3 target).
- Honor of Kings realism still deferred (r6b decision). r6-joints stays disabled.
- Live r6.1.sql / tg-r6.js path not exercised (offline stub + stubs only).
- L3 unowned-accessory strip is in r6-net; no dedicated UI screenshot.

## Pack refresh 2026-11-13 20:42:26 (Asia/Shanghai, UTC+8) — r7

Compliance (Article 17 + 66-item checklist), enlarged 缘堂 + 祈愿古树, UI drawer, TP camera damping, menu entries for 意见箱 / 游戏手册. Game `_src` + pack only; backend/SQL and codex2 modules (including suggest.js / manual.js) untouched.

### Backups (frozen)
- `v4/index.pre-r7.html` = r6c 14:31:38 pack, sha256 `d7bd2ee752249e6a559f74d228bcb296fb89c1f65bb2523b93050f0d8c6c66aa` (1,350,815 bytes)
- pre-r6 / pre-r6b / pre-r6c and r6/r6b/r6c.patch left as-is

### Packed index
- `v4/index.html` 1,433,104 bytes, 2026-11-13 20:42:26 +0800
- sha256 `6a0469275c744072a175c4a1c647b502823d2cad3eb8221dc82025fe78c4b5de`
- Pack order after core/enhance/art2/r3/r4/art3/r41:

`animals2.js → audio.js → r5.js → realism.js → avatar.js → npc.js → teahouse-assets.js → mounts.js → r6.js → r6-art.js → r6-net.js → r6-joints.js → r6-art-hk.js → suggest.js → manual.js → r7.js → r7-compliance.js`

- `v4/r7.patch` vs pre-r7: 83,877 bytes, 20:44:36 +0800, sha256 `1aaad4a1e964d10af2c7f529b61eff85e63b304dc076084cf1b35f922294f18b`

### Draw calls (Playwright SwiftShader, 390×844, 20:46 +0800)

| scene | calls | triangles |
|---|---|---|
| gate | 62 | 26,484 |
| plaza | 55 | 33,316 |
| market | 78 | 38,828 |
| yard | 61 | 33,310 |
| lotus | 70 | 41,364 |
| hall | 28 | 62,930 |
| zen | 20 | 8,100 |
| study | 12 | 8,110 |
| tea | 64 | 35,444 |

All <150. Gate TP clamp at player z=6, yaw=0, radius=16: camera.z=10.98 (≤13).

### Shots (v4/shots/, CSS 390×844 unless noted)
- r7-phone-hall-tree.png — 缘堂 + 祈愿古树
- r7-phone-yard-place.png — yard placement portrait
- r7-phone-yard-place-land.png — 844×390 viewport (shell still letterboxes #app as a tall phone frame)
- r7-phone-cam-wall-before.png — pre-r7, camera z=25.03 clips through a yard timber frame
- r7-phone-cam-wall-after.png — r7, same pose, camera damped to z=18.11 in front of the frame
- r7-phone-feedback.png / r7-phone-manual.png — 意见箱 / 游戏手册 at 390×844

### Compliance
66-item table: 60 pass, 6 partial (H7 yield remains +1 not the checklist's +3 toast; L12–L15/L17 comments/docs/URLs intentionally retained). Full table and leftover/codex2/backend lists: `/tmp/codex-v4-r7/compliance-status.md`, `leftover-terms.txt`, `codex2-list.md`, `backend-list.md`.

## Pack refresh 2026-11-13 21:39:12 (Asia/Shanghai, UTC+8) — r7b

Base was someone else's post-r7 H7/shell pack (sha prefix 902e1f56, verified). Backup `v4/index.pre-r7b.html` left identical (1,434,050 bytes, sha256 `902e1f56e0ab5030ba3dc8bdd0f8d48d8ace7752e71dd2e8cf27af8c713506c6`, mtime 20:49:30 +0800). Their H7 +1 lamp text, shell.html title/meta/favicon, and `*.pre-h7` copies were not overwritten.

r7b covers: a more impressive 祈愿古树 + drama entry camera; barrel replaced by a wooden wish rack; 静室 restyled as a tea room; golden_buddha displayed as 石灯 (id/price 2800 unchanged); manual.js source wording; 844×390 full-bleed HUD; yard placement top-down; r7.1 title display + old-save keep; UX QA client fixes; H1 `TG_APPLY_REMOTE_STATE` hookup to `backend/tg-backend.js`; packed codex2's cleaned modules.

### Frozen / not touched
- `v4/index.pre-r7b.html` and earlier pre-r3…pre-r7 backups, r6/r6b/r6c/r7 patches
- `v4/_src/r7.js.pre-h7`, `r7-compliance.js.pre-h7`, `shell.html` (title 福缘里 · 心田小院, tree favicon, og tags)
- `suggest.js`, backend/, SQL (tg-backend.js already had the r7.2 sync; client only added the hook)
- `avatar.js.pre-r7b` = pre-cleanup original (sha `c8d12c0514fde62071c5d744ec79fc48c9816ca65f081b94dcf8374f2d3da208`). Reference only.
- No publish / no git push

### Packed index
- `v4/index.html` 1,456,762 bytes, 2026-11-13 21:39:12 +0800
- sha256 `aa8de1e22df46c6c46aa8dc491fac296e1b2a6116594ccd524cf86dfd00bd2fa`
- Pack order after core/enhance/art2/r3/r4/art3/r41:

`animals2.js → audio.js → r7b-audio.js → r5.js → realism.js → avatar.js → npc.js → teahouse-assets.js → mounts.js → r6.js → r6-art.js → r6-net.js → r6-joints.js → r6-art-hk.js → suggest.js → manual.js → r7.js → r7-compliance.js → r7b.js → r7b-ux.js`

- `v4/r7b.patch` vs pre-r7b: 148,073 bytes, 21:41:57 +0800, sha256 `97423964d9e9fca09cd063d10d566c9b00a64c1e69ea08a27eff6aab45e5aa8d`

### Codex2 cleaned module sha256s (must not be overwritten; packed as-is)

| file | sha256 | bytes |
|---|---|---|
| audio.js | `c6ac1013ee3364cfc7a469400e30b4c68f364a16e761aad639a6e37ea9383373` | 32,463 |
| npc.js | `892880abcbba5a8991b6fac30e366cf2de0599690ae73608baa4632ab38508f2` | 21,665 |
| avatar.js | `eb7ffc52a92658586ad0fe76b92a04f3900a892482bcca6572bb96f59fb163bc` | 56,273 |
| art3.js | `f6f5fb047146f6f441c5bff19af3b13362b5f2c1af30433b77a2ffdbe09032ae` | 44,193 |
| teahouse-assets.js | `2f9b44fe056f0376976bb10e356f6dbece9d91ac428bf90d4534e77769619547` | 45,931 |
| mounts.js | `165bd786c0b45ccb0d1c3af9815b80e509e09e66061907e0ee82009beb0f22ad` | 50,301 |
| animals2.js | `c57b82bad89f4ed509c6ece4ecd936139dc1e692d35ef63a8ce2fcc23287305d` | 16,340 |
| realism.js (unchanged) | `6372c473f8a3da772372979756899069d407d0eb89f1b40021b74cc20b3af1df` | 27,212 |

`templeGarden.bgm` storage key unchanged. Public APIs / part ids / serialization keys unchanged.

### avatar.js edits
None. Codex2's cleaned title list already has 雅士/茶客/园丁/旅人; PAID_NAME.beads is already 珠串 / 400; no leftover 念珠. Hash stayed `eb7ffc52…`. Title mapping lives in r7.js pairs, r7b-ux.js display helpers, r6.js sanitizeR4 + onSave (id first, then 居士→雅士 etc.), and r6-net.js / r6.js wear source names 珠串/善友/雅士/旅人/福缘主.

### Draw calls (Playwright SwiftShader, 390×844, 21:42–21:43 +0800)

| scene | calls | triangles |
|---|---|---|
| gate | 48 | 26,236 |
| plaza | 71 | 41,452 |
| market | 73 | 40,012 |
| yard | 62 | 33,614 |
| lotus | 67 | 41,160 |
| hall | 20 | 103,386 |
| zen | 14 | 7,666 |
| study | 11 | 7,390 |
| tea | 62 | 35,394 |

All <150. Hall entry camera: pitch 0.7, radius 24, camera ≈ [0, 16.56, 29.86], player [0, 0, 9]. Yard placement: pitch 1.22, radius 24, top-down of the whole yard. 844×390 `#app` is 844×390 full-bleed (not a 430/540 column). Gate TP clamp and r7 damping kept.

### Shots (v4/shots/, CSS 390×844 unless noted)
- r7b-phone-hall-tree.png — 缘堂 entry: whole 祈愿古树 in frame, umbrella canopy, gnarled roots, 南 · 小院
- r7b-phone-hall-rack.png — wooden plaque/ribbon rack (barrel-with-gold-knob gone)
- r7b-phone-zen.png — 静室 as tea room (square cushions, low tea table, vase, landscape painting)
- r7b-phone-shop-stone-lantern.png — 善缘阁 「石灯」 2800, also 珠串 400
- r7b-phone-placed-stone-lantern.png — placed 石灯, stone lantern, not a statue
- r7b-phone-manual.png — 游戏手册 (includes 缘堂与祈愿古树)
- r7b-phone-yard-place.png — portrait yard placement, top-down whole yard
- r7b-phone-land-gate.png / r7b-phone-land-yard.png / r7b-phone-land-place.png — 844×390 full-bleed gate, yard, and placement

### H1 client hookup (self-tested)
`window.TG_APPLY_REMOTE_STATE` + `sanitizeLoaded(raw)` in gameplay.js. Playwright: yard standing and yard placement; no save()/TG_STORAGE.save; scene and player pose kept; panels closed; UI updated. Toast `另一台设备有更新，已同步` verbatim. Only the gameplay TG_STORAGE fallback adapter writes `templeGarden.v1`. Title panel save: 居士/善信/修行者/功德主 keep ids and display 雅士🎋/善友🌱/旅人🧭/福缘主✨.

### Left open
- Existing 香客NNNN server nicknames need a server migration (H4 leftover).
- M7 merit_wallet baseline still a server issue; not changed.
- L3 desktop 16:9 widening left as the existing 540px phone frame when `(min-width:600px) and (min-height:600px) and (hover:hover)`.
- 祈愿古树 world label can clip to 「愿古树」 at the default entry angle.
- 里门 landscape entry still has a large overhead lintel in frame (M10 residual possible).
- L11 market InstancedMesh rewrite not done; compile warmup only. Draws already <150.
- M13 nickname uniqueness is server-side.

## r7c — public plaza tree / private hall / daily poetry
- Added final r7c sidecar after r7b-ux; relocated the existing tree and rack to public plaza origin. First boot and gate arrival stand at [0,7,0]. Plaza walk limits ±22, existing 52×52 floor retained; all three stalls moved to perimeter.
- Rebuilt the compact private hall at limits {x:6,z:8}, floor 12×16, original compact exit coordinates; secular lamps, chime, family frames, offerings and decor retained. No tree or petals in hall.
- Poetry popup wraps original draw/save logic; displays neutral verses by unchanged S.lastSign index, with no grades or predictive explanations. Gameplay/world3d source unchanged.
- Owned/unowned 石灯 merit article gets a rendered thumbnail from the existing r3Furniture stone-lantern model; ID and 2800 price unchanged.
- Manual identifies public plaza ancient tree, daily poetry, and private hall. Local plaques only: no tea-wall/lotus writes, costs, or daily-cap consumption added.
- Phone QA: plaza 120 calls; compact hall 27 calls after a ground apron was added so the entry camera no longer shows a black void past the south threshold (25 after the rack guard, 26 in the first QA pass). Portrait full tree label and landscape full-bleed screenshots captured under shots/r7c-phone-*.png. Final pack 1,466,267 bytes, sha256 56ade8f49908f10f8219925acd809dff0fd1ef3033636118030ca7feebcde54c (2026-11-13 22:24:53 +0800).
- Prior r7b label clipping issue resolved by wider tree label. No publishing or backend changes.


## r7d — secular stall copy + plaza re-layout
- Base r7c pack verified sha256 56ade8f49908f10f8219925acd809dff0fd1ef3033636118030ca7feebcde54c; backup v4/index.pre-r7d.html identical and untouched.
- New sidecar v4/_src/r7d.js after r7c.js. Also a minimal r7c.js poetry-label update (每日寄语 / 诗句 / 抽一首诗 / 第N首) so the r7c observer does not fight the rewrite; two manual.js mentions of 抽每日诗签 became 抽每日寄语. gameplay.js / world3d.js / cleaned modules / shell / backend not edited.
- Fortune copy (runtime DOM, inspected): 读心笺 popup is 今日心语 (poetry-like encouragement, coins 字/背, hexagram diagram hidden); 赏园景 popup is 赏景小记 (scenery note, 今日配色 / 可以试试 / 今天不妨少做, no 吉方/运势/宜忌); tube stick is 第N首; rewards, IDs, save fields and timers unchanged.
- Plaza re-plan (standing rule: re-review the whole scene): tree stays at (0,0,0). Walk limit {x:24,z:24}. North 院子 doorway moved -12→-22, 里门 14→22, 集市/茶会 doors ±14→±22. Lions, stone lanterns, flags, eave lanterns, copper lamp, pines, shade trees, cat/monk, stalls and the wish rack were moved onto a symmetric courtyard with a low stone/flower ring at r=10 (south opening). Default camera (portrait 0,11.2,18.5 / landscape 0,10.5,16.5, lookAt 0,4.4,0) frames the whole tree including roots and the unclipped 「祈愿古树」 label; 里门 sits at the south entrance, behind the camera. Gate→plaza spawn [0,16,0], no straight-down camera. Nav: gate, plaza, yard, hall, market, tea all entered.
- Phone draw calls: plaza portrait 91, landscape 117; hall 27, yard 61, market 73, tea 62, gate 48. All under 150.
- AABB check vs trunk r=1.5 / roots r=2.9 / canopy r=7.1 (horizontal gap to the cylinder, vertical overlap required to count as a hit). No prop intersects trunk, roots or canopy. No large-prop vs large-prop overlaps after lions were nudged south of the north wall.

| object | AABB [x,X,y,Y,z,Z] | min clearance | nearest | overlap |
|---|---|---:|---|---|
| 北门（心田小院） | [-13.65,13.65,2.35,4.46,-22.53,-21.47] | 14.37 | canopy | no |
| 里门 | [-2.15,2.15,0,3.61,21.4,22.6] | 14.30 | canopy | no |
| 集市门 | [21.07,22.6,0,3.61,-2.15,2.15] | 13.97 | canopy | no |
| 茶会门 | [-22.6,-21.07,0,3.61,-2.15,2.15] | 13.97 | canopy | no |
| 今日心语摊 | [-17.92,-13.83,-0.12,2.79,6.1,9.7] | 8.01 | canopy | no |
| 每日诗签摊 / 每日寄语摊 | [13.92,17.3,-0.1,2.43,4,12] | 7.39 | canopy | no |
| 赏景小记摊 | [13.92,17.3,0,3.75,-10.1,-6.5] | 8.27 | canopy | no |
| 祈愿牌架 | [-17.05,-13.92,0,2.3,-8.36,-6.5] | 8.27 | canopy | no |
| 石狮西 | [-6.02,-4.18,0.6,3.83,-20.77,-17.85] | 11.23 | canopy | no |
| 石狮东 | [4.10,6.02,-0.12,3.83,-20.77,-17.48] | 10.85 | canopy | no |
| 石灯西 | [-5.98,-4.16,-0.12,2.44,18.93,20.27] | 12.28 | canopy | no |
| 石灯东 | [4.82,5.98,0,2.44,18.93,20.27] | 12.43 | canopy | no |
| 旗杆西 | [-7.3,-5.25,0,6.2,-16.85,-16.15] | 9.88 | canopy | no |
| 旗杆东 | [5.25,7.3,0,6.2,-16.85,-16.15] | 9.88 | canopy | no |
| 铜灯 | [-2.4,2.4,-0.12,2.47,-17.6,-12.8] | 5.70 | canopy | no |
| 石环 | circle r=10, y≈0–0.8; AABB is conservative | 3.40 (AABB) | canopy | no (ring is outside r=7.1) |

- Grep of packed HTML (comments excluded): leftover hits are (1) original gameplay.js UI template strings for openGua/openFeng/openQian, SIGNS 解签 and DIR_TEXT, plus the 玩法说明 sentence 算卦/求签/看风水 — these are overwritten at runtime and were not visible in the popup DOM; (2) r7/r7c/r7d replacement-pair left-hand sides and regexes used to scrub them; (3) IDs / function names (openGua, lastSign, fengYear, …) excluded as requested. 签约 in the activity-tag list is the verb “sign a contract,” not a fortune slip. Runtime popup/tube DOM greps for 吉/凶/卦/爻/风水/吉方/运势/签/宜忌/起卦 were empty.
- Official shots: v4/shots/r7d-phone-xinyu.png, r7d-phone-shangjing.png, r7d-phone-poem-tube.png, r7d-phone-plaza-tree.png, r7d-phone-plaza-tree-land.png, r7d-phone-plaza-top.png, r7d-phone-plaza-top-land.png.
- Final pack 1,496,421 bytes, sha256 3147eeb3e5bb9c0cb5515c7f4d5dd20c2768f6fe9520d1b287de9b6ec051601d, packed 2026-11-13 22:49:03 +0800. r7d.patch vs index.pre-r7d.html. No publishing or backend changes.

## r7e — gardener NPC, flower bed instead of lotus wheel, pulled-back plaza camera
- Base r7d pack verified sha256 3147eeb3e5bb9c0cb5515c7f4d5dd20c2768f6fe9520d1b287de9b6ec051601d (1,496,421 bytes, 2026-11-13 22:49:03 +0800). Backup v4/index.pre-r7e.html taken with cp -a; identical and untouched.
- New sidecar v4/_src/r7e.js appended after r7d.js in pack.mjs. gameplay.js / world3d.js / cleaned modules / shell / backend / economy not edited.
- Plaza decorative figure: world3d 「静坐僧人」 (orange cone robe #cf7d28 + shaved head #f3c994, relocated by r7d to ≈(-14,12), no dialogue). Replaced with standing gardener 「园丁阿禾」 (straw hat, short dark hair, olive tunic, watering can). Interact toasts secular lines: 「花要勤浇，土要松一松。」 / 「这圈花坛是新铺的，坐下来歇歇也行。」 / 「松土之后再浇水，根才站得稳。」 The tan cat at ≈(14,12) was left as a cat. Scene scan (plaza/yard/hall/market/tea/gate): no leftover #cf7d28/#f3c994/#e39432 monk meshes. npc.js shopkeepers were already secular (陆羽生, 花婆婆, 鲁师傅, …). The worldMonk() player fallback stays hidden under the r6 TG_AVATAR body.
- North-gate disc: art3 「圆形莲纹铺装」 (texMat inlay, 3 rings + 12 radiating ellipses, CircleGeometry scale 2.4) sitting with the copper lamp at (0,-15.2) after r7d moveCluster from (5,-6.5). It read as a dharma / prayer wheel in the top-down shot. The inlay was hidden; a round stone-curbed flower bed (soil, curb, mixed blooms) was placed at the same spot. The secular 铜灯 stays on its own octagonal base in the bed.
- Plaza default camera (FOV 55 unchanged; general TP follow-cam constants untouched). Portrait overview pulled back and up so a 390×844 frame can hold the player in the lower third plus the whole tree and the r=10 flower-bed ring (narrow portrait hFOV requires a high 3/4). During that overview the 「祈愿古树」 plaque is billboarded just above the canopy so it stays unclipped; it returns to (0, 3.15, 2.4) when the player walks or in landscape. Landscape is only modestly raised so the 3/4 cinematic framing and trunk label do not regress.

| view | position | lookAt |
|---|---|---|
| portrait default | (0, 42, 20.8) | (0, 2.5, 2.5) |
| landscape default | (0, 16.8, 20.4) | (0, 3.2, 1.2) |
| top-down shot (TG_R7D_SHOT=top) | (0, 52, 0.02), up (0,0,-1) | (0, 0, 0) |

- AABB re-run after the new props (same trunk r=1.5 / roots r=2.9 / canopy r=7.1 test). No tree overlaps. No large-prop pairs. New rows: 花坛 box [-2.19,2.19,0.02,0.70,-17.39,-13.01], min clearance 5.91 (canopy); 园丁阿禾 box [-14.65,-13.41,0,2.42,10.97,12.93], min clearance 10.35 (canopy). 铜灯 still clear (5.70 to canopy); it stands inside the flower bed on purpose. Previous r7d rows unchanged.
- Phone draw calls (Playwright SwiftShader): plaza portrait 124, plaza landscape 139, plaza top-down 124; yard 61, hall 27, market 73, tea 62, gate 48. All under 150. Nav into gate/plaza/yard/hall/market/tea confirmed.
- Official shots (inspected): v4/shots/r7e-phone-plaza-tree.png, r7e-phone-plaza-top.png, r7e-phone-plaza-tree-land.png, r7e-phone-gardener.png.
- Final pack 1,507,660 bytes, sha256 f6804985adcf9ef1f9f63d31abc0c94ed11e627ffc88d37c0d9ecf5e62fb2715, packed 2026-11-13 23:00:01 +0800. r7e.patch vs index.pre-r7e.html. No publishing or backend changes.

## r7f — wish tags, official titles, flower-bed cleanup, gardener clearance, yard start camera, copy fixes
- Base r7e pack verified sha256 f6804985adcf9ef1f9f63d31abc0c94ed11e627ffc88d37c0d9ecf5e62fb2715 (1,507,660 bytes, 2026-11-13 23:00:01 +0800). 来福 confirmed v14 (r7e) is live as commit 390bda7 and the r7.3 server injects `window.TG_WISH`. Backup v4/index.pre-r7f.html taken with cp -a; identical and untouched.
- New sidecar v4/_src/r7f.js appended after r7e.js in pack.mjs. Also source copy fixes in r6-net.js, r5.js, r41.js, plus r7.js / r7b-ux.js pair/regex alignment. gameplay.js / world3d.js / cleaned modules / shell / backend / economy not edited. SAVE_KEY, TP constants, plot WORLD coords, and merit spend(id) contract unchanged. Graceful `TG_WISH` fallback is kept even though the live server injects the real client; the stub never overwrites a real client and never sets `__TG_WISH_NET`.
- Wish tags: on plaza dress / worldEnter plaza / every 60s while in the plaza / after a hang, call `TG_WISH.recent(60)` (and `onChange` / `cached()`). Up to 60 wooden tags hang from the 祈愿古树 fringe (r≈5.85–6.3, y≈6.45–7.3) on a string, hashed by id so positions are stable, with a gentle sway and a warm outline on `mine:true`. Three InstancedMeshes (tag / cord / outline). Tap (capture-phase canvas pointerup, 8px move threshold) opens a small card with nickname, wish text and a relative time via `textContent` only; a tap outside closes it; movement and other taps are left alone. After local 挂祈愿牌 / 摆放心意 success (`r5PlaceOffering`), an optional input「写一句心愿（可不填）」(≤40) appears; `TG_WISH.hang(text)` runs without blocking or refunding the local flow, and a failed hang toasts `TG_WISH.reasonText(r)` (offline: visible only to you). Local altar still has 5 slots; the server 5/day and 10s gap are shown as messages only. No currency.
- Title matching: r6.js avatar panel / onSave / r6PickTitle now match by id or the legacy names 善友/雅士/旅人/福缘主/珠串 (overridden from r7f; r6.js itself not edited). Official display names 善友🌱 / 雅士🎋 / 旅人🧭 / 福缘主✨ / 珠串💠. r7.js maps already matched the DB (善信→善友🌱, 功德主→福缘主✨, 居士→雅士🎋, 修行者→旅人🧭, 念珠→珠串💠). r7 Alias/display-only rows are deduped so the 名牌 tab does not show duplicate official chips. HUD plate and panel agree.
- Flower bed (r7e leftover): the north-gate bed still read as a wheel (ring + spokes, then the copper lamp’s 4 posts + 4-sided roof). Every spoke/radial element was hidden (inlay, pots, hub bases, posts, roof; scale-in-place so the 铜灯 AABB does not bloat). Rebuilt as a solid soil surface with offset patches, 3 irregular shrub/flower clusters, informal stones, and a simple non-radial box lantern. Top-down shot no longer reads as a dharma wheel.
- 园丁阿禾: the r7e close-up had a stall fence post in front of his torso (AABB of the stall at z 6.1–9.7 did not overlap him at (-14,12), but the camera looked through the south-east posts). Moved to (-11.2, 13.2), facing the tree. Close-up fence is behind him, no torso clipping.
- 心田小院 start camera: default plaza→yard spawn was [-6.7, 10.2, 0]; the follow cam at yaw 0 / pitch .42 / radius 8.8 sat at z≈18.2, south of the r5 ceremonial red gate (lintel at z=14, y≈3.1), so the lintel filled about a third of the screen. Plaza→yard spawn is now [0, 5.2, 0]. An entry shot holds the camera inside the gate until the player walks 0.18m (portrait (0, 8.4, 11.6), landscape (0, 7.6, 11.4), lookAt (0, 1.8, 0)). A yard-only clamp also keeps camera.z ≤ 13 so the follow cam cannot jump back behind the lintel. Global TP constants are unchanged. Hall→yard still uses the previous spawn, but the z clamp applies there too.
- Copy at source: r6-net.js `R6_REASON` poor `'功德不足'` → `'善缘不足'`, offline `'需联网才能供奉'` → `'需联网才能点灯'`; r5.js `r5BuyMerit` toast likewise `'善缘不足'`; r41.js routes.plaza[0] `'南 · 山门'` → `'南 · 里门'`. r7.js rewrite pairs now map leftover `'需联网才能供奉'` to `'需联网才能点灯'` (was `'此操作需联网，请稍后重试'`); r7b-ux avatar-panel toast interceptor also matches the new string so the soft “已保存在本机…” notice still works.

Grep of packed index.html after the final pack:

| query | hits | notes |
|---|---:|---|
| 功德不足 | 0 | gone at source |
| 南 · 山门 | 0 | gone at origin; visible waypoint is 南 · 里门 |
| 供奉 | 6 | (1) gameplay shop category `'供奉祖师'` (r7 rewrites to 缘堂陈设 at runtime); (2–3) r7 rewrite pair left-hand sides `供奉祖师` / `供奉`; (4–5) r7 leftover-catcher pairs `需联网才能供奉` → `需联网才能点灯`; (6) r7b-ux interceptor regex. No visible player-facing source toast remains. |
| 山门 | 4 | (1) shell.html `data-title="山门"`; (2) gameplay.js `TG_SCENES` gate name `'山门'`; (3) help text “点山门进入院子”; (4) r7 rewrite pair `["山门","里门"]`, which rewrites the three sources at runtime. Not changed at origin because the request was specifically the route label 「南 · 山门」. |

- AABB re-run after tags / flower-bed / gardener move (same trunk r=1.5 / roots r=2.9 / canopy r=7.1 test). No tree overlaps. No large-prop pairs (铜灯∩花坛 filtered as intentional). 祈愿牌 box is reported from occupied hook slots, not the whole InstancedMesh (unused origin instances had been a false trunk overlap). Hanging under the canopy is intentional; only the trunk/roots count.

| object | AABB [x,X,y,Y,z,Z] | min clearance | nearest | overlap |
|---|---|---:|---|---|
| 花坛 | [-2.15,2.15,0,1.76,-17.35,-13.05] | 5.95 | canopy | no |
| 园丁阿禾 | [-12,-10.3,0,2.42,12.41,13.86] | 9.28 | canopy | no |
| 祈愿牌 | [-6.52,6.36,6.13,7.49,-6.27,6.39] | 4.11 | trunk | no |
| 铜灯 | [-2.4,2.4,-0.12,2.47,-17.6,-12.8] | 5.70 | canopy | no (in the bed on purpose) |

- Phone draw calls (Playwright SwiftShader, 60 seeded tags): plaza portrait 122 (125 after a later nav return), plaza landscape 139; yard 57, hall 29, market 74, tea 63, gate 49. All under 150. Nav into gate/plaza/yard/hall/market/tea confirmed. Yard start camera (0, 8.4, 11.6) / player (0, 0, 5.2) confirmed. ERR [].
- Official shots (inspected) under v4/shots/: r7f-phone-plaza-tags.png, r7f-phone-plaza-tags-land.png, r7f-phone-flowerbed-top.png (before: r7f-phone-flowerbed-top-before.png), r7f-phone-plaza-top.png, r7f-phone-gardener.png (before: r7f-phone-gardener-before.png), r7f-phone-wish-card.png, r7f-phone-wish-input.png, r7f-phone-title-panel.png, r7f-phone-yard-start.png, r7f-phone-yard-start-land.png.
- Final pack 1,543,449 bytes, sha256 7264bad133925d0b3f3fa93a8ffbb370ae96e5cfad28ffdff6887460ec5e7122, packed 2026-11-13 23:14:29 +0800. r7f.patch vs index.pre-r7f.html. No publishing or backend changes; nothing the r7.3 / TG_WISH server still needs. Hang is only after local success.

## r7g — title save no longer clears to null; wish tags on the canopy rim
- Base r7f pack verified sha256 7264bad133925d0b3f3fa93a8ffbb370ae96e5cfad28ffdff6887460ec5e7122 (1,543,449 bytes, 2026-11-13 23:14:29 +0800). Backup v4/index.pre-r7g.html taken with cp -a; identical and untouched.
- New sidecar v4/_src/r7g.js after r7f.js. Also: r6.js sanitize/onSave now keep stored names (r6TitleName, not r6TitleDisplay); r7f.js moves wish tags to the lower outer canopy rim and makes them larger/brighter. gameplay.js / world3d.js / cleaned modules / shell / backend / economy / RPC not edited.

### Root cause (confirmed)
hookTitles() in r7f wrapped `TG_AVATAR.normalize` (and opened the face editor with) a display rewrite: stored 雅士 became 雅士🎋. avatar.js `normalize` / `dropLocked` then compared `t.name===cfg.title`. `TG_AVATAR_NET.titles` had been wrapped to emit the emoji names, but the backend avatar script loads after the packed game and replaces the whole `TG_AVATAR_NET` object, so that wrap was gone. The server owned list holds 雅士, 雅士≠雅士🎋, and the title was cleared both locally and in the save payload. r6.js sanitize also wrote `r6TitleDisplay(...)` (emoji) into `d.avatar.title` on every load, which fed the same mismatch. Backend `save()` also runs `AV.normalize(avatar)` when given an object.

### Fix
- (a) Never alter stored or wire title names. Removed the normalize display rewrite. Emoji / official labels are applied only in the display layer (panel chips, HUD plate via fillText, shop title picker). Stored and wire names are the catalog forms 善友 / 雅士 / 旅人 / 福缘主 / 珠串. Legacy 居士/善信/修行者/功德主/念珠 canonicalize to those forms on save; leftover r7f emoji names are stripped back.
- (b) Ownership and equip checks compare by id via `titleIdOf`, or by a stripped name plus the legacy map (`canonicalStoredTitle` / `titleEquals` / `ownsTitle`). r6OpenAvatar, r6PickTitle, r6TitlePickerHtml and a replacement `A.normalize` all use this.
- `TG_AVATAR_NET.save(wire, titleId)` always sends the original id and the catalog name (wire string, so the backend deserialize path does not re-normalize). Wrappers are re-applied with a `window.TG_AVATAR_NET` getter/setter plus a 1s poll and again at open/save, so they survive the backend replacing the object.

### Title regression (Playwright, after a late `TG_AVATAR_NET = {…}` replacement)
15/15 passed. For each of 善友, 雅士, 旅人, 福缘主, 珠串: official name, legacy name (善信/居士/修行者/功德主/念珠), and emoji-in (善友🌱 etc.) were equipped, the face editor was opened and saved. Local `S.avatar.title` stayed the catalog name (never null, never emoji), `equipped.title` stayed the id, the intercepted save payload had the same name + id, `displayTitle` showed the emoji form, and a post-save `normalize(...,{checkOwned:true})` still kept the title. Late-load wrap was confirmed (`titles._r7g` / `save._r7g`). The reported 雅士 path passed. ERR [].

### Wish tags
Moved to the lower outer rim of the canopy (r≈7.72–8.08, y≈5.28–5.92, tilt 1.18) so they are visible from the top-down plaza shot and the portrait default. Boards are larger (0.52×0.74) and brighter (`#f3cc86` with a slight emissive). Warm outline for `mine:true` stays. AABB now reports a real canopy gap (no special-case “under the canopy is fine”).

- AABB: pairs [], overlaps none. 祈愿牌 min clearance 0.32 canopy; 花坛 5.95; 园丁阿禾 9.28; 铜灯 5.70. No clipping with canopy, plaque, label, flower bed, gardener or ring.
- Phone draw calls (60 seeded tags): plaza portrait 122, landscape 139. Both under 150.
- Official shots (inspected): v4/shots/r7g-phone-plaza-top.png, r7g-phone-plaza-tags.png, r7g-phone-plaza-tags-land.png, r7g-phone-title-save.png (panel after saving 雅士: HUD and selected chip 雅士🎋, stored title still 雅士).

- Final pack 1,556,098 bytes, sha256 37d06121924c9703e42fb07a7f477e4592e68874c4495b5639d9ecbb1c2df696, packed 2026-11-13 23:33:44 +0800. r7g.patch vs index.pre-r7g.html. No publishing or backend changes.

## r7h — free titles (茶客 etc.) survive face-editor save
- Base r7g pack verified sha256 37d06121924c9703e42fb07a7f477e4592e68874c4495b5639d9ecbb1c2df696 (1,556,098 bytes, 2026-11-13 23:33:44 +0800), live as commit 96f491d. Backup v4/index.pre-r7h.html taken with cp -a; identical and untouched.
- New sidecar v4/_src/r7h.js after r7g.js. gameplay.js / world3d.js / cleaned modules / shell / backend / economy / prices / IDs / RPCs not edited. Plaza layout and draw calls unchanged (portrait still 122).

### Root cause (confirmed, also on r7e)
The paid catalog has **4 titles**, not 5: `title_shanxin` 善友, `title_jushi` 雅士, `title_xingzhe` 旅人, `title_gongdezhu` 福缘主 (r6.sql:100-103, display names updated in r7.1.sql). `beads` / 珠串 is a paid **accessory** (kind=accessory, price 400, neck slot), not a title.

Free cosmetics live only in `TG_AVATAR.palette.title`: 雅士, 茶客, 园丁, 旅人, 茶博士, 园主, 游方客, 画师, 药师, 掌柜. Of those, 雅士 and 旅人 also collide with paid catalog names; the eight others are not in `avatar_catalog` at all.

avatar.js `normalize` / `dropLocked` keep a title only when `ownedTitles()` (from `TG_AVATAR_NET.titles()`) has `t.name===cfg.title`. The server list holds only the 4 paid titles, so 茶客 is treated as not owned and is cleared when the face editor opens. Saving then writes an empty title locally and to the server, and other players cannot see it. r7g already skipped `checkOwned` for palette names in the wrapper `normalize`, but it could not see the private `dropLocked` inside `openPanel`; r7g also stripped r7b-ux’s `r7DisplayOnly` injection, so the 茶客 chip could disappear.

### Client fix
- Build a free whitelist from `palette.title` plus any catalog title with `price===0` / `free` / `defaultOwned` (and its `legacy_names`).
- Re-wrap `TG_AVATAR_NET.titles()` (getter/setter + poll, survives late backend replacement) so those free titles are returned as default-owned `{id:name, name, owned:true, price:0, free:true}`. Deduped against paid rows of the same name. `dropLocked` / `normalize` / r6 sanitize then leave them alone.
- `r6OpenAvatar` / `save(wire, titleId)` send the free title’s **name as id** and the same name in the wire `title` field. Paid titles still send the catalog id + catalog name. An empty (“无”) save no longer false-matches the first free row (`titleIdOf('')===titleIdOf('茶客')` was both null).
- Other-player display: wrap `TG_NET.decorate` so if `title_name` is missing, `o.title` falls back to `avatar.title` in the JSON.

### Backend (readable on the box; not edited)
The live SQL (`backend/r7.1.sql`, latest `tg_avatar_reason` / `avatar_save`; not later overwritten by r7.2/r7.3) will still reject a free title even after this client fix, if the player is online.

1. `backend/r7.1.sql` lines 54–56, `tg_avatar_reason`: today any non-empty `p->>'title'` must match `avatar_catalog` kind=title (name or `legacy_names`) **and** `tg_owns`. 茶客 is not in the catalog, so this returns `title_not_owned`.
   Suggested logic: reject only when the text (or id) matches a **paid** catalog title (`price > 0`) that the user does not own. Allow price=0 catalog rows (already `tg_owns` via r6.sql:135), `legacy_names` of those, and names that are not paid catalog titles (free cosmetics, still bounded by `tg_text_reason` max 8).

2. `backend/r7.1.sql` lines 68–74, `avatar_save`:
   - Line 68 rejects `p_title` unless it is a catalog title id the user owns. A client payload with `p_title='茶客'` fails here.
   - Line 71–72 only resolves `p_title` from catalog names. Fine to leave null for free titles.
   - Line 74, if `p_title` is non-null, overwrites `p_avatar.title` with `(select name from avatar_catalog where id = p_title)`. If `p_title='茶客'` were forced through, this would null out the JSON title.
   Suggested logic: if `p_title` is a catalog title id, keep the current ownership check and name normalize. If `p_title` is a free cosmetic name (not a catalog id), set `p_title := null` and **do not** overwrite `p_avatar.title`. If `p_title` is null, only resolve a catalog id when the JSON title matches a catalog title; otherwise keep the JSON text.

3. `backend/r6.sql` lines 181–189, `tg_avatar_json` / `avatar_get`: `title_name` / `title_emoji` come from a join on `avatars.title` (FK to `avatar_catalog(id)`). A free title cannot be stored in that column unless it is added to the catalog. `NET.decorate` in `backend/tg-r6.js` line 177 then sets `o.title = c.title_name`, so other players’ nameplates stay empty even if `avatar.title` in the JSON is 茶客.
   Suggested logic: when `a.title` is null, fall back `title_name` to `a.avatar->>'title'`. (The r7h client already falls back in a decorate wrap, but the server JSON should too.)

Optional cleaner path (still no economy change): insert the eight free names into `avatar_catalog` as kind=title, price=0 (茶客, 园丁, 茶博士, 园主, 游方客, 画师, 药师, 掌柜). Do **not** insert 雅士/旅人 again — those ids already exist as paid titles. Then `tg_owns` is true for price=0, the FK works, and `title_name` is populated. `avatar_buy` already returns reason `free` for price=0 (r6.sql:236).

Live backend was not exercised and no test data was written. Review was of the SQL / `tg-r6.js` sources on the box only.

### Tests (Playwright, late `TG_AVATAR_NET = {…}` with only the 4 paid titles)
12/12 relevant cases passed after the late replacement:
- Paid titles 善友 / 雅士 / 旅人 / 福缘主: local state, intercepted `save(wire, titleId)` (catalog id + catalog name), and a second client `deserialize` + `normalize` (checkOwned false and true) plus decorate-style fallback all kept the title. Display names with emoji.
- Free titles 茶客, 园丁, 茶博士, 园主, 游方客, 画师, 药师, 掌柜: same matrix. Payload is `{title: name, titleId: name}`. Second client renders the title from the wire / avatar JSON.
- 珠串 was probed as a 5th “paid title” and correctly is **not** one: no title chip, face-editor save stores empty. It remains a paid accessory.
- ERR []. Plaza portrait draw calls 122 (unchanged).

- Official shot (inspected): v4/shots/r7h-phone-free-title-save.png — after saving 茶客, the panel HUD and the selected chip still show 茶客; all free titles are listed.
- Final pack 1,565,604 bytes, sha256 c29ac0d3b0bb4396de29af129532cdb24e532c89bab8407b1cd49d6cbbb2a7b3, packed 2026-11-13 23:55:20 +0800. r7h.patch vs index.pre-r7h.html. No publishing or backend changes.

## r8a (in progress checkpoint 2026-11-14 02:00 UTC+8)
- r8.js: shared camera (boom tilt-up before pull-in, enclosure clamp, near-plane push, sign fade, canopy fade incl. realism-swapped mats), plaza/gate/hall fixes, layered horizon, plaza enclosure + south-half props, gate 照壁 court, spawns.
- r7d ring rail: 4 openings + colliders. r7g/r7h: 行客 rename + free_* id mapping. codex2 UI merge done (ui-kit, r7b-ux.patch, emoji).
- codex2 audit (plaza,gate,hall): plaza H1(lion legs, intended) M0, gate 0/0, hall 0/0. Title test ALL pass.
- 02:30 checkpoint: camera tilt fallback (longest free boom, max tilt 1.5 rad), canopy/sign fade snap on reset, gate pines lifted (7), plaza stool colliders; buttons H1 (go() clears #gateLock + blurs; worldBlocked lock only in hall), H2 (demo-code hint/toast removed, text 缘堂; TG_ACCESS path untouched), H3 (#muyu pointer-events), 朱红宫殿→朱红厅堂.
- 02:48 r8a candidate: index.html 1646222 bytes sha b1f5b78867faf0dc78655f99ee9f46d9f0a6711723a8d6318e80d76483d312cb. Clip audit r8a (qa/r8-audit/r8a.md): hall/plaza/gate H/M all fixed except PLAZA-001 (intended lion contact). Walk stuck 0 all scenes. Report qa/r8-scenes.md. Button audit re-run in progress (baseline backed up as buttons.r7h-baseline.*).
- 03:20 triage: codex2 'new' in yard/tea/market are the same baseline issues re-labelled (index.html:line → source file); normalised compare shows 0 new H/M there. Indoor camera: inset .55 + push-out always indoors → STUDY spawn-door M fixed (cand sha 0dab5eb9, not yet in index.html while button audit runs on b1f5).
- 03:35 buttons re-run on b1f5: tested rows H0 (stale r7h portrait-plazahall rows excluded → qa/r8-audit/buttons.r8a.md), M34; coverage partial. Final pack 03:31, clip audit on final started.
- 03:46 FINAL r8a frozen: v4/index.r8a.html 1646244 bytes sha 0dab5eb90c0aa2f4f8f2f82f7f7cc3f20e7a5f7506da55347b40bf5cd390074c (packed 03:30:41). Clip audit on final: 212 fixed / 40 still / 78 new; hall/plaza/gate H/M all fixed except PLAZA-001 (intended). Walk stuck 0 everywhere. Buttons (b1f5): H0 M34 L53 (buttons.r8a.md). Screens r8-{plaza,gate,hall}-{before,after}[-land].png. r8a DONE.

## r8b (yard + market + tea) started 03:47 UTC+8
- base index.r8a.html 0dab5eb9; backup index.pre-r8b.html; src snapshot qa/r8b-base-src (for r8b.patch)
- 04:00 r8a.1 shipped: index.r8a1.html e962056e… (gate = tutorial, no passcode); result in _src/r8a1-result.md; same sidecar appended to r8b r8.js.
- 04:15 r8b: r8b.js added (pack after r8.js), horizon() parameterised (inner/square/seed/valley/villages) → distance for yard/market/tea; market ground trim.
- 04:40 yard pass 1 in r8b.js fixes.yard: north eave folded into a 6.6 m gate roof (brackets/stray plate pruned), stream+bridge removed, bare trunks removed, (13,5) tree out from under the roof, wall-embedded rails pruned, plot soil 0.1 m (ridges proud) + end boards trimmed, gravel/pots/flowers/stone lanterns cleared off the plots, pen signs beside gates, south gate frame+exit+prompt moved to the wall opening (z 21), path to both gates, real 条凳 replaces the 1 m solid block, 罗汉榻 off the doorway, north wall trimmed at jambs.
- Global (r8b.js): furniture = walk to approach point → turn → sit/lie (lerp) → get up back to the approach point; avatar sit pose with hips on the seat (seat top by raycast; r5 put players standing on benches at y .55). Prompt priority: nearest in facing direction, exits ×0.7.
- 04:39 market pass: counters/awnings/poles/globes (mkt3 audit H1 M0 L5; remaining H = tea-stall parasol into the hanging-lantern line → parasol lowered 0.55 m, packed). Next: tea.
- 04:49 r8b PAUSED for r8a.2 (parent steering). State: fixes.tea written (bamboo thinned at osmanthus/wall roof, bridge removed + river bank collider + 放河灯 north bank, wall pots ±3.1, pot flowers/stems, plants pruned in solids, plant/chess/cushion/door/bamboo-strip colliders, cushions face the table, cushion seat low + per-frame hip-on-seat correction), tea horizon inner 23/square 21.5, market parasol lowered. Packed into index.html (unaudited after tea pass; last tea audit r8b-tea0 = H12 M12 L5 pre-fix). Resume: tea audit, seat shots, yard re-audit, buttons, final.

## r8a.2 FROZEN (2026-11-14 05:10 UTC+8)
- v4/index.r8a2.html 1,660,193 B sha256 2a02a2d8df7394eb92b45beb1fe0a69110199ef4ff42f6c68b782b3301ceb675; v4/r8a2.patch; v4/_src/r8a2-result.md; shots qa/r8a2-shots/
- r8a2 camera edits and block carried into the r8b r8.js; index.html re-packed 1,697,667 B, smoke 0 errors. Pre-carry backup: /tmp/r8w/r8b-r8.js.bak
- Resume r8b from the PAUSED list above (re-verify the tea cushion hip correction first, then the tea audit).

## r8b RESUMED 05:11 UTC+8
- 05:15 tea cushions re-verified (seat shots /tmp/r8w/seatshots/t-*.png): hips on cushion, legs under the low table, facing the table.
- 05:20 tea: ghostSync re-links untouched ghost parts after a geometry clone (audit-only bookkeeping); bank-stone bamboo thinned, bush on bank pruned, bonsai side branch pruned, bamboo grove = walk boundary (r8bBounds via worldCanMove wrapper; 46 row colliders dropped), low leaf sprays lifted to 1.45 m, river collider to x 7.6, vase stem moved out of the cushion mesh. Audit r8b-tea2: H0 M1 L1 → stem fix for the M.
- 05:24 yard re-audit r8b-yard3: H0 M0 L5. market r8b-mkt5: H0 M1 → teapot moved off the parasol pole; pole ends at the canopy hub (2.27).
- 05:35 buttons: drawer buttons 44 px (r8b-css); all other M hit areas measure ≥44 in r8b; 意见箱 need_info follow-up box verified with a mocked list.
- 05:40 赏景小记: 「今天适合的小事」 (4 everyday tasks, daily seed), 忌 list removed; second 写一写 press no longer shows raw 宜/忌/吉利方位 (r7d dataset re-armed); direction note follows the chosen direction. NOTE: the second-press raw-result bug exists in frozen r8a1/r8a2 too.
- 05:55 market cart shafts start at the bed end (MKT M fixed); camera: r8b sets W3.r8CameraDt from the frame dt (r8.js used wall-clock dt → harness/idle creep). tree-trace r8b3: jumps 0, idle range 0/0/0 at both points. NOTE for r8a2: its idle "stable" at (3.37,-3.33) was mid-ease under the harness (wall-clock dt), not a real creep in-game.
- 05:55 final audit r8b-final2 (yard,tea,market): H0 M0 L11; normalised vs baseline: new H0 M0 L7; 27/28 baseline H fixed, TEA-009 H→L (OBB of trunk+branches). walk 51/50/50 ok, 0 stuck. ncmp script /tmp/r8w/ncmp.mjs, output /tmp/r8w/ncmp-final2.txt
- 06:01 interrupted during button crawl (/tmp/r8w/btn). New steer: 赏景小记 = ONE gentle sentence, no paired list, no 宜/忌/吉凶/运势/签.
- 06:10 赏景小记 (r8b): result = one sentence per direction (2 per direction, daily pick), e.g. 「院子朝南，阳光正好，今天适合把被子拿出来晒一晒。」; no list, no colours, no footer; banned-word guard; re-armed on every 写一写; centre tile ☯️ → 🏡. Verified: no 宜/忌/吉/凶/运势/签/卦/预测/方位/幸运 in the sheet.
- 06:25 button crawl (portrait, r8b pre-feng build): H1 (manual finding #184, not reproducible in r8b — tested locked & unlocked) M19. Fixed: 🪙 close → toast 商铺已收起; 领取10铜钱 → toast why; ← 回院子 in yard → toast; yard mounts hitched west of the post (5,12.8)+, post range 1.8 (prompts separate); placement summary + 意见箱 label 44 px. 放河灯 "unreachable" not reproducible (stand point (-0.35,9.05) free).
- 06:32 seated → prompt shows 「起身」 (gets up); verified on yard bench.
- 06:15 FREEZE candidate index.r8b.html f55ee469d1817548 — final audit running
- 11-14 06:22 r8b: 放河灯 fix — r6FixTeaInteracts rebuilt tea items after fixScene (direct #tea load left 放河灯 in river + cushion facing lost); wrapper re-applies teaItems(); fixScene only marks fixed when ready (retry from frame loop). RE-FROZEN index.r8b.html sha a81a5383df181db2… Next: freeze audit+ncmp, shots, calls, patch, result.md
- 11-14 06:30 r8b DONE: freeze2 audit H0M0L7 new, 27/28 H fixed, walk ok, calls, shots qa/r8b-shots, patches, r8b-result.md
- 11-14 06:33 r8c START on r8b (a81a5383…): backup index.pre-r8c.html, src base qa/r8c-base-src. Plan: 1 perf (static batcher per scene, horizon merge) 2 hall/zen/study colliders, cam, roof, bed anim 3 audits
- 11-14 06:51 r8c perf: r8c.js static render batching (proxies, sources kept+frustum-hidden, per-frame validation) + avatar rigid skinning. land calls plaza 195→77 market 205→55 tea 129→79 yard →33-44. A/B pixel diff (c/ab.mjs) only shadow-edge noise after world-UV normal fix (tgUVN). Tools /tmp/r8w/c/{calls,ab,diff.py,keys,diag,pick}.mjs. Next: all-scene table both vp, frame time, then hall/zen/study.
- 11-14 07:15 r8c rooms: r8c.js shell (ceiling/lining/floor ring/vestibules) hall,zen,study; furnish(): lamp split (wallSign fade), r8cNoCam (r8.js cameraMeshes skip), colliders lamps/stools/side table/shelves→wall/desk drawn footprint; zen stools face table; study 案前 sit first; indoor yaw swing (no boom collapse). gap test c/room.mjs → ~0 magenta. Next: audit hall,zen,study; furniture anim (bed edge-sit); shots.

## r8c checkpoint 07:23 (UTC+8) — audit r8c-3
- lamps: own mesh, r8cFade (fadeSigns list) + r8cNoCam, no wallSign → camera treats as blocker, still fades. r8.js fadeSigns list += r8cFade.
- audit r8c-3 (hall,zen,study): hall H0 M0 L3; zen H0 M0 L6; study H0 M1 L4. Remaining M: STUDY-001 desk block 17% covered.
- desk geometry: slab y .87–1.03, x ±1.0, z −3.75..−2.25 with NO legs in |x|<1.2 → audit finds no item there (slab probably merged into a wider component). Next: investigate desk item, fix block/visible geometry.
- 07:30 study desk split into own mesh r8c-desk (slab+panel legs, ±1.0×−3.75..−2.25, y0..1.03); block = that box ±.02. Next: audit r8c-4.
- 07:36 codex2 r8b-recheck (in progress) read: only H = PLAZA-001 (pre-existing old art3 box-lion parts inside/in front of r6 lions) → r8c plazaLions() collapses those 12 instances. L suggestion: delete raw fortune text from source (consider).
- 07:40 plazaLions tried and DISABLED: those art3 boxes are the lion's eyes/muzzle/front legs (shot c/lion-ab.jpg) → removal = visual regression; PLAZA-001 stays as structural, report it.
- 07:45 audit r8c-4 hall/zen/study: H0M0 (L3/L6/L4). normalised: vs baseline new H0 M0 L9 (fixed H8 M20); vs r8b(codex2 r8b.json) new H0 M0 L10, fixed M12; vs r8a: ZEN-005/006 STUDY-004/005 fixed. files /tmp/r8w/ncmp-r8c4-*.txt
- 07:58 bed anim coded in r8b.js (src): bedPlan/bedTick phases edge(.45s)→lie(.7s)→sat; get up rise(.6s)→stand(.35s). Next: test on yard daybed + shots.
- 08:05 bed anim verified yard daybed portrait+landscape: walk>turn>edge>lie>sat>rise>stand, head (4.62) at pillow (4.55), body along long x axis; rise one-frame glitch fixed. shots c/bed/{m,l}-*.png
- 08:12 seat shots c/seats: zen 4 stools face table edge (±x, perpendicular to long side), hips y .45 on stool; study cushion faces desk 0°, practice sheet opens after sat. Next: perf final table + frame time.
- 08:20 PRIORITY steer: codex2 r8b H/M first: (1) null.trim pageerror tea 留笺 / lotus buttons after face-editor crawl (2) remove fortune source text (3) zen 坐下喝茶 facing (4) ignore 坐下 no-feedback. perf.mjs run continues in bg (c/perf.log).
- 08:22 perf-1 done (c/perf-1.log): calls r8b→r8c land plaza 195→77 gate 93→47 hall 56→26 yard 133→44 zen 40→27 study 37→26 market 205→56 tea 133→81 lotus 102→55 (max of 8 yaws); portrait plaza 167→66 market 158→46 tea 119→75. SwiftShader ms NOT better (land market 107→203?) → re-measure later. Now: codex2 items.
- 08:24 steer+: 每日诗签→每日诗笺 (no 签 in that feature's display), zen facing fix in r8 layer (not r7b.js). chrome 496865 not mine (started after my perf).
- 08:35 null.trim: cause = three getProgramInfoLog/getShaderInfoLog().trim() on a lost context (捏脸 preview renderer forceContextLoss / SwiftShader). r8c-0 guard (prototype returns ''). crawler tea,lotus portrait running r8b then r8c (/tmp/r8w/btn).
- 08:50 诗签→诗笺: r8c-0b runtime rewrite (text nodes/attrs MutationObserver, canvas fillText, item labels) verified (#stallQian, injected help text, aria). r8b.js comment de-worded. zen facing already in r8c furnish() (rot x<0?π/2:-π/2) — shots c/seats.
- 09:05 null.trim verified: deterministic lost-context render → r8b THROW null.trim, r8c no throw (c/trim.mjs); 捏脸×3 + 留笺/采莲/河灯/锦鲤 sequence 0 pageerrors both (flaky in r8b; codex2's own repro also 0). crawler tea,lotus portrait r8b 0 trim (flaky).
- 09:12 r8c crawler tea,lotus portrait: 105 actions, 0 pageerror. Next: A/B render timing c/abtime.mjs (contention-proof: other agent's chrome was running during perf-1 r8c).
- 09:22 abtime2 (c/abtime2.log): CPU submit plaza 3.2→1.8 ms, market 2.0→1.3; SwiftShader GPU ms equal within noise (fill-bound). Next: freeze candidate, full 9-scene audit, shots, patches.
- 09:30 FROZEN candidate v4/index.r8c.html a97278fe…, 1,745,102 B; patches r8c.patch 41,006 B / r8c-src.patch 43,387 B (pack.mjs, r8.js, r8b.js, r8c.js only). running: full audit r8c-final, room shots.
- 09:50 r8c DONE: final audit r8c-final (new vs r8b H0 M0 L10), walk 0 stuck, room shots qa/r8c-shots/rooms, r8c-result.md written.
- 08:20 r8c.1 PREP start: hall ceiling lighter (material/light only), freeze-r8c1 script. index.r8c.html frozen — never modify.
- 08:32 steer: wish-tag visibility at plaza tree (camera tilt after hang, canopy bias near tree, HUD not covering tags, tree-trace 0 jumps) after ceiling; freeze script written v4/_src/freeze-r8c1.mjs (untested).
- 08:40 hall ceiling: hall-only clone of wall mat, emissive #7a6142 ×.6 with its own map. shots qa/r8c1-shots (hall-ab.jpg); zen/study diff ≤0.06% px (noise).
- 08:45 wish tags done (focus ease k 0→1, tap opens card, HUD clear logic; wishhud test interrupted). steer: apply codex2 compliance patches A,B; r7.js tables; gameplay 祠堂/炷香 hints; freeze r8c1 + src patch. r7c/r7d/gameplay are OURS.
- 08:52 applied codex2 A-r7d-slim + B-stall-labels (node --check ok). r8c1 src base = qa/r8c1-base-src (r8c-base-src + r8c-src.patch). pre-AB copy /tmp/r8w/src-pre-AB
- 09:00 r7.js fortune pairs removed (灵签/求签/算卦/看风水/抽签); gameplay.js toasts/help/name 祠堂→缘堂, 炷香→盏灯 (= former runtime text); r8c-0b runtime rewrite removed. packed.
- 09:05 freeze script extended (wider grep, stall smoke, r8c1-src.patch). dry run --no-freeze.
- 08:45 r8c.1: wishhud OK (HUD cleared pe:none, hit→canvas, m+l); tree-trace r8c1 0 jumps (qa/r8c1-shots/tree). Next: freeze dry2.
- 08:48 r8c.1: freeze dry2 OK (0 err, max 79 calls, bannedVisible none, stalls found); 今日心语 harness wait fixed; r8c-result.md ownership corrected. Next: real freeze.
- 08:51 r8c.1 FROZEN: v4/index.r8c1.html sha de2ce127… 1,741,088 B; r8c1.patch, r8c1-src.patch; r8c1-result.md. (note: the 09:00/09:05 stamps above were mis-entered; actual ≈08:3x UTC+8)
- 09:43 r8d start: base r8c1 de2ce127; backup v4/index.pre-r8d.html; qa/r8d-base-src; pack.mjs += r8d.js. Baseline metrics = qa/r8-smooth (r8c1).
- 09:51 r8d items coded: r8d.js (prewarm silent-visit+batchNow+compileAsync+upload, render counter, fade helper, moving hysteresis, cadence, joint limiter, modal close anim, 3D throttle, toast queue); gameplay.js go() fade waits opaque + 2 frames; r6.js moving; r8b.js seat/bed easing; r8.js camera rate limits + pump hold; r7c petals per-petal; r7b dead hall wind removed; r8c.js R8C.batchNow. Next: test.

- r8d 09:59 UTC+8: pre-upload moved in-frame (1px scissor, on-screen variants) → programs 184→184 after warm (was +61 with RT). Warm profiler: cost is sync shader compile (getProgramInfoLog/getShaderInfoLog ≈18 s on SwiftShader) inside worldEnter→worldResize render; inherent work moved from first visits to idle boot. Mitigation: warm only after ≥1.5 s with no pointer/key input, tab visible, 400 ms+idle gap per scene.

- r8d PAUSED 10:04 UTC+8 (parent: hall restoration r8c.2 first). WIP backup: qa/r8d-wip-1004 (_src, index.r8d-wip.html, qa scripts). Done so far: all P1/P2/P3 items coded; timing portrait r8d: 0 new programs per switch (r8c1 33), programs 184 flat, bufferData in switches 40 (r8c1 1550), gate-first apply() main-thread 13 ms (r8c1 1776 ms), 0 errs. Pending: landscape timing, anim/animals/ui/leaves, audit, tree-trace, draw calls, freeze.

- r8c.2 STARTED 10:13 UTC+8 (hall restoration; isolated src at qa/r8c2/src = r8c1 src copy, packs to qa/r8c2/index.html, verified r8c1 sha reproduces). Cause found: r7.js build() removed every v13 hall object (world3d/art2/r3/enhance art) and r7.js worldSyncHall hid art3 「古朴木作」 (朱漆柱/窗棂/额枋/宫灯/红毯); r7c rebuilt a bare room. Fix: r7.js stashes the removed objects (h.r7Legacy); new r8c2.js re-adds them (minus r7c/r8c-owned floor collider/walls/ceiling/altar dup, muyu, ancestral-tablet boards/text), un-hides art3 wood style, neutral text (couplets 花香满院/竹影临窗, door titles = current scene names, plaque 家和业兴), procedural paintings (山水/梅花/荷花), burner→flower planter, vase on side table, colliders for pillars/vessel/side table, entry view (0,1.6) yaw 0 pitch .15 r 6.

- r8c.2 FROZEN 10:41 UTC+8: v4/index.r8c2.html sha d401b494aafc2fc41482ddc1278f3fcb64743713179ebfc205631a5810842924 (1,764,848 B); r8c2.patch 31,179 B, r8c2-src.patch 33,950 B; hall + remote plates + raw user text. See r8c2-result.md. Next: re-apply to r8d line, then stop.

- r8d line: r8c2 re-applied 10:44 UTC+8 (r8c2-src.patch minus pack hunk; pack order …r8c.js,r8c2.js,r8c2b.js,r8d.js). v4/index.html repacked 1,780,744 B. Verified: hall view identical to r8c2, remote plates/raw text test pass, 0 page errors. r8d PAUSED per parent (resume: landscape timing, anim/animals/ui/leaves, audit, tree-trace, draw calls, freeze; r8d.patch should diff against r8c2 and r8d-src base should become qa/r8c2/src).

- r8d RESUMED 10:46 UTC+8 on r8c2 base (patches vs index.r8c2.html / qa/r8c2/src). New: time-sliced non-blocking pre-warm (≤~8 ms/frame, KHR_parallel via compileAsync, yield on input, next-scene-first) + metrics (longest warm frame, first interactive frame); hall point-light program reduction; r8c2 hall M items.

## r8d checkpoint 1 (2026-11-14 UTC+8, warm v2b)
- base: r8c2 (src diff vs qa/r8c2/src, build diff vs index.r8c2.html)
- warm v2b in r8d.js: renders suppressed during silent visits; the r7b-ux whole-scene compile is replaced by a sliced compile (one top-level child per idle slice, ≤6 ms, cMax 8–15 ms); a polled WebGL2 fence waits for the GPU without blocking; then per-object first use via layer 31 + 1×1 scissor, ≤6 ms and ≤1 never-used program per frame; any input pauses everything for 1.5 s; order = BFS from the current scene's exits.
- probe qa/r8-smooth/warmprobe.mjs → warm-r8d-quiet3-portrait.json, warm-r8d-input-portrait.json
- SwiftShader (no KHR_parallel_shader_compile): one program's first use is atomic (~0.5–1.1 s); one-time per-scene builders (r8/r8b fixScene) are atomic 30–320 ms.
- results: maxFrame during warm 1233 ms (quiet) vs old warm 4333; input latency while warming median ~170 ms, max 777 (the 1489 ms one was at boot) vs normal-play latency after warm 200–733 ms (frame median 450 ms on this box). programs 218–221 (was 278–309).

## r8d checkpoint 2 (hall lights shared)
- r8d.js §1b shareLights(): the 3 hall PointLights are re-parented to scene level (full intensity in the hall, 0 elsewhere), so there's one light setup → one program key everywhere.
- programs after warm 221 → 182 (portrait); cold landscape after hall 286 → 225; hall itself uses 19 programs (was 21).
- shots: qa/r8d-shots/hall-lights/compare-{portrait,landscape}.png (row 1 = before/off, row 2 = after/on); pixel diff is only the player's idle sway; the altar view is bit-identical.
- render cost (readPixels-synced, SwiftShader) plaza 189 vs 271, gate 68 vs 88, market 73 vs 78 ms: no measurable cost.

## r8d checkpoint 3 (hall M items, r8d line r8c2.js only — frozen r8c2 untouched)
- candle flame: flames() on hall enter lifts the art2 #ffffa7 flame parts by 0.09 m (base 2.19 on a 2.2 m candle top); lantern cords moved +0.37 (was +0.2) → bottom 4.32 vs cap 4.35; art3 pillar colliders (8 × 0.56 m) → camera sample (-5.5,.75) no longer walkable.
- hall audit qa/r8d-audit/hall-r8d.md: H0 M0 L8 (r8c2: 4 M = 2 clip + 2 camera); walk 53/53, 0 stuck.

- 11:28 UTC+8 parent edit kept: r7.js:13 RAWSEL without ',.tgs-dm' (backend marks DM content data-raw). Repacked; timing-r8d-portrait started 11:28:14 on the build just before this (RAWSEL only, no perf effect).
- 11:30 UTC+8 parent edit kept: r7b-ux.js neighbour filter (empty search → hidden=false, show all). Repacked.

## 12:50 UTC+8 r8c2c frozen (H-1 + H-2 only) — see qa/r8c2c/r8c2c-result.md; sha d456a527…67d98b, 1,769,787 B
- next: sync r8c2c.js into r8d (_src), r8d-only M-1/M-2/M-3, audio lazy-load merge + bgm culprit, sharedLights default OFF (it costs 25–100 % play frame time: r8d 83/233/100 ms vs nosl 67/150/50 ms in market/tea/lotus), then finish r8d.

## 13:20 UTC+8 r8d line synced with r8c2c (r8c2c.js in pack before r8d.js; camera part extended to 静室/书房 for M-2), audio.js = qa/audio-lazy, M-1 (r8c.js HUD fade), sharedLights default OFF
- room sweep qa/r8d/roomsweep.mjs (walk grid + furniture centres × 4 yaws, boom snapped after teleport): min head distance hall 0.92 / zen 1.15 / study 1.12 m, floor-only 0, head off-screen 0 (r8c1 codex indoor: 0.07 / 0.09 / 0.11).
- bgm culprit: r5.js:56 audio.setOn(!tgMuted), tgMuted from the legacy key templeGarden.mute (enhance.js:3) → S.on=true even with templeGarden.bgm='0'. With bgm='0' + mute='1' the off branch is reached: isOn false, no AudioContext created (qa/r8d/bgmtest.mjs).
## 14:17 UTC+8 r8d FROZEN — see v4/_src/r8d-result.md, qa/r8d/r8d-metrics.md; sha 4d791e71…b0a7f9
