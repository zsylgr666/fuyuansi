import {chromium} from '/workspace/temple-garden/node_modules/playwright-core/index.mjs';
import http from 'node:http';import fs from 'node:fs';
const server=http.createServer((q,r)=>{r.setHeader('content-type','text/html');r.end(fs.readFileSync('/workspace/temple-garden/v4/index.html'));});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const report={};
try{
for(const scene of ['plaza','yard','hall','zen','study','market','lotus','gate']){
 const p=await browser.newPage({viewport:{width:390,height:844}});
 await p.goto('http://127.0.0.1:'+server.address().port+'/#plaza');await p.waitForFunction(()=>window.W3?.active);
 await p.evaluate(async scene=>{S.unlocked=true;switching=false;await go(scene,true);document.querySelector('#gateLock').classList.remove('show');document.querySelector('#gateLock').style.display='none';worldStop();
 const previous={plaza:'yard',yard:'plaza',hall:'yard',zen:'hall',study:'hall',market:'plaza',lotus:'hall',gate:'plaza'}[scene];worldEnter(scene,previous);
 if(scene==='zen'||scene==='study')W3.yaw=0;
 if(scene==='market'){W3.player.position.set(0,0,12);W3.follow.copy(W3.player.position).y=1.1;W3.yaw=0;}
 worldCamera(1);
 },scene);
 await p.waitForTimeout(350);
 report[scene]=await p.evaluate(()=>{const maxY=W3.camera.position.y;const calls=[];const yaw=W3.yaw;for(const y of [0,1.57,3.14,4.71]){W3.yaw=y;worldCamera(1);W3.renderer.render(W3.scene,W3.camera);calls.push(W3.renderer.info.render.calls);}W3.yaw=yaw;worldCamera(1);W3.renderer.render(W3.scene,W3.camera);document.querySelector('#toast').classList.remove('show');return {calls,camera:W3.camera.position.toArray(),player:W3.player.position.toArray(),maxY};});
 await p.screenshot({path:'/tmp/codex-v4-r5/'+scene+'.png'});await p.close();
}
fs.writeFileSync('/tmp/codex-v4-r5/pass2-capture.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
}finally{await browser.close();server.close();}
