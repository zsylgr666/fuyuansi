/* r8c.2c hotfix — 缘堂 only (r8d line: the camera part also covers 静室 / 书房, M-2).
   H-1: the third-person camera never collapses into the head. The camera chain runs unchanged; afterwards, if the eye is
        closer than 0.9 m to the head (squeezed by the altar / planter / back-wall colliders), it eases (≈0.15 s) to a raised
        view above and slightly behind the player, looking down at the chest — never a floor-only frame. The chain keeps its
        own previous output, so its smoothing state is not disturbed; hysteresis 0.9 / 1.3 m.
   H-2: the copper 点灯 lamp moves from (2,2) to (3.2,2) with its prompt and collider, so the spawn (0,1.6) is outside
        every interaction radius (the prompt no longer covers 🎐 in landscape) and the planter is no longer hidden behind it. */
(()=>{const T=THREE;const R=window.TG_R8C2C={version:'r8c2c',cam:{raisedFrames:0,minD:99},lamp:null};
const LAMP_X=3.2,HEAD=1.45,IN=.9,OUT=1.3,CEIL={hall:5.2,zen:4.2,study:4.2};
function moveLamp(){const h=W3?.spaces?.hall;if(!h)return;const lamp=h.group.getObjectByName('r7-copper-lamp');if(!lamp)return;
 if(!lamp.userData.r8c2cMoved){const x0=lamp.position.x,z0=lamp.position.z,dx=LAMP_X-x0;lamp.position.x=LAMP_X;lamp.userData.r8c2cMoved=true;lamp.userData.r8c2cFrom=[x0,z0];lamp.updateMatrixWorld(true);
  let items=0;for(const it of h.items)if(Math.hypot(it.x-x0,it.z-z0)<.3){it.x+=dx;items++;}
  R.lamp={from:[x0,z0],to:[LAMP_X,z0],items};}
 // collider (r8.js adds it from the lamp's box, possibly before or after this move): keep it on the lamp
 const [x0,z0]=lamp.userData.r8c2cFrom,dx=LAMP_X-x0;for(const b of h.blocks)if(b.r8a==='copper lamp'&&!b.r8c2c&&Math.abs((b.x+b.X)/2-x0)<.2&&Math.abs((b.z+b.Z)/2-z0)<.2){b.x+=dx;b.X+=dx;b.r8c2c=true;}}
// the raised eye must have a clear line to the head (beams, lintels, lanterns, lattice): real raycast against the hall's
// visible meshes, cached per 0.25 m cell × yaw sector, so it only runs when the player moves into a new cell while raised
let meshes=null,meshScene=null,meshAt=0,meshSig='';const cache=new Map();
// r8d1: the list is refreshed every second (r8c batch proxies appear / originals are hidden after entry); caches drop when it changes
function hallMeshes(){const n=W3.active,now=performance.now();if(meshes&&meshScene===n&&now-meshAt<1000)return meshes;meshAt=now;const h=W3.spaces[n];h.group.updateMatrixWorld();const m=[];
 h.group.traverse(o=>{if((o.isMesh||o.isInstancedMesh)&&!o.isSprite&&!o.userData.r7Particle&&visUp(o))m.push(o);});const sig=n+':'+m.length+':'+(h.r8c?.batches?.length||0);
 if(sig!==meshSig||meshScene!==n){meshSig=sig;meshScene=n;cache.clear();bcache.clear();lbT=0;}meshes=m;return meshes;}
// r8d1: small hanging decor (chime, cords, tassels) never moves the camera — only solid pieces (bounding radius ≥ 0.35 m, merged batches, instanced)
function solid(o){if(o.isInstancedMesh||o.userData.r8cBatch||o.name==='r8c-batch')return true;const g=o.geometry;if(!g)return false;if(!g.boundingSphere)g.computeBoundingSphere();const sc=o.matrixWorld.getMaxScaleOnAxis();return g.boundingSphere.radius*sc>=.35;}
const V=new T.Vector3(),head=new T.Vector3(),rp=new T.Vector3(),look=new T.Vector3(),q1=new T.Quaternion(),m4=new T.Matrix4(),prevPos=new T.Vector3(),prevQ=new T.Quaternion(),rc=new T.Raycaster(),dir=new T.Vector3();
const visUp=o=>{for(let q=o;q;q=q.parent)if(!q.visible)return false;return true;};
function firstHit(from,to,near){dir.subVectors(to,from);const L=dir.length();if(L<1e-3)return null;dir.normalize();rc.set(from,dir);rc.near=near;rc.far=L;const h=rc.intersectObjects(hallMeshes(),false).find(x=>visUp(x.object)&&solid(x.object)&&!holdsHead(x.object));return h?h.distance:null;}
const HB=new T.Box3(),HV=new T.Vector3();function holdsHead(o){if(o.isInstancedMesh||o.name==='r8c-batch')return false;const g=o.geometry;if(!g)return false;if(!g.boundingBox)g.computeBoundingBox();HB.copy(g.boundingBox).applyMatrix4(o.matrixWorld);return HB.containsPoint(head)&&HB.getSize(HV).length()<4;}
// r8d1 (M-3): a segment is blocked if a face is hit in either direction (one-sided lattice / panels seen from behind)
function blockAt(from,to,near){const L=from.distanceTo(to);const f=firstHit(from,to,Math.max(near,.35));const r=firstHit(to,from,.02);const t=Math.min(f??99,r!=null&&L-r>.35?L-r:99);return t<L-.02?t:null;}/* hits within 0.35 m of the head (decor the player stands under) are ignored */
// r8d1 (M-3): keep the eye ≥ 0.18 m from any surface (6 axis probes) so the near plane never cuts into a wall / lattice / pillar
const AX=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]].map(v=>new T.Vector3(...v)),NP=.18;
function nearPush(pos){let m=false;for(const ax of AX){rc.set(pos,ax);rc.near=0;rc.far=NP;const h=rc.intersectObjects(hallMeshes(),false).find(x=>visUp(x.object));if(h){pos.addScaledVector(ax,-(NP-h.distance));m=true;}}return m;}
let legacy=false;/* player inside a collider (teleported into furniture — not reachable by walking): behave exactly like r8d */
function clear(from,to){if(legacy){dir.subVectors(to,from);const L=dir.length();dir.normalize();rc.set(from,dir);rc.near=.3;rc.far=L+.25;return !rc.intersectObjects(hallMeshes(),false).find(x=>visUp(x.object));}return blockAt(from,to,.3)==null;}
R.dbg={blockAt:(a,b,n)=>blockAt(new T.Vector3(...a),new T.Vector3(...b),n??.2),meshes:()=>hallMeshes().length,firstHit:(a,b,n)=>firstHit(new T.Vector3(...a),new T.Vector3(...b),n??.2)};
// r8d1 (M-3): the chain's eye must also see the head — camera colliders don't include the lattice / thin panels. Cached per 0.25 m cell × eye 0.2 m cell.
const bcache=new Map(),lbE=new T.Vector3(1e9,0,0),lbH=new T.Vector3();let lbT=0,lbR=null,lbN=0;
function eyeBlock(p,eye,d){const now=performance.now();if(lbT&&lbE.distanceToSquared(eye)<.0064&&lbH.distanceToSquared(head)<.0064&&++lbN<3)return lbR;/* re-cast when eye/head moved > 8 cm, else every 3rd frame */
 lbN=0;lbE.copy(eye);lbH.copy(head);lbT=now;lbR=blockAt(head,eye,.2);R.cam.brays=(R.cam.brays||0)+1;return lbR;}
function raised(w,out){const p=w.player.position,L=w.spaces[w.active].limit,H=CEIL[w.active]||5.2,key=(legacy?'L':'')+Math.round(p.x*4)+','+Math.round(p.z*4)+','+Math.round(w.yaw*8/Math.PI);
 const c=cache.get(key);if(c)return out.set(p.x+c[0],p.y+c[1],p.z+c[2]);
 const ys=[2.3,1.9,1.5,1.1],hbs=[.35,.15,.6];let pick=null;
 for(const up of ys){for(const hb of hbs){out.set(p.x+Math.sin(w.yaw)*hb,p.y+HEAD+up,p.z+Math.cos(w.yaw)*hb);out.x=Math.max(-L.x+.3,Math.min(L.x-.3,out.x));out.z=Math.max(-L.z+.3,Math.min(L.z-.3,out.z));out.y=Math.min(out.y,H-.35);
  if(clear(head,out)){pick=[out.x-p.x,out.y-p.y,out.z-p.z];break;}}if(pick)break;}
 // r8d1 (M-3): nothing fully clear (tight corners by the lattice / pillars) → best partial candidate, eye stopped 0.22 m short of its first hit
 if(!pick&&!legacy){let best=null,bt=-1;const cand=new T.Vector3();for(const up of [1.9,1.5,1.1,.7])for(const [sx,sz] of [[0,.35],[.45,0],[-.45,0],[0,-.35],[.3,.3],[-.3,.3]]){const sy=Math.sin(w.yaw),cy=Math.cos(w.yaw);
   cand.set(p.x+sy*sz+cy*sx,p.y+HEAD+up,p.z+cy*sz-sy*sx);cand.x=Math.max(-L.x+.3,Math.min(L.x-.3,cand.x));cand.z=Math.max(-L.z+.3,Math.min(L.z-.3,cand.z));cand.y=Math.min(cand.y,H-.35);
   const Lc=cand.distanceTo(head),t=blockAt(head,cand,.05);const free=t==null?Lc:t-.22;if(free>bt){bt=free;best=V.subVectors(cand,head).normalize().multiplyScalar(Math.max(.3,Math.min(Lc,free))).add(head).clone();}}
  if(best&&bt>=IN)pick=[best.x-p.x,best.y-p.y,best.z-p.z];}/* < 0.9 m free everywhere (player teleported into a piece) → plain overhead fallback as in r8d */
 if(!pick)pick=[Math.sin(w.yaw)*.25,HEAD+1.2,Math.cos(w.yaw)*.25];/* never exactly overhead (degenerate lookAt) */R.cam.rays=(R.cam.rays||0)+1;if(cache.size>4000)cache.clear();cache.set(key,pick);return out.set(p.x+pick[0],p.y+pick[1],p.z+pick[2]);}
/* r8d1 (M-N1): steep views — up vector in the view's own vertical plane (horizontal aim direction, or the walking yaw when looking almost straight down),
   so the roll never flips 180° when the aim crosses under the eye (a flip took the 230°/s limiter > 1 s and lost the player) */
const UPV=new T.Vector3();function lookM(eye,t){const w=W3;UPV.set(t.x-eye.x,0,t.z-eye.z);const hz=UPV.length(),dv=Math.abs(t.y-eye.y)+1e-6;
 UPV.x-=Math.sin(w.yaw)*.25*dv;UPV.z-=Math.cos(w.yaw)*.25*dv;const l=Math.hypot(UPV.x,UPV.z)||1;UPV.x/=l;UPV.z/=l;UPV.y=2;UPV.normalize();return m4.lookAt(eye,t,UPV);}/* continuous blend: aim direction, plus the walking direction weighted by how steep the view is */
let k=0,had=false,settle=false,outOK=false,wasPull=false;const F2=new T.Vector3(),aim=new T.Vector3(),V2=new T.Vector3();const outPos=new T.Vector3(),outQ=new T.Quaternion(),basePos=new T.Vector3();
const cam=worldCamera;worldCamera=function(a){const w=W3;const on=!!CEIL[w?.active]&&S.view!=='fp'&&!w.r6Plan&&!(typeof r6IsRiding==='function'&&r6IsRiding());
 if(on&&had&&(k>0||wasPull||settle)){w.camera.position.copy(prevPos);w.camera.quaternion.copy(prevQ);}// hand the chain its own last output
 const out=cam.apply(this,arguments);if(!on){k=0;had=false;settle=false;outOK=false;return out;}
 try{const c=w.camera,p=w.player.position;prevPos.copy(c.position);prevQ.copy(c.quaternion);had=true;head.set(p.x,p.y+HEAD,p.z);
  let d=c.position.distanceTo(head);const dt=a>=1?1:(a>0?Math.min(.1,-Math.log(1-a)/6):1/60);// worldCamera(1-exp(-6·dt)) → frame dt
  // r8d1 (M-3): eye behind / inside geometry → pull it in along the head→eye line to just in front of the hit (or raise below 0.9 m)
  legacy=!w.r5Seat&&typeof worldCanMove==='function'&&!worldCanMove(p.x,p.z);
  // r8d1 (M-N1): the chain's own aim point, taken before any pull / raise / limit moves the eye
  F2.set(0,0,-1).applyQuaternion(c.quaternion);aim.copy(c.position).addScaledVector(F2,Math.max(.5,d));
  let pull=false;const tb=d>.35&&!legacy?eyeBlock(p,c.position,d):null;if(tb!=null){const nd=Math.max(.05,tb-.22);V.subVectors(c.position,head).normalize();c.position.copy(head).addScaledVector(V,nd);d=nd;pull=true;R.cam.pulls=(R.cam.pulls||0)+1;}
  const want=d<IN?1:d>OUT?0:(k>.5?1:0);k+=(want-k)*(a===1?1:1-Math.exp(-dt*8));if(want===0&&k<.01)k=0;if(want===1&&k>.99)k=1;
  if(k>0){raised(w,rp);const e=k*k*(3-2*k);basePos.copy(c.position);c.position.lerpVectors(basePos,rp,e);look.set(p.x,p.y+.9,p.z);lookM(c.position,look);q1.setFromRotationMatrix(m4);c.quaternion.slerpQuaternions(prevQ,q1,e);R.cam.raisedFrames++;}
  // r8d: same per-frame limits as the r8.js boom (≤13 m/s, ≤230°/s) while raised or settling back, so entering/leaving the raised view never jumps
  // r8d1 (M-N1): aim point of the wanted view, so a clamped / pushed eye still looks at what the wanted eye looked at (never at the floor beside the player)
  if(k>0)aim.lerp(V2.set(p.x,p.y+.9,p.z),k*k*(3-2*k));/* raised: aim at the chest itself */
  if(a<1&&outOK&&(k>0||settle||pull||wasPull)){const st=Math.max(.06,13*dt),mv=V.subVectors(c.position,outPos);if(mv.length()>st)c.position.copy(outPos).addScaledVector(mv.normalize(),st);
   lookM(c.position,aim);const tq=new T.Quaternion().setFromRotationMatrix(m4);c.quaternion.copy(outQ).rotateTowards(tq,(230*Math.PI/180)*dt);settle=k>0||c.position.distanceTo(prevPos)>.02||c.quaternion.angleTo(prevQ)>.01;}else settle=false;
  // limiter state = the eye before the near-surface push, so the push can never hold the eye back from where it is heading (r8d1 M-N1: no stall)
  const limPos=V2.copy(c.position);if(!legacy)try{if(nearPush(c.position)){F2.set(0,0,-1).applyQuaternion(c.quaternion);aim.copy(limPos).addScaledVector(F2,Math.max(.5,limPos.distanceTo(head)));lookM(c.position,aim);c.quaternion.setFromRotationMatrix(m4);}}catch(e){}
  // head must stay on screen: if the rate-limited view lost it, turn faster (≤600°/s) toward the head
  if(a<1){c.updateMatrixWorld();V.copy(head).project(c);if(Math.abs(V.x)>.95||Math.abs(V.y)>.95||V.z>1){lookM(c.position,look.set(p.x,p.y+1.1,p.z));const hq=new T.Quaternion().setFromRotationMatrix(m4);if(outOK&&outQ.angleTo(hq)<c.quaternion.angleTo(hq))c.quaternion.copy(outQ);/* start from last frame's (on-target) view, not the chain's lost one */c.quaternion.rotateTowards(hq,(600*Math.PI/180)*dt);c.updateMatrixWorld();V.copy(head).project(c);if(Math.abs(V.x)>1||Math.abs(V.y)>1||V.z>1)c.quaternion.copy(hq);R.cam.headFix=(R.cam.headFix||0)+1;}}
  wasPull=pull;c.updateMatrixWorld();outPos.copy(limPos);outQ.copy(c.quaternion);outOK=true;
  R.cam.k=+k.toFixed(3);R.cam.minD=Math.min(R.cam.minD,c.position.distanceTo(head));}catch(e){R.cam.err=String(e);}
 return out;};
{const en=worldEnter;worldEnter=function(){const r=en.apply(this,arguments);try{if(W3?.active==='hall')moveLamp();meshes=null;cache.clear();bcache.clear();lbT=0;}catch(e){R.err=String(e);}k=0;had=false;settle=false;outOK=false;return r;};}
try{moveLamp();}catch(e){}
{const t=tgAnimate;tgAnimate=function(){const r=t.apply(this,arguments);try{if(W3?.active==='hall')moveLamp();}catch(e){}return r;};}
})();
