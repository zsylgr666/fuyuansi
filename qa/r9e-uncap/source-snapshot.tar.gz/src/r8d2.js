/* r8d2: (1) avatar editor 「随机」 never lands on religious options (avatar.js is codex2's: wrapped at runtime);
   (2) fake ground shadow under remote players — ONE InstancedMesh (shared circle geometry + basic material, transparent, depthWrite off) = 1 draw call for all remotes;
   (3) backend tg-garden notes (.tgg-notes, not our file) pass through the page rewrite as soon as they are written. */
(()=>{
'use strict';
const T=THREE;const R8D2=window.TG_R8D2={version:'r8d2',rand:{clicks:0,retries:0,fallback:0},shadow:{on:true,n:0}};
// --- (1) retired options = monk robe (sengpao), prayer beads (beads), incense (NPC-only); avatar.js r8d3 already never rolls the first two — this stays as a guard
const REL=c=>!!c&&(c.outfit==='sengpao'||c.acc?.neck==='beads'||c.acc?.hand==='incense');/* r8d3: 光头 / 玉串 are ordinary (来福 19:21) — only the retired robe / beads and NPC incense */R8D2.isReligious=REL;
function hookPanel(pn){try{const b=pn?.root?.querySelector('.tgav-top button[aria-label="随机外观"]');if(!b||b.dataset.r8d2)return;const orig=b.onclick;if(typeof orig!=='function')return;b.dataset.r8d2='1';
  b.onclick=function(ev){R8D2.rand.clicks++;let i=0;orig.call(this,ev);const MONK=c=>!!window.TG_R8D3?.isMonk?.(c);/* r8d3: also reroll monk-looking randoms */while((REL(pn.config)||MONK(pn.config))&&i<60){i++;orig.call(this,ev);}R8D2.rand.monkLeft=(R8D2.rand.monkLeft||0)+(MONK(pn.config)?1:0);R8D2.rand.retries+=i;
   if(REL(pn.config)){R8D2.rand.fallback++;/* practically unreachable (p<1e-12): set safe values through the editor's own chips */
    const c=pn.config,pick=(tab,sel)=>{pn.setTab(tab);pn.root.querySelector(sel)?.click();};if(c.outfit==='sengpao')pick('outfit','.tgav-chip[data-id="daopao"]');
    if(c.acc?.neck==='beads'||c.acc?.hand==='incense'){pn.setTab('acc');for(const s of pn.root.querySelectorAll('.tgav-sec')){const lab=s.querySelector('.tgav-lab')?.textContent;if((lab==='颈饰'&&c.acc.neck==='beads')||(lab==='手持'&&c.acc.hand==='incense'))s.querySelector('.tgav-chip[data-id="none"]')?.click();}}}};
 }catch(e){R8D2.err=String(e);}}
function wrapOpen(){const A=window.TG_AVATAR;if(!A?.openPanel||A.openPanel._r8d2)return !!A?.openPanel;const prev=A.openPanel;A.openPanel=function(){const pn=prev.apply(this,arguments);hookPanel(pn||A.panel);return pn;};A.openPanel._r8d2=true;return true;}
if(!wrapOpen()){let n=0;const t=setInterval(()=>{if(wrapOpen()||++n>100)clearInterval(t);},100);}
// --- (2) fake shadow: one instanced disc for every remote in view
let disc=null;const M4=new T.Matrix4(),Q=new T.Quaternion().setFromAxisAngle(new T.Vector3(1,0,0),-Math.PI/2),SC=new T.Vector3(),P=new T.Vector3(),MAX=48;
function ensureDisc(w){if(disc&&disc.parent===w.scene)return disc;const g=new T.CircleGeometry(.36,20),m=new T.MeshBasicMaterial({color:0x000000,transparent:true,opacity:.26,depthWrite:false,fog:false});
 disc=new T.InstancedMesh(g,m,MAX);disc.name='r8d2-remote-shadow';disc.count=0;disc.frustumCulled=false;disc.renderOrder=1;disc.castShadow=disc.receiveShadow=false;disc.userData.r8d2=true;w.scene.add(disc);return disc;}
function shadows(){const w=window.W3;if(!w?.scene||!w.remotes)return;const d=ensureDisc(w);let n=0;
 if(R8D2.shadow.on)for(const r of w.remotes.values()){if(!r?.model||!r.mesh?.parent||!r.mesh.visible||n>=MAX)continue;const p=r.mesh.position,rid=r.model.position.y>.5;
  SC.set(rid?1.5:1,rid?1.9:1,1);P.set(p.x,p.y+.025,p.z);M4.compose(P,Q,SC);d.setMatrixAt(n++,M4);}
 d.count=n;d.visible=n>0;if(n)d.instanceMatrix.needsUpdate=true;R8D2.shadow.n=n;}
{const wf=window.worldFrame;if(typeof wf==='function'){window.worldFrame=worldFrame=function(){const r=wf.apply(this,arguments);try{shadows();}catch(e){R8D2.err=String(e);}return r;};}}
// --- (3) backend notes (tg-garden.js note(): 「…可以拿去上供」 etc.) → same rewrite the page applies, at write time
const clean=root=>{if(!window.r7Rewrite)return;const tw=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n;while((n=tw.nextNode())){const t=window.r7Rewrite(n.nodeValue);if(t!==n.nodeValue)n.nodeValue=t;}};
new MutationObserver(ms=>{for(const m of ms)for(const a of m.addedNodes){const el=a.nodeType===1?a:a.parentElement;if(el&&(el.closest?.('.tgg-notes')||el.classList?.contains('tgg-notes')))clean(el);}}).observe(document.documentElement,{childList:true,subtree:true});
})();
