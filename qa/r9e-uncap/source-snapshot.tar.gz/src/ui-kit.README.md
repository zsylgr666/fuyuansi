# ui-kit.js — 共享界面样式与提示层（window.TG_UI）

r8 新增。给意见箱（suggest.js）、游戏手册（manual.js）、捏脸面板（avatar.js）提供同一套设计变量和组件类；也可以给 codex 的界面复用。

- **作用范围**：所有样式都挂在 `.tg-ui` 下（变量 `--tg-*`、类 `.tg-*`），不会影响游戏其他 DOM。
- **打包**：在 pack.mjs 的列表里加 `"ui-kit.js"`，建议放在 `"avatar.js"` 前。三个模块在 `open()` 时才读取 `TG_UI`，所以只要它在同一个包里就能生效；缺了它面板仍可用，但会退回朴素样式。
- **幂等**：重复加载直接返回。无 THREE 依赖。

## 设计变量
| 类别 | 变量 |
|---|---|
| 颜色 | `--tg-paper #fbf6ec` 底、`--tg-paper-2 #f3e9d5`、`--tg-card #fffdf8`、`--tg-ink #3b2a1e` 正文（12.7:1）、`--tg-ink-2 #634a37` 次要（7.6:1）、`--tg-ink-3 #7d624d` 辅助（5.2:1）、`--tg-line`/`--tg-line-2` 描边、`--tg-accent #9b3a2a` 主按钮（白字 6.6:1）、`--tg-ok/warn/err/info` 及 `-soft` 底色 |
| 圆角 | `--tg-r-1 8px` `--tg-r-2 12px` `--tg-r-3 16px` `--tg-r-pill` |
| 阴影 | `--tg-sh-1` `--tg-sh-2` `--tg-sh-3` |
| 字号 | `--tg-fs-1 14px` `--tg-fs-2 16px` `--tg-fs-3 18px` `--tg-fs-4 22px` |
| 间距 | `--tg-s-1 4` `--tg-s-2 8` `--tg-s-3 12` `--tg-s-4 16` `--tg-s-5 24`（px） |
| 触控 | `--tg-hit 44px`：按钮、标签、选择片、图标按钮的最小宽高 |
| 字体 | 正文 `--tg-font`（苹方/思源黑体），标题 `--tg-font-title`（思源宋体） |

## 组件类
`.tg-scrim` 遮罩 · `.tg-sheet` 面板（竖屏底部抽屉；横屏矮屏居中满高；≥700×600 居中卡片）· `.tg-sheet__head`（三栏：左返回 / 中标题 / 右关闭）· `.tg-sheet__title` · `.tg-sheet__body` · `.tg-sheet__foot` · `.tg-btn`（`--primary` `--danger` `--ghost` `--block`）· `.tg-iconbtn` · `.tg-tabs`/`.tg-tab`（分段标签，`aria-selected`）· `.tg-chips`/`.tg-chip`（`aria-pressed`）· `.tg-label` `.tg-input` `.tg-textarea` `.tg-help` `.tg-help--err` `.tg-intro` · `.tg-card` · `.tg-badge`（`--ok/warn/err/info/accent`）· `.tg-dot` · `.tg-empty` · `.tg-meta`

安全区：遮罩左右、面板底部、提示条顶部都加了 `env(safe-area-inset-*)`。

## API
```js
TG_UI.ensure()                                   // 注入 <style id="tg-ui-kit">（各模块 open 时会自动调用）
TG_UI.toast('已保存', {tone:'ok'})               // tone: info|ok|warn|error；duration 默认按字数 1.8–4.2 秒
TG_UI.openLayer(rootEl, {onClose})               // 登记一层面板，返回 {z, close(), remove()}；Esc 关闭最上层
TG_UI.modal({title, body, actions:[{label, primary, danger, onClick}]})   // onClick 返回 false 不关闭
await TG_UI.confirm({title, text, ok:'确定', cancel:'取消', danger:false}) // -> true/false
TG_UI.icon('close', 20)                          // 线性 SVG 字符串；TG_UI.icons 列出全部名称
TG_UI.Z                                          // {panel:9990, step:10, modal:10040, toast:10100}
```

**提示队列**：页面顶部（安全区下方 60px；横屏矮屏 12px）一列，最多同时 3 条，新的在下面，超出时最早的先退场；相同文字只刷新计时不重复叠加；`pointer-events:none`，不会挡住下面的按钮。

**层级**：面板从 9990 开始，每多一层加 10；对话框从 10040 开始；提示条固定 10100，始终在最上面。游戏自己的 `#modal`（70）、`#toast`（95）低于这些层，所以面板打开时游戏的 `#toast` 会被盖住，建议见 `qa/r8-ui/README.md`。
