# r8a.1: 缘堂 entry becomes a pure tutorial gate (来福's decision)

- Build: `v4/index.r8a1.html`, 1,648,301 bytes, sha256 `e962056e158e93a307c7c220ba73cc772e0836df0f61b2abe9cacacfa639785b`.
- Base: `v4/index.r8a.html` (0dab5eb9…), packed in isolation from the r8a src snapshot (`qa/r8b-base-src`). Re-packing the untouched snapshot reproduces 0dab5eb9 exactly. The only change is one sidecar block appended to r8.js.
- Diff: `v4/r8a1.patch` (31 lines, packed index.r8a.html → index.r8a1.html).

## Behaviour
- Condition not met (fewer than 3 harvests, offline/v4 build): a gentle card titled 「缘堂还没开门」 with the line 「先在小院收 3 次菜，缘堂就会为你打开」, the 已收获 n / 3 progress bar, and a 「回小院」 button. Tapping the dim backdrop or pressing Esc also goes back. The player is never hard-locked.
- No passcode field: the input is hidden, disabled and taken out of the tab order. 「进入缘堂」 is hidden. The old 口令 / 8888 / 短信 lines are removed. Pressing Enter does nothing, and `tryUnlock` now only checks the harvest condition.
- Condition met: entering 缘堂 opens it automatically (the existing `enterHall` auto-unlock at UNLOCK_HARVEST = 3).
- TG_ACCESS untouched: when `r3SkipDemoGate()` is true (TG_ACCESS present, or visiting), the gate is skipped exactly as before.
- The only digits left are the harvest progress 「已收获 0 / 3」 and the "3 次" in the hint. There is no code anywhere.

## Quick test (offline, portrait 390×844 and landscape 844×390, `/tmp/r8w/a1test.mjs`)
| Step | Portrait | Landscape |
|---|---|---|
| Enter 缘堂 with 0 harvests | hint card shown, 0 visible inputs, still locked | same |
| Press Enter | stays locked | same |
| Tap 回小院 | back in yard, lock off, focus on BODY, worldBlocked false | same |
| Yard prompt next to the 缘堂 exit | 「进入缘堂」 shown | same |
| Set 3 harvests, enter 缘堂 | opens, no lock, unlocked true | same |
| Back to yard, prompt | shown, not blocked | same |
| Page errors | none | none |

Shots: `v4/shots/r8a1-gate-hint.png` (+`-land`), `v4/shots/r8a1-gate-open.png` (+`-land`).

The same block is applied in the r8b line (`v4/_src/r8.js`).
