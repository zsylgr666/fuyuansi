/* r7 follow-up: display and geometry only; economy and persistence stay in r6c. */
(()=>{
'use strict';
const T=typeof THREE!=='undefined'&&THREE||window.THREE, rewrite=window.r7Rewrite;
for(const c of TG_CATALOG){c.name=rewrite(c.name);if(c.emoji)c.emoji=rewrite(c.emoji);}
for(let i=0;i<r4Quotes.length;i++)r4Quotes[i]=rewrite(r4Quotes[i]);
for(const v of Object.values(R3_STYLES))v.name=rewrite(v.name);
for(const scene of TG_SCENES)scene.name=rewrite(scene.name);
const textFloat=floatText;floatText=function(s,...args){return textFloat(rewrite(s),...args);};
// Match complete lamp messages before generic word rewriting.
const msg=toast;toast=function(s,...args){if(typeof s==='string'){s=s.replace(/敬上第\s*(\d+)\s*炷香/g,'点亮第 $1 盏灯，善缘 +1').replace(/香炉已插满三炷[^。]*/g,'灯台已满，请稍候').replace(/功课完成 · 回向\s*(\d+)\s*功德/g,'获得 $1 善缘');}return msg(s,...args);};
// Observe the existing r6 click transaction; do not replace its cap or reward logic.
document.addEventListener('click',e=>{if(!e.target.closest?.('#btnIncense'))return;const total=S.incense.total,merit=S.merit;queueMicrotask(()=>{if(S.incense.total>total)toast('点亮第 '+S.incense.total+' 盏灯，善缘 +'+Math.max(0,S.merit-merit));});},true);
// Retain original practice timer/reward contract; only replace its displayed sheet.
const practice=r6PracticeOpen;r6PracticeOpen=function(kind){const out=practice.apply(this,arguments);const el=document.querySelector('.r6-script');if(el)el.textContent=kind==='zen'?'庭铃轻响，花影疏疏。':'采菊东篱下，悠然见南山。';return out;};
const hall=renderHall;renderHall=function(){const out=hall.apply(this,arguments);$('#hallStats').innerHTML=`善缘 ${S.merit}<br>点灯 ${S.incense.total} 盏<br>陈列 ${S.shrine?.altar?.length||0} 件<br>庭铃 ${S.muyu} 下`;return out;};
$('#btnIncense').textContent='点灯';$('#btnOffer').textContent='摆放心意';$('#muyu').textContent='🎐';$('#muyu').title='摇风铃';$('#pillMerit').title='善缘';
const furniture=r3Furniture;r3Furniture=function(parent,item){if(item.id!=='incense-set')return furniture.apply(this,arguments);const g=new T.Group();g.position.set(item.x,item.y||0,item.z);parent.add(g);worldMesh(g,'cylinder','#957443',0,.12,0,.3,.24,.3);worldMesh(g,'ball','#ffc46c',0,.38,0,.1,.24,.1);};
const flames=[];
function lamp(g,x,z){const p=new T.Group();p.name='r7-copper-lamp';p.position.set(x,0,z);g.add(p);worldMesh(p,'cylinder','#8f794e',0,.65,0,.4,1.3,.4);const flame=worldMesh(p,'ball','#ffcf78',0,1.45,0,.16,.3,.16);flames.push(flame);return p;}
function chime(g,x,z){const p=new T.Group();p.name='r7-garden-chime';p.position.set(x,0,z);g.add(p);worldMesh(p,'cone','#829b91',0,1.8,0,.45,.32,.45);worldMesh(p,'cylinder','#cab87b',0,1.36,0,.025,.7,.025);worldMesh(p,'box','#a8c9b5',0,.95,0,.18,.32,.02);}
// A family picture frame is optional; no ancestral tablet or shaved portrait default.
/* r8d3: the r7 neutral-frame override of r3PlaqueTexture is retired — 来福 wants the v13 portrait card back (player's image or the cute default face, name verbatim); unset slots get r8c2's paintings. The default face now has hair (no shaved look). */
const studio=openShrineStudio;openShrineStudio=function(){const out=studio.apply(this,arguments);document.querySelectorAll('#sheet [data-name]').forEach(el=>{if(el.value==='列祖列宗之位')el.value='家和业兴';});return out;};
const shrine=worldSyncShrine;worldSyncShrine=function(){const out=shrine.apply(this,arguments);const g=W3?.spaces?.hall?.plaqueGroup;if(g)for(const [i,p] of g.children.entries()){p.scale.set(1.4,.65,1);p.position.x=(i-1)*2.3;p.position.y=3.2;}return out;};
function geometry(){if(!window.W3?.spaces)return;const h=W3.spaces.hall;if(h.r7Built&&!h.r7Compliant){h.r7Compliant=true;for(const o of [...h.group.children]){if(o.isMesh&&o.position.x===-4&&o.position.z===2)o.visible=false;}lamp(h.group,2,2);chime(h.group,-4,2);h.items.forEach(i=>{if(typeof i.label==='string')i.label=rewrite(i.label);});}
if(W3.sticks)W3.sticks.visible=false;if(W3.smoke)W3.smoke.visible=false;if(W3.r6SmokeBatch)W3.r6SmokeBatch.visible=false;
}
const decorate=tgDecorate;tgDecorate=function(){const out=decorate.apply(this,arguments);geometry();return out;};
let last=0;const animate=tgAnimate;tgAnimate=function(ts,dt){for(const f of flames)f.scale.y=.3*(1+.12*Math.sin(ts*.008)+.06*Math.sin(ts*.017));const out=animate.apply(this,arguments);if(ts-last>500){last=ts;geometry();}return out;};
// Copper lamp art replaces the dormant two-dimensional burner; IDs are retained.
const css=document.createElement('style');css.textContent='#burner .pot:after{content:"灯"!important}#sticks,#smoke{display:none!important}#muyu{display:block!important;width:40px;height:40px;background:transparent;border:0;box-shadow:none}#muyu:before,#muyu:after{display:none!important}.altar-cloth:after{content:"陈"!important}';document.head.append(css);
geometry();
})();
