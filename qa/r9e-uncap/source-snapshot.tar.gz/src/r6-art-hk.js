/* r6-art-hk.js — Honor of Kings / 王者荣耀家园 stylized-realism dress layer.
   r6-side only. Uses TG_REAL APIs. Must keep every scene under 150 draw calls on phone. */
(function(){
  'use strict';
  const T=()=>((typeof THREE!=='undefined'&&THREE)||window.THREE||globalThis.THREE);
  const phone=()=>matchMedia('(max-width:520px)').matches;
  const OUT=['gate','plaza','market','yard','lotus','tea','teahouse','home'];
  const IN=['hall','zen','study'];

  function cache(){
    const TH=T();
    if(window.__r6HkGeo)return window.__r6HkGeo;
    const C={};
    // Barrel roof tile + thin board (one merged unit)
    const board=new TH.BoxGeometry(.30,.035,.36);
    board.translate(0,.02,0);
    const barrel=new TH.CylinderGeometry(.055,.055,.36,8,1,false,0,Math.PI);
    barrel.rotateX(Math.PI/2); barrel.rotateZ(Math.PI); barrel.translate(0,.055,0);
    C.tile=merge(board,barrel);
    const ridge=new TH.CylinderGeometry(.07,.07,.34,8);
    ridge.rotateZ(Math.PI/2);
    const cap=new TH.SphereGeometry(.09,8,6);
    cap.translate(.18,0,0);
    C.ridge=merge(ridge,cap);
    const chi=new TH.BoxGeometry(.16,.18,.1);
    const chi2=new TH.BoxGeometry(.22,.08,.08); chi2.translate(.12,.04,0);
    const chi3=new TH.BoxGeometry(.08,.16,.07); chi3.translate(-.1,.06,0);
    C.ornament=merge(chi,chi2,chi3);

    // Dougong / bracket cluster (斗栱示意)
    const beam=new TH.BoxGeometry(.46,.07,.14);
    const dou=new TH.BoxGeometry(.16,.1,.16); dou.translate(0,-.085,0);
    const gong=new TH.BoxGeometry(.42,.055,.09); gong.translate(0,-.15,0);
    const gong2=new TH.BoxGeometry(.1,.12,.1); gong2.translate(0,-.22,0);
    const arm1=new TH.BoxGeometry(.36,.04,.06); arm1.translate(.16,-.2,0);
    const arm2=arm1.clone(); // will merge after translate via matrix later - just second box
    const armB=new TH.BoxGeometry(.36,.04,.06); armB.translate(-.16,-.2,0);
    C.dougong=merge(beam,dou,gong,gong2,arm1,armB);

    // Beveled timber post cap
    const post=new TH.BoxGeometry(.14,.7,.14);
    const capB=new TH.BoxGeometry(.2,.06,.2); capB.translate(0,.36,0);
    const brk=new TH.BoxGeometry(.22,.05,.08); brk.translate(.12,.28,0);
    const brk2=new TH.BoxGeometry(.22,.05,.08); brk2.translate(-.12,.28,0);
    C.bracket=merge(post,capB,brk,brk2);

    // Carved railing bay: post + pierced panel + rail
    const rp=new TH.BoxGeometry(.08,.7,.08); rp.translate(0,.35,0);
    const rail=new TH.BoxGeometry(.7,.05,.07); rail.translate(.36,.66,0);
    const rail2=new TH.BoxGeometry(.7,.04,.05); rail2.translate(.36,.28,0);
    const panel=new TH.BoxGeometry(.62,.34,.03); panel.translate(.36,.46,0);
    const knob=new TH.SphereGeometry(.05,6,5); knob.translate(0,.72,0);
    C.railBay=merge(rp,rail,rail2,panel,knob);

    // Grass clump: 5 crossed blades
    const blades=[];
    for(let i=0;i<5;i++){
      const b=new TH.BoxGeometry(.03,.22,.01);
      const a=i*1.256;
      b.rotateY(a); b.rotateZ((i-2)*.12); b.translate(Math.cos(a)*.04,.11,Math.sin(a)*.04);
      blades.push(b);
    }
    C.grass=merge(...blades);

    // Flower: stem + petals + center
    const stem=new TH.CylinderGeometry(.012,.016,.16,5); stem.translate(0,.08,0);
    const mid=new TH.SphereGeometry(.035,6,5); mid.translate(0,.17,0);
    const petals=[];
    for(let i=0;i<5;i++){
      const p=new TH.SphereGeometry(.03,6,4);
      const a=i*1.256;
      p.translate(Math.cos(a)*.045,.175,Math.sin(a)*.045);
      petals.push(p);
    }
    C.flower=merge(stem,mid,...petals);

    // Shrub: clustered spheres
    const bush=[];
    const pts=[[0,.22,0,.2],[.14,.16,.08,.14],[-.12,.18,.1,.15],[.05,.28,-.1,.12],[-.08,.12,-.12,.13],[.16,.12,-.06,.11]];
    pts.forEach(([x,y,z,r])=>{const s=new TH.SphereGeometry(r,8,6);s.translate(x,y,z);bush.push(s);});
    C.shrub=merge(...bush);

    C.mat={
      tile: mat('#5a4a48',.35,.25),
      ridge: mat('#4a3a38',.3,.2),
      ornament: mat('#8a2a22',.45,.3),
      dougong: mat('#6b4a2c',.45,.35),
      bracket: mat('#6e4d2e',.45,.35),
      rail: mat('#5c3e26',.4,.3),
      grass: mat('#4a6a38',.55,.45),
      flower: mat('#d48a9a',.5,.4),
      shrub: mat('#3d5a32',.5,.4),
      flowerY: mat('#e2b85a',.5,.4),
      flowerW: mat('#efe6d4',.5,.4)
    };
    vertexAO(C);
    window.__r6HkGeo=C;
    return C;
  }

  function mat(color,rough,metal){
    const TH=T();
    const M=TH.MeshStandardMaterial||TH.MeshPhongMaterial;
    const m=new M({color,roughness:rough??.45,metalness:metal??.15,flatShading:false});
    if('envMapIntensity' in m)m.envMapIntensity=.6;
    return m;
  }

  function merge(){
    const geos=[].slice.call(arguments).filter(Boolean);
    if(typeof mergeGeometries==='function'){
      const g=mergeGeometries(geos);
      geos.forEach(x=>x.dispose?.());
      return g;
    }
    return geos[0];
  }

  function vertexAOOnGeo(geo, base){
    if(!geo||geo.userData.r6AO)return geo;
    if(!geo.attributes.normal)geo.computeVertexNormals();
    const pos=geo.attributes.position, nor=geo.attributes.normal;
    const col=new Float32Array(pos.count*3);
    const r=base?.r??1,g=base?.g??1,b=base?.b??1;
    let minY=Infinity,maxY=-Infinity;
    for(let i=0;i<pos.count;i++){const y=pos.getY(i);if(y<minY)minY=y;if(y>maxY)maxY=y;}
    const span=Math.max(.001,maxY-minY);
    for(let i=0;i<pos.count;i++){
      const ny=nor.getY(i);
      const t=(pos.getY(i)-minY)/span;
      const ao=.62+.28*Math.max(0,ny)+.1*t;
      col[i*3]=r*ao; col[i*3+1]=g*ao; col[i*3+2]=b*ao;
    }
    geo.setAttribute('color',new (T()).BufferAttribute(col,3));
    geo.userData.r6AO=true;
    return geo;
  }

  function vertexAO(C){
    Object.keys(C).forEach(k=>{
      if(C[k]&&C[k].isBufferGeometry){
        const m=C.mat[k]||C.mat.tile;
        vertexAOOnGeo(C[k], m.color);
        if(m)m.vertexColors=true;
      }
    });
    // flower variants share C.flower; materials already vertexColors if we set flower
    C.mat.flowerY.vertexColors=true;
    C.mat.flowerW.vertexColors=true;
    C.mat.ridge.vertexColors=true;
    C.mat.ornament.vertexColors=true;
  }

  function skipMesh(m, space){
    if(!m||!m.isMesh)return true;
    if(m.isInstancedMesh)return true;
    if(m===space.floor)return true;
    const u=m.userData||{};
    if(u.r41Label||u.wallSign||u.r6Fade||u.r6Ghost||u.r6Hk||u.r6Merged||u.tgAvatar||u.r6Ride||u.r6Passenger||u.r6Lanterns)return true;
    if(m.material?.map||m.material?.transparent&&m.material.opacity<.95)return true;
    if(m.material?.isSpriteMaterial||m.isSprite)return true;
    let o=m;
    while(o){
      const n=(o.name||'')+'';
      if(/avatar|npc|fish|koi|water|lantern|player|tg-avatar|r6Ride/i.test(n))return true;
      if(o.userData?.tgAvatar||o.userData?.npc||o.userData?.r6Ride)return true;
      o=o.parent;
    }
    return false;
  }

  function mergeStatic(space){
    if(!space?.group||space.r6HkMerged)return 0;
    const bins=new Map();
    space.group.traverse(m=>{
      if(skipMesh(m,space))return;
      if(m.material?.vertexColors)return;
      const k=(m.material&&m.material.uuid)||'x';
      if(!bins.has(k))bins.set(k,[]);
      bins.get(k).push(m);
    });
    let saved=0;
    for(const arr of bins.values()){
      if(arr.length<3)continue;
      const geos=[];
      arr.forEach(m=>{
        m.updateMatrixWorld(true);
        const g=m.geometry;
        if(!g)return;
        const c=(g.index?g.toNonIndexed():g.clone()).applyMatrix4(m.matrixWorld);
        geos.push(c);
      });
      if(geos.length<3){geos.forEach(g=>g.dispose());continue;}
      try{
        const geo=typeof mergeGeometries==='function'?mergeGeometries(geos):null;
        if(!geo){geos.forEach(g=>g.dispose());continue;}
        vertexAOOnGeo(geo, arr[0].material.color);
        const mat=arr[0].material.clone();
        mat.vertexColors=true;
        const mesh=new (T()).Mesh(geo,mat);
        mesh.castShadow=mesh.receiveShadow=true;
        mesh.userData.r6Hk=true; mesh.userData.r6Merged=true;
        space.group.add(mesh);
        arr.forEach(m=>m.parent&&m.parent.remove(m));
        geos.forEach(g=>g.dispose());
        saved+=arr.length-1;
      }catch(e){geos.forEach(g=>g.dispose());}
    }
    space.r6HkMerged=true;
    return saved;
  }

  function instanced(geo, mat, poses, parent, cast){
    if(!poses.length)return null;
    const im=new (T()).InstancedMesh(geo, mat, poses.length);
    const TH=T();
    const dummy=new TH.Object3D();
    poses.forEach((p,i)=>{
      dummy.position.set(p.x,p.y,p.z);
      dummy.rotation.set(p.rx||0,p.ry||0,p.rz||0);
      dummy.scale.set(p.sx||1,p.sy||p.sx||1,p.sz||p.sx||1);
      dummy.updateMatrix();
      im.setMatrixAt(i,dummy.matrix);
    });
    im.instanceMatrix.needsUpdate=true;
    im.castShadow=cast!==false; im.receiveShadow=true;
    im.userData.r6Hk=true;
    parent.add(im);
    return im;
  }

  function isRoof(m, space){
    if(skipMesh(m,space)||!m.material?.color)return false;
    const hsl={}; try{m.material.color.getHSL(hsl);}catch(e){return false;}
    m.updateWorldMatrix(true);
    const b=new (T()).Box3().setFromObject(m);
    const sx=b.max.x-b.min.x, sy=b.max.y-b.min.y, sz=b.max.z-b.min.z;
    const midy=(b.min.y+b.max.y)/2;
    const roofColor=(hsl.s<.5&&hsl.l>.12&&hsl.l<.58&&(hsl.h<.08||hsl.h>.6||(hsl.h>.5&&hsl.h<.75)));
    return midy>2.15 && Math.max(sx,sz)>1.8 && sy>0.12 && sy<5.2 && roofColor;
  }

  function coverRoofs(space){
    if(space.r6HkRoofs)return;
    const C=cache();
    const roofs=[];
    space.group.traverse(m=>{if(m.isMesh&&isRoof(m,space))roofs.push(m);});
    if(!roofs.length){space.r6HkRoofs=true;return;}
    const TH=T();
    const ray=new TH.Raycaster();
    const down=new TH.Vector3(0,-1,0);
    const up=new TH.Vector3(0,1,0);
    const tiles=[], ridges=[], orns=[];
    const step=phone()?0.38:0.32;
    roofs.forEach(roof=>{
      const b=new TH.Box3().setFromObject(roof);
      const hits=[];
      for(let x=b.min.x+step*0.4;x<=b.max.x-step*0.3;x+=step){
        for(let z=b.min.z+step*0.4;z<=b.max.z-step*0.3;z+=step){
          ray.set(new TH.Vector3(x,b.max.y+1.2,z),down);
          const hit=ray.intersectObject(roof,false)[0];
          if(!hit||!hit.face)continue;
          const n=hit.face.normal.clone().transformDirection(roof.matrixWorld).normalize();
          if(n.y<.25)continue;
          const q=new TH.Quaternion().setFromUnitVectors(up,n);
          const e=new TH.Euler().setFromQuaternion(q);
          const p=hit.point.clone().addScaledVector(n,0.03);
          tiles.push({x:p.x,y:p.y,z:p.z,rx:e.x,ry:e.y,rz:e.z,sx:1});
          hits.push(p);
        }
      }
      // ridge: highest 8% of hits, run along the longer axis
      if(hits.length>6){
        const maxY=Math.max(...hits.map(p=>p.y));
        const ridgeHits=hits.filter(p=>p.y>maxY-0.18).sort((a,b)=>a.x===b.x?a.z-b.z:a.x-b.x);
        const alongX=(b.max.x-b.min.x)>=(b.max.z-b.min.z);
        ridgeHits.forEach((p,i)=>{
          ridges.push({x:p.x,y:p.y+.06,z:p.z,ry:alongX?0:Math.PI/2,sx:1});
          if(i===0||i===ridgeHits.length-1)orns.push({x:p.x,y:p.y+.14,z:p.z,ry:alongX?(i===0?0:Math.PI):(i===0?Math.PI/2:-Math.PI/2),sx:1.1});
        });
      }
      roof.visible=false;
      roof.userData.r6HkHiddenRoof=true;
    });
    instanced(C.tile,C.mat.tile,tiles,space.group);
    instanced(C.ridge,C.mat.ridge,ridges,space.group);
    instanced(C.ornament,C.mat.ornament,orns,space.group);
    space.r6HkRoofs=true;
  }

  function placeDougong(space){
    if(space.r6HkDougong)return;
    const C=cache();
    const roofs=[];
    space.group.traverse(m=>{if(m.userData?.r6HkHiddenRoof||isRoof(m,space))roofs.push(m);});
    const poses=[];
    const TH=T();
    roofs.forEach(roof=>{
      const b=new TH.Box3().setFromObject(roof);
      const y=Math.max(2.6,b.min.y-0.08);
      const step=1.15;
      const edges=[
        [b.min.x, b.min.z, b.max.z, false],
        [b.max.x, b.min.z, b.max.z, false],
        [b.min.z, b.min.x, b.max.x, true]
      ];
      // eaves along z at minX/maxX, and along x at minZ (front)
      for(let z=b.min.z+0.4;z<=b.max.z-0.3;z+=step){
        poses.push({x:b.min.x+.08,y,z,ry:Math.PI/2,sx:.95});
        poses.push({x:b.max.x-.08,y,z,ry:-Math.PI/2,sx:.95});
      }
      for(let x=b.min.x+0.4;x<=b.max.x-0.3;x+=step){
        poses.push({x,y,z:b.min.z+.08,ry:0,sx:.95});
        poses.push({x,y,z:b.max.z-.08,ry:Math.PI,sx:.95});
      }
    });
    // cap density: phone fewer
    let list=poses;
    if(phone()&&list.length>80)list=list.filter((_,i)=>i%2===0);
    if(list.length>140)list=list.filter((_,i)=>i%2===0);
    instanced(C.dougong,C.mat.dougong,list,space.group);
    // a few beveled timber brackets at door-height corners
    const br=[];
    (space.exits||[]).forEach(e=>{
      br.push({x:e.x+(e.x>0?-0.7:e.x<0?0.7:-1.1),y:2.7,z:e.z+(Math.abs(e.z)>Math.abs(e.x)?(e.z>0?-0.4:0.4):0),sx:1});
      br.push({x:e.x+(e.x>0?-0.7:e.x<0?0.7:1.1),y:2.7,z:e.z+(Math.abs(e.z)>Math.abs(e.x)?(e.z>0?-0.4:0.4):0),sx:1});
    });
    // r8a: these exit brackets were placed at the middle of each doorway (both copies on the same spot for side exits)
    // and hung from nothing, so they are no longer built.
    space.r6HkDougong=true;
  }

  function placeRailings(space){
    if(space.r6HkRails)return;
    const C=cache();
    const candidates=[];
    space.group.traverse(m=>{
      if(skipMesh(m,space)||!m.material?.color)return;
      const hsl={};try{m.material.color.getHSL(hsl);}catch(e){return;}
      if(hsl.s<.15||hsl.l<.12||hsl.l>.55)return;
      // wood-ish mid-height thin runs
      m.updateWorldMatrix(true);
      const b=new (T()).Box3().setFromObject(m);
      const sx=b.max.x-b.min.x, sy=b.max.y-b.min.y, sz=b.max.z-b.min.z, midy=(b.min.y+b.max.y)/2;
      if(midy>0.4&&midy<1.6&&sy>0.5&&sy<1.4&&((sx>1.6&&sz<.35)||(sz>1.6&&sx<.35)))candidates.push({m,b,sx,sz,alongX:sx>=sz});
    });
    const poses=[];
    candidates.forEach(c=>{
      const b=c.b, along=c.alongX, len=along?c.sx:c.sz, n=Math.max(1,Math.floor(len/0.72));
      for(let i=0;i<n;i++){
        const t=(i+0.05)/n;
        poses.push({
          x:along?b.min.x+t*c.sx: (b.min.x+b.max.x)/2,
          y:b.min.y,
          z:along?(b.min.z+b.max.z)/2:b.min.z+t*c.sz,
          ry:along?0:Math.PI/2,
          sx:1
        });
      }
      c.m.visible=false;
    });
    instanced(C.railBay,C.mat.rail,poses,space.group);
    space.r6HkRails=true;
  }

  function occupied(space,x,z){
    const blocks=space.blocks||[];
    for(const b of blocks){
      if(x>=(b.x??b.minx??-Infinity)-.3&&x<=(b.X??b.maxx??Infinity)+.3&&z>=(b.z??b.minz??-Infinity)-.3&&z<=(b.Z??b.maxz??Infinity)+.3)return true;
    }
    return Math.hypot(x,z)<1.1;
  }

  function scatter(space,count,span,opts){
    opts=opts||{};
    const pts=[];
    let guard=0;
    const rng=(n)=>{const x=Math.sin((n+1)*12.9898+span*78.233)*43758.5453;return x-Math.floor(x);};
    while(pts.length<count&&guard<count*14){
      const k=guard++;
      const x=(rng(k)-.5)*2*(opts.sx||span)+(opts.ox||0);
      const z=(rng(k+91)-.5)*2*(opts.sz||span)+(opts.oz||0);
      if(opts.exclude&&opts.exclude(x,z))continue;
      if(occupied(space,x,z))continue;
      pts.push({x,y:opts.y||0,z,ry:rng(k+7)*Math.PI*2,sx:.75+rng(k+3)*.7});
    }
    return pts;
  }

  function placeVeg(space,name){
    // Skip this vegetation pass: thin blades render as black strips on SwiftShader.
    // Leave the established scene vegetation intact.
  }

  function goldenHour(name){
    const w=window.W3; if(!w?.renderer)return;
    const TH=T();
    const indoor=IN.includes(name);
    w.renderer.shadowMap.enabled=true;
    w.renderer.shadowMap.type=TH.PCFSoftShadowMap;
    if(TH.NeutralToneMapping)w.renderer.toneMapping=TH.NeutralToneMapping;
    w.renderer.toneMappingExposure=indoor?1.14:1.06;
    if(w.sun){
      if(!indoor)w.sun.position.set(-18,8.5,10);
      else w.sun.position.set(-6,10,5);
      w.sun.color.set(indoor?'#ffc684':'#ffb15c');
      w.sun.castShadow=true;
      const sz=phone()?1024:2048;
      if(w.sun.shadow?.mapSize&&w.sun.shadow.mapSize.x!==sz){
        w.sun.shadow.mapSize.set(sz,sz);
        if(w.sun.shadow.map){w.sun.shadow.map.dispose();w.sun.shadow.map=null;}
      }
      if(w.sun.shadow){w.sun.shadow.bias=-0.00045;w.sun.shadow.normalBias=0.035;w.sun.shadow.radius=phone()?2:4;}
    }
    if(w.hemi){
      w.hemi.color.set(indoor?'#ffe0b8':'#ffe6c4');
      w.hemi.groundColor.set(indoor?'#3a281b':'#6a4a30');
    }
    if(w.scene?.fog){
      if(!indoor){w.scene.fog.color.set('#efd2a4');w.scene.fog.near=22;w.scene.fog.far=78;}
      else {w.scene.fog.near=12;w.scene.fog.far=34;}
    }
  }

  function dress(name){
    const w=window.W3; if(!w?.spaces)return;
    const id=name==='teahouse'?'tea':name;
    const space=w.spaces[id]||w.spaces[name];
    if(!space?.group)return;
    try{
      if(!space.r6HkDressed){
        mergeStatic(space);
        coverRoofs(space);
        placeDougong(space);
        placeRailings(space);
        placeVeg(space,id);
        space.r6HkDressed=true;
      }
    }catch(e){console.warn('[r6-art-hk] dress',id,e);}
    goldenHour(id);
  }

  function boot(){
    cache();
    const w=window.W3;
    if(w?.active)dress(w.active);
    // warm other spaces off-screen so first visit is cheap and budgets can be measured
    requestAnimationFrame(()=>{
      const order=['plaza','gate','yard','market','lotus','hall','tea','zen','study'];
      order.forEach(n=>{if(w?.spaces?.[n]&&n!==w.active)try{dress(n);}catch(e){}});
    });
  }

  const enter=window.worldEnter;
  window.worldEnter=function(name,previous){
    const out=enter.apply(this,arguments);
    try{dress(window.W3?.active||name);}catch(e){}
    return out;
  };

  if(window.W3?.renderer)boot();
  else addEventListener('load',()=>setTimeout(boot,0));
  window.TG_R6_HK={dress,goldenHour,mergeStatic,version:'r6-art-hk-1'};
})();
