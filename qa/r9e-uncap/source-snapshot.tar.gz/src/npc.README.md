# npc.js：集市摊主 NPC `window.TG_NPC`

独立的新文件，依赖全局 `THREE`（r170）。
- 有 `TG_AVATAR` 时用它的低模（`detail:0`）建模，画风和捏脸系统一致。
- 没有时退回内置的简易模型（圆柱身体加球形头）。

文件是幂等的。

## 快速上手

```js
// 进入集市后放置默认 6 位摊主（花木铺、家具铺、灯彩铺、茶摊、水果车、寄售摊）
TG_NPC.placeAtStalls();
// 每帧（worldFrame 里）调用，dt 的单位是秒
TG_NPC.update(dt, W3.camera);
// 点击：在 world3d 的 pointer 处理里，先于地面拾取调用
if (TG_NPC.handleTap(w.ray)) return;   // 命中 NPC 就弹出气泡并吃掉这次点击
```

## API

| 方法 | 说明 |
|---|---|
| `spawn({preset, name, title, lines, calls, position, rotation, stallId, parent, avatar, plate, block, space, onTalk, weights, id})` | 创建一个 NPC 并返回 npc 对象。`position` 可以是 `[x,y,z]`、`{x,y,z}` 或 Vector3。`rotation` 是 y 轴弧度（0 表示面朝 +Z）。`parent` 默认是 `W3.spaces.market.group`，其次是 `W3.scene`。`avatar` 写的字段会覆盖预设外观。`plate:false` 不显示名牌。`block:true` 且传了 `space` 时，会往 `space.blocks` 加一个 0.6×0.6 的碰撞块，移除时自动删掉。同一个 `stallId` 再次 spawn 时会替换旧的 NPC |
| `placeAtStalls(list?, opts?)` | 见下文 |
| `update(dt, camera?)` | 调度待机动作，面朝镜头时做转身插值，并更新气泡位置。所在场景隐藏（祖先节点 `visible=false`）时会跳过，并收起气泡 |
| `handleTap(x, camera?, canvas?)` | `x` 可以是 `THREE.Raycaster`（按鸭子类型识别：有 `.ray` 且有 `intersectObject` 方法；r170 的 Raycaster 没有 `isRaycaster` 标记）、NDC 坐标 `{x,y}` 或 `PointerEvent`（`{clientX,clientY}`）。命中时调用 `talk`（依次说下一句台词）并返回 npc，否则返回 `null` |
| `talk(id)` / `say(id, text, {shout, duration})` | 手动触发对白，或说任意一句话 |
| `hideBubbles()` | 收起所有气泡，切换场景或打开 UI 时用 |
| `remove(idOrStallIdOrNpc)` / `clear()` / `list()` / `get(id)` | 管理 NPC |
| `setView({camera, canvas, container, target, maxDist, occlude, occluders, occludeEvery, nearIgnore, minOccluder})` | 相机、canvas、气泡层容器（默认 `W3.camera`、`W3.canvas`、`document.body`），以及气泡的距离和遮挡参数，见下方「气泡」 |
| `refreshOccluders()` | 清空遮挡物缓存。场景里增删了墙或房屋后调用（父节点子物体数量变化时也会自动刷新） |
| `stats()` | 返回 `{npcs, triangles, drawCalls}` |
| `onTalk = (npc, text) => {}` | 全局对白回调，可以用来接 `TG_AUDIO.playSfx('pop')` 或任务系统 |
| `presets` / `marketStalls` | 预设表和集市默认摊位表，可读可改 |

npc 对象上可读的字段：`id`、`name`、`title`、`preset`、`stallId`、`root`（Group）、`model`（avatar Group）、`lines`、`action`。

### 预设（`TG_NPC.presets`）

| id | 名字 · 头衔 | 外观 | 手持 |
|---|---|---|---|
| tea | 陆羽生 · 茶商 | 竹青直裰、发髻、发簪、香囊 | 茶壶 |
| herb | 孙百草 · 药铺 | 黛青圆领袍、花白发、发冠、葫芦 | 药包 |
| cloth | 绣娘阿缨 · 布庄 | 藕荷襦裙、长发、玉佩 | 布匹 |
| snack | 王大勺 · 小吃摊 | 橘色短打、绑腿、健硕 | 瓷碗 |
| incense | 灯娘 · 灯彩铺 | 胭脂直裰 | 盆花 |
| painting | 沈墨白 · 书画摊 | 月白圆领袍、束发、发冠 | 毛笔 |
| flower | 花婆婆 · 花木铺 | 缃色襦裙、双髻、簪花 | 盆花 |
| furniture | 鲁师傅 · 家具铺 | 赭石短打、束发、葫芦 | — |
| fruit | 果农小满 · 水果摊 | 竹青短打、斗笠 | — |
| consign | 钱掌柜 · 寄售摊 | 檀紫圆领袍、发冠、玉佩 | 书卷 |

每个预设有 `lines`（点击时依次说的台词，3–4 句）、`calls`（吆喝，镜头靠近时会随机冒出来）和 `weights`（各待机动作的权重）。

### 待机动作

各动作的持续时间如下，到时间后按权重随机挑下一个：
- `idle`（呼吸）：2–5 秒
- `look`（张望）：3–5 秒
- `arrange`（整理货物）：3–6 秒
- `call`（吆喝）：2–3 秒
- `wave`（招手）：1.6–2.4 秒

镜头离 NPC 不到约 10.5 单位时，`wave` 和 `call` 的权重 ×2.2。`call` 有 60% 概率冒出一句吆喝气泡。说话、招手和吆喝时，NPC 会转向镜头（最多偏离摊位朝向 ±1.2 rad），结束后再转回摊位朝向。

### 气泡

- DOM 元素，挂在 `.tgnpc-layer`（fixed、`pointer-events:none`）下，类名都以 `tgnpc-` 为前缀。
- 外观：宣纸底、金边，左上角有红色名签，下方有尾巴。
- 位置：每帧把头顶上方（有名牌时更高一些）的点投影到 canvas 屏幕坐标。离屏或在相机背后时隐藏。
- 距离：按**玩家**（`target`，默认 `W3.player`；为 null 时用相机）到 NPC 的水平距离判断，超过 `maxDist`（默认 12）就收起气泡。
- 遮挡（`occlude:true`）：从相机向 NPC 头顶打一条射线，命中墙或房屋就隐藏气泡（`visibility:hidden`），走出遮挡后会重新显示。
  - 头顶前 `nearIgnore`（1.6）米内的命中不算，所以 NPC 自己的柜台、布帘和遮阳棚不会挡住气泡。
  - 水平面（|法线 y| > 0.6：棚顶、屋顶、地面）、隐藏物体、NPC 自身、Sprite，以及带 `userData.r41Label / wallSign / npcNoOcclude` 的物体都跳过。
  - 世界半径小于 `minOccluder`（1.2）的小物件（灯笼、幌子、杆子）不算遮挡物。
  - 每 `occludeEvery`（4）帧测一次，各 NPC 错开，只在气泡显示时才测。射线、向量和命中数组都复用；遮挡物列表按父节点缓存。three.js 的 `intersectObjects` 内部仍会为命中结果分配小对象。
- 显示时长：2.6 秒 + 每字 0.12 秒，最长 7 秒；吆喝是 2.2 秒。
- 最大宽度 `min(240px, 70vw)`。

### `placeAtStalls(list?, opts?)`

- **传数组**：每项格式为 `{stallId, preset?, x, z, ry, name?, lines?, calls?, avatar?, parent?}`。没写 `preset` 时，按 `stallId` 里的关键字猜（茶、药、布、吃、香、书画、花、家具、果、寄售）。
- **不传**：自动检测，顺序如下：
  1. 在 `opts.root`（默认集市 group）里找 `userData.stallId`、`userData.npcStall` 或名字以 `stall:` / `stall_` / `stall-` 开头的对象。站位是对象的世界坐标加 `userData.npcOffset`（默认 `[0,0,-1.2]`），朝向取 `userData.npcRy`；也可以用 `npcPreset`、`npcName`、`npcLines` 覆盖。
  2. 找不到就用内置的 `MARKET_STALLS`。坐标是按 r3.js、art3.js 和 r5.js 的集市布局量出来的：站在柜台和幌子杆之间，避开 art3 的 block。寄售摊只在 r5 的 (0,8) 柜台存在时才放人。
- 默认会跳过落在 `space.blocks` 里的站位，并打印 warn。`opts.skipBlocked:false` 可以关掉这个检查。
- `opts` 的其他参数：`space`（默认 `W3.spaces.market`）、`parent`、`block`、`plate`。

## 给 codex 的接入步骤

1. **pack.mjs**：放在 `avatar.js` 之后。

   ```js
   ["animals2.js","audio.js","r5.js","realism.js","avatar.js","npc.js","teahouse-assets.js","mounts.js","r6.js"]
   ```

   现在的打包顺序是 `npc.js` 在 `avatar.js` 之前。只要不在加载阶段就 spawn 也能用，但建议调换。另外现在的 `index.html` 是早期版本，**请重新打包**。
2. **放置**：world 初始化完、集市建好后调用一次 `TG_NPC.placeAtStalls()`。NPC 挂在 `W3.spaces.market.group` 下，会随场景一起显示或隐藏。
3. **每帧**：在 `worldFrame` 里调用 `TG_NPC.update(dt, w.camera)`，dt 的单位是秒。
4. **点击**：在 world3d.js 的 pointer 处理里（`w.ray.setFromCamera` 之后、拾取地面之前）加上 `if (window.TG_NPC && TG_NPC.handleTap(w.ray)) return;`。
5. **切换场景或打开面板时**：调用 `TG_NPC.hideBubbles()`。
6. **可选**：
   - `TG_NPC.onTalk = () => TG_AUDIO?.playSfx('pop')`。
   - 茶会小院（TG_TEA）想放 NPC，可以用 `spawn({preset:'tea', parent:teaGroup, position, rotation})`。
   - 想让玩家撞上 NPC，传 `{block:true, space:W3.spaces.market}`。

## 性能（实测：集市 6 位摊主）

- 每个 NPC 约 4.1k 三角面，7–8 次 draw call（长袍多 1 次裙摆），另加 1 个名牌 Sprite。6 位共约 25k 面、46 次 draw call。
- 点击用的拾取体是 1 个共享的 8 段圆柱，材质 `visible:false`，不参与渲染。
- `update` 每帧零分配，只复用向量。只有气泡显示时才写 `style.transform`，每帧最多调用 1 次 `getBoundingClientRect`。
- 想进一步省开销：远处 NPC 可以 `plate:false`，或者场景不可见时不调用 `update`（模块内部本来也会跳过）。

## 已知限制

- 遮挡只是射线近似：玩家从墙缝里看过去时气泡可能闪一下。如果宁可总显示，可以 `setView({occlude:false})`。
- **r6.js 里的 `r6NpcOcclude`**（相机距离 > 8 就藏气泡，并且每帧分配对象）跟本模块的遮挡逻辑重复，还会互相覆盖 `visibility`，建议删掉。如果要保留它，就调用 `TG_NPC.setView({occlude:false, maxDist:0})`。
- 转向镜头的计算假设 NPC 的父节点没有旋转（集市 group 没有旋转）。
- 内置摊位坐标对应当前的集市布局。r3、art3 或 r5 的摊位一旦挪动，就要同步改 `TG_NPC.marketStalls`，或者给摊位对象加上 `userData.stallId`。
- 没有 `TG_AVATAR` 时的退化模型很简陋，只用来兜底。
