/* r7h: free titles (茶客 etc.) must survive face-editor save and stay visible to others. */
(()=>{ 'use strict';

const PAID_IDS={title_shanxin:1,title_jushi:1,title_xingzhe:1,title_gongdezhu:1,beads:1};
const FREE_FALLBACK=['雅士','茶客','园丁','旅人','茶博士','园主','行客','画师','药师','掌柜'];

function stripTitle(s){return String(s==null?'':s).replace(/[🌱🎋🧭✨💠]/gu,'').trim();}
function G(){return window.TG_R7G||{};}
function titleIdOf(s){return G().titleIdOf?G().titleIdOf(s):(PAID_IDS[String(s||'').trim()]?String(s).trim():null);}
function canonicalStoredTitle(s){return G().canonicalStoredTitle?G().canonicalStoredTitle(s):stripTitle(s);}
function displayTitle(s,id){return G().displayTitle?G().displayTitle(s,id):(s==null||s===''?'':String(s));}

function catalogItems(){
  try{
    const c=window.TG_AVATAR_NET?.catalog?.();
    if(Array.isArray(c))return c;
    if(c&&Array.isArray(c.items))return c.items;
  }catch(e){}
  return [];
}
function paletteFreeNames(){
  const pal=window.TG_AVATAR?.palette?.title;
  return Array.isArray(pal)&&pal.length?pal.slice():FREE_FALLBACK.slice();
}
/* Free whitelist: palette titles + any catalog title with price 0 / free / default-owned. */
function freeWhitelist(){
  const names=new Set();
  paletteFreeNames().forEach(n=>{if(n)names.add(String(n));});
  catalogItems().forEach(t=>{
    if(!t||(t.kind&&t.kind!=='title'))return;
    const free=t.price===0||t.price==='0'||t.free===true||t.defaultOwned===true;
    if(!free)return;
    if(t.name)names.add(String(t.name));
    if(t.id&&!PAID_IDS[t.id])names.add(String(t.id));
    (t.legacy_names||t.legacyNames||[]).forEach(n=>{if(n)names.add(String(n));});
  });
  return names;
}
function isPaidCatalogTitle(s){
  const id=titleIdOf(s);
  if(id&&PAID_IDS[id]&&id!=='beads')return true;
  const bare=canonicalStoredTitle(s);
  return catalogItems().some(t=>t&&t.kind==='title'&&(t.price>0)&&(t.id===s||t.name===s||t.name===bare||t.id===id));
}
function isFreeTitle(s){
  if(s==null||s==='')return false;
  const raw=String(s).trim(), bare=canonicalStoredTitle(raw);
  const free=freeWhitelist();
  if(free.has(raw)||free.has(bare)||free.has(stripTitle(raw)))return true;
  /* A paid catalog title that also sits in the palette (雅士/旅人) is free only when not treated as the paid id. */
  return false;
}

function freeIdOf(s){
  const stored=canonicalStoredTitle(s);
  if(!stored)return null;
  if(isFreeTitle(stored)&&!isPaidOwned(stored))return stored;
  return titleIdOf(stored)||(isFreeTitle(stored)?stored:null);
}
function isPaidOwned(s){
  const id=titleIdOf(s);
  if(!id||!PAID_IDS[id])return false;
  const inv=S?.avatarInv?.titles||[];
  if(inv.includes(id))return true;
  try{
    const rows=window.TG_AVATAR_NET?.titles?.()||[];
    return rows.some(t=>t&&(t.id===id||titleIdOf(t.id||t.name)===id)&&(t.owned===true||t.owned===1||t.have));
  }catch(e){return false;}
}

function ownsTitle(val){
  if(!val)return true;
  if(isFreeTitle(val))return true;
  if(G().ownsTitle)return G().ownsTitle(val);
  return false;
}

function wrapTitles(N){
  if(!N||typeof N.titles!=='function'||N.titles._r7h)return;
  const fn=N.titles;
  N.titles=function(){
    const rows=fn.apply(this,arguments)||[];
    const out=[], seen=new Set();
    rows.forEach(t=>{
      if(!t||!t.name)return;
      if(t.r7Alias)return;
      const key=canonicalStoredTitle(t.name)||t.id||t.name;
      if(seen.has(key))return;seen.add(key);
      out.push(t);
    });
    freeWhitelist().forEach(name=>{
      const key=canonicalStoredTitle(name)||name;
      if(!key||seen.has(key))return;
      seen.add(key);
      out.push({id:key,name:key,owned:true,price:0,free:true,kind:'title',emoji:''});
    });
    return out;
  };
  N.titles._r7h=true;
}

function wrapSave(N){
  if(!N||typeof N.save!=='function'||N.save._r7h)return;
  const prev=N.save;
  N.save=async function(avatar,titleId){
    let cfg=avatar;
    if(typeof avatar==='string'){
      try{cfg=window.TG_AVATAR?.deserialize?.(avatar);}catch(e){cfg=null;}
    }
    const explicit=cfg&&typeof cfg==='object';
    const stored=canonicalStoredTitle((explicit&&cfg.title)||titleId||'');
    const id=stored?(titleIdOf(titleId)||titleIdOf(stored)||(isFreeTitle(stored)?stored:null)||titleId||null):null;
    if(explicit){
      cfg=Object.assign({},cfg,{title:stored});
      const wire=window.TG_AVATAR?.serialize?.(cfg)||avatar;
      return prev.call(this,wire,id);
    }
    return prev.call(this,avatar,id);
  };
  N.save._r7h=true;
}

function applyH(N){
  if(!N||typeof N!=='object')return N;
  if(typeof G().applyNet==='function'&&G().applyNet!==applyNet)G().applyNet(N);
  wrapTitles(N);
  wrapSave(N);
  return N;
}

let origR7gApply=G().applyNet;
function applyNet(N){
  if(origR7gApply&&origR7gApply!==applyNet)N=origR7gApply(N);
  return applyH(N);
}
if(window.TG_R7G)window.TG_R7G.applyNet=applyNet;

let netRef=window.TG_AVATAR_NET;
try{
  Object.defineProperty(window,'TG_AVATAR_NET',{
    configurable:true,enumerable:true,
    get(){return netRef;},
    set(v){netRef=applyNet(v);}
  });
}catch(e){}
netRef=applyNet(netRef);
setInterval(()=>{const n=window.TG_AVATAR_NET;if(n&&(!n.titles||!n.titles._r7h||!n.save||!n.save._r7h))applyNet(n);},1000);

function hookNormalize(){
  const A=window.TG_AVATAR;if(!A||!A.normalize||A.normalize._r7h)return;
  const norm=A.normalize;
  A.normalize=function(c,opts){
    const incoming=c&&c.title;
    const o=norm.call(this,c,incoming&&isFreeTitle(incoming)?Object.assign({},opts,{checkOwned:false}):opts);
    if(o&&incoming&&isFreeTitle(incoming)&&!o.title)o.title=canonicalStoredTitle(incoming);
    if(o&&o.title&&isFreeTitle(o.title))o.title=canonicalStoredTitle(o.title);
    return o;
  };
  A.normalize._r7h=true;
  A.isFreeTitle=isFreeTitle;
  A.ownsTitle=function(s){return ownsTitle(s);};
}

function hookOpenPanel(){
  const A=window.TG_AVATAR;if(!A?.openPanel||A.openPanel._r7h)return;
  const prev=A.openPanel;
  A.openPanel=function(opts){
    applyNet(window.TG_AVATAR_NET);
    opts=opts||{};
    const cfg0=opts.config?Object.assign({},opts.config):{};
    if(cfg0.title&&isFreeTitle(cfg0.title))cfg0.title=canonicalStoredTitle(cfg0.title);
    const userSave=opts.onSave;
    const ret=prev.call(this,Object.assign({},opts,{
      config:Object.assign({},opts.config||{},cfg0),
      onSave:function(c,wire){
        const stored=canonicalStoredTitle(c&&c.title);
        const c2=Object.assign({},c,{title:stored});
        const w2=window.TG_AVATAR?.serialize?.(c2)||wire;
        if(typeof userSave==='function')return userSave(c2,w2);
      }
    }));
    /* If dropLocked still raced, restore a free title onto the live panel config after open. */
    try{
      const p=A.panel;
      if(p&&cfg0.title&&isFreeTitle(cfg0.title)&&p.config&&!p.config.title){
        /* panel.config is a getter of normalize(cfg); we cannot write private cfg. titles() injection is the real fix. */
      }
    }catch(e){}
    return ret;
  };
  A.openPanel._r7h=true;
}

function hookR6(){
  if(typeof r6OpenAvatar==='function'&&!r6OpenAvatar._r7h){
    window.r6OpenAvatar=function(){
      const A=window.TG_AVATAR;if(!A?.openPanel)return typeof toast==='function'&&toast('捏脸即将开放');
      if(typeof r3DenyVisit==='function'&&r3DenyVisit())return;
      window.TG_NPC?.hideBubbles?.();
      applyNet(window.TG_AVATAR_NET);
      const cfg0=Object.assign({},S.avatar||A.defaultConfig());
      if(cfg0.title)cfg0.title=canonicalStoredTitle(cfg0.title);
      A.openPanel({config:cfg0,onSave:async(cfg,wire)=>{
        const stored=canonicalStoredTitle(cfg.title);
        S.avatar=A.normalize(Object.assign({},cfg,{title:stored}),{checkOwned:false});
        if(S.avatar)S.avatar.title=stored;
        S.avatarWire=A.serialize(S.avatar);
        S.avatarInv??={accessories:[],titles:[],equipped:{}};
        S.avatarInv.equipped??={};
        const rows=(window.r6OwnedTitleRows?.()||[]);
        const paid=titleIdOf(stored);
        const row=stored?rows.find(t=>t&&t.id&&(t.id===cfg.title||t.id===stored||canonicalStoredTitle(t.name)===stored||(paid&&titleIdOf(t.id||t.name)===paid))):null;
        S.avatarInv.equipped.title=stored?(row&&row.id&&PAID_IDS[row.id]?row.id:(paid&&isPaidOwned(stored)?paid:(isFreeTitle(stored)?stored:row?.id||null))):null;
        save();r6ApplyAvatar();
        try{
          const r=await window.TG_AVATAR_NET?.save?.(S.avatarWire||S.avatar,S.avatarInv.equipped.title);
          if(r?.ok===false){toast(r6ToastReason(r));return;}
          toast('已保存容貌');
        }catch(e){toast(r6ToastReason('error'));}
      }});
    };
    window.r6OpenAvatar._r7h=true;
  }
}

/* Other players: decorate currently sets o.title from title_name (catalog join). Fall back to avatar JSON. */
function hookDecorate(){
  const net=window.TG_NET;if(!net||typeof net.decorate!=='function'||net.decorate._r7h)return;
  const prev=net.decorate;
  net.decorate=function(o){
    const r=prev.apply(this,arguments);
    if(o&&!o.title&&o.avatar&&o.avatar.title){
      o.title=o.avatar.title;
      if(o.name)o.nameWithTitle='【'+o.title+'】'+o.name;
    }else if(o&&o.avatar&&!o.avatar.title&&o.title){
      o.avatar=Object.assign({},o.avatar,{title:o.title});
    }
    return r;
  };
  net.decorate._r7h=true;
}

hookNormalize();
hookOpenPanel();
hookR6();
hookDecorate();
setTimeout(hookDecorate,0);
window.TG_R7H={isFreeTitle,ownsTitle,freeWhitelist,applyNet,freeIdOf};

})();
