/* r7g: keep stored/wire title names clean; ownership by id; wish-tag rim tweak lives in r7f.js. */
(()=>{ 'use strict';

const TITLE_OFF={
  title_shanxin:'善友',善信:'善友',善友:'善友',
  title_jushi:'雅士',居士:'雅士',雅士:'雅士',
  title_xingzhe:'旅人',修行者:'旅人',旅人:'旅人',
  title_gongdezhu:'福缘主',功德主:'福缘主',福缘主:'福缘主',福缘客:'福缘主',
  beads:'珠串',念珠:'珠串',佛珠:'珠串',珠串:'珠串',
  free_youfangke:'行客',游方客:'行客',行客:'行客', /* r8a: free title renamed (backend r7.4.1), id unchanged */
  free_chake:'茶客',free_yuanding:'园丁',free_chaboshi:'茶博士',free_yuanzhu:'园主',free_huashi:'画师',free_yaoshi:'药师',free_zhanggui:'掌柜' /* r8a: backend r7.4 free ids may arrive on the wire */
};
const STORED={
  title_shanxin:'善友',善信:'善友',善友:'善友',
  title_jushi:'雅士',居士:'雅士',雅士:'雅士',
  title_xingzhe:'旅人',修行者:'旅人',旅人:'旅人',
  title_gongdezhu:'福缘主',功德主:'福缘主',福缘主:'福缘主',福缘客:'福缘主',
  beads:'珠串',念珠:'珠串',佛珠:'珠串',珠串:'珠串',
  free_youfangke:'行客',游方客:'行客',行客:'行客', /* r8a: free title renamed (backend r7.4.1), id unchanged */
  free_chake:'茶客',free_yuanding:'园丁',free_chaboshi:'茶博士',free_yuanzhu:'园主',free_huashi:'画师',free_yaoshi:'药师',free_zhanggui:'掌柜' /* r8a: backend r7.4 free ids may arrive on the wire */
};
const IDS={title_shanxin:1,title_jushi:1,title_xingzhe:1,title_gongdezhu:1,beads:1};

function stripTitle(s){return String(s==null?'':s).replace(/[🌱🎋🧭✨💠]/gu,'').trim();}
function titleIdOf(s){
  const raw=String(s==null?'':s).trim(), bare=stripTitle(raw);
  if(IDS[raw])return raw;
  const map={善信:'title_shanxin',善友:'title_shanxin',居士:'title_jushi',雅士:'title_jushi',修行者:'title_xingzhe',旅人:'title_xingzhe',功德主:'title_gongdezhu',福缘主:'title_gongdezhu',福缘客:'title_gongdezhu',念珠:'beads',佛珠:'beads',珠串:'beads'};
  return map[bare]||map[raw]||null;
}
function displayTitle(s,id){
  const key=id||s;
  return TITLE_OFF[key]||TITLE_OFF[s]||TITLE_OFF[stripTitle(s)]||(s==null||s===''?'':String(s));
}
function canonicalStoredTitle(s){
  if(s==null||s==='')return '';
  const raw=String(s).trim(), id=titleIdOf(raw), bare=stripTitle(raw);
  if(id&&STORED[id])return STORED[id];
  return STORED[bare]||STORED[raw]||bare||raw;
}
function titleEquals(a,b){
  if(a==null||b==null||a===''||b==='')return a===b;
  if(a===b)return true;
  const ia=titleIdOf(a), ib=titleIdOf(b);
  if(ia&&ib)return ia===ib;
  return stripTitle(a)===stripTitle(b)||canonicalStoredTitle(a)===canonicalStoredTitle(b);
}
function matchTitleRow(rows,val){
  const id=titleIdOf(val), bare=stripTitle(val);
  return (rows||[]).find(t=>t&&(t.id===val||t.id===id||titleIdOf(t.id||t.name)===id||stripTitle(t.name)===bare||titleEquals(t.name,val)));
}
function netReady(N){return !!(N&&(typeof N.titles==='function'||typeof N.catalog==='function'||N.__offline||N.mine));}
function ownedRows(){
  try{
    const rows=window.r6OwnedTitleRows?.();
    if(Array.isArray(rows)&&rows.length)return rows;
  }catch(e){}
  const N=window.TG_AVATAR_NET;
  try{
    if(N?.titles)return (N.titles()||[]).filter(t=>t&&(t.owned===true||t.owned===1||t.have));
  }catch(e){}
  return (S?.avatarInv?.titles||[]).map(id=>({id,name:canonicalStoredTitle(id)}));
}
function isFreeTitle(s){
  const pal=window.TG_AVATAR?.palette?.title;
  if(!Array.isArray(pal)||!s)return false;
  return pal.includes(s)||pal.includes(stripTitle(s))||pal.includes(canonicalStoredTitle(s));
}
function ownsTitle(val){
  if(!val)return true;
  if(isFreeTitle(val))return true;
  const id=titleIdOf(val), bare=canonicalStoredTitle(val);
  const rows=ownedRows();
  if(rows.some(t=>t&&(t.id===val||t.id===id||titleIdOf(t.id||t.name)===id||titleEquals(t.name,val)||stripTitle(t.name)===bare)))return true;
  const inv=S?.avatarInv?.titles||[];
  return inv.some(x=>x===val||x===id||titleIdOf(x)===id);
}

function hookNormalize(){
  const A=window.TG_AVATAR;if(!A)return;
  A.displayTitle=function(s,id){return displayTitle(s,id);};
  A.titleMatches=function(s,t){return titleEquals(s,t&&(t.id||t.name))||titleEquals(s,t&&t.name);};
  A.titleIdOf=titleIdOf;
  A.canonicalTitle=canonicalStoredTitle;
  const norm=A.normalize;
  if(typeof norm==='function'&&!norm._r7g){
    A.normalize=function(c,opts){
      const incoming=c&&c.title;
      const stored=incoming?canonicalStoredTitle(incoming):incoming;
      const input=c&&typeof c==='object'?Object.assign({},c,stored!==undefined&&stored!==incoming?{title:stored}:{}):c;
      const o=norm.call(this,input,Object.assign({},opts,{checkOwned:false}));
      if(o&&o.title)o.title=canonicalStoredTitle(o.title);
      if(incoming&&!(opts&&opts.checkOwned===false)){
        const N=window.TG_AVATAR_NET;
        if(N&&netReady(N)&&!ownsTitle(o.title||stored||incoming))o.title='';
        else if(o)o.title=canonicalStoredTitle(o.title||stored||incoming);
      }
      return o;
    };
    A.normalize._r7g=true;
  }
}

function wrapTitles(N){
  if(!N||typeof N.titles!=='function'||N.titles._r7g)return;
  const fn=N.titles;
  N.titles=function(){
    const seen=new Set(), out=[];
    (fn.apply(this,arguments)||[]).forEach(t=>{
      if(!t||t.r7Alias||t.r7DisplayOnly)return;
      const id=t.id||t.key||titleIdOf(t.name);
      const name=canonicalStoredTitle(t.name||(id&&STORED[id])||'');
      const key=id||name;if(!name||seen.has(key))return;seen.add(key);
      // keep catalog name (no emoji) so avatar.js chips/dropLocked compare stored names
      out.push(Object.assign({},t,{id,name,emoji:''}));
    });
    return out;
  };
  N.titles._r7g=true;
}

function fixWire(avatar, stored, titleId){
  const id=titleIdOf(titleId)||titleIdOf(stored)||null;
  let cfg=avatar;
  if(typeof avatar==='string'){
    try{cfg=window.TG_AVATAR?.deserialize?.(avatar);}catch(e){cfg=null;}
  }
  if(cfg&&typeof cfg==='object'){
    cfg=Object.assign({},cfg,{title:stored||canonicalStoredTitle(cfg.title)});
    const wire=window.TG_AVATAR?.serialize?.(cfg)||cfg;
    return {wire, cfg, id};
  }
  return {wire:avatar, cfg, id};
}

function wrapSave(N){
  if(!N||typeof N.save!=='function'||N.save._r7g){
    // offline stub may lack save; install a passthrough so intercepts still work
    if(N&&typeof N.save!=='function'){
      N.save=async function(avatar,titleId){return {ok:true,offline:true,avatar,title:titleId};};
      N.save._r7g=true;N.save._r7gStub=true;
    }
    return;
  }
  const prev=N.save;
  N.save=async function(avatar,titleId){
    applyNet(N);
    const stored=canonicalStoredTitle(typeof avatar==='string'
      ?(function(){try{return window.TG_AVATAR?.deserialize?.(avatar)?.title;}catch(e){return '';}})()
      :(avatar&&avatar.title)||'');
    const fixed=fixWire(avatar, stored||canonicalStoredTitle(titleId), titleId);
    return prev.call(this, fixed.wire, fixed.id||titleId||null);
  };
  N.save._r7g=true;
}

function applyNet(N){
  if(!N||typeof N!=='object')return N;
  wrapTitles(N);
  wrapSave(N);
  return N;
}

let netRef=window.TG_AVATAR_NET;
netRef=applyNet(netRef);
try{
  const desc=Object.getOwnPropertyDescriptor(window,'TG_AVATAR_NET');
  if(!desc||desc.configurable!==false){
    Object.defineProperty(window,'TG_AVATAR_NET',{
      configurable:true,enumerable:true,
      get(){return netRef;},
      set(v){netRef=applyNet(v);}
    });
  }
}catch(e){}
setInterval(()=>{const n=window.TG_AVATAR_NET;if(n&&(!n.titles||!n.titles._r7g||!n.save||!n.save._r7g))applyNet(n);},1000);

function relabelTitleChips(root){
  const host=root||document.querySelector('.tgav-root');
  if(!host)return;
  host.querySelectorAll('.tgav-chip').forEach(b=>{
    const id=b.getAttribute('data-id');
    if(!id)return;
    const d=displayTitle(id);
    if(!d||d===id)return;
    if(!(titleIdOf(id)||TITLE_OFF[stripTitle(id)]))return;
    const lock=b.querySelector('.tgav-lock');
    const text=[...b.childNodes].find(n=>n.nodeType===3);
    if(text)text.textContent=d;
    else if(!lock)b.textContent=d;
    else b.insertBefore(document.createTextNode(d),lock);
  });
  const hud=host.querySelector('.tgav-plate, .tgav-hud, canvas');
  // plate is a canvas, fillText hook handles it
}

function hookOpenPanel(){
  const A=window.TG_AVATAR;if(!A?.openPanel||A.openPanel._r7g)return;
  const prev=A.openPanel;
  A.openPanel=function(opts){
    applyNet(window.TG_AVATAR_NET);
    opts=opts||{};
    const cfg0=opts.config?Object.assign({},opts.config):{};
    if(cfg0.title)cfg0.title=canonicalStoredTitle(cfg0.title);
    const userSave=opts.onSave;
    const ret=prev.call(this,Object.assign({},opts,{
      config:Object.assign({},opts.config||{},cfg0),
      onSave:function(c,wire){
        const stored=canonicalStoredTitle(c&&c.title);
        const c2=Object.assign({},c,{title:stored});
        const w2=window.TG_AVATAR?.serialize?.(c2)||wire;
        if(typeof userSave==='function')return userSave(c2,w2);
      }
    }));
    const hookPanel=()=>{
      const p=A.panel;
      if(p&&!p._r7g){
        const st=p.setTab, rd=p.render;
        if(typeof st==='function')p.setTab=function(){const r=st.apply(this,arguments);relabelTitleChips(p.root);return r;};
        if(typeof rd==='function')p.render=function(){const r=rd.apply(this,arguments);relabelTitleChips(p.root);return r;};
        p._r7g=true;
      }
      relabelTitleChips(p&&p.root);
    };
    hookPanel();
    requestAnimationFrame(hookPanel);
    const body=document.querySelector('.tgav-body');
    if(body&&!body._r7gMo){
      const mo=new MutationObserver(()=>relabelTitleChips());
      mo.observe(body,{childList:true,subtree:true});
      body._r7gMo=mo;
    }
    return ret;
  };
  A.openPanel._r7g=true;
}

function hookR6(){
  if(typeof r6PickTitle==='function'&&!r6PickTitle._r7g){
    const prev=r6PickTitle;
    window.r6PickTitle=function(idOrName){
      if(!idOrName)return prev.apply(this,arguments);
      const row=matchTitleRow(ownedRows(),idOrName);
      const r=prev.call(this,row?row.id:idOrName);
      if(S?.avatar)S.avatar.title=row?canonicalStoredTitle(row.name||row.id):'';
      return r;
    };
    window.r6PickTitle._r7g=true;
  }
  if(typeof r6TitlePickerHtml==='function'&&!r6TitlePickerHtml._r7g){
    window.r6TitlePickerHtml=function(){
      const owned=ownedRows();
      if(!owned.length)return '<p class="muted">尚未获得称号</p>';
      const cur=canonicalStoredTitle(S.avatar?.title||'');
      const curId=titleIdOf(S.avatar?.title||S.avatarInv?.equipped?.title||'');
      return '<p>称号</p><select id="r6TitlePick"><option value="">（不佩戴）</option>'+owned.map(t=>{
        const name=displayTitle(t.name,t.id);
        const sel=(t.id===curId||canonicalStoredTitle(t.name)===cur||t.id===(S.avatarInv?.equipped?.title||''))?' selected':'';
        return '<option value="'+r3Esc(t.id)+'"'+sel+'>'+r3Esc(name)+'</option>';
      }).join('')+'</select>';
    };
    window.r6TitlePickerHtml._r7g=true;
  }
  if(typeof r6OpenAvatar==='function'&&!r6OpenAvatar._r7g){
    window.r6OpenAvatar=function(){
      const A=window.TG_AVATAR;if(!A?.openPanel)return typeof toast==='function'&&toast('捏脸即将开放');
      if(typeof r3DenyVisit==='function'&&r3DenyVisit())return;
      window.TG_NPC?.hideBubbles?.();
      applyNet(window.TG_AVATAR_NET);
      const cfg0=Object.assign({},S.avatar||A.defaultConfig());
      if(cfg0.title)cfg0.title=canonicalStoredTitle(cfg0.title);
      A.openPanel({config:cfg0,onSave:async(cfg,wire)=>{
        const stored=canonicalStoredTitle(cfg.title);
        S.avatar=A.normalize(Object.assign({},cfg,{title:stored}),{checkOwned:false});
        if(S.avatar)S.avatar.title=stored;
        S.avatarWire=A.serialize(S.avatar);
        S.avatarInv??={accessories:[],titles:[],equipped:{}};
        S.avatarInv.equipped??={};
        const row=matchTitleRow(ownedRows(),cfg.title||stored);
        S.avatarInv.equipped.title=row?row.id:(stored?titleIdOf(stored):null);
        save();r6ApplyAvatar();
        try{
          const r=await window.TG_AVATAR_NET?.save?.(S.avatarWire||S.avatar,S.avatarInv.equipped.title);
          if(r?.ok===false){toast(r6ToastReason(r));return;}
          toast('已保存容貌');
        }catch(e){toast(r6ToastReason('error'));}
      }});
    };
    window.r6OpenAvatar._r7g=true;
  }
}

// Display layer only: HUD / plate canvas shows official names with emoji.
(function hookFillText(){
  const fill=CanvasRenderingContext2D.prototype.fillText;
  if(fill._r7g)return;
  function wrapped(text,...args){
    if(typeof text==='string'){
      const d=displayTitle(text);
      if(d&&d!==text&&(titleIdOf(text)||TITLE_OFF[stripTitle(text)]))text=d;
    }
    return fill.call(this,text,...args);
  }
  wrapped._r7g=true;
  CanvasRenderingContext2D.prototype.fillText=wrapped;
})();

hookNormalize();
hookOpenPanel();
hookR6();
window.TG_R7G={titleIdOf,displayTitle,canonicalStoredTitle,titleEquals,ownsTitle,applyNet};

})();
