import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const dir = path.dirname(fileURLToPath(import.meta.url));
const shell = fs.readFileSync(path.join(dir, 'shell.html'), 'utf8');
const styles = fs.readFileSync(path.join(dir, 'styles.css'), 'utf8');
const three = fs.readFileSync(path.join(dir, 'three.inline.js'), 'utf8');
const gameplay = fs.readFileSync(path.join(dir, 'gameplay.js'), 'utf8');
const world = fs.readFileSync(path.join(dir, 'world3d.js'), 'utf8');
const html = shell
  .replace('<title>福缘寺 · 心田小院</title>', '<title>福缘里 · 心田小院</title>')
  .replace('/*__STYLES__*/', () => styles)
  .replace('/*__THREE__*/', () => fs.readFileSync(path.join(dir,'hooks.txt'),'utf8')+'\n'+three)
  .replace('/*__GAMEPLAY__*/', () => gameplay)
  .replace('/*__WORLD__*/', () => world+"\n"+fs.readFileSync(path.join(dir,"enhance.js"),"utf8")+"\n"+fs.readFileSync(path.join(dir,"art2.js"),"utf8")+"\n"+fs.readFileSync(path.join(dir,"r3.js"),"utf8")+"\n"+fs.readFileSync(path.join(dir,"r4.js"),"utf8")+"\n"+fs.readFileSync(path.join(dir,"art3.js"),"utf8")+"\n"+fs.readFileSync(path.join(dir,"r41.js"),"utf8")+["animals2.js","audio.js","r7b-audio.js","r5.js","realism.js","ui-kit.js","avatar.js","npc.js","teahouse-assets.js","mounts.js","r6.js","r6-art.js","r6-net.js","r6-joints.js","r6-art-hk.js","suggest.js","manual.js","r7.js","r7-compliance.js","r7b.js","r7b-ux.js","r7c.js","r7d.js","r7e.js","r7f.js","r7g.js","r7h.js","r8.js","r8b.js","r8c.js","r8c2.js","r8c2b.js","r8c2c.js","r8d.js","r8d1.js","r8d2.js","r8d3.js","r8d4.js","r9-sell.js","r9-fortune.js"].filter(f=>fs.existsSync(path.join(dir,f))).map(f=>"\n"+fs.readFileSync(path.join(dir,f),"utf8")).join(""));
const out = path.join(dir, '..', 'index.html');
fs.writeFileSync(out, html);
console.log('packed', out, fs.statSync(out).size, 'bytes');
