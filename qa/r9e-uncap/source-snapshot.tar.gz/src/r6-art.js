/* r6-art.js — TG_REAL install, shader warm-up, tea interact fix, teahouse wall sync. */
(()=>{
const phone=()=>document.body.classList.contains('is-touch')||('ontouchstart' in window)||(navigator.maxTouchPoints>0)||innerWidth<=500;
window.r6IsPhone=phone;

function quality(){return phone()?'low':'high';}

window.r6InstallReal=function(){
  const R=window.TG_REAL;if(!R||R.r6Installed)return;
  try{R.install({upgrade:true,quality:quality(),toneMapping:'neutral'});R.applyToActive();}catch(e){console.warn('[r6] TG_REAL.install',e);}
  R.r6Installed=true;
};

window.r6WarmShaders=function(){
  const R=window.TG_REAL,w=W3;if(!R||!w?.renderer||!w.scene||!w.camera||w.r6Warmed)return;
  const names=['gate','plaza','market','yard','lotus','hall','zen','study','teahouse','tea'];
  const vis={};
  for(const [id,s]of Object.entries(w.spaces||{}))vis[id]=s.group.visible;
  try{
    for(const name of names){
      const space=w.spaces[name]||w.spaces[name==='teahouse'?'tea':name==='tea'?'teahouse':name];
      if(!space)continue;
      for(const s of Object.values(w.spaces))s.group.visible=s===space;
      try{R.applyPreset(w.renderer,w.scene,name,{hemi:w.hemi,sun:w.sun,keepSunPosition:true,toneMapping:'neutral'});if(space.group)R.upgradeScene(space.group,{quality:quality(),filter:m=>!m.userData.r41Label&&!m.userData.wallSign&&!m.userData.tgRealSkip});w.renderer.compile(w.scene,w.camera);}catch(e){console.warn('[r6] compile',name,e);}
    }
  }finally{
    for(const [id,s]of Object.entries(w.spaces||{}))s.group.visible=vis[id];
    try{R.applyToActive();}catch(e){}
    w.r6Warmed=true;
  }
};

window.r6FixTeaInteracts=function(){
  const t=W3?.spaces?.tea||W3?.spaces?.teahouse;const court=t?.r6Tea;if(!t||!court)return;
  const parts={messageWall:court.wall||court.parts?.wall,chessTable:court.parts?.chess,river:court.river||court.parts?.river};
  if(Array.isArray(court.interact)){
    for(const i of court.interact){
      const part=parts[i.kind];
      if(part?.position)part.position.set(i.x,part.position.y,i.z);
    }
    court.group?.updateMatrixWorld?.(true);
  }
  t.items=t.items.filter(i=>!/留言墙|对弈|河灯|寄愿|落座/.test(i.label||''));
  if(Array.isArray(court.interact)){
    for(const i of court.interact){
      if(i.kind==='messageWall')worldInteract(t,i.x,i.z,'茶会留言墙',r6TeaWall,3);
      else if(i.kind==='chessTable')worldInteract(t,i.x,i.z,'石桌对弈',()=>toast('棋局待友，先坐片刻'));
      else if(i.kind==='river')worldInteract(t,i.x,i.z,'放河灯',()=>r6ReleaseLantern(court));
    }
  }
  const tables=court.parts?.tables||[];
  for(const table of tables)for(const seat of table.userData?.seats||[]){
    const v=new THREE.Vector3(seat.x,0,seat.z).applyAxisAngle(new THREE.Vector3(0,1,0),table.rotation.y).add(table.position);
    worldInteract(t,v.x,v.z,'落座品茶',()=>{
      const id='tea-'+Math.round(v.x*10)+'-'+Math.round(v.z*10);
      if(window.TG_TEAHOUSE?.sit&&!TG_TEAHOUSE.sit(id))return toast('这个座位有人了');
      r4Use({id:'cushion',x:v.x,z:v.z,rot:seat.ry+table.rotation.y},W3.active);
    });
  }
};

window.r6ReleaseLantern=function(court){
  if(r3DenyVisit&&r3DenyVisit())return;
  const go=()=>{try{court?.river?.release?.();}catch(e){}toast('一盏河灯，寄愿平安');};
  if(window.TG_TEAHOUSE?.release)return Promise.resolve(TG_TEAHOUSE.release('平安')).then(r=>{
    if(!r||r.ok){r6Daily(S).lanterns=(S.daily.lanterns||0)+1;save();go();}
    else toast(r.reason==='daily'?'今日河灯已满三盏':'暂时无法放灯');
  });
  r6Daily(S);
  if((S.daily.lanterns||0)>=3)return toast('今日河灯已满三盏');
  if(S.coins>=3){S.coins-=3;S.daily.lanterns=(S.daily.lanterns||0)+1;save();renderTop();}
  go();
};

window.r6TeaSyncWall=async function(){
  const court=(W3?.spaces?.tea||W3?.spaces?.teahouse)?.r6Tea;
  let msgs=S.tea?.messages||[];
  if(window.TG_TEAHOUSE?.wall){
    try{
      const posts=await TG_TEAHOUSE.wall();
      if(Array.isArray(posts))msgs=posts.map(p=>({name:p.name||p.author||'茶客',text:p.text||p.body||'',at:p.at||p.id}));
    }catch(e){}
  }
  court?.wall?.setMessages?.(msgs.map(m=>({text:m.text,author:m.name||m.author})));
};

const originalWall=window.r6TeaWall;
window.r6TeaWall=function(){
  r6TeaSyncWall();
  openModal('<h2>茶会留言墙</h2>'+(S.tea.messages||[]).map(m=>{window.r7RawText?.(m.name,m.text);return `<p><b data-raw>${r3Esc(m.name)}</b>：<span data-raw>${r3Esc(m.text)}</span></p>`;}).join('')+'<input id="r6Message" maxlength="120" placeholder="留一句善意（120 字）"><button class="btn" id="r6Send">留笺</button>');
  $('#r6Send').onclick=async()=>{
    const text=$('#r6Message').value.trim();if(!text)return;
    if(text.length>120)return toast('最多 120 字');
    r6Daily(S);
    if((S.daily.wallPosts||0)>=30)return toast('今日留言已达 30 条');
    const wait=20000-((Date.now()-(S.daily.wallAt||0)));
    if(wait>0)return toast('请再稍候 '+Math.ceil(wait/1000)+' 秒');
    if(window.TG_TEAHOUSE?.post){
      const r=await TG_TEAHOUSE.post(text);
      if(!r||!r.ok)return toast({empty:'请写一句',too_long:'最多 120 字',slow:'请稍后再留',daily:'今日留言已满',blocked:'这条留言无法发布'}[r?.reason]||'暂时无法留笺');
    }else{
      S.tea.messages.push({id:'msg_'+Date.now().toString(36),name:String(window.TG_AUTH?.name||'茶客').slice(0,20),text,at:Date.now()});
      S.tea.messages=S.tea.messages.slice(-40);
    }
    S.daily.wallPosts=(S.daily.wallPosts||0)+1;S.daily.wallAt=Date.now();save();
    await r6TeaSyncWall();r6TeaWall();
  };
};


window.r6SegmentBamboo=function(space){
  const court=space?.r6Tea;if(!court)return;
  const groups=[];court.group?.traverse?.(o=>{if(o.userData?.kind==='bambooFence')groups.push(o);});
  if(!groups.length)return;
  const big=groups.flatMap(g=>g.userData.blocks||[]);
  const match=(a,b)=>Math.abs(a.x-b.x)<.2&&Math.abs(a.X-b.X)<.2&&Math.abs(a.z-b.z)<.2&&Math.abs(a.Z-b.Z)<.2;
  function segs(b,step=1.6){
    const w=b.X-b.x,d=b.Z-b.z,out=[];
    if(w>=d){for(let x=b.x;x<b.X-1e-6;x+=step)out.push({x,X:Math.min(b.X,x+step),z:b.z,Z:b.Z});}
    else{for(let z=b.z;z<b.Z-1e-6;z+=step)out.push({x:b.x,X:b.X,z,Z:Math.min(b.Z,z+step)});}
    return out.length?out:[b];
  }
  const extra=big.flatMap(b=>segs(b));
  const filter=list=>list.filter(b=>!big.some(g=>match(b,g)));
  if(Array.isArray(court.blocks)){court.blocks=filter(court.blocks).concat(extra);}
  if(space.blocks){space.blocks=filter(space.blocks).concat(extra);}
};

window.r6TagRealismFixes=function(root){
  if(!root)return;
  root.traverse(m=>{
    if(!m.isMesh)return;
    const rx=Math.abs(m.rotation.x)%Math.PI,rz=Math.abs(m.rotation.z)%Math.PI;
    const near=(a,t)=>Math.abs(a-t)<.18||Math.abs(a-(Math.PI-t))<.18;
    // Sloped roofs (~18–45°) keep their own UVs — box-projected world UVs seam on the ridge.
    if(near(rx,Math.PI/4)||near(rz,Math.PI/4)||near(rx,.3)||near(rz,.3)) m.userData.tgRealSkip=true;
    // Green stall canopies / banners are often mis-classified as foliage.
    const c=m.material?.color;
    if(c){
      const h=c.getHex?c.getHex():0;
      const hex=c.getHexString?.();
      if(hex&&/^[0-4][0-9a-f][89a-f][0-9a-f][0-4][0-9a-f]$/.test(hex)&&m.position.y>1.6) m.userData.tgRealSkip=true;
    }
    if(m.userData.r41Label||m.userData.wallSign||m.userData.tgLabel) m.userData.tgRealSkip=true;
  });
};


window.r6TrimMarket=function(){
  const s=W3?.spaces?.market;if(!s?.group||s.r6Trimmed)return;
  const npcRoots=new Set((window.TG_NPC?.list?.()||[]).map(n=>n.root||n.model).filter(Boolean));
  const isNpc=m=>{let o=m;while(o){if(npcRoots.has(o))return true;o=o.parent;}return false;};
  const bins=new Map();
  s.group.traverse(m=>{
    if(!m.isMesh||m.isInstancedMesh||m===s.floor||isNpc(m))return;
    if(m.userData?.r41Label||m.userData?.wallSign||m.userData?.r6Fade)return;
    if(m.material?.map||m.material?.vertexColors)return;
    if(m.geometry!==W3.geometries?.box&&m.geometry?.type!=='BoxGeometry')return;
    const k=m.material?.uuid||'x';
    if(!bins.has(k))bins.set(k,[]);
    bins.get(k).push(m);
  });
  for(const arr of bins.values()){
    if(arr.length<2)continue;
    const geos=arr.map(m=>{m.updateMatrixWorld(true);const g=(m.geometry.index?m.geometry.toNonIndexed():m.geometry.clone()).applyMatrix4(m.matrixWorld);return g;});
    try{
      const geo=typeof mergeGeometries==='function'?mergeGeometries(geos):null;
      if(!geo)continue;
      const mesh=new THREE.Mesh(geo,arr[0].material);
      mesh.castShadow=mesh.receiveShadow=true;mesh.userData.r6Merged=true;
      s.group.add(mesh);
      arr.forEach(m=>m.parent?.remove(m));
      geos.forEach(g=>g.dispose());
    }catch(e){}
  }
  s.r6Trimmed=true;
};

function boot(){
  const tea=W3?.spaces?.tea||W3?.spaces?.teahouse;
  if(tea)r6SegmentBamboo(tea);
  for(const sp of Object.values(W3?.spaces||{}))r6TagRealismFixes(sp.group);
  r6TrimMarket();r6InstallReal();
  r6FixTeaInteracts();
  r6TeaSyncWall();
  r6WarmShaders();
}
const enter=worldEnter;
worldEnter=function(name,previous){
  window.TG_NPC?.hideBubbles?.();
  const out=enter.apply(this,arguments);
  const id=W3?.active||name;
  if(id==='tea'||id==='teahouse')r6FixTeaInteracts(),r6TeaSyncWall();
  window.TG_REAL?.applyToActive?.();
  return out;
};
if(W3?.renderer)boot();
else addEventListener('load',()=>setTimeout(boot,0));
})();
