/* r7e: gardener instead of plaza monk, flower bed instead of lotus wheel, pulled-back plaza camera. */
(()=>{'use strict';
const T=typeof THREE!=='undefined'&&THREE||window.THREE;
const merge=typeof mergeGeometries==='function'?mergeGeometries:(T.BufferGeometryUtils&&T.BufferGeometryUtils.mergeGeometries);

function hideLotusDisc(){
  const p=W3.spaces.plaza, box=new T.Box3(), m4=new T.Matrix4(), pos=new T.Vector3(), q=new T.Quaternion(), s=new T.Vector3();
  let n=0;
  p.group.traverse(m=>{
    if(!m.isMesh)return;
    if(m.parent&&(m.parent.name==='r7e-flower-bed'||m.parent.name==='r7e-gardener'))return;
    if(m.isInstancedMesh){
      let changed=false;
      if(!m.geometry.boundingBox)m.geometry.computeBoundingBox();
      for(let i=0;i<m.count;i++){
        m.getMatrixAt(i,m4);m4.decompose(pos,q,s);
        const r=Math.hypot(pos.x,pos.z+15.2);
        const xz=Math.max(Math.abs(s.x),Math.abs(s.z));
        // the baked 圆形莲纹铺装 is a disc instance, scale 2.4, y≈0.092, at (0,-15.2)
        if(r<1.2&&pos.y<0.35&&xz>=2){
          pos.y=-8;s.set(0.001,0.001,0.001);m4.compose(pos,q,s);m.setMatrixAt(i,m4);changed=true;n++;
        }
      }
      if(changed){m.instanceMatrix.needsUpdate=true;if(m.computeBoundingSphere)m.computeBoundingSphere();}
      return;
    }
    box.setFromObject(m);
    const cx=(box.min.x+box.max.x)/2, cz=(box.min.z+box.max.z)/2, cy=(box.min.y+box.max.y)/2;
    const tall=box.max.y-box.min.y, wide=Math.max(box.max.x-box.min.x,box.max.z-box.min.z);
    if(Math.hypot(cx,cz+15.2)<1.6&&cy<0.4&&tall<0.4&&wide>2.8){
      m.visible=false;n++;
    }
  });
  return n;
}

function mergeGroup(g){
  if(!merge)return;
  g.updateMatrixWorld(true);
  const inv=g.matrixWorld.clone().invert(), geos=[], colors=[];
  g.traverse(m=>{
    if(!m.isMesh||m.isInstancedMesh)return;
    if(m.userData.skipMerge)return;
    const geo=(m.geometry.index?m.geometry.toNonIndexed():m.geometry.clone()).applyMatrix4(new T.Matrix4().multiplyMatrices(inv,m.matrixWorld));
    geos.push(geo);
    const c=m.material.color;
    for(let i=0;i<geo.attributes.position.count;i++)colors.push(c.r,c.g,c.b);
  });
  if(!geos.length)return;
  const geo=merge(geos);
  geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));
  const keep=[];
  [...g.children].forEach(ch=>{
    if(ch.isMesh&&!ch.userData.skipMerge){g.remove(ch);if(ch.geometry)ch.geometry.dispose();if(ch.material)ch.material.dispose();}
    else keep.push(ch);
  });
  const mesh=new T.Mesh(geo,new T.MeshLambertMaterial({vertexColors:true}));
  mesh.castShadow=true;mesh.userData.tgRealSkip=true;mesh.name='r7e-merged';
  g.add(mesh);
  geos.forEach(o=>o.dispose());
}

function addMesh(g,geo,color,x,y,z,sx,sy,sz,rx,ry,rz){
  const mesh=new T.Mesh(geo,new T.MeshLambertMaterial({color}));
  mesh.position.set(x,y,z);if(sx!=null)mesh.scale.set(sx,sy,sz);if(rx||ry||rz)mesh.rotation.set(rx||0,ry||0,rz||0);
  g.add(mesh);return mesh;
}
function addFlowerBed(){
  const p=W3.spaces.plaza;
  if(p.group.getObjectByName('r7e-flower-bed'))return;
  const g=new T.Group();g.name='r7e-flower-bed';g.position.set(0,0,-15.2);p.group.add(g);
  const soil=new T.Mesh(new T.CircleGeometry(2.05,28).rotateX(-Math.PI/2),new T.MeshLambertMaterial({color:'#6a4e32'}));
  soil.position.y=0.12;soil.receiveShadow=true;g.add(soil);
  const boxG=new T.BoxGeometry(1,1,1), cyl=new T.CylinderGeometry(.5,.5,1,5), ball=new T.SphereGeometry(1,6,5), leaf=new T.SphereGeometry(1,5,4);
  for(let i=0;i<16;i++){
    const a=i/16*Math.PI*2,x=Math.cos(a)*2.05,z=Math.sin(a)*2.05;
    addMesh(g,boxG,'#9b9584',x,0.16,z,0.28,0.28,0.22,0,-a,0);
  }
  let seed=19;const rand=()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);
  const palette=['#c45b5b','#e8d36a','#e9eef2','#d986b3','#f2a65a'];
  for(let i=0;i<22;i++){
    const a=rand()*Math.PI*2,r=rand()*1.55,x=Math.cos(a)*r,z=Math.sin(a)*r,h=.18+rand()*.22;
    addMesh(g,cyl,'#4f7a3d',x,0.12+h/2,z,.03,h,.03);
    addMesh(g,ball,palette[i%palette.length],x,0.14+h+.06,z,.12,.1,.12);
    if(i%3===0)addMesh(g,leaf,'#5d8a4a',x*.9,0.1,z*.9,.2,.05,.16);
  }
  mergeGroup(g);
  if(!p.blocks.some(b=>b.r7eBed))p.blocks.push({x:-2.15,X:2.15,z:-15.2-2.15,Z:-15.2+2.15,r7eBed:true});
}

function replaceMonk(){
  const p=W3.spaces.plaza, box=new T.Box3(), remove=[];
  p.group.traverse(m=>{
    if(!m.isMesh||m.isInstancedMesh)return;
    if(m.parent&&(m.parent.name==='r7e-gardener'||m.parent.name==='r7e-flower-bed'))return;
    let hex='';try{hex=(m.material?.color?.getHexString?.()||'').toLowerCase();}catch(e){}
    if(hex!=='cf7d28'&&hex!=='f3c994')return;
    box.setFromObject(m);
    const cx=(box.min.x+box.max.x)/2, cz=(box.min.z+box.max.z)/2;
    if(Math.hypot(cx+14,cz-12)<2.5||Math.hypot(cx+10,cz-5)<2.5)remove.push(m);
  });
  remove.forEach(m=>{if(m.parent)m.parent.remove(m);m.visible=false;});
  if(p.group.getObjectByName('r7e-gardener'))return;
  const g=new T.Group();g.name='r7e-gardener';g.position.set(-14,0,12);g.rotation.y=Math.PI*0.65;p.group.add(g);
  function add(geo,color,x,y,z,sx,sy,sz,rx,ry,rz){
    const mesh=new T.Mesh(geo,new T.MeshLambertMaterial({color}));
    mesh.position.set(x,y,z);if(sx!=null)mesh.scale.set(sx,sy,sz);if(rx||ry||rz)mesh.rotation.set(rx||0,ry||0,rz||0);
    g.add(mesh);return mesh;
  }
  const boxG=new T.BoxGeometry(1,1,1), sph=new T.SphereGeometry(1,8,6), cyl=new T.CylinderGeometry(.5,.5,1,8), cone=new T.ConeGeometry(.5,1,8);
  add(cyl,'#4a5a38',-.12,.28,0,.16,.56,.16);
  add(cyl,'#4a5a38', .12,.28,0,.16,.56,.16);
  add(boxG,'#5a3d28',-.12,.04,.06,.18,.08,.28);
  add(boxG,'#5a3d28', .12,.04,.06,.18,.08,.28);
  add(boxG,'#5f7c45',0,.82,0,.55,.7,.36);
  add(boxG,'#8b5a32',0,.72,.2,.4,.12,.08);
  add(cyl,'#5f7c45',-.38,.9,0,.14,.5,.14,0,0,.4);
  add(sph,'#e8b98e',-.52,.62,.08,.09,.09,.09);
  add(cyl,'#5f7c45', .38,.88,.05,.14,.48,.14,0,0,-.5);
  add(sph,'#e8b98e', .55,.62,.18,.09,.09,.09);
  add(cyl,'#6d7f6a', .62,.52,.22,.16,.22,.16);
  add(cyl,'#6d7f6a', .62,.66,.22,.12,.06,.12);
  add(cyl,'#6d7f6a', .72,.54,.22,.16,.06,.06,0,0,Math.PI/2);
  add(sph,'#e8b98e',0,1.32,0,.2,.22,.2);
  add(sph,'#3a3028',0,1.4,-.02,.21,.16,.2);
  add(cone,'#c9a15b',0,1.62,0,.62,.22,.62);
  add(cyl,'#b89048',0,1.52,0,.7,.05,.7);
  add(sph,'#372f2a',-.07,1.34,.17,.025,.02,.02);
  add(sph,'#372f2a', .07,1.34,.17,.025,.02,.02);
  mergeGroup(g);
  worldLabel(g,'园丁阿禾',0,2.15,.1,2.2);
  worldInteract(p,-14,12,'园丁阿禾',()=>{
    const lines=['花要勤浇，土要松一松。','这圈花坛是新铺的，坐下来歇歇也行。','松土之后再浇水，根才站得稳。'];
    if(typeof toast==='function')toast('园丁阿禾：'+lines[Math.floor(Math.random()*lines.length)]);
  },2.2);
}

function extendAabb(){
  const prev=window.TG_R7D_AABB;
  if(typeof prev!=='function'||prev._r7e)return;
  window.TG_R7D_AABB=function(){
    const r=prev();
    const p=W3.spaces.plaza, box=new T.Box3();
    function add(name,obj,y0,y1){
      if(!obj)return;
      box.setFromObject(obj);
      const b={x:box.min.x,X:box.max.x,y:box.min.y,Y:box.max.y,z:box.min.z,Z:box.max.z};
      const cx=(b.x+b.X)/2, cz=(b.z+b.Z)/2;
      const hx=(b.X-b.x)/2, hz=(b.Z-b.z)/2;
      // reuse the same clearance math as printed rows
      const existing=r.rows.find(row=>row.object===name);
      const row={
        object:name,
        box:[+b.x.toFixed(2),+b.X.toFixed(2),+b.y.toFixed(2),+b.Y.toFixed(2),+b.z.toFixed(2),+b.Z.toFixed(2)],
        trunk:+(Math.hypot(cx,cz)-1.5-Math.max(hx,hz)).toFixed(2),
        roots:+(Math.hypot(cx,cz)-2.9-Math.max(hx,hz)).toFixed(2),
        canopy:+(Math.hypot(cx,cz)-7.1-Math.max(hx,hz)).toFixed(2),
        min:0,nearest:'canopy',overlap:false
      };
      row.min=Math.min(row.trunk,row.roots,row.canopy);
      row.nearest=row.min===row.trunk?'trunk':row.min===row.roots?'roots':'canopy';
      row.overlap=row.min<0;
      if(existing)Object.assign(existing,row);else r.rows.push(row);
    }
    add('花坛',p.group.getObjectByName('r7e-flower-bed'));
    add('园丁阿禾',p.group.getObjectByName('r7e-gardener'));
    // 铜灯 stands in the flower bed on purpose — drop that pair
    r.pairs=(r.pairs||[]).filter(pr=>!(pr.includes('铜灯')&&pr.includes('花坛')));
    return r;
  };
  window.TG_R7D_AABB._r7e=true;
}

function treeLabel(){
  const p=W3.spaces.plaza?.group;if(!p)return null;
  let found=p.children.find(ch=>ch.userData&&ch.userData.r7eTreeLabel);
  if(found)return found;
  p.children.forEach(ch=>{
    if(ch.userData&&ch.userData.wallSign&&Math.abs(ch.position.x)<.2&&Math.abs(ch.position.y-3.15)<.4&&Math.abs(ch.position.z-2.4)<.4){
      ch.userData.r7eTreeLabel=true;
      ch.userData.r7eLabelRest={x:ch.position.x,y:ch.position.y,z:ch.position.z};
      found=ch;
    }
  });
  return found||null;
}
function placeTreeLabel(mode,cam){
  const lab=treeLabel();if(!lab)return;
  const rest=lab.userData.r7eLabelRest||{x:0,y:3.15,z:2.4};
  if(mode==='port'){
    // float above the canopy and billboard toward the high overview camera
    lab.position.set(0,12.55,3.2);
    if(cam){lab.quaternion.copy(cam.quaternion);}
  }else{
    lab.position.set(rest.x,rest.y,rest.z);
    lab.rotation.set(0,0,0);
    lab.quaternion.set(0,0,0,1);
  }
}

function r7eDress(){
  if(!W3?.spaces?.plaza||W3.spaces.plaza.r7eDressed)return;
  W3.spaces.plaza.r7eDressed=true;
  hideLotusDisc();
  addFlowerBed();
  replaceMonk();
  treeLabel();
  extendAabb();
  if(typeof window.TG_R7D_AABB==='function')window.TG_R7E_AABB=window.TG_R7D_AABB();
}

const CAM={
  // portrait: high 3/4 from just north of 里门 so the player sits in the lower third
  // and the full r=10 flower ring plus the tree stay in a 390×844 55° frame.
  port:[0,15,27],
  land:[0,17,27],
  lookPort:[0,3,6.5],
  lookLand:[0,2,6]
};
window.TG_R7E_CAM=CAM;

const camera=worldCamera;worldCamera=function(){
  const w=W3;
  if(window.TG_R7E_SHOT==='gardener'&&w?.camera){
    w.camera.up.set(0,1,0);
    // 3/4 front: gardener faces the tree, camera sits between him and the trunk
    w.camera.position.set(-11.05,1.72,9.45);
    w.camera.lookAt(-14,1.18,12);
    if(w.scene.fog){w.scene.fog.near=20;w.scene.fog.far=64;}
    return;
  }
  if(w?.active==='plaza'&&window.TG_R7D_SHOT==='top'&&S.view!=='fp'){
    placeTreeLabel('land',w.camera);
    return camera.apply(this,arguments);
  }
  if(w?.active==='plaza'&&S.view!=='fp'&&!w.r6Plan&&w.player){
    const nearSpawn=Math.hypot(w.player.position.x,w.player.position.z-16)<.35||Math.hypot(w.player.position.x,w.player.position.z-14)<.35;
    if(nearSpawn){
      const land=w.camera.aspect>1;
      const c=land?CAM.land:CAM.port;
      const look=land?CAM.lookLand:CAM.lookPort;
      w.camera.up.set(0,1,0);
      w.camera.position.set(c[0],c[1],c[2]);
      w.camera.lookAt(look[0],look[1],look[2]);
      w.camera.updateMatrixWorld();
      placeTreeLabel(land?'land':'port',w.camera);
      if(w.scene.fog){w.scene.fog.near=land?48:70;w.scene.fog.far=land?110:160;}
      return;
    }
  }
  placeTreeLabel('land',w&&w.camera);
  return camera.apply(this,arguments);
};

const iw=typeof initWorld==='function'?initWorld:null;
if(iw)initWorld=function(){const r=iw.apply(this,arguments);try{r7eDress();}catch(e){console.warn('r7e',e);}return r;};
})();
