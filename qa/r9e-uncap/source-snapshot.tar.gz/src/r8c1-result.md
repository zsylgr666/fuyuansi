# r8c.1 result — FROZEN 2026-11-14 08:51 (UTC+8)
- v4/index.r8c1.html  1,741,088 B  sha256 de2ce1272d57912e1b2da8b728cf8c5b5ed6dc612a205776bd52a790aa4a7595 (index.r8c1.html.sha256)
- v4/r8c1.patch (diff -u index.r8c.html → index.r8c1.html) 67,361 B; v4/r8c1-src.patch (qa/r8c1-base-src → v4/_src) 68,373 B: gameplay.js r7.js r7c.js r7d.js r8c.js world3d.js — no codex2 module
- Frozen r8c (a97278fe…) / r8b (a81a5383…) / r8a* untouched (checked by script). Save key, IDs, economy, RPC, S.lastSign unchanged.
- Script: v4/_src/freeze-r8c1.mjs → report v4/_src/freeze-r8c1-report.json

## Ceiling (r8c.js shell)
Hall ceiling = cloned wall material, emissive #7a6142 ×0.6 with its map, roughness kept → lighter roof; no geometry/layout change; +0 draw calls (hall 20/25). Zen/study unchanged (pixel diff ≤0.06%). Shots: qa/r8c1-shots/hall-{main,roof}-{mobile,land}-{before,after}.png, hall-ab.jpg.

## Wish tags (r8c.js section 3; TG_WISH r7.3 untouched)
After a successful hang: orientation-only ease (slerp, smoothstep, ~0.8 s, rate-limited, wall-clock dt clamp 0.25) to frame the new tag; releases on move >0.35 m / joystick / tap-move / yaw change / 8 s, easing back. Gentle canopy bias within 8.5 m of the tree. HUD/direction-sign elements overlapping a visible projected tag get opacity .3 + pointer-events none (restored after). Camera position untouched.
Verified: tag on screen and clear of HUD rects after hang, tap opens the tag card (m/l); HUD sweep — overlapping signs (北·心田小院 / 南·里门 / 东·集市) cleared, elementFromPoint → CANVAS#view (m/l); tree-trace 0 jumps, idle range 0 (qa/r8c1-shots/tree/tree-trace-r8c1.json). Shots: qa/r8c1-shots/wish/{m,l}-{0-near,1-hung,2-tap}.png, m-strip.jpg, {mobile,land}-hud*.
## Compliance
codex2 A-r7d-slim + B-stall-labels applied; gameplay.js data neutral (codex2 cleanup); r7.js pairs 福缘寺灵签/灵签/求签/抽签/算卦/看风水 removed; gameplay.js 祠堂/炷香 toasts, unlock msg, hall name, help → 缘堂/点灯 (= former runtime text); r8c-0b 诗签 runtime rewrite removed (source now 每日诗笺). Ownership: gameplay.js is base; r7c/r7d ours (r8c-result.md corrected).
## Grep (packed bundle, 38 hits; none visible — smoke visible-text/title/aria scan clean in all scenes + stalls)
- 祠堂 in styles.css comments, gameplay.js comments, hooks comment; shell.html titles/labels, world3d 61/63, r3 95/148, r41 15, r5 111, r6 42/248 → all pass the r7 runtime rewrite (祠堂→缘堂 etc.) before display; scan confirms 0 visible.
- r7.js 5/8, r7-compliance 11, r8.js 574 (replacement tables), r8b.js 396 (BAN regex) → never displayed.
- r7d.js 439 '每日诗签摊' internal collider id → never displayed.
- npc.js 25 便宜 → innocuous (codex2).
## Smoke (portrait/landscape calls, 0 page errors)
plaza 66/77 gate 43/47 hall 20/25 yard 41/44 zen 19/27 study 17/26 market 44/55 tea 75/79 lotus 52/55 (max 79 ≤150). Stalls 今日心语×3, 每日寄语×3, 赏景小记×5 with directions: all open, results shown, 0 banned words visible.
