/* manual.js — 福缘里 · 心田小院 游戏手册  window.TG_MANUAL
 * 面板：open(chapterId) / close()；全文检索并高亮。
 * 用语按 r7 改名：游戏名「福缘里 · 心田小院」，大殿→缘堂，功德→善缘。
 * 内容依据 v12 与 v4/_src 现有玩法，不编造未实现功能。无 THREE 依赖。可重复加载。
 * r8：外观改用 ui-kit.js（TG_UI，需先于本文件打包）；章节图标为 TG_UI.icon 名称；章节末尾可翻到上一章/下一章。 */
(function(){
'use strict';
if(window.TG_MANUAL && window.TG_MANUAL.__v) return;
var VER=2;
var panel=null, opts={};

function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function el(tag,cls,attrs,text){var e=document.createElement(tag);if(cls)e.className=cls;if(attrs)for(var k in attrs)if(attrs[k]!=null)e.setAttribute(k,attrs[k]);if(text!=null)e.textContent=text;return e;}


/* 章节：id 稳定，供 open(chapterId) 与检索使用。icon 是 TG_UI.icon 的图标名（线性 SVG），不用表情符号。
 * 文案依据现有玩法和 r7 之后的按钮叫法（缘堂「点灯 / 摆放心意」），数值与代码一致。 */
var CH=[
{id:'intro',icon:'home',title:'入门',body:[
  {h:'这是什么游戏',p:'「福缘里 · 心田小院」是一个种田、布置、串门的小游戏。进度默认存在本机，登录后会同步到云端，换台设备也能接着玩。'},
  {h:'顶栏',p:'左上角是当前场景名。右边依次是善缘、铜钱和背包，点一下能看数量或打开背包；再往右是登录、声音开关和菜单。'},
  {h:'第一步',p:'进游戏时你站在大厅广场。走到院门口，点「进入院子 →」，就回到自己的心田小院。广场上还有去集市、荷塘和茶会小院的路，以及抽每日寄语、读心笺、赏园景的摊点。'},
  {h:'打开缘堂',p:'小院北边的门通往缘堂。在田里累计收获 3 份作物后门会打开，知道口令也可以直接进。缘堂里可以点灯、摆放心意，两侧是书房和静室。'},
  {h:'今日事项',p:'每天做完四件事：喂食一次、收获一季、点一盏灯、收取一次产物，可以领 10 铜钱。卖作物和产物每天最多换 100 铜钱（未联网时和今日事项、善缘兑换共用 40 铜钱）；今日事项和善缘兑换另算。到上限会提示。'},
  {h:'找不到怎么玩时',p:'菜单里随时能打开这本手册，顶部可以搜索。有建议或遇到问题，用意见箱告诉我们，见最后一章。'}
]},
{id:'controls',icon:'hand',title:'操作',body:[
  {h:'走路',p:'按住左下角的摇杆，往哪边推就往哪边走。靠近能互动的东西时，屏幕下方会出现提示，点提示或直接点那个东西都可以。'},
  {h:'场景按钮',p:'每个场景底部的按钮不同。小院里有「一键播种」「全浇水」「一键收获」「回大厅」；缘堂里有「点灯」「摆放心意」「整修」「布置」。'},
  {h:'视角',p:'右侧可以切换第一人称和第三人称。第一人称看得更近，第三人称跟在身后，摆家具时看得更全。'},
  {h:'坐下',p:'在茶会小院、集市或缘堂里，点椅子、条凳、坐垫或卧榻就能坐下或躺下，推一下摇杆就起身。'},
  {h:'去别人家',p:'串门时只能参观和打招呼，不能改主人的布置，也不会花主人的铜钱和善缘。看到「正在拜访」时，要先回自己的小院才能管理。'},
  {h:'声音和重置',p:'♫ 按钮开关音效和音乐。菜单里的「重置全部进度」会清空本机存档，点之前想清楚；在别人家时不能重置。'}
]},
{id:'yard',icon:'layout',title:'小院与布置',body:[
  {h:'在哪',p:'从大厅点「进入院子」就到心田小院。田、动物、拴马桩和缘堂的门都在这里。有时场景名会显示为「福缘里 · 大厅」，那是广场。'},
  {h:'摆家具',p:'在小院、缘堂、静室、书房或「自家小院」点「布置」，从已有家具里选一件，点地面放下，可以旋转或收回。再点一次「布置」退出。'},
  {h:'整修缘堂',p:'在缘堂里点「整修缘堂」，可以换一套装饰风格，具体款式以游戏里提供的为准。'},
  {h:'自家小院',p:'缘堂一侧可以进「自家小院」，这是更安静的室内空间，同样用「布置」摆家具，点「返回」回缘堂。'},
  {h:'摆好之后',p:'家具会一直留在原处。和家人共用小院时，摆设也一起共享；访客能看到，但改不了。'}
]},
{id:'farm',icon:'sprout',title:'田园种植',body:[
  {h:'在哪',p:'心田小院里的田垄。屏幕下方是种子栏，以及「一键播种」「全浇水」「一键收获」。'},
  {h:'播种',p:'先在种子栏选一种种子，再点空地；或者用「一键播种」把空地都种上。没选种子时会提示你先选。'},
  {h:'浇水',p:'点还在长的作物，或用「全浇水」。每次浇水推进大约四分之一的生长进度，同一块地浇完要等一会儿才能再浇，连着点不会更快。'},
  {h:'收获',p:'成熟后点一下收进背包，或用「一键收获」，每季收 3 份。关掉游戏作物也照常按真实时间长。'},
  {h:'能种什么',p:'白菜约 15 分钟，萝卜 25 分钟，番茄 40 分钟，玉米 1 小时 40 分，仙桃 6 小时，西瓜 12 小时。在集市商铺「卖作物/产物」一栏卖掉，每份大约 1～8 铜钱，计入每天 100 铜钱的出售上限；「全卖」会卖到上限为止。'},
  {h:'收成的用处',p:'卖掉、放到寄售摊，或拿到缘堂摆放心意。累计收获 3 份后缘堂的门会打开。'}
]},
{id:'animals',icon:'paw',title:'动物',body:[
  {h:'在哪',p:'动物养在心田小院。家禽、家畜、蜂箱和鱼池都在集市商铺买，买来后放进院子。'},
  {h:'照料',p:'走近动物，按提示「喂食」。吃饱了才会产东西。到时间点「收取产物」，有鸡蛋、鸭蛋、鹅蛋、牛奶、兔毛、羊毛、羊驼毛、蜂蜜和鲜鱼，间隔约 40 分钟到两个半小时。'},
  {h:'有哪些',p:'小鸡、小鸭、大白鹅、奶牛、小猪、绵羊、小兔、羊驼，还有小狗、小猫、小马。蜂箱和鱼池固定不动。以商铺当前在卖的为准。'},
  {h:'产物的用处',p:'卖掉、寄售，或拿到缘堂摆放心意。动物本身不产铜钱。加入家庭后，看门狗的值班位置会同步给家人。'},
  {h:'串门时',p:'在别人家不会用掉主人的饲料，也不能收走主人的产物。'}
]},
{id:'hall',icon:'tree',title:'自家缘堂与广场古树',body:[
  {h:'在哪',p:'心田小院北侧的门进去就是缘堂。门在收获满 3 份作物后打开，也可以输口令进。堂内两侧通往书房和静室，北侧通往荷塘；从大厅广场也能走到荷塘。'},
  {h:'点灯',p:'点「点灯」，每盏 1 点善缘，每天前 5 盏有善缘。之后还能点，但当天不再加。'},
  {h:'摆放心意',p:'点「摆放心意」，从背包选作物、产物或精制的心意放到托台上，最多同时放 5 份。到时间后计入善缘，这一项每天最多 40 点，多出的不会留到明天。清莲蓬等特殊物品以物品说明为准。'},
  {h:'书房和静室',p:'书房里誊写一页书，约 2 分钟，得 3 点善缘，每天 3 次。静室里静坐听风铃，约 3 分钟，得 4 点善缘，每天 2 次。中途关掉面板或离开房间不算完成。'},
  {h:'摇风铃',p:'缘堂里的风铃每摇一次得 1 点善缘，每天前 5 次有效。'},
  {h:'荷塘',p:'放锦鲤：每天 3 次，每次 2 点善缘，次数用完还能看动画。采清莲蓬：每天最多 3 枚，放进背包，不能卖。投心愿笺：每次 2 铜钱，每天 3 次，不加善缘。晚上 18:00 到次日 05:59（北京时间）能看到河灯。这些只能在自己的家园里做。'},
  {h:'心愿树',p:'心愿树在公共广场正中，所有玩家都从这里出发。点树或「挂心愿牌」，从背包选一样心意挂上，规则和缘堂托台相同。广场摊位的「抽每日寄语」只给一句诗或一句鼓励的话。缘堂里没有古树。'}
]},
{id:'tea',icon:'cup',title:'茶会小院',body:[
  {h:'在哪',p:'大厅广场西侧，跟着路牌走进「茶会小院」。这是公共的院子，谁都可以来。'},
  {h:'能做什么',p:'茶席上有矮桌、坐垫、鼓凳和茶具，点一下坐下，推摇杆起身。院里还有一张石棋桌。河边可以放河灯：写一句话放出去，每盏 3 铜钱，每天 3 盏，不加善缘；晚上 18:00 到次日 05:59 看得最清楚。'},
  {h:'留言墙',p:'每条最多 120 字，每天最多 30 条，两条之间隔 20 秒。带链接、纯数字或不当内容发不出去。留言会贴在墙上，后来的人都能看到。'},
  {h:'适合什么时候来',p:'这里不产作物，也不发善缘，适合约朋友坐坐、留句话、看看灯。'}
]},
{id:'market',icon:'shop',title:'集市与寄售',body:[
  {h:'在哪',p:'从大厅广场走到集市。这里有集市商铺和寄售摊，摊主会跟你打招呼、介绍货物。'},
  {h:'集市商铺',p:'买种子、家具和动物，也能卖掉背包里的作物和产物。「善缘阁」一栏用善缘换少见的摆设、配饰、称号和部分坐骑，换来的东西不能再折成铜钱。商铺里还能用 25 点善缘换 1 铜钱，每天最多换 8 枚。在商铺买的家具和装饰，收进背包后可以在「卖作物/产物」一栏按原价一半卖回（摆着的要先收起；初始赠送、善缘换来、寄售或家人那里得来的不能卖）。'},
  {h:'寄售摊',p:'面板有三页：「逛摊」「我要寄售」「我的摊位」。把作物、农产、心意或家具上架，填价格和数量（1～99）。作物和农产每件最多标 50 铜钱，心意和家具最多 2000。同时最多挂 10 件，不能买自己的东西。'},
  {h:'卖出以后',p:'别人买走后铜钱自动到账；当天寄售收入超过 500 铜钱的部分第二天到账。过期或下架的东西会退回背包。'},
  {h:'注意',p:'操作太快时会请你稍等再试。没联网或没登录时，寄售摊可能用不了。'}
]},
{id:'avatar',icon:'user',title:'捏脸与配饰',body:[
  {h:'在哪',p:'在自己的家园里点右侧的「捏脸」，或从菜单进入。串门时不能改外观。'},
  {h:'怎么调',p:'上方是自己的形象，左右拖动可以转身。下方分为体型、面容、发型、服饰、配饰、名牌六页：身高、体格、脸型、肤色、发型发色，直裰、襦裙、圆领袍、广袖长袍、短打等款式和绣边颜色都能改。点「保存」生效。'},
  {h:'配饰',p:'头饰有发簪、簪花、斗笠、发冠；腰饰玉佩、葫芦、香囊；背饰云肩；手持折扇、玉串、书卷。'},
  {h:'免费和兑换',p:'默认形象不带需要兑换的配饰。发簪、玉佩、云肩和部分称号要用善缘兑换，没拥有的会显示锁和所需善缘，在商铺换到后回来选上即可。称号只能从已拥有的里选，不能自己填。'},
  {h:'保存之后',p:'新形象会用在小院、茶会和骑乘中。坐下或骑马时，长裙和衣摆会自动收好，不会穿进坐具里。'}
]},
{id:'mounts',icon:'route',title:'坐骑',body:[
  {h:'在哪',p:'在集市商铺的「坐骑」页兑换。换到后坐骑会拴在心田小院的拴马桩上。'},
  {h:'骑上和下来',p:'走到拴马桩，按提示选「牵出」或「骑上」，不会自动上马。骑着出院门，坐骑才会跟你去大厅、集市等户外场景；走路离开的话它留在桩上。进缘堂、静室、书房这些室内会自动下来，坐骑在门外等。骑回小院会自动拴好。'},
  {h:'有哪些',p:'用铜钱换：小毛驴、黄牛车、枣红马。用善缘换：白马、白鹿、青牛。骑着走会快一到四成，只影响走路，不影响种田和收益。一次只能骑一匹。'},
  {h:'黄牛车和装饰',p:'黄牛车可以带一位家人同乘。坐骑能装鞍具、缰绳和铜铃，银鞍铃只有白马能用。装饰在坐骑商店买。'},
  {h:'说明',p:'坐骑不产铜钱和善缘，也不能卖回商店。别人只有在你骑着的时候才看得到你的坐骑。'}
]},
{id:'family',icon:'family',title:'家人共享',body:[
  {h:'在哪',p:'菜单里的「家庭」。需要先登录。'},
  {h:'邀请和加入',p:'一家最多 6 人，由家长发邀请。对方在菜单的「家庭」里接受或拒绝。家长可以请人离开或解散家庭，成员可以自己退出。'},
  {h:'用谁的小院',p:'加入时要选用哪座小院。没选上的那座会先封存，作物、动物、摆设和缘堂都原样保留，退出或解散后自动恢复。缘堂跟着小院走。'},
  {h:'哪些共用',p:'田、动物、摆设和缘堂一家人共用，每个人都能改。背包、铜钱、当天次数和自己的形象各算各的。看门狗的值班位置也会同步。'}
]},
{id:'economy',icon:'coin',title:'善缘与经济',body:[
  {h:'两种货币',p:'铜钱用来买种子、家具、动物和部分坐骑，也用于寄售标价。善缘在缘堂和荷塘慢慢攒，用来在善缘阁换摆设、配饰、称号和少数坐骑。顶栏随时能看到余额。'},
  {h:'善缘怎么来',p:'点灯 1 点（每天 5 盏）、托台心意到期（每天最多 40 点）、摇风铃 1 点（每天 5 次）、书房誊写 3 点（每天 3 次）、静室听风铃 4 点（每天 2 次）、荷塘放锦鲤 2 点（每天 3 次）。全做满一天约 73 点。到上限后还能继续做，只是不再加善缘。'},
  {h:'铜钱怎么来',p:'卖作物和产物、完成今日事项（10 铜钱）、用 25 点善缘换 1 铜钱（每天最多 8 枚）。卖作物和产物每天最多 100 枚；今日事项 10 枚、善缘兑换最多 8 枚另算。在商铺买的家具装饰也能半价卖回，每天最多 400 枚。铜钱不能换成善缘。'},
  {h:'善缘阁',p:'在商铺打开「善缘阁」，能换琉璃灯、银杏盆景、古琴、锦鲤屏风、石灯等摆设，发簪、云肩、玉佩和若干称号，以及白马、白鹿、青牛。换到的东西不能卖回。'},
  {h:'串门时',p:'不会动主人的善缘、铜钱和次数。如果在别人家顺手收了熟透的作物，收入算进你自己每天 15 铜钱的访客上限，不占主人的出售上限。'}
]},
{id:'feedback',icon:'mail',title:'意见箱怎么用',body:[
  {h:'在哪',p:'菜单里的「意见箱」。有没看过的回复时，入口上会有一个小红点。'},
  {h:'写一条',p:'在「写意见」里选类别（装饰、玩法、界面、问题反馈、其他），写 10～500 字后点「提交」。每人每天最多 3 条。不要写微信、电话或链接，也不要用不当词语，否则会提示你修改。需要联网。'},
  {h:'看进度',p:'「我的意见」里能看到每一条的状态：待审阅、需要补充、已上线、未采纳，有时是「已转交」。回复写在条目下面。'},
  {h:'需要补充时',p:'状态是「需要补充」的条目下面有「补充说明」按钮，写至少 5 个字提交，状态会回到待审阅。'},
  {h:'说明',p:'意见箱不发铜钱或善缘。采纳的改动上线后，会在那条意见下回复说明。'}
]}
];

/* 样式：通用外观来自 ui-kit.js（.tg-*）；这里只放手册自己的排版。旧类名 .tgmn-* 保留。 */
var CSS=[
'.tgmn-root{z-index:9990}',
'.tgmn-search{position:relative;flex:0 0 auto;padding:12px 16px 4px}',
'.tgmn-search .tgmn-sico{position:absolute;left:28px;top:50%;margin-top:4px;transform:translateY(-50%);color:var(--tg-ink-3,#7d624d);pointer-events:none;display:flex}',
'.tgmn-in{padding-left:40px!important;padding-right:48px!important;border-radius:var(--tg-r-pill,999px)!important;-webkit-appearance:none;appearance:none}',
'.tgmn-in::-webkit-search-cancel-button{display:none}',
'.tgmn-clear{position:absolute;right:16px;top:12px}',
'.tgmn-clear[hidden]{display:none}',
'.tgmn-list{display:grid;grid-template-columns:1fr;gap:8px}',
'@media (min-width:560px){.tgmn-list{grid-template-columns:1fr 1fr}}',
'.tgmn-item{display:flex;align-items:center;gap:12px;min-height:56px;width:100%;padding:8px 12px;border:1px solid var(--tg-line,#e5d6ba);border-radius:var(--tg-r-2,12px);background:var(--tg-card,#fffdf8);color:var(--tg-ink,#3b2a1e);font-size:var(--tg-fs-2,16px);text-align:left;cursor:pointer;box-shadow:var(--tg-sh-1)}',
'.tgmn-item:active{background:var(--tg-paper-2,#f3e9d5)}',
'.tgmn-ico{display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:10px;background:var(--tg-paper-2,#f3e9d5);color:var(--tg-accent,#9b3a2a);flex-shrink:0}',
'.tgmn-item b{flex:1;font-weight:600}',
'.tgmn-item .tgmn-chev{display:flex;color:var(--tg-ink-3,#7d624d)}',
'.tgmn-title{display:flex;align-items:center;gap:12px;margin:0 0 12px;font-family:var(--tg-font-title);font-size:var(--tg-fs-4,22px);font-weight:600;color:var(--tg-ink,#3b2a1e)}',
'.tgmn-sec{margin:0;padding:12px 0;border-top:1px solid var(--tg-line,#e5d6ba)}',
'.tgmn-sec:first-of-type{border-top:0;padding-top:0}',
'.tgmn-sec h3{margin:0 0 4px;font-size:var(--tg-fs-2,16px);font-weight:600;color:var(--tg-accent-2,#7c2d20)}',
'.tgmn-sec p{margin:0;font-size:var(--tg-fs-2,16px);line-height:1.75;color:var(--tg-ink,#3b2a1e)}',
'.tgmn-hit{background:#ffe3a3;color:inherit;border-radius:3px;padding:0 1px}',
'.tgmn-res{display:block;width:100%;margin:0 0 8px;padding:12px 16px;border:1px solid var(--tg-line,#e5d6ba);border-radius:var(--tg-r-2,12px);background:var(--tg-card,#fffdf8);color:var(--tg-ink,#3b2a1e);text-align:left;cursor:pointer;font-size:var(--tg-fs-2,16px)}',
'.tgmn-res b{display:flex;align-items:center;gap:8px;font-weight:600}',
'.tgmn-res b .tg-icon{color:var(--tg-accent,#9b3a2a)}',
'.tgmn-res p{margin:4px 0 0;font-size:var(--tg-fs-1,14px);line-height:1.6;color:var(--tg-ink-2,#634a37)}',
'.tgmn-nav{display:flex;gap:12px;margin-top:16px;padding-top:12px;border-top:1px solid var(--tg-line,#e5d6ba)}',
'.tgmn-nav .tg-btn{flex:1 1 0;min-width:0;font-weight:500}',
'.tgmn-nav .tg-btn span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
].join('');
var FALLBACK_CSS='.tg-scrim{position:fixed;inset:0;display:flex;align-items:flex-end;justify-content:center;background:rgba(28,18,10,.48);font-family:sans-serif;color:#3b2a1e}.tg-sheet{position:relative;display:flex;flex-direction:column;width:100%;max-width:560px;height:88%;background:#fbf6ec;border-radius:16px 16px 0 0}.tg-sheet__head{display:grid;grid-template-columns:44px 1fr 44px;align-items:center;min-height:56px;padding:0 8px}.tg-sheet__title{text-align:center;font-size:18px;margin:0}.tg-sheet__body{flex:1;min-height:0;overflow:auto;padding:16px}.tg-btn,.tg-iconbtn{min-height:44px;min-width:44px;font-size:16px}.tg-input{width:100%;font-size:16px;min-height:44px}';

function UI(){return window.TG_UI||null;}
function ico(name,size){var u=UI();return u?u.icon(name,size||20):'';}
function ensureCss(){
  var u=UI();
  if(u) u.ensure();
  else if(!document.getElementById('tgmn-fallback-css')){var f=el('style',null,{id:'tgmn-fallback-css'});f.textContent=FALLBACK_CSS;document.head.appendChild(f);}
  if(document.getElementById('tgmn-css')) return;
  var st=el('style',null,{id:'tgmn-css'});st.textContent=CSS;document.head.appendChild(st);
}

function findChapter(id){
  if(!id) return null;
  var q=String(id).trim();
  for(var i=0;i<CH.length;i++){
    if(CH[i].id===q || CH[i].title===q) return CH[i];
  }
  return null;
}
function chapterText(ch){
  var t=ch.title+' ';
  (ch.body||[]).forEach(function(s){t+=s.h+'：'+s.p+' ';});
  return t;
}
function searchHay(ch){return chapterText(ch)+' '+ch.id+' '+ch.title;}
function highlight(text,q){
  var s=esc(text);
  if(!q) return s;
  var parts=String(q).trim().split(/\s+/).filter(Boolean);
  parts.forEach(function(w){
    var src=esc(w);
    if(!src) return;
    var re=new RegExp(src.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi');
    s=s.replace(re,function(m){return '<span class="tgmn-hit">'+m+'</span>';});
  });
  return s;
}
function snippet(ch,q,limit){
  limit=limit||80;
  var blob=chapterText(ch);
  var idx=-1, low=blob.toLowerCase(), term=String(q||'').trim().split(/\s+/)[0]||'';
  if(term) idx=low.indexOf(term.toLowerCase());
  if(idx<0) idx=0;
  var a=Math.max(0,idx-24), b=Math.min(blob.length,a+limit);
  var cut=(a>0?'…':'')+blob.slice(a,b)+(b<blob.length?'…':'');
  return cut;
}
function matchQuery(ch,q){
  var parts=String(q||'').trim().split(/\s+/).filter(Boolean);
  if(!parts.length) return true;
  var hay=searchHay(ch).toLowerCase();
  for(var i=0;i<parts.length;i++) if(hay.indexOf(parts[i].toLowerCase())<0) return false;
  return true;
}

function close(){
  if(!panel) return;
  var p=panel;panel=null;
  if(p.layer) p.layer.remove();
  if(p.root&&p.root.parentNode)p.root.parentNode.removeChild(p.root);
}

function open(chapterId,o){
  if(chapterId && typeof chapterId==='object'){o=chapterId;chapterId=o.chapterId||o.chapter||null;}
  o=o||{};
  close();
  ensureCss();
  var view= chapterId ? 'chapter' : 'list';
  var current=findChapter(chapterId);
  if(chapterId && !current) view='list';
  var q0=o.query||'';
  if(q0 && !current) view='search';

  var host=o.container||document.body;
  var root=el('div','tgmn-root tg-ui tg-scrim',{role:'dialog','aria-modal':'true','aria-labelledby':'tgmn-title'});
  if(o.container&&o.container!==document.body) root.style.position='absolute';
  var wrap=el('div','tgmn-wrap tg-sheet');
  var head=el('div','tgmn-head tg-sheet__head');
  var back=el('button','tgmn-back tg-iconbtn',{type:'button','aria-label':'返回目录'});
  back.innerHTML=ico('back',22)||'‹';
  var title=el('h2','tg-sheet__title',{id:'tgmn-title'},'游戏手册');
  var x=el('button','tgmn-x tg-iconbtn',{type:'button','aria-label':'关闭'});
  x.innerHTML=ico('close',22)||'×';
  x.onclick=function(){close();};
  head.appendChild(back);head.appendChild(title);head.appendChild(x);
  wrap.appendChild(head);
  var search=el('div','tgmn-search');
  var sico=el('span','tgmn-sico');sico.innerHTML=ico('search',18);
  var inp=el('input','tgmn-in tg-input',{type:'search',enterkeyhint:'search',placeholder:'搜索：浇水、寄售、坐骑…',value:q0,'aria-label':'搜索手册'});
  var clr=el('button','tgmn-clear tg-iconbtn',{type:'button','aria-label':'清除搜索'});
  clr.innerHTML=ico('close',18)||'×';
  search.appendChild(sico);search.appendChild(inp);search.appendChild(clr);
  wrap.appendChild(search);
  var body=el('div','tgmn-body tg-sheet__body');
  wrap.appendChild(body);
  root.appendChild(wrap);
  root.addEventListener('click',function(e){if(e.target===root) close();});
  host.appendChild(root);
  var layer=UI()?UI().openLayer(root,{onClose:close}):null;

  function goList(){view='list';current=null;body.scrollTop=0;render();}
  function goChapter(id){
    var ch=findChapter(id);
    if(!ch) return;
    view='chapter';current=ch;body.scrollTop=0;render();
  }
  function goSearch(q){
    q=String(q||'').trim();
    if(!q){view='list';render();return;}
    view='search';current=null;render();
  }
  back.onclick=function(){if(view==='chapter'&&inp.value.trim()) goSearch(inp.value);else goList();};
  clr.onclick=function(){inp.value='';goList();try{inp.focus({preventScroll:true});}catch(e){}};
  var t=0;
  inp.addEventListener('input',function(){
    clearTimeout(t);
    var v=inp.value;
    clr.hidden=!v;
    t=setTimeout(function(){goSearch(v);},120);
  });
  inp.addEventListener('keydown',function(e){if(e.key==='Enter'){clearTimeout(t);goSearch(inp.value);try{inp.blur();}catch(_){}}});

  function chrome(){
    var inChapter=view==='chapter'&&current;
    back.style.visibility=inChapter||view==='search'?'visible':'hidden';
    back.setAttribute('aria-label',inChapter&&inp.value.trim()?'返回搜索结果':'返回目录');
    clr.hidden=!inp.value;
  }

  function renderList(){
    body.textContent='';
    var list=el('div','tgmn-list');
    CH.forEach(function(ch){
      var b=el('button','tgmn-item',{type:'button'});
      var ic=el('span','tgmn-ico',{'aria-hidden':'true'});ic.innerHTML=ico(ch.icon,20);
      b.appendChild(ic);
      b.appendChild(el('b',null,null,ch.title));
      var chev=el('span','tgmn-chev',{'aria-hidden':'true'});chev.innerHTML=ico('next',18)||'›';
      b.appendChild(chev);
      b.onclick=function(){goChapter(ch.id);};
      list.appendChild(b);
    });
    body.appendChild(list);
  }
  function renderChapter(){
    body.textContent='';
    var t=el('div','tgmn-title');
    var ic=el('span','tgmn-ico',{'aria-hidden':'true'});ic.innerHTML=ico(current.icon,20);
    t.appendChild(ic);
    t.appendChild(el('span',null,null,current.title));
    body.appendChild(t);
    (current.body||[]).forEach(function(sec){
      var box=el('section','tgmn-sec');
      var h=el('h3');h.innerHTML=highlight(sec.h,inp.value);box.appendChild(h);
      var p=el('p');p.innerHTML=highlight(sec.p,inp.value);box.appendChild(p);
      body.appendChild(box);
    });
    var i=CH.indexOf(current), nav=el('nav','tgmn-nav',{'aria-label':'章节翻页'});
    var prev=CH[i-1], next=CH[i+1];
    if(prev){var pb=el('button','tg-btn',{type:'button'});pb.innerHTML=ico('back',18);pb.appendChild(el('span',null,null,prev.title));pb.onclick=function(){goChapter(prev.id);};nav.appendChild(pb);}
    if(next){var nb=el('button','tg-btn',{type:'button'});nb.appendChild(el('span',null,null,next.title));nb.insertAdjacentHTML('beforeend',ico('next',18));nb.onclick=function(){goChapter(next.id);};nav.appendChild(nb);}
    body.appendChild(nav);
  }
  function renderSearch(){
    body.textContent='';
    var q=inp.value.trim();
    var hits=CH.filter(function(ch){return matchQuery(ch,q);});
    if(!hits.length){
      body.appendChild(el('div','tgmn-empty tg-empty',null,'没有找到「'+q+'」。试试「浇水」「寄售」「善缘」或「坐骑」。'));
      return;
    }
    hits.forEach(function(ch){
      var b=el('button','tgmn-res',{type:'button'});
      var title=el('b');title.innerHTML=ico(ch.icon,18)+'<span>'+highlight(ch.title,q)+'</span>';
      b.appendChild(title);
      var p=el('p');p.innerHTML=highlight(snippet(ch,q,90),q);
      b.appendChild(p);
      b.onclick=function(){goChapter(ch.id);};
      body.appendChild(b);
    });
  }
  function render(){
    if(view==='chapter'&&current) renderChapter();
    else if(view==='search'&&inp.value.trim()) renderSearch();
    else {view='list';renderList();}
    chrome();
  }

  panel={root:root,layer:layer,render:render,goChapter:goChapter,goList:goList,input:inp,
    get view(){return view;},get chapter(){return current&&current.id;}};
  render();
  if(view==='list' && q0) goSearch(q0);
  return panel;
}

window.TG_MANUAL={
  __v:VER,
  open:open,close:close,
  chapters:CH.map(function(c){return {id:c.id,title:c.title,icon:c.icon};}),
  chapter:findChapter,
  search:function(q){return CH.filter(function(ch){return matchQuery(ch,q);}).map(function(c){return c.id;});},
  get panel(){return panel;}
};
})();
