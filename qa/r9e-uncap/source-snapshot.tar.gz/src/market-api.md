# 寄售摊临时接入约定

- `window.TG_INV_TAKE(kind,id,qty) → boolean`：足额才扣除，无部分扣除。
- `window.TG_INV_GIVE(kind,id,qty) → boolean`：有效物品加到背包。
- `window.TG_COINS_ADD(n) → boolean`：有限数字，可为负；余额不足时不变并返回 false。

qty 必须为正的有限安全整数。`r3IsVisiting() && !r3CanEdit()` 时三个接口均拒绝且不修改。成功后调用原 `save()` 与 HUD 刷新；可编辑家庭访问经 TG_SPACE_SAVE，自己的存档经 TG_STORAGE。

| kind | ids | 存放 |
|---|---|---|
| crop | cabbage, carrot, tomato, corn, peach, melon | S.inventory |
| produce | egg, milk, duck-egg, goose-egg, fur, wool, honey, fish | S.inventory |
| offering | fruit-plate, incense-set, tea-cup, beef, roast_duck, white_chicken, roast_pork, roast_goose, offering_fish | S.backpack |
| decor | wood-table, bench, cabinet, daybed, altar-table, vase, lantern, bonsai, screen, cushion, rocking-chair, golden_buddha, glazed_lamp, guqin, koi_screen, ginkgo_bonsai | S.backpack |

集市的寄售摊仅调用 `window.TG_MARKET?.open()`，未连接时提示“寄售摊即将开放”。跨玩家托管交易由后端负责；最终合同将由来福提供。

## 只读查询（访问中也可调用，不修改、不保存）

- `window.TG_INV_LIST() → [{kind,id,qty,name?,emoji?}, ...]`：上述目录内当前库存/背包 qty>0 的条目。
- `window.TG_ITEM_INFO(kind,id) → {name,emoji} | null`：同 TAKE/GIVE 目录，未知 kind/id 返回 null。
- `window.TG_COINS_GET() → number`：当前 S.coins；缺失或非有限数字时返回 0。

每块成熟田固定收获 3 单位；harvestTotal 仍每块只加 1。作物售价为客户端配置，生长时间最长 4 小时（上限 7 天）。

供品店兑换专属（exchange-only）：beef 牛肉 🥩、roast_duck 烧鸭 🦆、white_chicken 白切鸡 🍗、roast_pork 烧肉 🥓、roast_goose 烧鹅 🪿、offering_fish 供鱼 🐟。这些供品不在普通商铺用铜钱出售；鲜鱼兑换消耗产物，保留鱼池。五种功德阁装饰仅用功德请回，不提供回售。
