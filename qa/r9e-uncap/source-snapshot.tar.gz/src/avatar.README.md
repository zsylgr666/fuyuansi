# avatar.js：角色定制（捏脸）模块 `window.TG_AVATAR`

独立的新文件，只依赖全局 `THREE`（r170）。它兼容两种写法：打包版里的 `const THREE` 和 `window.THREE`。
文件是幂等的，重复加载时会直接 return。现有文件一个都没改。

**画风**：参考王者荣耀家园的精致风格化写实。
- 身材约 7 头身（身高 100% 时约 1.75 个场景单位，和玩家小人的比例尺一致）。
- 服装有交领、腰带、前襟绣带、下摆和袖口的双色绣边，整体暖色调。

## 快速上手

```js
const cfg = TG_AVATAR.randomConfig('player-42');      // 或 defaultConfig()
const g   = TG_AVATAR.build(cfg);                     // THREE.Group，脚底在 y=0，面朝 +Z
scene.add(g);
TG_AVATAR.animate(g, 'walk', performance.now());      // 每帧调用，t 的单位是毫秒
TG_AVATAR.update(g, {...cfg, color1:'#b8322a'});      // 只重建变化的部件
const wire = TG_AVATAR.serialize(cfg);                // 网络同步用，约 90~110 字节
const back = TG_AVATAR.deserialize(wire);
TG_AVATAR.dispose(g);                                 // 释放引用并移出父节点
```

## 配置格式（`normalize` 之后）

```js
{ v:1, name:'林清和', title:'雅士',          // 名字最多 12 字，头衔最多 8 字；会剔除控制字符和 < >
  height:100,                               // 90–110（百分比）
  build:'slim'|'normal'|'sturdy',           // 纤细 / 匀称 / 健硕
  skin:'#f0cba8', face:'oval'|'round'|'square'|'heart',     // 鹅蛋脸 / 圆脸 / 方脸 / 瓜子脸
  hair:'bun'|'bald'|'long'|'ponytail'|'twin'|'short', hairColor:'#1b1512',  // 发髻 / 光头（带戒疤）/ 长发 / 束发 / 双髻 / 短发
  outfit:'daopao'|'ruqun'|'yuanling'|'sengpao'|'duanda',    // 直裰 / 襦裙 / 圆领袍 / 广袖长袍 / 短打
  color1:'#…', color2:'#…', trim:'#…',      // 主色 / 辅色（腰带、裙）/ 绣边色
  acc:{ head:'none'|'hairpin'|'flower'|'hat'|'crown',       // 发簪 / 簪花 / 斗笠 / 发冠
        neck:'none'|'beads',                                // 珠串
        waist:'none'|'jade'|'gourd'|'pouch',                // 玉佩 / 葫芦 / 香囊
        back:'none'|'cape',                                 // 云肩
        hand:'none'|'fan'|'rosary'|'scroll'                 // 折扇 / 玉串 / 书卷
             |'teapot'|'brush'|'incense'|'bowl'|'bolt'|'herb'|'flowerpot' },  // 后 7 个是 NPC 道具（incense 显示名「花灯」），面板里不显示
  capeColor:'#…', plate:'gold'|'jade'|'crimson'|'ink' }     // 名牌样式：鎏金 / 青玉 / 胭脂 / 水墨
```

- 所有可选项和中文名都在 `TG_AVATAR.options`，推荐色板在 `TG_AVATAR.palette`。
- `normalize` 只保留上面列出的字段。r6.js 存档里的 `accessories / titles / equipped` 这类扩展字段请另外存放。
- 光头不能戴发簪或发冠，`normalize` 会把这两种头饰改成 `none`。

## API

| 方法 | 说明 |
|---|---|
| `defaultConfig()` | 默认配置（新对象）。所有饰品槽都是 `none`，没有收费件，新玩家直接保存不会被拒（`not_owned`） |
| `randomConfig(seed)` | 按种子随机；seed 可以是数字或字符串。**只会选免费件**（判断规则见下文「经济系统」），头衔永远为空 |
| `normalize(cfg, opts?)` | 补全默认值、夹取范围、校验枚举和颜色，并清洗文本。永不抛错。`TG_AVATAR_NET` 已加载（`catalog()` 非空）时，`title` 必须是已拥有头衔的 `name`，否则清空。`opts.checkOwned:false` 跳过这项检查。渲染其他玩家时要用它，或者直接用 `deserialize`、`build` |
| `locked(slot, part)` | 返回 `null` 或 `{id, price, name}`（内置兜底时多一个 `fallback:true`），面板和 `randomConfig` 都用它判断 |
| `ownedTitles()` | 返回 `TG_AVATAR_NET.titles()` 里 `owned` 为真的那些。没有 NET 时返回 `null` |
| `freeParts` | 内置的保守免费表（没有 NET 时用） |
| `validate(cfg)` | 返回 `{ok, errors:[字段…], config}`，`errors` 列出被 normalize 修改过的字段 |
| `serialize(cfg)` | 返回紧凑 JSON 数组字符串：`["A1",name,title,height,build#,skin,face#,hair#,hairColor,outfit#,c1,c2,trim,head#,neck#,waist#,back#,hand#,capeColor,plate#]`。枚举存下标，颜色去掉 # |
| `deserialize(str)` | 解析失败或版本不对时返回默认配置，也接受普通配置对象。**不做**头衔归属检查，因为它要渲染别人的头衔；`serialize`、`build`、`update` 同样不检查 |
| `build(cfg, opts)` | 返回 THREE.Group。`opts.detail`：1 为默认，0 为低模（NPC 用）；`opts.plate:false` 不显示名牌；`opts.shadow:false` 不投影；`opts.phase` 固定动画相位 |
| `update(group, cfg)` | 按部件 key 对比，只替换变化部件的几何。身高和体型会重新布局关节，名字、头衔或样式变化时会重建名牌 |
| `animate(group, state, tMs)` | 纯函数，零分配，只由 t 和相位决定，可以跳帧。状态：`idle` 呼吸和轻微张望；`walk` 走路（长袍步幅较小）；`wave` 招手；`call` 吆喝（手到嘴边）；`arrange` 俯身整理货物；`look` 左右张望；`bow` 作揖；`talk` 说话手势 |
| `setPose(group, pose, opts?)` | 姿势：`'stand'`（站立，别名 `idle`、`none`、`null`）、`'ride'`（跨骑，别名 `straddle`）、`'sit'`（坐凳，别名 `bench`）。返回 `true`。会切换裙摆、腿、云肩的几何（都走缓存），并固定腿和手臂角度。ride 的两腿张开角按马背半宽算，取值顺序是 `opts.bodyRx`、父节点（座位）的 `userData.bodyRx`、默认 0.32，公式和 mounts.js 的通用骑姿相同，再加上袍摆厚度。可逆：`setPose(g,'stand')` 完全还原 |
| `getPose(group)` | 返回当前姿势 |
| `dispose(group)` | 归还共享几何和名牌贴图的引用（计数为 0 才真正 dispose），并从父节点移除 |
| `stats(group)` | 返回 `{triangles, drawCalls}` |
| `openPanel({container, config, onChange, onSave, onCancel, title, tab})` | 打开定制面板，返回面板句柄（含 `.config`） |
| `closePanel()` | 关闭面板，释放预览渲染器和 WebGL 上下文 |
| `setMaterialFactory(fn)` | 替换共享材质。默认是 `MeshStandardMaterial({vertexColors:true, roughness:.78})`。想接 TG_REAL 就在这里接，但必须保留 `vertexColors:true` |
| `cacheInfo()` | 返回 `{geometries, plates}`，可用来检查泄漏 |

### 层级（`group.userData.parts`）

```
root(Group 'tg-avatar')                 ← 调用方负责 position / rotation.y
 ├ rig                                  ← 按身高缩放，animate 会改它的 y（走路起伏）
 │  ├ legLJ / legRJ  → Mesh legL / legR（髋关节）
 │  └ torsoJ → Mesh torso（衣身 + 领 + 腰带 + 珠串 + 腰饰）
 │       ├ Mesh skirt（长袍裙摆；短打时 visible=false）
 │       ├ headJ → Mesh head（脸 + 发型 + 头饰）
 │       ├ armLJ / armRJ → Mesh armL / armR（右手含手持物）
 │       └ capeJ → Mesh cape（无云肩时 visible=false）
 └ Sprite 'plate'（名牌，有名字或头衔时才有）
```

`group.userData.meshes` 里是 8 个 Mesh（含 skirt）。挂件挂点：
- 右手：`parts.armRJ`，手心在局部坐标 (0, -0.6, 0.03) 左右。
- 头顶：`parts.headJ`，头顶在局部坐标 y≈0.32。

## 骑乘和坐姿（`setPose`，配合 mounts.js）

长袍（直裰、襦裙、圆领袍、广袖长袍）的裙摆是独立部件 `skirt`，各姿势的处理如下：

- **`ride`**：
  - 裙摆收短到胯下（y≈-0.24；襦裙到 -0.2），保留绣边。
  - 余下的袍摆作为宽筒挂在两条腿上，带下摆绣边，并跟着腿一起张开，所以不会穿进马背。
  - 云肩缩短到腰下。
  - 两腿张开（x -0.3，z ±张开角）；双臂前伸握缰（x -0.8）。
- **`sit`**：裙摆和腿上的袍摆同上；双腿前倾垂下（x -0.5），双臂放在膝上（x -0.55）。
- **`stand`**：换回整条裙摆和长云肩，关节交还给 `animate`。

`mounts.js` 的 `poseRider()` 会优先调用 `TG_AVATAR.setPose(rider, 'ride'|'sit'|'idle', {style:'straddle'|'bench'|null, mount})`。返回 true 之后就不再套用通用骑姿，下马时 `unposeRider` 会传 `'idle'` 还原。所以接入时**只需要** `TG_MOUNTS.mount(m, avatarGroup)` / `dismount`。

`animate()` 在非 stand 姿势下仍然做呼吸、张望和头部动作，`wave`、`call`、`talk` 这类手臂动作也照常生效，但腿始终保持骑姿或坐姿，`walk` 不会摆腿也不会起伏（颠簸交给坐骑动画）。因此每帧照常调用 `animate(g, state, t)` 即可，不需要再调用 `TG_MOUNTS.reapplyPose`。setPose 只在切换姿势时换几何，每帧零分配。

测试：`qa/r6-shots/avatar-ride-test.mjs`，截图为 `avatar-ride-*.png`（白马、牛车两座、下马还原）。

## 经济系统（`TG_AVATAR_NET`，backend/tg-r6.js）

接口形状以 `backend/tg-r6.js` 为准：
- `locked(slot, part)` 返回 `null` 或 `{id, price, name}`。
- `titles()` 返回 `[{id, name, emoji, price, owned}]`。
- `catalog()` 返回 `[{id, kind, name, emoji, price, slot, part}]`。

源码在 `backend/tg-r6.js`，`v12/index.html` 里有，**`v4/index.html` 里没有**。

- **免费还是收费**：`TG_AVATAR_NET` 存在且 `catalog()` 非空时，以 `locked()` 为准，已买的收费件也算可用。
  其他情况（没有 NET、未登录、目录还没加载）用内置的保守表：
  - 收费：`neck:beads`、`head:hairpin`、`waist:jade`、`back:cape`（价格和 `backend/r6.sql` 一致：400/500/600/700）。
  - 免费：`head` 的 none/flower/hat/crown，`waist` 的 none/gourd/pouch，`hand` 的 none/fan/rosary/scroll。
  - `neck` 和 `back` 只有 `none` 免费。
- **头衔**：存在 `config.title` 里的是头衔**名字**，例如「雅士」，这和服务器的规则一致：`title` 要么为空，要么是已拥有头衔的 name。整个模块没有任何自由输入头衔的地方。
- **事件**：面板打开时会监听 `tg-avatar` 事件（loaded、bought 等），收到后重新渲染，刚买的饰品会立即解锁。
- **测试**：`qa/r6-shots/panel-locked-test.mjs` 覆盖三种情况，截图为 `panel-locked-{stub,fallback,real}-{acc,tap-hint,title}.png`（390×844）：
  - 用桩代替 NET。
  - 没有 NET。
  - 真实的 v12 构建，用 `TG_R6_RPC` 假装已登录。
- **命名**：part id 是 `cape`，和后端目录（`backend/r6.sql` 的 `cape` 条目，`slot:'back'`、`part:'cape'`）一致；面板和文档统一叫「云肩」，和后端名称一致。

## 定制面板

```js
TG_AVATAR.openPanel({
  config: S.avatar,                         // 当前配置
  onChange: cfg => {},                      // 每次改动都会触发（已 normalize）
  onSave: (cfg, wire) => { S.avatar = cfg; net.send(wire); TG_AVATAR.update(W3.playerAvatar, cfg); },
  onCancel: () => {}
});
```

- **布局**：
  - 上方约 42% 是预览台，可以左右拖动旋转，左上「随机」、右上关闭（r8 起用 `TG_UI.icon` 线性图标；横屏矮屏时改为左预览、右面板）。
  - 下方是底部抽屉，分 6 个标签页：体型、面容、发型、服饰、配饰、名牌。
  - **配饰页**：`locked()` 判定为未拥有的部件显示成虚线框加「🔒」，`aria-disabled="true"`，不能选，点一下会弹「未拥有 · 500 善缘」提示，1.6 秒后消失。仍然保持 44px 触控区。
  - **打开面板时**：配置里未拥有的饰品会被改成 `none`；NET 已加载时，未拥有的头衔也会被清空，并触发一次 `onChange`。
  - **名牌页**：只有「名字」一个输入框（服务器会过滤文本）。「称号（只列出已拥有的）」只列出 `ownedTitles()` 返回的头衔加一个「无」，带 emoji。没有 NET 时只列出「无」和当前配置里的头衔（保留，但不能新增），并提示「可在商铺用善缘兑换」。
  - 底部有「取消 / 保存」按钮。
  - 宽度 ≥ 700px 的屏幕上居中显示为卡片。
- **样式**：
  - CSS 全部以 `tgav-` 为前缀，`<style id="tgav-css">` 只注入一次。
  - 所有按钮、色块和输入框的触控区都不小于 44px，已在 390×844 下自动检查。
  - 视觉是暖色宣纸底、金边加朱红高亮，字体用宋体或衬线体。
- **渲染**：预览用独立的小 WebGLRenderer（ACES 色调映射，暖色主光加冷色轮廓光）。关闭面板时会 `dispose` 并调用 `forceContextLoss`，不占游戏的上下文。
- **容器**：`container` 不传时挂到 `document.body`（fixed 全屏）；传了就挂到该元素里（absolute）。

## 给 codex 的接入步骤

1. **pack.mjs**：`avatar.js` 要放在 `npc.js` **之前**。npc.js 在 spawn 时才去取 `TG_AVATAR`，但如果 r6.js 在加载阶段就 spawn，顺序就很重要了。

   ```js
   ["animals2.js","audio.js","r5.js","realism.js","avatar.js","npc.js","teahouse-assets.js","mounts.js","r6.js"]
   ```

   注意：现在的 `v4/index.html`（02:10 打包）里的 avatar.js 还是早期版本，那版只认 `window.THREE`，所以会打印 `[TG_AVATAR] THREE 不存在`，TG_AVATAR 不会生效。**请用当前 `_src/avatar.js` 和 `_src/npc.js` 重新打包。**
2. **玩家模型**：
   - 在 `world3d.js` 创建 `w.body` 的地方，用 `TG_AVATAR.build(S.avatar)` 生成一个 Group，加进 `w.body`。原有的锥形小人可以隐藏或删除。
   - 原来的 `w.limbs` 摆臂逻辑改成每帧调用 `TG_AVATAR.animate(avatarGroup, moving ? 'walk' : 'idle', ts)`。
3. **存档和网络**：
   - 本地存 `normalize` 之后的对象。
   - 同步时发 `serialize(cfg)`，收到后用 `deserialize` 加 `build`；对方换装时调用 `update`。
4. **入口**：在设置或个人页加一个「捏脸」按钮，调用 `TG_AVATAR.openPanel({config:S.avatar, onSave:…})`。

## 性能（headless swiftshader 实测）

| 情况 | 三角面 | draw call |
|---|---|---|
| 默认细节（detail:1），无云肩 | 约 6.0k | 8（长袍，含 skirt）/ 7（短打）（+1 名牌） |
| 默认细节，带云肩 | 约 6.8k | 8（+1） |
| 低模（detail:0，NPC 用） | 约 4.0k | 8 / 7（+1） |

- **材质**：全场只有 1 个共享材质，颜色用顶点色表示。名牌用 SpriteMaterial，每个角色 1 个，贴图按「名字 + 头衔 + 样式」缓存。
- **几何**：按部件 key 缓存并引用计数，同款衣服或同款头的角色共享同一份几何。
- **动画**：只改关节的 rotation 和 position，每帧零分配。

## 已知限制

- 没有蒙皮或骨骼：手臂没有肘关节，所以「吆喝」和「作揖」是整臂旋转的近似效果。
- 布料没有物理，长袍和云肩是刚体，走路时只做轻微摆动。骑乘时腿上的袍摆是两段独立的筒，从正侧面看胯下有一点断开。宽袖和裙摆在手臂下垂时会有轻微互插，从正面基本看不出来。
- 脸部特征是几何小件（眼、眉、鼻、唇、腮红），没有贴图，所以表情不会变。
- 名牌是普通 Sprite，会被墙挡住（`depthTest` 开着），但不会自动避让 UI。
- `animate` 在状态之间切换时没有过渡，是瞬时切换。NPC 模块用转身插值掩盖了这一点。
