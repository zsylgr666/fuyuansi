/* avatar.js — 福缘里 · 心田小院 角色定制（捏脸）模块  window.TG_AVATAR
 * 风格：王者荣耀家园风的“精致风格化写实”——约 7 头身、汉服/长袍/短打，绣边色带、暖色调。
 * 性能：每个部件一个合并几何（顶点色）+ 全局共享 1 个材质；相同部件按 key 缓存并引用计数；animate 每帧零分配。
 * 只依赖全局 THREE（r170）。独立文件，可重复加载（幂等）。 */
(function(){
'use strict';
if(window.TG_AVATAR&&window.TG_AVATAR.__v)return;
var T=(typeof THREE!=='undefined')?THREE:window.THREE;if(!T){console.warn('[TG_AVATAR] THREE 不存在');return;}

/* ---------------- 选项表（只允许在末尾追加，序列化用下标） ---------------- */
var OPT={
 build:[{id:'slim',name:'纤细',w:.9},{id:'normal',name:'匀称',w:1},{id:'sturdy',name:'健硕',w:1.14}],
 face:[{id:'oval',name:'鹅蛋脸',jw:.8,cl:1.1,e:1.4,h:[1,1.1,1.04]},{id:'round',name:'圆脸',jw:.93,cl:1,e:1.8,h:[1.04,1.06,1.05]},
       {id:'square',name:'方脸',jw:.97,cl:1.02,e:3,h:[1.03,1.08,1.03]},{id:'heart',name:'瓜子脸',jw:.66,cl:1.16,e:1.2,h:[.98,1.1,1.03]}],
 hair:[{id:'bun',name:'发髻'},{id:'bald',name:'光头'},{id:'long',name:'长发'},{id:'ponytail',name:'束发'},{id:'twin',name:'双髻'},{id:'short',name:'短发'}],
 outfit:[{id:'daopao',name:'直裰',long:1,sleeve:'wide',collar:'cross'},{id:'ruqun',name:'襦裙',long:1,sleeve:'wide',collar:'cross',high:1},
         {id:'yuanling',name:'圆领袍',long:1,sleeve:'narrow',collar:'round'},{id:'sengpao',name:'广袖长袍',long:1,sleeve:'wide',collar:'cross',hide:1},
         {id:'duanda',name:'短打',long:0,sleeve:'narrow',collar:'cross'}],
 head:[{id:'none',name:'无'},{id:'hairpin',name:'发簪'},{id:'flower',name:'簪花'},{id:'hat',name:'斗笠'},{id:'crown',name:'发冠'}],
 neck:[{id:'none',name:'无'},{id:'beads',name:'珠串',hide:1}],
 waist:[{id:'none',name:'无'},{id:'jade',name:'玉佩'},{id:'gourd',name:'葫芦'},{id:'pouch',name:'香囊'}],
 back:[{id:'none',name:'无'},{id:'cape',name:'云肩'}],
 hand:[{id:'none',name:'无'},{id:'fan',name:'折扇'},{id:'rosary',name:'玉串'},{id:'scroll',name:'书卷'},
       {id:'teapot',name:'茶壶',npc:1},{id:'brush',name:'毛笔',npc:1},{id:'incense',name:'花灯',npc:1},{id:'bowl',name:'瓷碗',npc:1},{id:'bolt',name:'布匹',npc:1},{id:'herb',name:'药包',npc:1},{id:'flowerpot',name:'盆花',npc:1}],
 plate:[{id:'gold',name:'鎏金',bg:['#7a1f18','#a8322a'],fg:'#ffe6a6',edge:'#e2b95c'},{id:'jade',name:'青玉',bg:['#2f5a4e','#4f8a7a'],fg:'#f3fff4',edge:'#bfe3cf'},
        {id:'crimson',name:'胭脂',bg:['#7d2440','#b04a64'],fg:'#fff0f3',edge:'#f3c3cf'},{id:'ink',name:'水墨',bg:['#24262e','#454a56'],fg:'#f1e6cf',edge:'#c9b58a'}]
};
var PAL={
 skin:['#f7dfc8','#f0cba8','#e3b18b','#cd946b','#a9744f','#7f5139'],
 hair:['#1b1512','#33241b','#4e3424','#74503a','#8d8a86','#dcd6cc'],
 cloth:['#b8322a','#9e2f4a','#d9773a','#e3b25a','#f0d58c','#f1e6cf','#e9eef0','#c79bb0','#8fb3c2','#6f9a72','#4f8a7a','#3f5d6b','#2f3a5a','#6b3a4a','#9a5b34','#c48a3a','#7a7368','#2b2d38'],
 trim:['#d8ae55','#efd79a','#b8322a','#f1e6cf','#4f8a7a','#2b2d38','#c79bb0'],
 title:['雅士','茶客','园丁','旅人','茶博士','园主','游方客','画师','药师','掌柜']
};
function DEF(){return {v:1,name:'',title:'',height:100,build:'normal',skin:'#f0cba8',face:'oval',hair:'bun',hairColor:'#1b1512',
 outfit:'daopao',color1:'#f1e6cf',color2:'#3f5d6b',trim:'#d8ae55',acc:{head:'none',neck:'none',waist:'none',back:'none',hand:'none'},capeColor:'#b8322a',plate:'gold'};}
var SLOTS=['head','neck','waist','back','hand'];
function ids(list){return list.map(function(o){return o.id;});}
function find(list,id){for(var i=0;i<list.length;i++)if(list[i].id===id)return list[i];return list[0];}
var HEX=/^#?[0-9a-fA-F]{6}$/;
function hex(v,d){if(typeof v==='number'&&isFinite(v))return '#'+('00000'+(v&0xffffff).toString(16)).slice(-6);if(typeof v==='string'&&HEX.test(v.trim()))return ('#'+v.trim().replace('#','')).toLowerCase();return d;}
function cleanText(s,max){if(typeof s!=='string')return '';s=s.replace(/[\u0000-\u001f\u007f<>]/g,'').trim();return Array.from(s).slice(0,max).join('');}
function oneOf(list,v,d){return ids(list).indexOf(v)>=0?v:d;}
function normBase(c){
 var d=DEF();c=(c&&typeof c==='object')?c:{};var a=c.acc&&typeof c.acc==='object'?c.acc:{};
 var o={v:1,name:cleanText(c.name,12),title:cleanText(c.title,8),
  height:Math.round(Math.min(110,Math.max(90,+c.height||100))),
  build:oneOf(OPT.build,c.build,d.build),skin:hex(c.skin,d.skin),face:oneOf(OPT.face,c.face,d.face),hair:oneOf(OPT.hair,c.hair,d.hair),
  hairColor:hex(c.hairColor,d.hairColor),outfit:oneOf(OPT.outfit,c.outfit,d.outfit),color1:hex(c.color1,d.color1),color2:hex(c.color2,d.color2),trim:hex(c.trim,d.trim),
  acc:{},capeColor:hex(c.capeColor,d.capeColor),plate:oneOf(OPT.plate,c.plate,d.plate)};
 SLOTS.forEach(function(s){o.acc[s]=oneOf(OPT[s],a[s],'none');});
 if(o.hair==='bald'&&(o.acc.head==='hairpin'||o.acc.head==='crown'))o.acc.head='none';
 return o;
}
/* ---------------- 经济系统对接（TG_AVATAR_NET，backend/tg-r6.js） ----------------
 * NET.locked(slot,part) -> null | {id,price,name}；NET.titles() -> [{id,name,emoji,price,owned}]；NET.catalog() -> [...]
 * NET 未加载或目录为空时，退回内置的保守免费表（与 backend/r6.sql avatar_catalog 一致：beads/hairpin/jade/cape 收费）。 */
var FREE={head:['none','flower','hat','crown'],neck:['none'],waist:['none','gourd','pouch'],back:['none'],hand:['none','fan','rosary','scroll']};
var PAID_NAME={hairpin:['发簪',500],beads:['珠串',400],jade:['玉佩',600],cape:['云肩',700]};
function NET(){return window.TG_AVATAR_NET||null;}
function netReady(n){try{return !!(n&&typeof n.catalog==='function'&&n.catalog().length);}catch(e){return false;}}
function lockInfo(slot,part){if(!part||part==='none')return null;var n=NET();
 if(n&&typeof n.locked==='function'&&netReady(n)){try{return n.locked(slot,part)||null;}catch(e){}}
 if(FREE[slot]&&FREE[slot].indexOf(part)>=0)return null;var pn=PAID_NAME[part];return {id:part,price:pn?pn[1]:null,name:pn?pn[0]:part,fallback:true};}
function ownedTitles(){var n=NET();if(!n||typeof n.titles!=='function')return null;try{return (n.titles()||[]).filter(function(t){return t&&t.owned&&t.name;});}catch(e){return null;}}
/* 对外 normalize：TG_AVATAR_NET 已加载时，头衔必须是已拥有头衔的名字，否则清空。opts.checkOwned:false 跳过（渲染他人时用） */
function normalize(c,opts){var o=normBase(c);if(o.title&&!(opts&&opts.checkOwned===false)){var n=NET();if(n&&netReady(n)){var ts=ownedTitles()||[];
 if(!ts.some(function(t){return t.name===o.title;}))o.title='';}}return o;}
/* r8d3：广袖长袍(sengpao)、珠串(beads) 下架——面板不列、随机不抽；下标保留不动（序列化兼容），旧存档/远端形象原样保存，只在渲染时映射：
 * sengpao→daopao（直裰，同为长袍/宽袖/交领），beads→无（手持为空时补玉串 rosary）。 */
function visIds(list){return list.filter(function(o){return !o.hide;}).map(function(o){return o.id;});}
function renderMap(c){if(c.outfit==='sengpao')c.outfit='daopao';if(c.acc&&c.acc.neck==='beads'){c.acc.neck='none';if(c.acc.hand==='none')c.acc.hand='rosary';}return c;}
function validate(c){var errs=[];if(!c||typeof c!=='object')return {ok:false,errors:['not an object']};var n=normalize(c);
 ['name','title','height','build','skin','face','hair','hairColor','outfit','color1','color2','trim','capeColor','plate'].forEach(function(k){if(c[k]!==undefined&&String(c[k]).toLowerCase()!==String(n[k]).toLowerCase())errs.push(k);});
 SLOTS.forEach(function(s){if(c.acc&&c.acc[s]!==undefined&&c.acc[s]!==n.acc[s])errs.push('acc.'+s);});return {ok:!errs.length,errors:errs,config:n};}
/* 紧凑序列化：["A1",name,title,height,build#,skin,face#,hair#,hairColor,outfit#,c1,c2,trim,head#,neck#,waist#,back#,hand#,capeColor,plate#]，颜色去掉 # */
function idx(list,id){return Math.max(0,ids(list).indexOf(id));}
function h6(s){return s.slice(1);}
function serialize(c){c=normBase(c);return JSON.stringify(['A1',c.name,c.title,c.height,idx(OPT.build,c.build),h6(c.skin),idx(OPT.face,c.face),idx(OPT.hair,c.hair),h6(c.hairColor),idx(OPT.outfit,c.outfit),
 h6(c.color1),h6(c.color2),h6(c.trim),idx(OPT.head,c.acc.head),idx(OPT.neck,c.acc.neck),idx(OPT.waist,c.acc.waist),idx(OPT.back,c.acc.back),idx(OPT.hand,c.acc.hand),h6(c.capeColor),idx(OPT.plate,c.plate)]);}
function deserialize(s){var a;try{a=typeof s==='string'?JSON.parse(s):s;}catch(e){return normBase({});}
 if(!Array.isArray(a)){return normBase(a);}if(a[0]!=='A1')return normBase({});
 function at(list,i){var o=list[a[i]|0];return o?o.id:undefined;}
 return normBase({name:a[1],title:a[2],height:a[3],build:at(OPT.build,4),skin:a[5],face:at(OPT.face,6),hair:at(OPT.hair,7),hairColor:a[8],outfit:at(OPT.outfit,9),
  color1:a[10],color2:a[11],trim:a[12],acc:{head:at(OPT.head,13),neck:at(OPT.neck,14),waist:at(OPT.waist,15),back:at(OPT.back,16),hand:at(OPT.hand,17)},capeColor:a[18],plate:at(OPT.plate,19)});}
function rng(seed){var s=(typeof seed==='string'?Array.from(seed).reduce(function(h,ch){return Math.imul(h^ch.charCodeAt(0),16777619);},2166136261):(seed|0))>>>0;
 return function(){s=(s+0x6D2B79F5)>>>0;var t=s;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296;};}
function randomConfig(seed){var r=rng(seed==null?(Math.random()*1e9):seed);function pick(l){return l[Math.floor(r()*l.length)];}
 function free(slot,l){var f=l.filter(function(p){return !lockInfo(slot,p);});return f.length?pick(f):(r(),'none');}
 var hair=pick(ids(OPT.hair)),outfit=pick(visIds(OPT.outfit));
 var c1=pick(PAL.cloth),c2=pick(PAL.cloth);while(c2===c1)c2=pick(PAL.cloth);
 return normalize({height:90+Math.round(r()*20),build:pick(ids(OPT.build)),skin:pick(PAL.skin),face:pick(ids(OPT.face)),hair:hair,hairColor:r()<.8?PAL.hair[Math.floor(r()*3)]:pick(PAL.hair),
  outfit:outfit,color1:c1,color2:c2,trim:pick(PAL.trim),
  acc:{head:r()<.45?free('head',['hairpin','flower','hat','crown']):'none',neck:r()<.3?(r(),'none'):'none',waist:free('waist',['none','jade','gourd','pouch']),back:r()<.25?free('back',['cape']):'none',hand:r()<.3?free('hand',['fan','rosary','scroll']):'none'},
  capeColor:pick(PAL.cloth),plate:pick(ids(OPT.plate))},{checkOwned:false});}

/* ---------------- 几何工具：顶点色合并 ---------------- */
var _m=new T.Matrix4(),_q=new T.Quaternion(),_e=new T.Euler(),_v=new T.Vector3(),_s=new T.Vector3(),_n3=new T.Matrix3(),_c=new T.Color(),_c2=new T.Color();
var PRIM={};
function sph(ws,hs){var k='s'+ws+'_'+hs;return PRIM[k]||(PRIM[k]=new T.SphereGeometry(1,ws,hs));}
function boxG(){return PRIM.box||(PRIM.box=new T.BoxGeometry(1,1,1));}
function cylG(rt,rb,seg,open){var k='c'+rt+'_'+rb+'_'+seg+(open?'o':'');return PRIM[k]||(PRIM[k]=new T.CylinderGeometry(rt,rb,1,seg,1,!!open));}
function coneG(seg){var k='k'+seg;return PRIM[k]||(PRIM[k]=new T.ConeGeometry(1,1,seg));}
function torusG(tube,rs,ts){var k='t'+tube+'_'+rs+'_'+ts;return PRIM[k]||(PRIM[k]=new T.TorusGeometry(1,tube,rs,ts));}
function B(){this.items=[];this.tmp=[];}
B.prototype.add=function(g,col,p,r,s,tmp){this.items.push({g:g,c:col,p:p||[0,0,0],r:r||[0,0,0],s:s==null?[1,1,1]:(typeof s==='number'?[s,s,s]:s),q:null});if(tmp)this.tmp.push(g);return this;};
B.prototype.addQ=function(g,col,p,q,s){this.items.push({g:g,c:col,p:p,r:null,q:q,s:s});return this;};
B.prototype.lathe=function(pts,seg,col,p,s,phiStart,phiLen,inward){pts=pts.slice();if((pts[0][1]>pts[pts.length-1][1])!==!!inward)pts.reverse();var g=new T.LatheGeometry(pts.map(function(a){return new T.Vector2(a[0],a[1]);}),seg,phiStart||0,phiLen||Math.PI*2);return this.add(g,col,p,null,s,true);};
B.prototype.build=function(){
 var nv=0,ni=0,it=this.items,i,k;for(i=0;i<it.length;i++){var g=it[i].g;nv+=g.attributes.position.count;ni+=g.index?g.index.count:g.attributes.position.count;}
 var P=new Float32Array(nv*3),N=new Float32Array(nv*3),C=new Float32Array(nv*3),I=nv>65535?new Uint32Array(ni):new Uint16Array(ni),vo=0,io=0;
 for(i=0;i<it.length;i++){var o=it[i];g=o.g;
  if(o.q)_q.copy(o.q);else _q.setFromEuler(_e.set(o.r[0],o.r[1],o.r[2]));
  _m.compose(_v.set(o.p[0],o.p[1],o.p[2]),_q,_s.set(o.s[0],o.s[1],o.s[2]));_n3.getNormalMatrix(_m);
  var pa=g.attributes.position,na=g.attributes.normal,cnt=pa.count;_c.set(o.c);
  for(k=0;k<cnt;k++){_v.fromBufferAttribute(pa,k).applyMatrix4(_m);P[(vo+k)*3]=_v.x;P[(vo+k)*3+1]=_v.y;P[(vo+k)*3+2]=_v.z;
   _v.fromBufferAttribute(na,k).applyMatrix3(_n3).normalize();N[(vo+k)*3]=_v.x;N[(vo+k)*3+1]=_v.y;N[(vo+k)*3+2]=_v.z;
   C[(vo+k)*3]=_c.r;C[(vo+k)*3+1]=_c.g;C[(vo+k)*3+2]=_c.b;}
  if(g.index){var ia=g.index.array;for(k=0;k<ia.length;k++)I[io+k]=ia[k]+vo;io+=ia.length;}else{for(k=0;k<cnt;k++)I[io+k]=vo+k;io+=cnt;}
  vo+=cnt;}
 this.tmp.forEach(function(g){g.dispose();});
 var out=new T.BufferGeometry();out.setAttribute('position',new T.BufferAttribute(P,3));out.setAttribute('normal',new T.BufferAttribute(N,3));out.setAttribute('color',new T.BufferAttribute(C,3));out.setIndex(new T.BufferAttribute(I,1));
 out.computeBoundingSphere();out.computeBoundingBox();return out;};
/* 贴着身体表面的带子：p0→p1（局部坐标），宽 w 厚 t */
var _y=new T.Vector3(),_x=new T.Vector3(),_z=new T.Vector3(),_mb=new T.Matrix4();
B.prototype.strap=function(p0,p1,w,t,col,nrm){_y.set(p1[0]-p0[0],p1[1]-p0[1],p1[2]-p0[2]);var len=_y.length();_y.multiplyScalar(1/len);
 _z.set(nrm?nrm[0]:(p0[0]+p1[0])/2,nrm?nrm[1]:0,nrm?nrm[2]:(p0[2]+p1[2])/2).normalize();_x.crossVectors(_y,_z).normalize();_z.crossVectors(_x,_y);
 _mb.makeBasis(_x,_y,_z);var q=new T.Quaternion().setFromRotationMatrix(_mb);
 return this.addQ(boxG(),col,[(p0[0]+p1[0])/2,(p0[1]+p1[1])/2,(p0[2]+p1[2])/2],q,[w,len,t]);};
function mix(a,b,t){_c.set(a);_c2.set(b);_c.lerp(_c2,t);return '#'+_c.getHexString();}
function shade(a,k){_c.set(a);_c.multiplyScalar(k);return '#'+_c.getHexString();}

/* ---------------- 身体表面（给带子、珠串、玉佩贴面用） ---------------- */
var TORSO=[[.16,-.02],[.168,0],[.152,.1],[.146,.16],[.163,.28],[.178,.37],[.18,.45],[.165,.5],[.11,.55],[.06,.575]];
var Z_T=.74;
function lerpProf(pr,y){if(y<=pr[0][1])return pr[0][0];for(var i=1;i<pr.length;i++){if(y<=pr[i][1]){var a=pr[i-1],b=pr[i],t=(y-a[1])/(b[1]-a[1]);return a[0]+(b[0]-a[0])*t;}}return pr[pr.length-1][0];}
function skirtProf(o,w){return o.high?[[.182*w,.4],[.19*w,.2],[.25*w,-.3],[.31*w,-.84]]:[[.162*w,.13],[.19*w,-.15],[.26*w,-.55],[.295*w,-.84]];}
function surf(o,w,y){ // 返回 [半径x, z缩放]
 if(o.long){var sp=skirtProf(o,w);if(y<sp[0][1])return [lerpProf(sp.slice().reverse().map(function(a){return a;}).sort(function(a,b){return a[1]-b[1];}),y),.86];}
 if(!o.long&&y<.16)return [lerpProf([[.2*w,-.2],[.17*w,0],[.152*w,.16]],y),.8];
 return [lerpProf(TORSO,y)*w,Z_T];}
function onBody(o,w,x,y,front,off){var s=surf(o,w,y),r=s[0];var z=s[1]*Math.sqrt(Math.max(0,r*r-x*x))+(off||0);return [x,y,front?z:-z];}

/* ---------------- 部件构建（局部坐标；全身 1.75 高时的单位） ---------------- */
var DET=1;function sg(n){return Math.max(4,Math.round(n*(DET?1:.62)));}
function buildTorso(c){
 var b=new B(),o=find(OPT.outfit,c.outfit),w=find(OPT.build,c.build).w,c1=c.color1,c2=c.color2,tr=c.trim,i;
 var top=o.high?TORSO:TORSO;b.lathe(top.map(function(p){return [p[0]*w,p[1]];}),sg(20),o.high?c1:c1,[0,0,0],[1,1,Z_T]);
 if(o.long){ /* 裙摆在独立部件 skirt（buildSkirt），随姿势切换 */ }else{ // 短打：衣摆
  b.lathe([[.152*w,.16],[.17*w,0],[.2*w,-.2]],sg(20),c1,[0,0,0],[1,1,.8]);b.add(cylG(1,1,sg(20),true),tr,[0,-.19,0],null,[.202*w,.04,.202*w*.8]);}
 // 领
 if(o.collar==='cross'){var col='#f4ecda';
  var L=[onBody(o,w,.05*w,.54,1,.006),onBody(o,w,.0,.46,1,.008),onBody(o,w,-.07*w,.36,1,.008),onBody(o,w,-.13*w,o.high?.4:.24,1,.006)];
  for(i=1;i<L.length;i++){b.strap(L[i-1],L[i],.05,.012,col);}
  for(i=1;i<L.length;i++){var a=L[i-1],e=L[i];b.strap([a[0]+.018,a[1]+.01,a[2]+.004],[e[0]+.018,e[1]+.01,e[2]+.004],.016,.008,tr);}
  var R=[onBody(o,w,-.05*w,.54,1,.004),onBody(o,w,-.005,.47,1,.005)];b.strap(R[0],R[1],.045,.01,col);
  // 后领
  b.add(torusG(.12,6,sg(16)),col,[0,.545,-.005],[Math.PI/2,0,0],[.075*w,.07*w*.9,.075*w]);
 }else{b.add(torusG(.18,6,sg(16)),tr,[0,.55,.0],[Math.PI/2,0,0],[.078*w,.07*w,.07]);b.add(torusG(.12,6,sg(16)),c2,[0,.55,0],[Math.PI/2,0,0],[.09*w,.074*w,.09]);}
 // 腰带 / 胸带
 var by=o.high?.38:.14,br=(o.high?lerpProf(TORSO,.38):.148)*w+.008,bz=o.high?Z_T:(o.long?Z_T+.02:Z_T+.02);
 b.add(cylG(1,1,sg(20),true),o.collar==='round'?'#2b2420':c2,[0,by,0],null,[br,.075,br*bz]);
 b.add(cylG(1,1,sg(20),true),tr,[0,by+.04,0],null,[br+.003,.012,(br+.003)*bz]);b.add(cylG(1,1,sg(20),true),tr,[0,by-.04,0],null,[br+.003,.012,(br+.003)*bz]);
 if(o.collar==='round'){for(i=0;i<7;i++){var an=-1.2+i*.4;b.add(boxG(),tr,[Math.sin(an)*br*1.02,by,Math.cos(an)*br*bz*1.04],[0,an,0],[.028,.045,.012]);}}
 else{ // 结与垂带
  var f=onBody(o,w,.04*w,by,1,.012);b.add(sph(8,6),c2,f,null,[.03,.024,.018]);
  var t0=onBody(o,w,.03*w,by-.03,1,.012),t1=onBody(o,w,.045*w,by-(o.high?.42:.36),1,.012);b.strap(t0,t1,.03,.008,o.high?c1:c2);
  var t2=onBody(o,w,.065*w,by-.03,1,.01),t3=onBody(o,w,.085*w,by-(o.high?.36:.3),1,.01);b.strap(t2,t3,.026,.008,tr);}
  // 领口下颈部
 b.add(cylG(1,1,8),c.skin,[0,.575,0],null,[.045,.03,.042]);
 // 珠串（挂颈）
 if(c.acc.neck==='beads'){var n=18;for(i=0;i<n;i++){var aa=i/n*Math.PI*2,cy=.535-.15*Math.pow((1+Math.cos(aa))/2,1.6),sr=surf(o,w,cy),rr=Math.max(sr[0]*1.0,.07)+.016;
   b.add(sph(6,5),i%9===0?'#8cc7a3':(i%3===0?'#d8ae55':'#c9a070'),[Math.sin(aa)*rr,cy,Math.cos(aa)*rr*sr[1]+(Math.cos(aa)>0?.0:0)],null,.017);}
  var fb=onBody(o,w,0,.37,1,.03);b.add(sph(8,6),'#c9a050',fb,null,.024);b.add(coneG(6),'#b8322a',[fb[0],fb[1]-.06,fb[2]],null,[.016,.08,.016]);}
 // 腰间
 var wy=o.high?.32:.12,ws=c.acc.waist;
 if(ws==='jade'){var j0=onBody(o,w,-.08*w,wy-.03,1,.012),j1=onBody(o,w,-.09*w,wy-.15,1,.022);b.strap(j0,j1,.008,.006,'#b8322a');
  b.add(torusG(.38,6,sg(14)),'#8cc7a3',[j1[0],j1[1]-.02,j1[2]+.004],null,.028);b.add(sph(6,5),'#d8ae55',[j1[0],j1[1]+.01,j1[2]+.006],null,.011);b.add(coneG(6),'#b8322a',[j1[0],j1[1]-.1,j1[2]],null,[.014,.09,.012]);}
 if(ws==='gourd'){var g0=onBody(o,w,.15*w,wy-.08,1,.0);g0[0]=surf(o,w,wy-.08)[0]+.035;g0[2]*=.5;b.add(sph(10,8),'#d9a54a',[g0[0],g0[1]+.045,g0[2]],null,.03);b.add(sph(10,8),'#d9a54a',[g0[0],g0[1]-.03,g0[2]],null,[.045,.05,.045]);
  b.add(cylG(1,1,6),'#b8322a',[g0[0]-.01,g0[1]+.085,g0[2]],[0,0,.5],[.008,.07,.008]);b.add(boxG(),'#b8322a',[g0[0],g0[1]+.012,g0[2]],null,[.07,.012,.05]);}
 if(ws==='pouch'){var q0=onBody(o,w,.09*w,wy-.12,1,.025);b.add(sph(8,6),'#b8322a',q0,null,[.035,.042,.02]);b.add(cylG(1,1,8),tr,[q0[0],q0[1]+.035,q0[2]],null,[.018,.012,.012]);b.add(coneG(6),tr,[q0[0],q0[1]-.075,q0[2]],null,[.01,.06,.01]);
  b.strap(onBody(o,w,.085*w,wy-.02,1,.012),[q0[0],q0[1]+.04,q0[2]],.006,.005,tr);}
 return b.build();
}
function buildHead(c){
 var b=new B(),f=find(OPT.face,c.face),sk=c.skin,hc=c.hairColor,tr=c.trim,hs=f.h,hair=c.hair;
 b.add(cylG(1,1,10),sk,[0,.04,0],null,[.044,.12,.042]);
function deform(f,v){if(v.y<0){var t=Math.pow(-v.y,f.e),k=1-(1-f.jw)*t;v.x*=k;v.z*=1-(1-f.jw)*.45*t;v.y*=1+(f.cl-1)*(-v.y);}if(v.z>0&&v.y>.2)v.z*=1-.06*(v.y-.2);return v;}
 var HS=[.115*hs[0],.115*hs[1],.115*hs[2]],hv=new T.Vector3();
 function hp(nx,ny,off){hv.set(nx,ny,Math.sqrt(Math.max(0,1-nx*nx-ny*ny)));deform(f,hv);return [hv.x*HS[0],.19+hv.y*HS[1],hv.z*HS[2]+(off||0)];}
 var hg=new T.SphereGeometry(1,sg(22),sg(16)),pa=hg.attributes.position;for(var i0=0;i0<pa.count;i0++){hv.fromBufferAttribute(pa,i0);deform(f,hv);pa.setXYZ(i0,hv.x,hv.y,hv.z);}hg.computeVertexNormals();
 b.add(hg,sk,[0,.19,0],null,HS,true);
 for(var s=-1;s<=1;s+=2){
  b.add(sph(8,6),shade(sk,.93),[s*.112*hs[0],.183,-.004],null,[.018,.034,.024]);
  b.add(sph(10,6),'#2a1e1a',hp(s*.36,.03,-.004),[0,s*.3,s*.14],[.024,.0105,.012]);   // 眼
  b.add(sph(6,4),'#f7f1e8',hp(s*.41,.05,-.001),null,[.008,.0055,.006]);              // 眼神光
  b.add(boxG(),shade(hc,.85),hp(s*.4,.3,-.002),[0,s*.3,-s*.16],[.046,.0075,.012]); // 眉
  b.add(sph(8,6),mix(sk,'#ff9a8e',.14),hp(s*.55,-.24,-.009),[0,s*.5,0],[.02,.011,.01]);     // 腮红
 }
 b.add(coneG(6),shade(sk,.94),hp(0,-.2,-.012),[Math.PI/2+.3,0,0],[.014,.032,.017]);
 b.add(sph(8,6),'#c25c55',hp(0,-.55,-.004),null,[.021,.0068,.008]);
 // 头发
 var cap=function(col,lift){b.add(new T.SphereGeometry(1,sg(20),sg(10),0,Math.PI*2,0,1.5),col,[0,.197+(lift||0),-.006],[-.36,0,0],[.123*hs[0],.137*hs[1],.13*hs[2]],true);};
 var back=function(){b.add(sph(sg(14),sg(10)),hc,[0,.155,-.05],null,[.112*hs[0],.11,.085]);};
 if(hair==='bald'){cap(mix(sk,'#3a3a3a',.14),.002);for(var i=0;i<6;i++)b.add(sph(6,4),'#f4dcc0',[(i%3-1)*.03,.322-(i<3?0:.03)*.6,-.01-(i<3?0:.025)],[-.3,0,0],[.007,.003,.007]);}
 else{cap(hc);back();}
 if(hair==='bun'){b.add(sph(sg(14),sg(10)),hc,[0,.335,-.035],null,[.062,.055,.06]);b.add(torusG(.22,6,sg(14)),tr,[0,.29,-.03],[Math.PI/2,0,0],.05);}
 if(hair==='twin'){for(s=-1;s<=1;s+=2){b.add(sph(sg(12),sg(8)),hc,[s*.082,.31,-.02],null,.046);b.add(torusG(.25,6,12),tr,[s*.07,.28,-.02],[Math.PI/2,0,s*.6],.034);
   b.add(boxG(),tr,[s*.1,.2,-.06],[0,0,s*.15],[.014,.12,.008]);}}
 if(hair==='ponytail'){b.add(cylG(1,.9,sg(12)),tr,[0,.33,-.03],null,[.034,.045,.034]);b.add(sph(8,6),hc,[0,.36,-.03],null,.026);
  var seg=[[0,.31,-.11,.042],[0,.22,-.15,.04],[0,.11,-.17,.034],[0,.0,-.17,.026],[0,-.09,-.16,.016]];for(i=0;i<seg.length;i++)b.add(sph(10,8),hc,seg[i].slice(0,3),[i?-.15:.6,0,0],[seg[i][3],.085,seg[i][3]*.8]);
  b.add(boxG(),tr,[.03,.24,-.14],[.3,0,-.15],[.015,.16,.006]);}
 if(hair==='long'){b.add(sph(sg(14),sg(12)),hc,[0,.04,-.11],[.22,0,0],[.118*hs[0],.23,.05]);
  for(s=-1;s<=1;s+=2)b.add(sph(10,8),hc,[s*.1,.1,.02],[0,0,s*.08],[.024,.11,.03]);
  b.add(boxG(),tr,[0,.17,-.125],[.2,0,0],[.07,.012,.012]);}
 if(hair==='short'){for(s=-1;s<=1;s+=2)b.add(sph(10,8),hc,[s*.045,.268,.078],[-.5,0,s*.7],[.05,.022,.035]);b.add(sph(10,8),hc,[0,.1,-.07],null,[.09,.08,.06]);}
 // 头饰
 var ha=c.acc.head,top=hair==='bun'?[0,.34,-.035]:hair==='ponytail'?[0,.34,-.03]:hair==='twin'?[-.082,.31,-.02]:[.07,.29,-.04];
 if(ha==='hairpin'&&hair!=='bald'){b.add(cylG(1,1,6),'#d8ae55',[top[0],top[1]+.005,top[2]],[0,0,1.15],[.0055,.2,.0055]);
  b.add(sph(8,6),'#8cc7a3',[top[0]+.09,top[1]+.045,top[2]],null,.016);b.add(coneG(6),'#b8322a',[top[0]+.095,top[1]-.005,top[2]],null,[.008,.07,.008]);
  for(i=0;i<5;i++){var an=i/5*Math.PI*2;b.add(sph(6,4),'#efd79a',[top[0]-.085+Math.cos(an)*.014,top[1]-.035+Math.sin(an)*.014,top[2]+.005],null,.01);}}
 if(ha==='flower'){var fp=hair==='bald'?[.09,.27,.02]:[.095,.27,-.01];var fc=['#e86a7a','#f2a3b0','#e86a7a','#f6c1c9','#d94a5a'];
  for(i=0;i<5;i++){an=i/5*Math.PI*2;b.add(sph(6,5),fc[i],[fp[0]+.01,fp[1]+Math.sin(an)*.022,fp[2]+Math.cos(an)*.022],null,[.014,.018,.018]);}
  b.add(sph(6,5),'#f3d36a',[fp[0]+.018,fp[1],fp[2]],null,.011);b.add(sph(6,4),'#5f8a4a',[fp[0]+.004,fp[1]-.035,fp[2]-.03],[.6,0,0],[.01,.03,.015]);}
 if(ha==='crown'&&hair!=='bald'){var cp=hair==='twin'?[0,.32,-.03]:top;cp=[0,cp[1]-.005,cp[2]];b.add(cylG(.9,1,sg(12)),'#d8ae55',cp,null,[.04,.035,.033]);
  b.add(boxG(),'#d8ae55',[cp[0],cp[1]+.03,cp[2]],null,[.016,.03,.05]);b.add(cylG(1,1,6),'#efd79a',[cp[0],cp[1]+.012,cp[2]],[0,0,Math.PI/2],[.005,.16,.005]);b.add(sph(6,5),'#b8322a',[cp[0],cp[1]+.02,cp[2]+.035],null,.009);}
 if(ha==='hat'){var hy=(hair==='bun'||hair==='ponytail')?.36:hair==='twin'?.345:.3;
  b.add(coneG(sg(20)),'#cfae6c',[0,hy+.06,0],null,[.31,.12,.31]);b.add(coneG(sg(20)),'#b8924f',[0,hy+.025,0],null,[.315,.05,.315]);
  b.add(cylG(1,1,sg(20),true),'#8f6a3a',[0,hy,0],null,[.312,.012,.312]);b.add(sph(8,6),'#8f6a3a',[0,hy+.12,0],null,.018);
  b.add(cylG(1,1,8,true),'#6e4f2c',[0,hy-.015,0],null,[.085,.02,.085]);
  for(s=-1;s<=1;s+=2)b.strap([s*.112,.17,0],[s*.07,.07,.06],.006,.004,'#6e4f2c',[s,0,.3]);}
 return b.build();
}
function handProp(b,c,hy){var h=c.acc.hand,y=hy-.03;
 if(h==='fan'){b.add(new T.CircleGeometry(.15,10,0,Math.PI),'#f4ecda',[0,y-.03,.06],[-.25,Math.PI/2,0],1,true);for(var i=0;i<6;i++){var a=i/5*Math.PI;b.add(boxG(),'#8a5a3c',[0,y-.03+Math.sin(a)*.075,.06+Math.cos(a)*.075],[a-Math.PI/2,0,0],[.012,.15,.004]);}
  b.add(boxG(),c.trim,[0.006,y+.02,.06],[-.25,0,0],[.002,.05,.22]);}
 if(h==='rosary'){for(i=0;i<12;i++){a=i/12*Math.PI*2;b.add(sph(6,4),i%3?'#8cc7a3':'#d8ae55',[Math.sin(a)*.05,y-.02-(1+Math.cos(a))*.04,.04+Math.cos(a)*.02],null,.012);}b.add(coneG(6),'#b8322a',[0,y-.13,.06],null,[.012,.06,.012]);}
 if(h==='scroll'){b.add(cylG(1,1,10),'#f1e6cf',[0,y,.05],[Math.PI/2,0,0],[.03,.2,.03]);for(var s=-1;s<=1;s+=2)b.add(cylG(1,1,8),'#8a5a3c',[0,y,.05+s*.105],[Math.PI/2,0,0],[.012,.02,.012]);b.add(boxG(),'#b8322a',[0,y,.05],null,[.065,.02,.064]);}
 if(h==='teapot'){b.add(sph(12,9),'#5d7f86',[0,y-.05,.06],null,[.075,.06,.075]);b.add(cylG(1,1,10),'#5d7f86',[0,y+.005,.06],null,[.03,.02,.03]);b.add(sph(6,4),'#d8ae55',[0,y+.02,.06],null,.012);
  b.add(cylG(.4,1,6),'#5d7f86',[0,y-.04,.15],[1.1,0,0],[.012,.07,.012]);b.add(torusG(.3,5,10),'#4c6b72',[0,y-.04,-.02],[0,Math.PI/2,0],[.035,.035,.035]);}
 if(h==='brush'){b.add(cylG(1,1,6),'#8a5a3c',[0,y,.04],[1.2,0,0],[.008,.2,.008]);b.add(coneG(6),'#222',[0,y-.035,.13],[1.2+Math.PI,0,0],[.012,.04,.012]);}
 if(h==='incense'){b.add(cylG(1,1,8),'#d8ae55',[0,y+.06,.06],null,[.035,.012,.035]);b.add(cylG(1,1,8),'#c7362a',[0,y+.01,.06],null,[.04,.08,.04]);b.add(cylG(1,1,8),'#d8ae55',[0,y-.04,.06],null,[.035,.012,.035]);b.add(sph(6,4),'#ffd27a',[0,y+.01,.06],null,.016);b.add(coneG(6),'#d8ae55',[0,y-.09,.06],null,[.008,.06,.008]);}
 if(h==='bowl'){b.add(new T.SphereGeometry(1,12,6,0,Math.PI*2,Math.PI/2,Math.PI/2),'#eef3f5',[0,y-.0,.08],null,[.08,.06,.08],true);b.add(cylG(1,1,12),'#d9b27a',[0,y-.004,.08],null,[.072,.008,.072]);b.add(torusG(.15,4,12),'#3f6a8a',[0,y-.012,.08],[Math.PI/2,0,0],[.078,.078,.078]);}
 if(h==='bolt'){b.add(cylG(1,1,12),c.color2,[0,y-.02,.07],[0,0,Math.PI/2],[.055,.3,.055]);b.add(cylG(1,1,12,true),c.trim,[.0,y-.02,.07],[0,0,Math.PI/2],[.057,.03,.057]);}
 if(h==='herb'){b.add(boxG(),'#d8c49a',[0,y-.04,.06],[0,.3,0],[.1,.07,.08]);b.strap([-.05,y-.005,.06],[.05,y-.005,.06],.008,.004,'#b8322a',[0,1,0]);b.add(sph(6,4),'#b8322a',[0,y,.06],null,.012);}
 if(h==='flowerpot'){b.add(cylG(1,.75,10),'#b5653c',[0,y-.04,.08],null,[.06,.08,.06]);b.add(sph(8,6),'#5f8a4a',[0,y+.03,.08],null,[.07,.05,.07]);for(i=0;i<4;i++)b.add(sph(6,4),['#e86a7a','#f3d36a','#f2a3b0','#e86a7a'][i],[Math.cos(i*1.6)*.04,y+.07,.08+Math.sin(i*1.6)*.04],null,.016);}
}
function buildArm(c,right){
 var b=new B(),o=find(OPT.outfit,c.outfit),w=find(OPT.build,c.build).w,c1=c.color1,tr=c.trim,sk=c.skin,hy;
 b.add(sph(sg(12),sg(8)),c1,[0,-.02,0],null,[.062*w,.062,.066*w]);
 if(o.sleeve==='wide'){b.lathe([[.066*w,0],[.08*w,-.18],[.12*w,-.42],[.145*w,-.6]],sg(14),c1,[0,0,0],[1,1,.9]);
  b.add(cylG(1,1,sg(14),true),tr,[0,-.58,0],null,[.148*w,.05,.148*w*.9]);b.add(cylG(1,1,sg(14),true),c.color2,[0,-.535,0],null,[.142*w,.028,.142*w*.9]);
  b.add(cylG(1,1,sg(14)),shade(c1,.45),[0,-.6,0],null,[.14*w,.004,.14*w*.88]);
  b.add(cylG(1,1,8),sk,[0,-.6,.01],null,[.034,.08,.03]);hy=-.66;}
 else{b.lathe([[.064*w,0],[.06*w,-.25],[.05*w,-.5]],sg(12),c1,[0,0,0]);b.add(cylG(1,1,sg(12),true),tr,[0,-.49,0],null,[.054*w,.05,.054*w]);
  if(c.outfit==='duanda')b.add(cylG(1,1,sg(12),true),'#f1e6cf',[0,-.43,0],null,[.058*w,.06,.058*w]);hy=-.57;}
 b.add(sph(10,8),sk,[0,hy,.008],null,[.036,.058,.026]);b.add(sph(6,4),sk,[(right?1:-1)*.025,hy+.015,.03],[0,0,(right?-1:1)*.5],[.012,.03,.012]);
 if(right)handProp(b,c,hy);
 return b.build();
}
function buildSkirt(c){
 var b=new B(),o=find(OPT.outfit,c.outfit),w=find(OPT.build,c.build).w,c1=c.color1,c2=c.color2,tr=c.trim,col=o.high?c2:c1,band=o.high?c1:c2,i,y,p;
 if(c._pose==='ride'||c._pose==='sit'){ // 骑/坐：裙摆收短到胯下，余下布料挂在腿上（见 buildLeg）
  var sp=o.high?[[.182*w,.4],[.19*w,.2],[.21*w,-.05],[.235*w,-.2]]:[[.162*w,.13],[.19*w,-.15],[.215*w,-.24]];
  b.lathe(sp,sg(22),col,[0,0,0],[1,1,.86]);var e=sp[sp.length-1];var hy=e[1],hr=e[0];
  b.add(cylG(1,1,sg(22),true),tr,[0,hy+.02,0],null,[hr+.006,.045,(hr+.006)*.86]);
  if(!o.high){p=[];for(y=.12;y>=hy+.01;y-=.12)p.push(onBody(o,w,-.03*w,y,1,.004));for(i=1;i<p.length;i++)b.strap(p[i-1],p[i],.032,.008,tr);}
  return b.build();}
 var sp2=skirtProf(o,w);b.lathe(sp2,sg(22),col,[0,0,0],[1,1,.86]);
 var hr2=sp2[sp2.length-1][0];b.add(cylG(1,1,sg(22),true),tr,[0,-.81,0],null,[hr2+.006,.06,(hr2+.006)*.86]);b.add(cylG(1,1,sg(22),true),band,[0,-.75,0],null,[hr2*.985+.005,.035,(hr2*.985+.005)*.86]);
 if(!o.high){p=[];for(y=.12;y>=-.8;y-=.23)p.push(onBody(o,w,-.03*w,y,1,.004));for(i=1;i<p.length;i++)b.strap(p[i-1],p[i],.032,.008,tr);}
 return b.build();
}
function buildLeg(c){
 var b=new B(),o=find(OPT.outfit,c.outfit),w=find(OPT.build,c.build).w,lc=o.long?shade(c.color1,.62):c.color2;
 b.lathe([[.088*w,.02],[.08*w,-.2],[.06*w,-.46],[.05*w,-.78],[.048*w,-.82]],sg(12),lc,[0,0,0]);
 if(c.outfit==='duanda'){b.add(cylG(.9,1,sg(12)),'#efe3c8',[0,-.68,0],null,[.058*w,.22,.06*w]);for(var i=0;i<3;i++)b.add(cylG(1,1,sg(10),true),'#8a5a3c',[0,-.6-i*.065,0],[.25,0,0],[.062*w,.01,.064*w]);}
 b.add(sph(sg(12),8),'#2b2420',[0,-.85,.035],null,[.052,.045,.11]);b.add(boxG(),'#f1e6cf',[0,-.893,.035],null,[.1,.014,.21]);
 b.add(cylG(1,1,sg(10)),o.long?c.trim:'#2b2420',[0,-.81,0],null,[.052*w,.04,.052*w]);
 if(o.long&&(c._pose==='ride'||c._pose==='sit')){ // 披在腿上的袍摆：随腿一起转，不会穿进马背/车板
  var rc=o.high?c.color2:c.color1,ro=c._pose==='ride'?.62:.58;
  b.lathe([[.1*w,.06],[.118*w,-.12],[.13*w,-.4],[.14*w,-ro]],sg(14),rc,[0,0,0],[1,1,1.05]);
  b.add(cylG(1,1,sg(14),true),c.trim,[0,-ro+.02,0],null,[.143*w,.045,.143*w*1.05]);b.add(cylG(1,1,sg(14),true),o.high?c.color1:c.color2,[0,-ro+.07,0],null,[.139*w,.025,.139*w*1.05]);
  b.add(cylG(1,1,sg(14)),shade(rc,.45),[0,-ro+.001,0],null,[.138*w,.003,.138*w*1.03]);}
 return b.build();
}
function buildCape(c){
 var b=new B(),w=find(OPT.build,c.build).w,cc=c.capeColor,lin=mix(c.trim,'#f1e6cf',.4),ph0=Math.PI-1.95,phl=3.9,o=find(OPT.outfit,c.outfit);
 var hem=o.long?.33:.3,pts=(c._pose==='ride'||c._pose==='sit')?[[.15*w,.02],[.22*w,-.05],[.26*w,-.3],[.3*w,-.62]]:[[.15*w,.02],[.22*w,-.05],[.26*w,-.3],[hem*w,-.85],[(hem+.03)*w,-1.24]];
 b.lathe(pts,sg(20),cc,[0,0,-.01],[1,1,.82],ph0,phl);
 b.lathe(pts.map(function(p){return [p[0]-.006,p[1]];}),sg(20),lin,[0,0,-.01],[1,1,.82],ph0,phl,true);
 var e=pts[pts.length-1];b.lathe([[e[0]+.004,e[1]+.05],[e[0]+.006,e[1]]],sg(20),c.trim,[0,0,-.01],[1,1,.82],ph0,phl);
 b.add(torusG(.12,6,sg(16)),c.trim,[0,.015,-.0],[Math.PI/2,0,0],[.15*w,.13*w*.82,.1]);
 b.add(sph(8,6),'#d8ae55',[0,-.06,.12*w],null,[.025,.025,.012]);b.strap([-.1*w,.0,.08*w],[0,-.06,.12*w],.02,.006,c.trim,[0,0,1]);b.strap([.1*w,.0,.08*w],[0,-.06,.12*w],.02,.006,c.trim,[0,0,1]);
 return b.build();
}

/* ---------------- 缓存（引用计数） ---------------- */
var GC=new Map();
function partKey(part,c){var a=c.acc;switch(part){
 case 'torso':return [c.outfit,c.build,c.color1,c.color2,c.trim,c.skin,a.neck,a.waist].join('|');
 case 'head':return [c.face,c.skin,c.hair,c.hairColor,c.trim,a.head].join('|');
 case 'armL':return [c.outfit,c.build,c.color1,c.color2,c.trim,c.skin].join('|');
 case 'armR':return [c.outfit,c.build,c.color1,c.color2,c.trim,c.skin,a.hand].join('|');
 case 'legL':case 'legR':return [c.outfit,c.build,c.color1,c.color2,c.trim,find(OPT.outfit,c.outfit).long?c._pose:''].join('|');
 case 'skirt':return find(OPT.outfit,c.outfit).long?[c.outfit,c.build,c.color1,c.color2,c.trim,c._pose].join('|'):'';
 case 'cape':return a.back==='cape'?[c.build,c.outfit,c.capeColor,c.trim,c._pose==='stand'?'':'short'].join('|'):'';}}
var BUILDERS={skirt:buildSkirt,torso:buildTorso,head:buildHead,armL:function(c){return buildArm(c,false);},armR:function(c){return buildArm(c,true);},legL:buildLeg,legR:buildLeg,cape:buildCape};
function acquire(part,c,det){var k=(part==='legR'?'legL':part)+'#'+det+'#'+partKey(part,c);var e=GC.get(k);
 if(!e){DET=det;e={g:BUILDERS[part](c),n:0,k:k};DET=1;e.g.userData.tgAvatarKey=k;GC.set(k,e);}e.n++;return e.g;}
function release(g){if(!g||!g.userData||!g.userData.tgAvatarKey)return;var e=GC.get(g.userData.tgAvatarKey);if(e&&--e.n<=0){e.g.dispose();GC.delete(e.k);}}
var MAT=null,matFactory=null;
function material(){if(MAT)return MAT;MAT=matFactory?matFactory():new T.MeshStandardMaterial({vertexColors:true,roughness:.78,metalness:0,name:'tgAvatar'});return MAT;}

/* ---------------- 名牌 ---------------- */
var PC=new Map();
function plateTex(c){var k=c.name+'\u0001'+c.title+'\u0001'+c.plate,e=PC.get(k);if(e){e.n++;return e.t;}
 var st=find(OPT.plate,c.plate),cv=document.createElement('canvas');cv.width=512;cv.height=176;var x=cv.getContext('2d'),F='"Noto Serif CJK SC","Noto Serif SC","Songti SC","STSong","SimSun",serif';
 x.textAlign='center';x.textBaseline='middle';
 if(c.title){x.font='600 40px '+F;var tw=Math.min(440,x.measureText(c.title).width+70),tx=256-tw/2;
  var gr=x.createLinearGradient(0,0,0,64);gr.addColorStop(0,st.bg[1]);gr.addColorStop(1,st.bg[0]);x.fillStyle=gr;
  x.beginPath();x.moveTo(tx,10);x.lineTo(tx+tw,10);x.lineTo(tx+tw-16,36);x.lineTo(tx+tw,62);x.lineTo(tx,62);x.lineTo(tx+16,36);x.closePath();x.fill();
  x.strokeStyle=st.edge;x.lineWidth=3;x.stroke();x.fillStyle=st.edge;for(var s=-1;s<=1;s+=2){x.beginPath();x.arc(256+s*(tw/2-34),36,4,0,7);x.fill();}
  x.fillStyle=st.fg;x.fillText(c.title,256,37);}
 if(c.name){x.font='700 62px '+F;x.lineJoin='round';x.lineWidth=10;x.strokeStyle='rgba(40,22,12,.85)';x.strokeText(c.name,256,118);x.fillStyle='#fff7e6';x.fillText(c.name,256,118);}
 var t=new T.CanvasTexture(cv);t.colorSpace=T.SRGBColorSpace;t.anisotropy=2;t.userData.k=k;PC.set(k,{t:t,n:1});return t;}
function plateRelease(t){if(!t)return;var e=PC.get(t.userData.k);if(e&&--e.n<=0){e.t.dispose();PC.delete(t.userData.k);}}

/* ---------------- 构建 / 更新 / 释放 ---------------- */
var PARTS=['torso','skirt','head','armL','armR','legL','legR','cape'];
function layout(g,c){var u=g.userData,w=find(OPT.build,c.build).w,P=u.parts;
 P.rig.scale.setScalar(c.height/100);P.legL.position.set(.088*w,.9,0);P.legR.position.set(-.088*w,.9,0);P.torsoJ.position.set(0,.9,0);
 P.headJ.position.set(0,.575,0);P.armLJ.position.set(.188*w,.495,0);P.armRJ.position.set(-.188*w,.495,0);P.capeJ.position.set(0,.53,0);
 if(P.plate){var hat=c.acc.head==='hat'?.08:0;P.plate.position.set(0,(1.97+hat)*c.height/100,0);}}
function setPlate(g,c){var P=g.userData.parts,want=g.userData.opts.plate!==false&&(c.name||c.title);
 if(P.plate){plateRelease(P.plate.material.map);P.plate.material.dispose();g.remove(P.plate);P.plate=null;}
 if(want){var sm=new T.SpriteMaterial({map:plateTex(c),transparent:true,depthWrite:false,fog:false});var sp=new T.Sprite(sm);sp.name='plate';sp.scale.set(1.15,.395,1);sp.center.set(.5,0);sp.renderOrder=10;g.add(sp);P.plate=sp;}}
function build(cfg,opts){
 var c=normBase(cfg);opts=opts||{};var det=opts.detail===0?0:1,mat=material();
 var root=new T.Group();root.name='tg-avatar';var rig=new T.Group();rig.name='rig';root.add(rig);
 var J=function(n,parent){var j=new T.Group();j.name=n;parent.add(j);return j;};
 var P={rig:rig};P.legL=J('legLJ',rig);P.legR=J('legRJ',rig);P.torsoJ=J('torsoJ',rig);P.headJ=J('headJ',P.torsoJ);P.armLJ=J('armLJ',P.torsoJ);P.armRJ=J('armRJ',P.torsoJ);P.capeJ=J('capeJ',P.torsoJ);
 var hold={skirt:P.torsoJ,torso:P.torsoJ,head:P.headJ,armL:P.armLJ,armR:P.armRJ,legL:P.legL,legR:P.legR,cape:P.capeJ};
 root.userData={tgAvatar:true,pose:'stand',poseSpl:.3,cfg:c,parts:P,keys:{},opts:{detail:det,plate:opts.plate,shadow:opts.shadow!==false},phase:opts.phase!=null?opts.phase:Math.random()*100,meshes:{}};
 PARTS.forEach(function(p){var m=new T.Mesh(new T.BufferGeometry(),mat);m.name=p;m.castShadow=opts.shadow!==false;m.receiveShadow=false;hold[p].add(m);root.userData.meshes[p]=m;P[p]=m;});
 root.userData.keys={};update(root,c,true);return root;}
function update(g,cfg,force){var u=g.userData;if(!u||!u.tgAvatar)return g;var c=renderMap(normBase(cfg));c._pose=u.pose||'stand';
 PARTS.forEach(function(p){var k=partKey(p,c),m=u.meshes[p];if(!force&&u.keys[p]===k)return;
  if(m.geometry.userData.tgAvatarKey)release(m.geometry);else m.geometry.dispose();
  if(k===''){m.geometry=new T.BufferGeometry();m.visible=false;}else{m.geometry=acquire(p,c,u.opts.detail);m.visible=true;}u.keys[p]=k;});
 var pk=c.name+'|'+c.title+'|'+c.plate;if(force||u.plateKey!==pk){setPlate(g,c);u.plateKey=pk;}
delete c._pose;u.cfg=c;u.long=!!find(OPT.outfit,c.outfit).long;u.wide=find(OPT.outfit,c.outfit).sleeve==='wide';layout(g,c);return g;}
function dispose(g){var u=g&&g.userData;if(!u||!u.tgAvatar)return;PARTS.forEach(function(p){var m=u.meshes[p];if(m.geometry.userData.tgAvatarKey)release(m.geometry);else m.geometry.dispose();m.geometry=new T.BufferGeometry();});
 if(u.parts.plate){plateRelease(u.parts.plate.material.map);u.parts.plate.material.dispose();g.remove(u.parts.plate);u.parts.plate=null;}if(g.parent)g.parent.remove(g);u.tgAvatar=false;}

/* ---------------- 姿势：stand / ride（跨骑）/ sit（坐凳） ---------------- */
var POSE_ALIAS={stand:'stand',idle:'stand',none:'stand',ride:'ride',straddle:'ride',sit:'sit',bench:'sit'};
function setPose(g,pose,opts){var u=g&&g.userData;if(!u||!u.tgAvatar)return false;opts=opts||{};
 var p=POSE_ALIAS[pose==null?'stand':pose]||(opts.style?POSE_ALIAS[opts.style]:null)||'stand';
 if(p==='ride'){ // 按马背半宽算两腿张开角（与 mounts.js 通用骑姿同公式，再加袍摆厚度）
  var seat=g.parent&&g.parent.userData,rx=opts.bodyRx!=null?opts.bodyRx:(seat&&seat.bodyRx!=null?seat.bodyRx:.32),k=u.cfg.height/100,w=find(OPT.build,u.cfg.build).w;
  var hipX=.088*w*k,legLen=.86*k,pad=find(OPT.outfit,u.cfg.outfit).long?.1*k:.04*k,need=(rx+pad-hipX)/legLen;u.poseSpl=Math.asin(Math.max(.12,Math.min(.95,need)))+.06;}
 if(u.pose!==p){u.pose=p;update(g,u.cfg,false);}
 poseLimbs(u,null);return true;}
function getPose(g){return g&&g.userData&&g.userData.pose||'stand';}
function poseLimbs(u,state){var P=u.parts;if(u.pose==='stand')return;
 if(u.pose==='ride'){P.legL.rotation.set(-.3,0,u.poseSpl);P.legR.rotation.set(-.3,0,-u.poseSpl);}
 else{P.legL.rotation.set(-.5,0,.06);P.legR.rotation.set(-.5,0,-.06);}
 if(!state||state==='idle'||state==='walk'){var ax=u.pose==='ride'?-.8:-.55,az=u.pose==='ride'?.15:.1;P.armLJ.rotation.set(ax,0,-az);P.armRJ.rotation.set(ax,0,az);}
 P.rig.position.y=0;P.capeJ.rotation.x=u.pose==='ride'?.25:.05;}

/* ---------------- 动画（纯函数：只由 t 与 phase 决定，零分配） ---------------- */
var STATES=['idle','walk','wave','call','arrange','look','bow','talk'];
function animate(g,state,t){var u=g.userData;if(!u||!u.tgAvatar)return;var P=u.parts,s=(t||0)/1000+u.phase,br=Math.sin(s*2.1);
 var tj=P.torsoJ,hj=P.headJ,al=P.armLJ,ar=P.armRJ,ll=P.legL,lr=P.legR,cj=P.capeJ;
 P.rig.position.set(0,0,0);P.rig.rotation.set(0,0,0);tj.rotation.set(0,0,0);hj.rotation.set(0,0,0);ll.rotation.set(0,0,0);lr.rotation.set(0,0,0);cj.rotation.set(0,0,0);
 var spread=u.wide?.11:.07;al.rotation.set(0,0,spread);ar.rotation.set(0,0,-spread);
 P.torso.scale.set(1+.012*br,1+.006*br,1+.016*br);tj.position.y=.9+.003*br;
 al.rotation.x=.04*Math.sin(s*1.1);ar.rotation.x=.04*Math.sin(s*1.1+1);hj.rotation.y=.12*Math.sin(s*.45);hj.rotation.x=.03*Math.sin(s*.7);
 cj.rotation.x=.02+.015*Math.sin(s*1.3);
 if(state==='walk'){var f=s*7.2,sn=Math.sin(f),A=u.long?.24:.5;ll.rotation.x=A*sn;lr.rotation.x=-A*sn;al.rotation.x=-.42*sn;ar.rotation.x=.42*sn;
  P.rig.position.y=.022*Math.abs(Math.cos(f));tj.rotation.y=.07*sn;hj.rotation.y=-.05*sn;tj.rotation.x=.04;cj.rotation.x=.14+.05*Math.abs(sn);}
 else if(state==='wave'){ar.rotation.z=(u.wide?-2.15:-2.55)+.28*Math.sin(s*9);ar.rotation.x=-.25;hj.rotation.z=.05;hj.rotation.y=-.12;tj.rotation.z=.03;}
 else if(state==='call'){ar.rotation.x=-1.25;ar.rotation.z=.55;ar.rotation.y=.3;hj.rotation.x=-.12+.04*Math.sin(s*6);tj.rotation.x=-.03;al.rotation.z=.25;}
 else if(state==='arrange'){var k=Math.sin(s*2.4);tj.rotation.x=.16;hj.rotation.x=.3;al.rotation.x=-.85+.18*k;ar.rotation.x=-.8-.18*k;al.rotation.z=-.15;ar.rotation.z=.15+.05*k;}
 else if(state==='look'){hj.rotation.y=.62*Math.sin(s*.9);tj.rotation.y=.12*Math.sin(s*.9);}
 else if(state==='bow'){var b2=.5-.5*Math.cos(Math.min(1,(s%3)/1.2)*Math.PI);tj.rotation.x=.38*b2;al.rotation.x=ar.rotation.x=-1.15;al.rotation.z=-.42;ar.rotation.z=.42;hj.rotation.x=.12*b2;}
 else if(state==='talk'){ar.rotation.x=-.55+.12*Math.sin(s*5);ar.rotation.z=.08;hj.rotation.x=.05*Math.sin(s*4.3);hj.rotation.y=.08*Math.sin(s*2.1);}
 if(u.pose&&u.pose!=='stand'){if(state==='walk'){tj.rotation.set(0,0,0);hj.rotation.y=.12*Math.sin(s*.45);}poseLimbs(u,state);}
}
function stats(g){var tris=0,calls=0;g.traverse(function(o){if((o.isMesh||o.isSprite)&&o.visible){calls++;if(o.isMesh&&o.geometry.index)tris+=o.geometry.index.count/3;if(o.isSprite)tris+=2;}});return {triangles:tris,drawCalls:calls};}

/* ---------------- 定制面板 ---------------- */
/* r8：通用外观（按钮、标签页、选择片、输入框、提示）来自 ui-kit.js 的 .tg-* 与 --tg-* 变量；这里只放捏脸面板的排版。
 * 旧类名 .tgav-* 全部保留（r7g/r7b-ux 按它们定位）。竖屏：上预览下抽屉；横屏矮屏：左预览右面板；宽屏：居中卡片。 */
var CSS='.tgav-root{position:fixed;inset:0;z-index:9990;display:flex;justify-content:center;align-items:flex-end;background:var(--tg-scrim,rgba(28,18,10,.48));font-family:var(--tg-font,sans-serif);color:var(--tg-ink,#3b2a1e);-webkit-tap-highlight-color:transparent}'
+'.tgav-root *{box-sizing:border-box}.tgav-wrap{position:relative;width:100%;max-width:520px;height:100%;display:flex;flex-direction:column;padding:0 env(safe-area-inset-right,0px) 0 env(safe-area-inset-left,0px)}'
+'.tgav-stage{position:relative;flex:1 1 40%;min-height:200px;background:radial-gradient(ellipse at 50% 85%,#fff3d6 0%,#f0d8a8 38%,#b9874e 100%);overflow:hidden;touch-action:none}'
+'.tgav-stage canvas{position:absolute;inset:0;width:100%;height:100%;display:block}'
+'.tgav-hint{position:absolute;left:50%;bottom:28px;transform:translateX(-50%);font-size:var(--tg-fs-1,14px);color:var(--tg-ink-2,#634a37);background:rgba(255,250,240,.82);padding:4px 12px;border-radius:999px;pointer-events:none;white-space:nowrap}'
+'.tgav-top{position:absolute;top:calc(env(safe-area-inset-top,0px) + 8px);right:8px;left:8px;display:flex;justify-content:space-between;gap:8px;z-index:2}'
+'.tgav-ibtn{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-width:44px;min-height:44px;padding:0 12px;border-radius:999px;border:1px solid rgba(201,171,114,.9);background:rgba(255,253,248,.92);color:var(--tg-ink,#3b2a1e);font-size:var(--tg-fs-1,14px);font-weight:600;box-shadow:var(--tg-sh-1);cursor:pointer}'
+'.tgav-ibtn.tgav-x{width:44px;padding:0}'
+'.tgav-sheet{flex:0 0 auto;height:58%;max-height:560px;display:flex;flex-direction:column;background:var(--tg-paper,#fbf6ec);border-radius:var(--tg-r-3,16px) var(--tg-r-3,16px) 0 0;box-shadow:var(--tg-sh-3);margin-top:-16px;position:relative;z-index:3;padding-bottom:env(safe-area-inset-bottom,0px)}'
+'.tgav-head{display:flex;align-items:center;justify-content:center;min-height:48px;padding:4px 16px 0;font-family:var(--tg-font-title,serif);font-size:var(--tg-fs-3,18px);font-weight:600;color:var(--tg-ink,#3b2a1e)}'
+'.tgav-tabs{margin:4px 12px 0!important}'
+'.tgav-tab{min-width:0!important;padding:0 4px!important}'
+'.tgav-body{flex:1;min-height:0;overflow-y:auto;overscroll-behavior:contain;padding:8px 16px 12px;-webkit-overflow-scrolling:touch}'
+'.tgav-sec{margin:8px 0 16px}.tgav-lab{font-size:var(--tg-fs-1,14px);font-weight:600;color:var(--tg-ink-2,#634a37);margin:0 0 8px}'
+'.tgav-row{display:flex;flex-wrap:wrap;gap:8px}'
+'.tgav-chip.tgav-locked{color:var(--tg-ink-3,#7d624d);background:var(--tg-paper-2,#f3e9d5);border-style:dashed;box-shadow:none}'
+'.tgav-lock{display:inline-flex;color:var(--tg-ink-3,#7d624d)}'
+'.tgav-hint2{position:absolute;left:50%;top:-52px;transform:translateX(-50%);padding:8px 16px;border-radius:12px;background:rgba(45,30,20,.92);color:#fff8ec;font-size:14px;opacity:0;transition:opacity .2s;pointer-events:none;z-index:5;max-width:90%}.tgav-hint2.on{opacity:1}'
+'.tgav-note{width:100%;font-size:var(--tg-fs-1,14px);color:var(--tg-ink-2,#634a37);padding:4px 0}'
+'.tgav-sw{width:44px;height:44px;border-radius:50%;border:3px solid var(--tg-card,#fffdf8);box-shadow:0 0 0 1px var(--tg-line-2,#c9ab72);cursor:pointer;padding:0}'
+'.tgav-sw[aria-pressed=true]{box-shadow:0 0 0 2px var(--tg-card,#fffdf8),0 0 0 4px var(--tg-accent,#9b3a2a)}'
+'.tgav-range{width:100%;height:44px;accent-color:var(--tg-accent,#9b3a2a)}'
+'.tgav-foot{display:flex;gap:12px;padding:12px 16px;border-top:1px solid var(--tg-line,#e5d6ba)}'
+'@media (min-width:700px) and (min-height:600px){.tgav-root{align-items:center}.tgav-wrap{height:min(860px,92%);border-radius:var(--tg-r-3,16px);overflow:hidden;box-shadow:var(--tg-sh-3);padding:0}.tgav-sheet{border-radius:var(--tg-r-3,16px) var(--tg-r-3,16px) 0 0;padding-bottom:0}}'
+'@media (orientation:landscape) and (max-height:560px){.tgav-root{align-items:stretch}.tgav-wrap{flex-direction:row;max-width:980px;height:100%}.tgav-stage{flex:0 0 42%;min-height:0}'
+'.tgav-top{top:calc(env(safe-area-inset-top,0px) + 8px);right:24px}.tgav-sheet{flex:1 1 auto;height:auto;max-height:none;margin:0 0 0 -16px;border-radius:var(--tg-r-3,16px) 0 0 var(--tg-r-3,16px);padding-bottom:env(safe-area-inset-bottom,0px)}'
+'.tgav-head{display:none}.tgav-tabs{margin-top:8px!important}.tgav-body{padding:4px 16px 8px}.tgav-sec{margin:4px 0 12px}.tgav-foot{padding:8px 16px}.tgav-hint2{top:8px}}'
+'.tgav-fallback .tg-btn,.tgav-fallback .tg-chip,.tgav-fallback .tg-tab{min-height:44px;min-width:44px;font-size:16px}.tgav-fallback .tg-tabs{display:flex}.tgav-fallback .tg-tab{flex:1}.tgav-fallback .tg-input{width:100%;min-height:44px;font-size:16px}';
var panel=null;
function UIicon(n,sz){return window.TG_UI?window.TG_UI.icon(n,sz):'';}
function el(tag,cls,attrs,text){var e=document.createElement(tag);if(cls)e.className=cls;if(attrs)for(var k in attrs)e.setAttribute(k,attrs[k]);if(text!=null)e.textContent=text;return e;}
function openPanel(o){
 o=o||{};closePanel();var cfg=normalize(o.config||DEF());if(window.TG_UI)window.TG_UI.ensure();if(!document.getElementById('tgav-css')){var st=el('style',null,{id:'tgav-css'});st.textContent=CSS;document.head.appendChild(st);}
 var host=o.container||document.body,root=el('div','tgav-root tg-ui'+(window.TG_UI?'':' tgav-fallback'),{role:'dialog','aria-modal':'true','aria-label':'捏脸'}),wrap=el('div','tgav-wrap');root.appendChild(wrap);
 if(o.container&&o.container!==document.body)root.style.position='absolute';
 var stage=el('div','tgav-stage'),cv=el('canvas');stage.appendChild(cv);stage.appendChild(el('div','tgav-hint',null,'左右拖动可转身'));
 var top=el('div','tgav-top'),bClose=el('button','tgav-ibtn tgav-x',{type:'button','aria-label':'关闭'}),bRand=el('button','tgav-ibtn',{type:'button','aria-label':'随机外观'});bClose.innerHTML=UIicon('close',22)||'×';bRand.innerHTML=UIicon('shuffle',18);bRand.appendChild(document.createTextNode('随机'));top.appendChild(bRand);top.appendChild(bClose);stage.appendChild(top);wrap.appendChild(stage);
 var sheet=el('div','tgav-sheet');sheet.appendChild(el('div','tgav-grip'));sheet.appendChild(el('div','tgav-head',null,o.title||'捏脸'));
 var tabs=el('div','tgav-tabs tg-tabs',{role:'tablist'}),body=el('div','tgav-body'),foot=el('div','tgav-foot');sheet.appendChild(tabs);sheet.appendChild(body);
 var bCancel=el('button','tgav-btn tg-btn tg-btn--block',{type:'button'},'取消'),bSave=el('button','tgav-btn tgav-ok tg-btn tg-btn--primary tg-btn--block',{type:'button'},'保存');foot.appendChild(bCancel);foot.appendChild(bSave);sheet.appendChild(foot);wrap.appendChild(sheet);host.appendChild(root);var layer=window.TG_UI?window.TG_UI.openLayer(root,{onClose:function(){var cb=o.onCancel;closePanel();if(cb)cb();}}):null;
 // 预览渲染器
 var R=new T.WebGLRenderer({canvas:cv,antialias:true,alpha:true,preserveDrawingBuffer:!!o.preserveDrawingBuffer});R.setPixelRatio(Math.min(2,window.devicePixelRatio||1));R.outputColorSpace=T.SRGBColorSpace;R.toneMapping=T.ACESFilmicToneMapping;R.toneMappingExposure=1.05;
 var sc=new T.Scene(),cam=new T.PerspectiveCamera(30,1,.1,30);sc.add(new T.HemisphereLight('#fff3dc','#8a6a48',1.7));var key=new T.DirectionalLight('#ffe2b8',2.4);key.position.set(2.5,4,3.5);sc.add(key);var rim=new T.DirectionalLight('#bcd4ff',1.1);rim.position.set(-3,2.5,-3);sc.add(rim);
 var disc=new T.Mesh(new T.CylinderGeometry(.62,.68,.06,40),new T.MeshStandardMaterial({color:'#b98a52',roughness:.9}));disc.position.y=-.03;sc.add(disc);
 var ring=new T.Mesh(new T.TorusGeometry(.64,.012,6,48),new T.MeshStandardMaterial({color:'#e2b95c',roughness:.4,metalness:.5}));ring.rotation.x=Math.PI/2;ring.position.y=.001;sc.add(ring);
 var av=build(cfg,{phase:0});sc.add(av);var yaw=-.35,drag=null,raf=0,t0=performance.now(),tab=o.tab||'body';
 function size(){var r=stage.getBoundingClientRect(),w=Math.max(1,r.width),h=Math.max(1,r.height-18);R.setSize(w,Math.max(1,r.height),false);cam.aspect=w/Math.max(1,r.height);cam.setViewOffset(w,r.height,0,9,w,r.height);
  var top=cfg.height/100*((cfg.name||cfg.title)?2.36:1.95),bot=-.08,span=top-bot,fov=cam.fov*Math.PI/180,dv=span/2/Math.tan(fov/2),dh=.75/2/Math.tan(fov/2)/cam.aspect,d=Math.max(dv,dh)*1.1;
  cam.position.set(0,(top+bot)/2+.25,d);cam.lookAt(0,(top+bot)/2,0);cam.updateProjectionMatrix();}
 function loop(){raf=requestAnimationFrame(loop);av.rotation.y=yaw;animate(av,'idle',performance.now()-t0);R.render(sc,cam);}
 stage.addEventListener('pointerdown',function(e){if(e.target!==cv&&e.target!==stage)return;drag={x:e.clientX,y:yaw};stage.setPointerCapture&&stage.setPointerCapture(e.pointerId);});
 stage.addEventListener('pointermove',function(e){if(drag)yaw=drag.y+(e.clientX-drag.x)*.012;});stage.addEventListener('pointerup',function(){drag=null;});stage.addEventListener('pointercancel',function(){drag=null;});
 function changed(){update(av,cfg);size();if(o.onChange)try{o.onChange(normalize(cfg));}catch(e){console.warn(e);}}
 function section(lab){var s=el('div','tgav-sec');s.appendChild(el('div','tgav-lab',null,lab));var r=el('div','tgav-row');s.appendChild(r);body.appendChild(s);return r;}
 function chips(lab,list,get,set,filter,slot){var r=section(lab);list.forEach(function(it){if(it.hide)return;if(filter&&!filter(it))return;var lk=slot?lockInfo(slot,it.id):null;
  var b=el('button','tgav-chip tg-chip'+(lk?' tgav-locked':''),{type:'button','aria-pressed':String(!lk&&get()===it.id),'data-id':it.id,'aria-disabled':String(!!lk)},it.name);
  if(lk){var bd=el('span','tgav-lock',{'aria-hidden':'true'});bd.innerHTML=UIicon('lock',16)||'🔒';b.appendChild(bd);b.setAttribute('aria-label',it.name+'（未拥有'+(lk.price?'，'+lk.price+' 善缘':'')+'）');b.onclick=function(){hint('还没有「'+it.name+'」'+(lk.price?'，可在善缘阁用 '+lk.price+' 善缘兑换':'，可在商铺兑换'));};}
  else b.onclick=function(){set(it.id);changed();render();};r.appendChild(b);});}
 var hintEl=el('div','tgav-hint2',{role:'status','aria-live':'polite'}),hintT=0;sheet.appendChild(hintEl);
 function hint(t){if(window.TG_UI){window.TG_UI.toast(t);return;}hintEl.textContent=t;hintEl.classList.add('on');clearTimeout(hintT);hintT=setTimeout(function(){hintEl.classList.remove('on');},1600);}
 function dropLocked(){var ch=false;SLOTS.forEach(function(sl){if(lockInfo(sl,cfg.acc[sl])){cfg.acc[sl]='none';ch=true;}});var ts=ownedTitles();if(ts&&netReady(NET())&&cfg.title&&!ts.some(function(t){return t.name===cfg.title;})){cfg.title='';ch=true;}return ch;}
 function swatches(lab,list,get,set){var r=section(lab);list.forEach(function(cl){var b=el('button','tgav-sw',{type:'button','aria-label':cl,'aria-pressed':String(get()===cl)});b.style.background=cl;b.onclick=function(){set(cl);changed();render();};r.appendChild(b);});}
 var TABS=[['body','体型'],['face','面容'],['hair','发型'],['outfit','服饰'],['acc','配饰'],['plate','名牌']];
 function render(){tabs.textContent='';TABS.forEach(function(tb){var b=el('button','tgav-tab tg-tab',{type:'button',role:'tab','aria-selected':String(tab===tb[0])},tb[1]);b.onclick=function(){tab=tb[0];render();body.scrollTop=0;};tabs.appendChild(b);});
  body.textContent='';
  if(tab==='body'){var r=section('身高 '+cfg.height+'%');var rg=el('input','tgav-range',{type:'range',min:90,max:110,step:1,value:cfg.height,'aria-label':'身高'});rg.oninput=function(){cfg.height=+rg.value;r.previousSibling.textContent='身高 '+cfg.height+'%';changed();};r.appendChild(rg);
   chips('体格',OPT.build,function(){return cfg.build;},function(v){cfg.build=v;});swatches('肤色',PAL.skin,function(){return cfg.skin;},function(v){cfg.skin=v;});}
  if(tab==='face'){chips('脸型',OPT.face,function(){return cfg.face;},function(v){cfg.face=v;});swatches('肤色',PAL.skin,function(){return cfg.skin;},function(v){cfg.skin=v;});}
  if(tab==='hair'){chips('发型',OPT.hair,function(){return cfg.hair;},function(v){cfg.hair=v;cfg=normalize(cfg);});swatches('发色',PAL.hair,function(){return cfg.hairColor;},function(v){cfg.hairColor=v;});
   swatches('发饰色（发带/发冠）',PAL.trim,function(){return cfg.trim;},function(v){cfg.trim=v;});}
  if(tab==='outfit'){chips('款式',OPT.outfit,function(){return cfg.outfit;},function(v){cfg.outfit=v;});swatches('主色',PAL.cloth,function(){return cfg.color1;},function(v){cfg.color1=v;});
   swatches('辅色（腰带/裙）',PAL.cloth,function(){return cfg.color2;},function(v){cfg.color2=v;});swatches('绣边',PAL.trim,function(){return cfg.trim;},function(v){cfg.trim=v;});}
  if(tab==='acc'){chips('头饰',OPT.head,function(){return cfg.acc.head;},function(v){cfg.acc.head=v;cfg=normalize(cfg);},function(it){return cfg.hair!=='bald'||(it.id!=='hairpin'&&it.id!=='crown');},'head');
   chips('颈饰',OPT.neck,function(){return cfg.acc.neck;},function(v){cfg.acc.neck=v;},null,'neck');chips('腰饰',OPT.waist,function(){return cfg.acc.waist;},function(v){cfg.acc.waist=v;},null,'waist');
   chips('手持',OPT.hand,function(){return cfg.acc.hand;},function(v){cfg.acc.hand=v;},function(it){return !it.npc;},'hand');chips('背饰',OPT.back,function(){return cfg.acc.back;},function(v){cfg.acc.back=v;},null,'back');
   if(cfg.acc.back==='cape')swatches('云肩色',PAL.cloth,function(){return cfg.capeColor;},function(v){cfg.capeColor=v;});}
  if(tab==='plate'){var r2=section('名字（最多 12 个字）');var inN=el('input','tgav-in tg-input',{type:'text',maxlength:12,placeholder:'给自己起个名字',value:cfg.name,'aria-label':'名字'});inN.oninput=function(){cfg.name=inN.value;cfg=normalize(cfg);changed();};r2.appendChild(inN);
   var ts=ownedTitles(),tl=[{id:'',name:'无'}];(ts||[]).forEach(function(t){tl.push({id:t.name,name:t.name});});
   if(!ts&&cfg.title)tl.push({id:cfg.title,name:cfg.title});
   chips('称号（只列出已拥有的）',tl,function(){return cfg.title;},function(v){cfg.title=v;});
   if(tl.length<2)body.lastChild.appendChild(el('div','tgav-note',null,'还没有称号，可以在善缘阁兑换。'));
   chips('名牌样式',OPT.plate,function(){return cfg.plate;},function(v){cfg.plate=v;});}
 }
 bRand.onclick=function(){var keep={name:cfg.name,title:cfg.title};cfg=randomConfig(Math.random()*1e9|0);cfg.name=keep.name;cfg.title=keep.title;changed();render();};
 bClose.onclick=bCancel.onclick=function(){var cb=o.onCancel;closePanel();if(cb)cb();};
 bSave.onclick=function(){var c=normalize(cfg),cb=o.onSave;closePanel();if(cb)cb(c,serialize(c));};
 var ro=window.ResizeObserver?new ResizeObserver(size):null;if(ro)ro.observe(stage);else window.addEventListener('resize',size);
 if(dropLocked()){update(av,cfg);if(o.onChange)try{o.onChange(normalize(cfg));}catch(e){}}
 var onNet=function(){render();};window.addEventListener('tg-avatar',onNet);
 render();size();loop();
 panel={root:root,R:R,av:av,sc:sc,layer:layer,stop:function(){if(layer)layer.remove();cancelAnimationFrame(raf);window.removeEventListener('tg-avatar',onNet);clearTimeout(hintT);if(ro)ro.disconnect();else window.removeEventListener('resize',size);},get config(){return normalize(cfg);},setTab:function(t){tab=t;render();},render:function(){R.render(sc,cam);}};
 return panel;}
function closePanel(){if(!panel)return;var p=panel;panel=null;p.stop();dispose(p.av);p.sc.traverse(function(o){if(o.isMesh&&!o.material.vertexColors){o.geometry.dispose();o.material.dispose();}});p.R.dispose();if(p.R.forceContextLoss)p.R.forceContextLoss();if(p.root.parentNode)p.root.parentNode.removeChild(p.root);}

window.TG_AVATAR={__v:1,options:OPT,palette:PAL,states:STATES,slots:SLOTS,
 defaultConfig:DEF,randomConfig:randomConfig,normalize:normalize,locked:lockInfo,ownedTitles:ownedTitles,freeParts:FREE,validate:validate,serialize:serialize,deserialize:deserialize,
 build:build,update:function(g,c){return update(g,c,false);},animate:animate,setPose:setPose,getPose:getPose,poses:['stand','ride','sit'],dispose:dispose,stats:stats,
 openPanel:openPanel,closePanel:closePanel,get panel(){return panel;},
 material:material,setMaterialFactory:function(fn){matFactory=fn;MAT=null;},
 cacheInfo:function(){return {geometries:GC.size,plates:PC.size};}};
})();
