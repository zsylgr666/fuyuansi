/* animals2.js — 福缘里 · 心田小院：新动物低多边形模型（独立模块，未接入 pack.mjs）
 * window.TG_ANIMALS2 = { build(kind) => THREE.Group, kinds:[...], anim(group, t, state), info }
 * 风格对齐 r3.js r3AnimalModel / world3d.js worldMesh：
 *   MeshLambertMaterial + flatShading，ball=Sphere(1,10,7)、cone=Cone(1,1,8)、cylinder=Cylinder(1,1,1,12)、box
 *   同一色板（#f6e5c4 米白 / #514233 深褐 / #e7aa9f 粉 / #d8ac57 金 / #c99860 黄褐 / #ca6a52 朱红）
 *   地面 y=0，头朝 +Z，体型与鸡（≈0.9 高）、牛（≈1.3 高）同一比例尺。
 * 结构：group(调用方拥有 position / rotation.y) → userData.rig(动画拥有) → 各部件。
 * t 单位毫秒（与 tgAnimate / r3UpdateAnimalMatrices 的 ts 相同）；state: 'idle' | 'walk' | 'rest'。
 */
(function(){
'use strict';
var G=typeof window!=='undefined'?window:globalThis;
if(G.TG_ANIMALS2&&G.TG_ANIMALS2.__v)return;           // 幂等加载
var T=(typeof THREE!=='undefined')?THREE:G.THREE;
if(!T){console.warn('[animals2] THREE 未加载，跳过');return;}

var C={cream:'#f6e5c4',dark:'#514233',pink:'#e7aa9f',gold:'#d8ac57',tan:'#c99860',red:'#ca6a52',
  white:'#f3efe4',grey:'#b9b3a6',orange:'#e0913e',green:'#5f8a5f',teal:'#4f7a6a',chestnut:'#a8724a',
  mane:'#5a3e2b',wood:'#a7774a',woodDark:'#7a5434',stone:'#a9a493',stoneDark:'#8c8778',leaf:'#7fa565',
  bee:'#e8b83a',koi:'#e7743e',koiW:'#f4eee2'};

// ---- 共享材质 / 几何（若游戏内 W3 存在则直接复用它的缓存）----
var OWN={mat:{},geo:{}};
function W(){return G.W3&&G.W3.materials&&G.W3.geometries?G.W3:null;}
function mat(color){
  var w=W(); if(w&&typeof G.worldMat==='function')return G.worldMat(color);
  var k=color; return OWN.mat[k]||(OWN.mat[k]=new T.MeshLambertMaterial({color:color,flatShading:true}));
}
function geo(type){
  var w=W(),cache=w?w.geometries:OWN.geo;
  return cache[type]||(cache[type]=type==='ball'?new T.SphereGeometry(1,10,7):type==='cone'?new T.ConeGeometry(1,1,8)
    :type==='cylinder'?new T.CylinderGeometry(1,1,1,12):new T.BoxGeometry(1,1,1));
}
function extraGeo(key,make){return OWN.geo[key]||(OWN.geo[key]=make());}
var waterMat=null,padMat=null;
function getWaterMat(){return waterMat||(waterMat=new T.MeshLambertMaterial({color:'#7fb6b8',transparent:true,opacity:.82,flatShading:true}));}
function m(parent,type,color,x,y,z,sx,sy,sz){
  var o=new T.Mesh(geo(type),mat(color));o.position.set(x,y,z);o.scale.set(sx,sy,sz);
  o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;
}
function grp(parent,x,y,z,name){var g=new T.Group();g.position.set(x||0,y||0,z||0);if(name)g.name=name;parent.add(g);return g;}
// 腿：髋部枢轴（可摆动）+ 向下的圆柱
function leg(parent,x,hipY,z,r,len,color,name){
  var p=grp(parent,x,hipY,z,name);m(p,'cylinder',color,0,-len/2,0,r,len,r);return p;
}
function foot(parent,color,len){var f=m(parent,'box',color,0,-len,.05,.09,.025,.13);return f;}

var seq=0;
function base(kind){
  var g=new T.Group();g.name='tg-animal2-'+kind;var rig=grp(g,0,0,0,'rig');
  g.userData={kind:kind,rig:rig,legs:[],phase:(seq++*1.7)%6.283,tgAnimals2:true};return g;
}

// ---------------- 各物种 ----------------
var B={};
B.duck=function(){
  var g=base('duck'),u=g.userData,r=u.rig;
  var body=grp(r,0,.32,0,'body');u.body=body;
  m(body,'ball',C.white,0,0,0,.26,.21,.36);
  m(body,'ball',C.tan,0,.03,-.05,.2,.12,.26);                    // 背羽
  var tail=m(body,'cone',C.white,0,.08,-.37,.09,.18,.06);tail.rotation.x=-1.2;
  u.wings=[-1,1].map(function(s){var w=grp(body,s*.22,.04,-.02,'wing');var f=m(w,'ball',C.grey,0,0,0,.06,.13,.22);f.rotation.x=.15;return w;});
  var head=grp(r,0,.58,.25,'head');u.head=head;
  m(r,'cylinder',C.white,0,.47,.2,.08,.2,.08);                    // 颈
  m(head,'ball',C.teal,0,0,0,.15,.15,.16);
  m(head,'box',C.orange,0,-.035,.18,.12,.04,.14);                  // 扁嘴
  for(var s=-1;s<=1;s+=2)m(head,'ball',C.dark,s*.1,.04,.09,.022,.03,.022);
  for(var s2=-1;s2<=1;s2+=2){var l=leg(r,s2*.1,.16,0,.025,.16,C.orange,'leg');foot(l,C.orange,.16);u.legs.push(l);}
  return g;
};
B.goose=function(){
  var g=base('goose'),u=g.userData,r=u.rig;
  var body=grp(r,0,.42,-.04,'body');u.body=body;
  m(body,'ball',C.white,0,0,0,.32,.27,.46);
  var tail=m(body,'cone',C.white,0,.1,-.47,.11,.22,.07);tail.rotation.x=-1.2;
  u.wings=[-1,1].map(function(s){var w=grp(body,s*.27,.06,-.04,'wing');m(w,'ball',C.grey,0,0,0,.07,.17,.32);return w;});
  var neck=grp(r,0,.55,.3,'neck');u.neck=neck;                      // 长颈枢轴
  var n1=m(neck,'cylinder',C.white,0,.2,.03,.075,.42,.075);n1.rotation.x=.12;
  var head=grp(neck,0,.43,.08,'head');u.head=head;
  m(head,'ball',C.white,0,0,0,.13,.12,.15);
  var bill=m(head,'cone',C.orange,0,-.02,.2,.06,.17,.06);bill.rotation.x=Math.PI/2;
  m(head,'ball',C.orange,0,.05,.12,.04,.04,.04);                    // 额瘤
  for(var s=-1;s<=1;s+=2)m(head,'ball',C.dark,s*.09,.03,.06,.02,.028,.02);
  for(var s2=-1;s2<=1;s2+=2){var l=leg(r,s2*.12,.22,0,.03,.22,C.orange,'leg');foot(l,C.orange,.22);u.legs.push(l);}
  return g;
};
B.rabbit=function(){
  var g=base('rabbit'),u=g.userData,r=u.rig,col='#e9dfcf';
  var body=grp(r,0,.3,-.04,'body');u.body=body;
  m(body,'ball',col,0,0,0,.24,.23,.32);
  m(body,'ball',C.white,0,-.02,.1,.17,.17,.18);                    // 胸
  u.tail=m(body,'ball',C.white,0,.05,-.32,.09,.09,.09);
  var head=grp(r,0,.52,.22,'head');u.head=head;
  m(head,'ball',col,0,0,0,.17,.16,.17);
  m(head,'ball',C.white,0,-.06,.13,.08,.06,.06);                   // 口鼻
  u.nose=m(head,'ball',C.pink,0,-.03,.18,.025,.02,.02);
  for(var s=-1;s<=1;s+=2)m(head,'ball',C.dark,s*.1,.04,.11,.025,.032,.025);
  u.ears=[-1,1].map(function(s){var e=grp(head,s*.07,.12,-.03,'ear');e.rotation.z=-s*.12;m(e,'ball',col,0,.15,0,.05,.17,.035);m(e,'ball',C.pink,0,.14,.02,.03,.12,.012);return e;});
  // 前爪 + 大后腿
  for(var s2=-1;s2<=1;s2+=2){var f=leg(r,s2*.09,.16,.12,.035,.16,col,'leg');u.legs.push(f);}
  for(var s3=-1;s3<=1;s3+=2){var h=grp(r,s3*.15,.18,-.15,'leg');m(h,'ball',col,0,0,0,.08,.14,.17);m(h,'box',col,0,-.15,.05,.08,.04,.19);u.legs.push(h);}
  return g;
};
B.horse=function(){
  var g=base('horse'),u=g.userData,r=u.rig,col=C.chestnut;
  var body=grp(r,0,1.0,0,'body');u.body=body;
  m(body,'ball',col,0,0,0,.34,.36,.74);
  var neck=grp(r,0,1.12,.55,'neck');u.neck=neck;
  var nk=m(neck,'cylinder',col,0,.28,.1,.15,.6,.19);nk.rotation.x=.55;
  m(neck,'box',C.mane,0,.33,-.02,.06,.58,.12).rotation.x=.55;    // 鬃毛
  var head=grp(neck,0,.56,.28,'head');u.head=head;
  var hd=m(head,'box',col,0,0,.1,.2,.2,.42);hd.rotation.x=.35;
  m(head,'box',C.dark,0,-.1,.3,.17,.12,.12).rotation.x=.35;       // 口鼻
  m(head,'box',C.cream,0,.07,.16,.05,.04,.2).rotation.x=.35;      // 白鼻梁
  for(var s=-1;s<=1;s+=2){m(head,'ball',C.dark,s*.105,.06,.04,.025,.035,.03);m(head,'cone',col,s*.07,.17,-.06,.04,.14,.04);}
  var tail=grp(r,0,1.16,-.7,'tail');u.tail=tail;var tm=m(tail,'cone',C.mane,0,-.3,-.07,.09,.62,.07);tm.rotation.x=-(Math.PI-.2);
  var pos=[[-.2,.42],[.2,.42],[-.2,-.44],[.2,-.44]];
  for(var i=0;i<4;i++){var l=leg(r,pos[i][0],.84,pos[i][1],.075,.84,col,'leg');m(l,'cylinder',C.dark,0,-.81,0,.085,.07,.085);u.legs.push(l);} // 蹄
  return g;
};
B.alpaca=function(){
  var g=base('alpaca'),u=g.userData,r=u.rig,col=C.cream,fl='#efdcbc';
  var body=grp(r,0,.78,-.04,'body');u.body=body;
  m(body,'ball',col,0,0,0,.34,.32,.5);
  for(var k=0;k<5;k++)m(body,'ball',fl,((k%2)?.12:-.12)*(k<4?1:0),.18,-.32+k*.15,.2,.18,.2); // 毛团
  var neck=grp(r,0,.94,.34,'neck');u.neck=neck;
  m(neck,'cylinder',col,0,.3,0,.13,.6,.13);
  m(neck,'ball',fl,0,.2,0,.17,.2,.17);
  var head=grp(neck,0,.64,.04,'head');u.head=head;
  m(head,'ball',fl,0,.04,-.02,.17,.15,.16);                       // 头顶毛
  m(head,'ball',col,0,-.04,.08,.12,.12,.16);
  m(head,'ball',C.tan,0,-.07,.21,.06,.05,.04);
  u.jaw=m(head,'ball',C.tan,0,-.11,.17,.05,.025,.04);
  for(var s=-1;s<=1;s+=2){m(head,'ball',C.dark,s*.085,.0,.15,.022,.03,.022);var e=m(head,'cone',col,s*.08,.18,-.02,.04,.14,.04);e.rotation.z=-s*.15;}
  u.tail=m(r,'ball',fl,0,.86,-.55,.09,.1,.09);
  var pos=[[-.17,.25],[.17,.25],[-.17,-.3],[.17,-.3]];
  for(var i=0;i<4;i++){var l=leg(r,pos[i][0],.56,pos[i][1],.065,.56,col,'leg');m(l,'ball',C.dark,0,-.55,.03,.07,.03,.09);u.legs.push(l);}
  return g;
};
B.beehive=function(){
  var g=base('beehive'),u=g.userData,r=u.rig;
  // 木架
  for(var x=-1;x<=1;x+=2)for(var z=-1;z<=1;z+=2)m(r,'box',C.woodDark,x*.28,.14,z*.22,.07,.28,.07);
  m(r,'box',C.woodDark,0,.3,0,.7,.05,.56);
  var hive=grp(r,0,.33,0,'hive');u.hive=hive;
  m(hive,'box',C.gold,0,.16,0,.56,.3,.46);
  m(hive,'box',C.wood,0,.32,0,.6,.04,.5);
  m(hive,'box',C.gold,0,.46,0,.54,.24,.44);
  m(hive,'box',C.wood,0,.6,0,.6,.04,.5);
  var roof=m(hive,'cone',C.red,0,.74,0,.48,.26,.42);roof.rotation.y=Math.PI/8;   // 小屋顶
  m(hive,'box',C.dark,0,.07,.235,.2,.035,.02);                     // 巢门
  m(hive,'box',C.wood,0,.04,.29,.3,.02,.1);                        // 起落板
  // 一株花
  m(r,'cylinder',C.leaf,.45,.12,.25,.015,.24,.015);m(r,'ball','#e99bb0',.45,.25,.25,.05,.04,.05);
  var swarm=grp(r,0,0,0,'bees');u.bees=[];
  for(var i=0;i<7;i++){var b=grp(swarm,0,0,0,'bee');m(b,'ball',C.bee,0,0,0,.035,.03,.05);m(b,'ball',C.dark,0,0,-.02,.036,.031,.02);
    var wl=m(b,'ball','#f4f6f2',-.03,.025,0,.03,.006,.02),wr=m(b,'ball','#f4f6f2',.03,.025,0,.03,.006,.02);
    b.userData={a:i*0.9,rad:.42+(i%3)*.14,h:.55+(i%4)*.12,sp:.9+(i%5)*.17,wl:wl,wr:wr,active:i<3};u.bees.push(b);}
  return g;
};
B.fishpond=function(){
  var g=base('fishpond'),u=g.userData,r=u.rig,R=.95;
  // 石砌池沿
  var n=14;for(var i=0;i<n;i++){var a=i/n*Math.PI*2,s=m(r,'ball',i%2?C.stone:C.stoneDark,Math.cos(a)*R,.07,Math.sin(a)*R,.2,.11,.16);s.rotation.y=-a;}
  m(r,'cylinder','#6d8f7d',0,.015,0,R*.95,.03,R*.95);              // 池底
  var water=new T.Mesh(extraGeo('pond-water',function(){return new T.CircleGeometry(1,20);}),getWaterMat());
  water.rotation.x=-Math.PI/2;water.position.y=.1;water.scale.setScalar(R*.93);water.receiveShadow=true;water.name='water';r.add(water);u.water=water;
  // 荷叶 + 一朵莲
  var pads=[[.4,.3,.17],[-.35,.45,.13],[.1,-.5,.15]];u.pads=[];
  for(var p=0;p<pads.length;p++){var pd=m(r,'cylinder',C.leaf,pads[p][0],.11,pads[p][1],pads[p][2],.012,pads[p][2]);u.pads.push(pd);}
  m(r,'cone','#f1b8c4',.4,.15,.3,.05,.08,.05);
  // 锦鲤
  u.fish=[];var fc=[[C.koi,C.koiW],[C.koiW,C.koi],[C.gold,C.koiW]];
  for(var f=0;f<3;f++){var fish=grp(r,0,.07,0,'fish');var bd=m(fish,'ball',fc[f][0],0,0,0,.05,.035,.12);m(fish,'ball',fc[f][1],0,.012,.03,.035,.025,.05);
    var tl=grp(fish,0,0,-.11,'tail');m(tl,'cone',fc[f][0],0,0,-.04,.04,.09,.015).rotation.x=Math.PI/2;
    fish.userData={rad:.3+f*.17,sp:(f%2?-1:1)*(.55+f*.12),a:f*2.1,tail:tl};u.fish.push(fish);}
  // 涟漪（每圈独立透明材质，仅 3 个）
  u.ripples=[];var rg=extraGeo('pond-ring',function(){return new T.RingGeometry(.85,1,24);});
  for(var k=0;k<3;k++){var rm=new T.Mesh(rg,new T.MeshBasicMaterial({color:'#eaf4f1',transparent:true,opacity:0,depthWrite:false}));
    rm.rotation.x=-Math.PI/2;rm.position.set(0,.105,0);rm.name='ripple';r.add(rm);rm.userData={off:k/3,x:0,z:0,cyc:-1};u.ripples.push(rm);}
  return g;
};

var INFO={
  duck:   {name:'小鸭',emoji:'🦆',size:[.5,.75,.85], speed:.55},
  goose:  {name:'大白鹅',emoji:'🪿',size:[.65,1.15,1.05],speed:.6},
  rabbit: {name:'小兔',emoji:'🐇',size:[.5,.85,.75],  speed:.8},
  horse:  {name:'小马',emoji:'🐎',size:[.7,2.0,1.9],  speed:1.1},
  alpaca: {name:'羊驼',emoji:'🦙',size:[.7,1.8,1.25], speed:.7},
  beehive:{name:'蜂箱',emoji:'🐝',size:[1.2,1.3,1.2], speed:0,static:true},
  fishpond:{name:'鱼池',emoji:'🐟',size:[2.2,.2,2.2], speed:0,static:true}
};
var KINDS=Object.keys(B);

function build(kind){
  if(!B[kind]){console.warn('[animals2] 未知 kind:',kind);return null;}
  var g=B[kind]();g.userData.info=INFO[kind];return g;
}

// ---------------- 动画 ----------------
function swingLegs(u,w,amp,quad){
  var L=u.legs;for(var i=0;i<L.length;i++){var ph=quad?((i===0||i===3)?0:Math.PI):(i%2?Math.PI:0);L[i].rotation.x=Math.sin(w+ph)*amp;}
}
function rest(u){for(var i=0;i<u.legs.length;i++)u.legs[i].rotation.x=0;}
function anim(group,t,state){
  if(!group||!group.userData||!group.userData.rig)return;
  var u=group.userData,r=u.rig,k=u.kind,ph=u.phase,s=t*.001+ph,walk=state==='walk',lie=state==='rest';
  r.position.set(0,0,0);r.rotation.set(0,0,0);r.scale.set(1,1,1);
  if(k==='duck'||k==='goose'){
    var big=k==='goose',f=walk?(big?7:9):1.2;
    if(walk){swingLegs(u,s*f,.6);r.rotation.z=Math.sin(s*f)*.09;r.position.y=Math.abs(Math.sin(s*f))*.02;}
    else rest(u);
    if(lie){r.position.y=-(big?.16:.12);}
    if(big){u.neck.rotation.x=walk?.25+Math.sin(s*f*2)*.08:Math.sin(s*.8)*.12;u.neck.rotation.y=walk?0:Math.sin(s*.5)*.5;u.head.rotation.x=walk?-.2:0;}
    else{u.head.rotation.x=walk?Math.sin(s*f*2)*.12:Math.max(0,Math.sin(s*.9))*.5;u.head.rotation.y=walk?0:Math.sin(s*.45)*.4;}
    var flap=(!walk&&Math.sin(s*.37)>.93)?Math.sin(s*30)*.5:walk?.05:0;
    u.wings[0].rotation.z=-flap;u.wings[1].rotation.z=flap;
  }else if(k==='rabbit'){
    if(walk){var hp=(s*5.5)%(Math.PI);r.position.y=Math.sin(hp)*.16;r.rotation.x=-Math.cos(hp)*.18;
      u.legs[0].rotation.x=u.legs[1].rotation.x=Math.cos(hp)*.7;u.legs[2].rotation.x=u.legs[3].rotation.x=-Math.cos(hp)*.6;}
    else{rest(u);var hop=Math.sin(s*.6);if(!lie&&hop>.97)r.position.y=(hop-.97)*2;}
    if(lie){r.scale.y=.82;}
    u.nose.scale.y=.02*(1+.4*Math.sin(s*14));
    var tw=walk?-.45:(Math.sin(s*1.3)>.8?Math.sin(s*20)*.2:0);
    u.ears[0].rotation.x=tw+(lie?-.9:0);u.ears[1].rotation.x=(walk?-.45:Math.sin(s*.7)*.12)+(lie?-.9:0);
    u.head.rotation.x=walk?0:Math.sin(s*.9)*.1;u.head.rotation.y=walk?0:Math.sin(s*.4)*.25;
  }else if(k==='horse'||k==='alpaca'){
    var hz=k==='horse',fq=walk?(hz?6:5):0;
    if(walk){swingLegs(u,s*fq,hz?.42:.36,true);r.position.y=Math.abs(Math.sin(s*fq))*.035;}else rest(u);
    if(lie){r.position.y=-(hz?.5:.33);r.rotation.x=.04;rest(u);for(var i=0;i<u.legs.length;i++)u.legs[i].rotation.x=i<2?-1.3:1.3;}
    if(hz){
      var graze=!walk&&!lie&&Math.sin(s*.25)>.3;
      u.neck.rotation.x=walk?Math.sin(s*fq*2)*.07:graze?1.05+Math.sin(s*2)*.05:Math.sin(s*.6)*.08;
      u.head.rotation.x=graze?.2:0;
      u.tail.rotation.z=Math.sin(s*(walk?4:1.6))*(walk?.15:.3);u.tail.rotation.x=walk?-.35:0;
    }else{
      u.neck.rotation.x=walk?.12+Math.sin(s*fq*2)*.05:Math.sin(s*.5)*.08;
      u.neck.rotation.y=walk?0:Math.sin(s*.33)*.35;u.neck.rotation.z=walk?Math.sin(s*fq)*.05:0;
      u.jaw.position.y=-.11+(walk?0:Math.abs(Math.sin(s*5))*-.02);       // 反刍
      u.tail.rotation.x=Math.sin(s*3)*.2;
    }
  }else if(k==='beehive'){
    var act=walk?1:0,n=walk?u.bees.length:3;
    u.hive.position.x=walk?Math.sin(t*.09)*.004:0;
    for(var b=0;b<u.bees.length;b++){var bee=u.bees[b],d=bee.userData,on=b<n;bee.visible=on;if(!on)continue;
      var sp=d.sp*(walk?1.9:1),a=d.a+s*sp,rad=d.rad*(walk?1.25:1)+Math.sin(s*3+b)*.05;
      bee.position.set(Math.cos(a)*rad,d.h+Math.sin(s*(4+b)+b)*(.06+act*.06),Math.sin(a)*rad);
      bee.rotation.y=-a+(sp>0?0:Math.PI);                            // 切向朝前
      var wf=Math.sin(t*.12+b)*.6;d.wl.rotation.z=wf;d.wr.rotation.z=-wf;}
  }else if(k==='fishpond'){
    var fsp=walk?2.1:1;
    for(var q=0;q<u.fish.length;q++){var fi=u.fish[q],fd=fi.userData,fa=fd.a+s*fd.sp*fsp,wob=Math.sin(s*1.3+q)*.06,rr=fd.rad+wob;
      fi.position.x=Math.cos(fa)*rr;fi.position.z=Math.sin(fa)*rr;fi.rotation.y=-fa+(fd.sp>0?0:Math.PI);
      fi.position.y=.07+(walk&&q===0?Math.max(0,Math.sin(s*1.7))*.12:0);
      fd.tail.rotation.y=Math.sin(s*(walk?18:9)+q)*.45;}
    for(var p=0;p<u.pads.length;p++)u.pads[p].position.y=.11+Math.sin(s*1.1+p*2)*.006;
    var period=walk?1.4:2.6;
    for(var j=0;j<u.ripples.length;j++){var rp=u.ripples[j],rd=rp.userData,c=s/period+rd.off,cyc=Math.floor(c),fr=c-cyc;
      if(cyc!==rd.cyc){rd.cyc=cyc;var src=u.fish[(cyc+j)%u.fish.length].position;rd.x=src.x;rd.z=src.z;}
      var sc=.05+fr*(walk?.3:.22);rp.scale.set(sc,sc,sc);rp.position.x=rd.x;rp.position.z=rd.z;rp.material.opacity=(1-fr)*.55;}
  }
}

G.TG_ANIMALS2={__v:1,kinds:KINDS.slice(),info:INFO,build:build,anim:anim,palette:C};
})();
