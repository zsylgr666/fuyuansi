/* realism.js — window.TG_REAL：程序生成的「风格化写实」纹理/材质库 + r170 PBR 灯光/色调/雾预设。
 * 美术参考：王者荣耀家园/农场——暖金主光、暖环境光、柔雾、略饱和带笔触细节，非纯卡通也非照片级。
 * 独立文件，不改任何既有代码；只依赖全局 THREE（r170）。可选 TG_REAL.install() 包装 worldEnter/tgAnimate 自动套用。
 * 性能：所有贴图 CanvasTexture 生成一次后缓存（默认 256px），材质按 (名称+tint+质量+UV模式) 缓存共享；
 *       update(dt) 无分配；upgradeScene 只换 material 引用，可 restoreScene 还原。
 */
(function(){
'use strict';
var G=typeof window!=='undefined'?window:globalThis;
if(G.TG_REAL)return;
function T(){return typeof THREE!=='undefined'?THREE:G.THREE;}

/* ---------------- 工具：可平铺噪声 ---------------- */
function hash(x,y,s){var h=(x*374761393+y*668265263+s*1442695041)|0;h=(h^(h>>>13))*1274126177|0;h=h^(h>>>16);return (h>>>0)/4294967295;}
function vnoise(x,y,P,s){ // 周期 P 的值噪声
 var xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi;
 var u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf);
 var x0=((xi%P)+P)%P,y0=((yi%P)+P)%P,x1=(x0+1)%P,y1=(y0+1)%P;
 var a=hash(x0,y0,s),b=hash(x1,y0,s),c=hash(x0,y1,s),d=hash(x1,y1,s);
 return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v;
}
function fbm(u,v,base,oct,s){var sum=0,amp=.5,tot=0,P=base;for(var o=0;o<oct;o++){sum+=amp*vnoise(u*P,v*P,P,s+o*17);tot+=amp;amp*=.5;P*=2;}return sum/tot;}
function rng(seed){var s=(seed>>>0)||1;return function(){s=(s*16807)%2147483647;return s/2147483647;};}
function hex(c){c=c.replace('#','');return [parseInt(c.substr(0,2),16)/255,parseInt(c.substr(2,2),16)/255,parseInt(c.substr(4,2),16)/255];}
function mix(a,b,t){return [a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}
function cl(x){return x<0?0:x>1?1:x;}
function sstep(a,b,x){var t=cl((x-a)/(b-a));return t*t*(3-2*t);}

/* ---------------- 程序化图案：每个返回 {h,c,r}（高度/颜色/粗糙度，均 0..1） ---------------- */
var GEN={};
// 青瓦：竖向筒瓦（凸）+ 板瓦（凹）交替，逐行搭接，沟里少许青苔
GEN.roofTile=function(S){
 var A=alloc(S),cols=4,rows=6,base=hex('#4f5a5e'),dark=hex('#2f3739'),moss=hex('#5d6e3c'),lite=hex('#7d898a');
 for(var y=0;y<S;y++)for(var x=0;x<S;x++){
  var u=x/S,v=y/S,cu=u*cols,ci=Math.floor(cu),fu=cu-ci,rv=v*rows,ri=Math.floor(rv+((ci%2)?.5:0)),fv=rv+((ci%2)?.5:0)-ri;
  var n=fbm(u,v,8,4,3),cover=fu<.28,h,c,r;
  if(cover){var k=(fu/.28)*2-1;h=.55+.45*Math.sqrt(1-k*k);}else{var k2=((fu-.28)/.72)*2-1;h=.25+.2*k2*k2;}
  var lip=sstep(.0,.85,fv);h=h*.75+lip*.25-(fv>.93?.25:0)+n*.08;
  var tv=hash(ci,ri,9)*.18;c=mix(base,lite,tv+(cover?.12*h:0)+n*.15);c=mix(c,dark,(1-h)*.55+(fv>.9?.3:0));
  var mo=sstep(.55,.8,fbm(u,v,4,3,7))*(cover?.15:.6)*(1-h);c=mix(c,moss,mo);
  r=.62+n*.2-(cover?.08:0);set(A,x+y*S,h,c,r);
 }return A;};
// 朱漆木：饱和朱红、细木纹透底、少量开片与磨损，较光亮
GEN.lacquer=function(S){
 var A=alloc(S),base=hex('#a8261a'),deep=hex('#741410'),hi=hex('#cc4632'),wood=hex('#6b3a22');
 for(var y=0;y<S;y++)for(var x=0;x<S;x++){
  var u=x/S,v=y/S,w=fbm(u,v*.25,4,3,11),g=Math.sin((u*28+w*6)*Math.PI)*.5+.5,n=fbm(u,v,16,3,5);
  var crack=Math.abs(fbm(u,v,6,4,21)-.5)<.012?1:0,wear=sstep(.78,.9,fbm(u,v,3,4,33));
  var h=.6+g*.08+n*.06-crack*.25-wear*.15,c=mix(base,deep,g*.25+n*.2);c=mix(c,hi,sstep(.6,.9,n)*.2);c=mix(c,wood,wear*.6+crack*.5);
  set(A,x+y*S,h,c,.26+n*.12+wear*.4+crack*.3);
 }return A;};
// 木纹：4 块木板，横向年轮纹，暖棕
GEN.wood=function(S){
 var A=alloc(S),a=hex('#a37a4e'),b=hex('#765234'),k=hex('#45301c'),planks=4;
 for(var y=0;y<S;y++)for(var x=0;x<S;x++){
  var u=x/S,v=y/S,pi=Math.floor(v*planks),fv=v*planks-pi,off=hash(pi,1,4);
  var w=fbm(u+off,v,4,3,pi+40),g=Math.sin((v*planks*9+w*5+off*7)*Math.PI*2)*.5+.5,n=fbm(u+off,v,32,2,pi+60);
  var seam=fv<.04||fv>.96,knot=0,kx=hash(pi,2,4),dx=u-kx,dy=(fv-.5)*.25,dd=Math.sqrt(dx*dx+dy*dy);if(dd<.04)knot=1-dd/.04;
  var h=.7+g*.12+n*.06-(seam?.5:0)-knot*.2,c=mix(a,b,g*.55+n*.2+hash(pi,3,4)*.2);c=mix(c,k,(seam?.7:0)+knot*.6);
  set(A,x+y*S,h,c,.55+g*.15+(seam?.2:0));
 }return A;};
// 青石板：错缝不规则石板，石缝下凹带青苔，暖灰青
GEN.bluestone=function(S){
 var A=alloc(S),base=hex('#7f8b8a'),warm=hex('#a39a86'),dark=hex('#4e5856'),moss=hex('#566b34'),rows=4;
 for(var y=0;y<S;y++)for(var x=0;x<S;x++){
  var u=x/S,v=y/S,ri=Math.floor(v*rows),fv=v*rows-ri,cnt=2+(ri%2),uu=(u+hash(ri,0,6))%1,si=Math.floor(uu*cnt),fu=uu*cnt-si;
  var ex=Math.min(fu,1-fu)*S/cnt,ey=Math.min(fv,1-fv)*S/rows,e=Math.min(ex,ey),n=fbm(u,v,8,5,13),sp=fbm(u,v,64,1,14);
  var gw=2.2+fbm(u,v,8,2,15)*2,joint=sstep(gw,gw+3,e),h=joint*(.75+n*.2)+(sp-.5)*.05;
  var tv=hash(ri,si,7),c=mix(base,warm,tv*.5+n*.25);c=mix(c,dark,(1-joint)*.7+(sp>.7?.12:0));
  c=mix(c,moss,(1-joint)*sstep(.45,.65,fbm(u,v,6,3,17))*.45);
  set(A,x+y*S,h,c,.7+(1-joint)*.25-tv*.1);
 }return A;};
// 砖墙：青砖顺砌，灰浆缝内凹
GEN.brick=function(S){
 var A=alloc(S),b1=hex('#6d7574'),b2=hex('#8a8679'),mort=hex('#ada28b'),rows=8,cols=4;
 for(var y=0;y<S;y++)for(var x=0;x<S;x++){
  var u=x/S,v=y/S,ri=Math.floor(v*rows),fv=v*rows-ri,uu=(u+(ri%2)*.5/cols)%1,ci=Math.floor(uu*cols),fu=uu*cols-ci;
  var e=Math.min(Math.min(fu,1-fu)*S/cols,Math.min(fv,1-fv)*S/rows),n=fbm(u,v,16,4,23),m=sstep(1.5,3,e);
  var tv=hash(ri,ci,3),c=mix(b1,b2,tv*.6+n*.3);c=mix(mort,c,m);c=mix(c,hex('#3e4442'),sstep(.7,.95,fbm(u,v,4,3,24))*.25*m);
  set(A,x+y*S,m*(.8+n*.2)+(1-m)*.2*n,c,.82+n*.12);
 }return A;};
// 泥土：暖褐，土块+小卵石
GEN.soil=function(S){
 var A=alloc(S),a=hex('#8a5d36'),b=hex('#5c3a20'),pb=hex('#8f8270');
 for(var i=0;i<S*S;i++){var x=i%S,y=(i/S)|0,u=x/S,v=y/S,n=fbm(u,v,8,5,31),cl2=fbm(u,v,24,2,32);set(A,i,n*.7+cl2*.3,mix(a,b,n*.8+cl2*.2),.9+n*.08);}
 var R=rng(77),N=Math.round(S*S/900);for(var p=0;p<N;p++){var px=R()*S,py=R()*S,rad=1.5+R()*S/90,col=mix(pb,a,R()*.5);stamp(A,S,px,py,rad,function(t){return t;},col,.6);}
 return A;};
// 草地：暖绿色斑块 + 草叶笔触 + 少许黄绿
GEN.grass=function(S){
 var A=alloc(S),a=hex('#6aa036'),b=hex('#3f7428'),y2=hex('#a8b84a'),dirt=hex('#7a5a32');
 for(var i=0;i<S*S;i++){var x=i%S,y=(i/S)|0,u=x/S,v=y/S,n=fbm(u,v,4,4,41),m=fbm(u,v,16,2,42);var c=mix(b,a,n);c=mix(c,y2,sstep(.6,.85,m)*.45);c=mix(c,dirt,sstep(.78,.9,fbm(u,v,6,3,43))*.4);set(A,i,.25+n*.2,c,.85);}
 var R=rng(91),N=Math.round(S*S/7);
 for(var k=0;k<N;k++){var x0=R()*S,y0=R()*S,len=S/40+R()*S/28,ang=-Math.PI/2+(R()-.5)*1.1,bright=R();
  var col=mix(b,mix(a,y2,R()*.5),.4+bright*.6);
  for(var t=0;t<len;t++){var px=(((x0+Math.cos(ang)*t)|0)%S+S)%S,py=(((y0+Math.sin(ang)*t)|0)%S+S)%S,j=px+py*S,hh=.4+.6*(t/len)*(0.6+bright*.4);if(hh>A.h[j]){A.h[j]=hh;var f=.35+.65*t/len;A.c[j*3]=col[0]*f+A.c[j*3]*(1-f);A.c[j*3+1]=col[1]*f+A.c[j*3+1]*(1-f);A.c[j*3+2]=col[2]*f+A.c[j*3+2]*(1-f);A.r[j]=.75;}}
 }return A;};
// 水面：清透青绿，交错正弦波 + fbm 涟漪，焦散亮纹
GEN.water=function(S){
 var A=alloc(S),deep=hex('#1e6e78'),mid=hex('#2f9a92'),hi=hex('#9fe0d0');
 for(var i=0;i<S*S;i++){var x=i%S,y=(i/S)|0,u=x/S,v=y/S,P=Math.PI*2;
  var w=Math.sin(P*(u*3+v*2)+fbm(u,v,4,2,51)*4)*.3+Math.sin(P*(u*-2+v*5)+fbm(u,v,4,2,52)*3)*.25+(fbm(u,v,8,4,53)-.5)*.9;
  var ca=Math.pow(1-Math.abs(fbm(u,v,6,3,54)-.5)*2,8);var c=mix(deep,mid,cl(.5+w*.5));c=mix(c,hi,ca*.35);
  set(A,i,.5+w*.35,c,.05+ca*.05);}
 return A;};
// 白灰墙（额外）：暖白抹灰、轻微斑驳
GEN.plaster=function(S){
 var A=alloc(S),a=hex('#ece2cc'),b=hex('#cfc0a2'),d=hex('#9a8c72');
 for(var i=0;i<S*S;i++){var x=i%S,y=(i/S)|0,u=x/S,v=y/S,n=fbm(u,v,4,5,61),s=fbm(u,v*.3,8,3,62);var c=mix(a,b,n*.6+s*.2);c=mix(c,d,sstep(.75,.9,fbm(u,v,3,4,63))*.35);set(A,i,.5+n*.15,c,.88);}
 return A;};
// 青苔（额外）：给石头/墙根用
GEN.moss=function(S){
 var A=alloc(S),a=hex('#5f8a2c'),b=hex('#35561e'),y2=hex('#9db244');
 for(var i=0;i<S*S;i++){var x=i%S,y=(i/S)|0,u=x/S,v=y/S,n=fbm(u,v,8,5,71),m=fbm(u,v,48,2,72);var c=mix(b,a,n);c=mix(c,y2,sstep(.65,.85,m)*.5);set(A,i,n*.6+m*.4,c,.95);}
 return A;};
var ALIAS={'青瓦':'roofTile','朱漆木':'lacquer','木纹':'wood','青石板':'bluestone','砖墙':'brick','泥土':'soil','草地':'grass','水面':'water','白灰墙':'plaster','青苔':'moss',roof:'roofTile',tile:'roofTile',stone:'bluestone',dirt:'soil'};
var NAMES=['roofTile','lacquer','wood','bluestone','brick','soil','grass','water','plaster','moss'];
// 每种材质的物理参数：法线强度、金属度、默认世界 UV 密度（每米多少次平铺）、透明
var PHYS={roofTile:{ns:1.2,uv:.55},lacquer:{ns:.35,uv:.6,clear:true},wood:{ns:.8,uv:.45},bluestone:{ns:1.1,uv:.36},brick:{ns:1.1,uv:.45},
 soil:{ns:1.3,uv:.4},grass:{ns:.9,uv:.35},water:{ns:.7,uv:.18,water:true},plaster:{ns:.5,uv:.3},moss:{ns:1,uv:.6}};

function alloc(S){return {S:S,h:new Float32Array(S*S),c:new Float32Array(S*S*3),r:new Float32Array(S*S)};}
function set(A,i,h,c,r){A.h[i]=h;A.c[i*3]=c[0];A.c[i*3+1]=c[1];A.c[i*3+2]=c[2];A.r[i]=r;}
function stamp(A,S,cx,cy,rad,prof,col,amt){for(var dy=-Math.ceil(rad);dy<=rad;dy++)for(var dx=-Math.ceil(rad);dx<=rad;dx++){var d=Math.sqrt(dx*dx+dy*dy)/rad;if(d>1)continue;var px=((Math.round(cx+dx))%S+S)%S,py=((Math.round(cy+dy))%S+S)%S,j=px+py*S,t=Math.sqrt(1-d*d);A.h[j]=Math.max(A.h[j],.5+t*amt);var f=Math.min(1,t*1.5);A.c[j*3]=A.c[j*3]*(1-f)+col[0]*f;A.c[j*3+1]=A.c[j*3+1]*(1-f)+col[1]*f;A.c[j*3+2]=A.c[j*3+2]*(1-f)+col[2]*f;A.r[j]=.7;}}

/* ---------------- 贴图生成与缓存 ---------------- */
var TEX={},MATS={},ENV=typeof WeakMap!=='undefined'?new WeakMap():null,SAT=1.12;
var TIME={value:0},WATER_MATS=[],UPGRADED=new Set();
function canvas(S){var c=document.createElement('canvas');c.width=c.height=S;return c;}
function build(name,S){
 var A=GEN[name](S),cc=canvas(S),nc=canvas(S),rc=canvas(S),cx=cc.getContext('2d'),nx=nc.getContext('2d'),rx=rc.getContext('2d');
 var ci=cx.createImageData(S,S),ni=nx.createImageData(S,S),ri=rx.createImageData(S,S),ns=PHYS[name].ns*S/64,sum=[0,0,0];
 for(var y=0;y<S;y++)for(var x=0;x<S;x++){
  var i=x+y*S,p=i*4,r=A.c[i*3],g=A.c[i*3+1],b=A.c[i*3+2],l=(r+g+b)/3;
  r=cl(l+(r-l)*SAT);g=cl(l+(g-l)*SAT);b=cl(l+(b-l)*SAT);// 略饱和的风格化
  ci.data[p]=r*255;ci.data[p+1]=g*255;ci.data[p+2]=b*255;ci.data[p+3]=255;sum[0]+=r;sum[1]+=g;sum[2]+=b;
  var xl=A.h[((x-1+S)%S)+y*S],xr=A.h[((x+1)%S)+y*S],yu=A.h[x+((y-1+S)%S)*S],yd=A.h[x+((y+1)%S)*S];
  var dx=(xr-xl)*ns,dy=(yd-yu)*ns,inv=1/Math.sqrt(dx*dx+dy*dy+1);
  ni.data[p]=(-dx*inv*.5+.5)*255;ni.data[p+1]=(dy*inv*.5+.5)*255;ni.data[p+2]=(inv*.5+.5)*255;ni.data[p+3]=255;
  var rv=cl(A.r[i])*255;ri.data[p]=ri.data[p+1]=ri.data[p+2]=rv;ri.data[p+3]=255;// roughness 读 G 通道
 }
 cx.putImageData(ci,0,0);nx.putImageData(ni,0,0);rx.putImageData(ri,0,0);
 var TH=T(),mk=function(c,srgb){var t=new TH.CanvasTexture(c);t.wrapS=t.wrapT=TH.RepeatWrapping;t.colorSpace=srgb?TH.SRGBColorSpace:TH.NoColorSpace;t.anisotropy=4;t.generateMipmaps=true;return t;};
 var n2=S*S;return {map:mk(cc,true),normal:mk(nc,false),roughness:mk(rc,false),mean:[sum[0]/n2,sum[1]/n2,sum[2]/n2],canvas:{map:cc,normal:nc,roughness:rc}};
}
function resolve(name){name=ALIAS[name]||name;if(!GEN[name])throw new Error('TG_REAL: unknown material '+name);return name;}
function set3(name,size){name=resolve(name);size=size||API.textureSize;var k=name+'@'+size;return TEX[k]||(TEX[k]=build(name,size));}
function texture(name,kind,opts){var s=set3(name,opts&&opts.size);return kind==='normal'?s.normal:kind==='roughness'?s.roughness:kind==='canvas'?s.canvas:kind==='mean'?s.mean:s.map;}

/* 世界空间盒式投影 UV：缩放过的 Box/合并几何也不会拉伸；instancing 兼容。 */
function patchWorldUV(m,density,flow){
 m.userData.tgWorldUV=density;
 var U={tgUVScale:{value:density},tgTime:TIME,tgFlow:{value:new (T().Vector2)(flow?flow[0]:0,flow?flow[1]:0)}};m.userData.tgUniforms=U;
 m.onBeforeCompile=function(sh){
  sh.uniforms.tgUVScale=U.tgUVScale;sh.uniforms.tgTime=U.tgTime;sh.uniforms.tgFlow=U.tgFlow;
  sh.vertexShader='uniform float tgUVScale;uniform float tgTime;uniform vec2 tgFlow;\n'+sh.vertexShader.replace('#include <worldpos_vertex>',
  '#include <worldpos_vertex>\n{mat4 tgM=modelMatrix;\n#ifdef USE_INSTANCING\ntgM=modelMatrix*instanceMatrix;\n#endif\n'+
  'vec3 tgW=(tgM*vec4(transformed,1.0)).xyz;vec3 tgN=abs(normalize(mat3(tgM)*objectNormal));'+
  'vec2 tgUV=tgN.y>max(tgN.x,tgN.z)?tgW.xz:(tgN.x>tgN.z?vec2(tgW.z,-tgW.y):vec2(tgW.x,-tgW.y));tgUV=tgUV*tgUVScale+tgFlow*tgTime;\n'+
  '#ifdef USE_MAP\nvMapUv=tgUV;\n#endif\n#ifdef USE_NORMALMAP\nvNormalMapUv=tgUV*1.0+tgFlow.yx*tgTime*0.7;\n#endif\n#ifdef USE_ROUGHNESSMAP\nvRoughnessMapUv=tgUV;\n#endif\n}');
 };
 m.customProgramCacheKey=function(){return 'tgWorldUV1';};
}

/* material(name,{repeat,tint,tintMix,quality:'high'|'low',worldUV:true|density,side,size,opacity}) */
function material(name,opts){
 opts=opts||{};name=resolve(name);var TH=T(),ph=PHYS[name],q=opts.quality||API.quality,size=opts.size||API.textureSize;
 var rep=opts.repeat==null?null:(typeof opts.repeat==='number'?[opts.repeat,opts.repeat]:opts.repeat);
 var wuv=opts.worldUV===true?ph.uv:(typeof opts.worldUV==='number'?opts.worldUV:0);
 var tint=opts.tint!=null?new TH.Color(opts.tint):null,tm=opts.tintMix==null?.6:opts.tintMix;
 var key=[name,q,size,rep?rep.join('x'):'-',wuv,tint?tint.getHexString()+':'+tm:'-',opts.side||0,opts.opacity||'',opts.key||''].join('|');
 if(MATS[key])return MATS[key];
 var s=set3(name,size),maps={map:s.map,normalMap:s.normal,roughnessMap:s.roughness};
 if(rep&&!wuv){['map','normalMap','roughnessMap'].forEach(function(k){var t=maps[k].clone();t.repeat.set(rep[0],rep[1]);t.needsUpdate=true;maps[k]=t;});}// clone 共享 Source，只多一份 transform
 var color=new TH.Color(1,1,1);
 if(tint){// 让贴图平均色趋近 tint，同时保留纹理细节（保留原场景配色）
  var mean=new TH.Color().setRGB(s.mean[0],s.mean[1],s.mean[2],TH.SRGBColorSpace),f=[tint.r/Math.max(.02,mean.r),tint.g/Math.max(.02,mean.g),tint.b/Math.max(.02,mean.b)];
  var cf=function(v){return Math.min(4,Math.max(.02,v));};color.setRGB(1+(cf(f[0])-1)*tm,1+(cf(f[1])-1)*tm,1+(cf(f[2])-1)*tm);
 }
 var m,p={color:color,map:maps.map,normalMap:maps.normalMap,side:opts.side||TH.FrontSide};
 if(q==='low'){m=new TH.MeshLambertMaterial(p);}// 低档：Lambert 也支持 normalMap（r151+）
 else{p.roughnessMap=maps.roughnessMap;p.roughness=1;p.metalness=0;m=new TH.MeshStandardMaterial(p);if(ph.clear){m.envMapIntensity=1.4;}}
 m.normalScale=new TH.Vector2(1,1);
 if(ph.water){m.transparent=true;m.opacity=opts.opacity||.9;m.depthWrite=false;if(m.isMeshStandardMaterial)m.envMapIntensity=1.6;}
 m.name='tgReal:'+name;m.userData.tgReal=name;
 if(wuv)patchWorldUV(m,wuv,ph.water?[.035,.02]:null);
 if(ph.water)WATER_MATS.push(m);
 return MATS[key]=m;
}

/* ---------------- 场景预设：暖金色调（王者荣耀家园风） ---------------- */
var PRESETS={
 gate:   {bg:'#f3d6a6',fog:['#efd1a0',26,78],hemi:['#ffe8c2','#7a6542',1.55],sun:['#ffc98a',3.1,[-10,14,8]],exposure:1.0,env:.45},
 plaza:  {bg:'#f5dcae',fog:['#f0d7a8',30,85],hemi:['#ffebc8','#7d6a48',1.6],sun:['#ffcd90',3.2,[-9,15,9]],exposure:1.0,env:.45},
 market: {bg:'#f4cf9a',fog:['#eec99a',24,72],hemi:['#ffe3b6','#806040',1.6],sun:['#ffbf78',3.1,[-12,12,6]],exposure:1.02,env:.45},
 yard:   {bg:'#efdcaa',fog:['#e9d9a6',28,80],hemi:['#fff0c8','#6f7442',1.65],sun:['#ffd08e',3.2,[-8,16,9]],exposure:1.0,env:.45},
 lotus:  {bg:'#e3e3c2',fog:['#dbe0c0',18,62],hemi:['#fff0cf','#5f7458',1.5],sun:['#ffd59c',2.9,[-8,14,10]],exposure:1.0,env:.5},
 hall:   {bg:'#2f231b',fog:['#3a2a1f',14,36],hemi:['#ffd9a6','#3a281b',1.25],sun:['#ffbe78',1.5,[-4,12,6]],exposure:1.15,env:.35,indoor:true},
 zen:    {bg:'#2e2a23',fog:['#38322a',14,36],hemi:['#fbe6c4','#3b342a',1.2],sun:['#ffd6a0',1.3,[-4,12,6]],exposure:1.12,env:.35,indoor:true},
 study:  {bg:'#33271e',fog:['#3d2e22',14,36],hemi:['#ffdcaa','#3d2b1d',1.25],sun:['#ffc684',1.4,[-4,12,6]],exposure:1.15,env:.35,indoor:true},
 teahouse:{bg:'#f0d3a2',fog:['#ecd0a0',22,70],hemi:['#ffe9c4','#6f6a42',1.6],sun:['#ffc584',3.0,[-11,12,7]],exposure:1.02,env:.45}
};
PRESETS.tea=PRESETS.teahouse;// 游戏里茶会小院的场景 id 是 'tea'
function envFor(renderer,p){
 if(!ENV||!renderer)return null;var e=ENV.get(renderer);if(e)return e;var TH=T();
 try{var pm=new TH.PMREMGenerator(renderer),rt;
  if(TH.RoomEnvironment){rt=pm.fromScene(new TH.RoomEnvironment(),.04);}
  else{// 程序化暖色天空：上暖白、地平线金、下土褐 + 太阳亮斑
   var es=new TH.Scene(),geo=new TH.SphereGeometry(10,24,12),col=[],pos=geo.attributes.position,top=new TH.Color('#bcd6e6'),hz=new TH.Color('#ffd9a0'),gr=new TH.Color('#6b5a40'),c=new TH.Color();
   for(var i=0;i<pos.count;i++){var yy=pos.getY(i)/10;if(yy>0)c.copy(hz).lerp(top,Math.pow(yy,.6));else c.copy(hz).lerp(gr,Math.min(1,-yy*3));col.push(c.r,c.g,c.b);}
   geo.setAttribute('color',new TH.Float32BufferAttribute(col,3));
   es.add(new TH.Mesh(geo,new TH.MeshBasicMaterial({vertexColors:true,side:TH.BackSide})));
   var sun=new TH.Mesh(new TH.SphereGeometry(1.4,12,8),new TH.MeshBasicMaterial({color:new TH.Color(6,4.6,3)}));sun.position.set(-6,6,5);es.add(sun);
   rt=pm.fromScene(es,.03);geo.dispose();
  }pm.dispose();e=rt.texture;ENV.set(renderer,e);return e;
 }catch(err){return null;}
}
function findLights(scene){var o={hemi:null,sun:null};scene.traverse(function(n){if(!o.hemi&&n.isHemisphereLight)o.hemi=n;if(!o.sun&&n.isDirectionalLight)o.sun=n;});return o;}
/* applyPreset(renderer,scene,name,{hemi,sun,toneMapping:'aces'|'agx'|'neutral',exposure,env:true,shadows:'mobile'|'soft'|false,background:true,fog:true,keepSunPosition}) */
function applyPreset(renderer,scene,name,opts){
 opts=opts||{};var TH=T(),p=PRESETS[name]||PRESETS.plaza;
 var L0=findLights(scene),lh=opts.hemi||L0.hemi,ls=opts.sun||L0.sun;
 if(!scene.userData.__tgRealPrev)scene.userData.__tgRealPrev={lights:[lh&&[lh,lh.color.clone(),lh.groundColor.clone(),lh.intensity],ls&&[ls,ls.color.clone(),null,ls.intensity,ls.position.clone()]],fog:scene.fog,bg:scene.background,env:scene.environment,envI:scene.environmentIntensity,tm:renderer&&renderer.toneMapping,exp:renderer&&renderer.toneMappingExposure};
 if(renderer){
  var tm=opts.toneMapping||API.toneMapping;renderer.toneMapping=tm==='agx'?TH.AgXToneMapping:tm==='aces'?TH.ACESFilmicToneMapping:tm==='none'?TH.NoToneMapping:(TH.NeutralToneMapping||TH.ACESFilmicToneMapping);// 默认 Khronos PBR Neutral：保色相/饱和度，最接近暖色风格化写实
  renderer.toneMappingExposure=opts.exposure||p.exposure;renderer.outputColorSpace=TH.SRGBColorSpace;
  var sh=opts.shadows===undefined?'mobile':opts.shadows;
  if(sh){renderer.shadowMap.enabled=true;var want=sh==='soft'?TH.PCFSoftShadowMap:TH.PCFShadowMap;if(renderer.shadowMap.type!==want){renderer.shadowMap.type=want;renderer.shadowMap.needsUpdate=true;}}
 }
 if(opts.fog!==false){var fc=new TH.Color(p.fog[0]);if(scene.fog&&scene.fog.isFog&&scene.fog.__tgReal){scene.fog.color.copy(fc);scene.fog.near=p.fog[1];scene.fog.far=p.fog[2];}else{scene.fog=new TH.Fog(fc,p.fog[1],p.fog[2]);scene.fog.__tgReal=true;}}
 if(opts.background!==false){if(scene.background&&scene.background.isColor)scene.background.set(p.bg);else scene.background=new TH.Color(p.bg);}
 var L=findLights(scene),hemi=opts.hemi||L.hemi,sun=opts.sun||L.sun;
 if(hemi){hemi.color.set(p.hemi[0]);hemi.groundColor.set(p.hemi[1]);hemi.intensity=p.hemi[2];}
 if(sun){sun.color.set(p.sun[0]);sun.intensity=p.sun[1];if(!opts.keepSunPosition)sun.position.set(p.sun[2][0],p.sun[2][1],p.sun[2][2]);
  if(sun.castShadow){sun.shadow.bias=-.0004;sun.shadow.normalBias=.03;if(opts.shadowMapSize&&sun.shadow.mapSize.x!==opts.shadowMapSize){sun.shadow.mapSize.set(opts.shadowMapSize,opts.shadowMapSize);if(sun.shadow.map){sun.shadow.map.dispose();sun.shadow.map=null;}}}}
 if(opts.env!==false){var env=envFor(renderer,p);if(env){scene.environment=env;scene.environmentIntensity=p.env;}}
 API.activePreset=name;return p;
}
function resetPreset(renderer,scene){var v=scene.userData.__tgRealPrev;if(!v)return;scene.fog=v.fog;scene.background=v.bg;scene.environment=v.env;if(v.envI!=null)scene.environmentIntensity=v.envI;if(renderer){renderer.toneMapping=v.tm;renderer.toneMappingExposure=v.exp;}(v.lights||[]).forEach(function(a){if(!a)return;a[0].color.copy(a[1]);if(a[2])a[0].groundColor.copy(a[2]);a[0].intensity=a[3];if(a[4])a[0].position.copy(a[4]);});delete scene.userData.__tgRealPrev;}

/* ---------------- upgradeScene：按颜色/形状启发式把平面材质换成写实材质（可逆） ---------------- */
var _c,_v1,_v2,_box;
function classify(mesh,mat){
 var TH=T();_c=_c||new TH.Color();_v1=_v1||new TH.Vector3();_v2=_v2||new TH.Vector3();_box=_box||new TH.Box3();
 var hsl={};_c.copy(mat.color).getHSL(hsl,TH.SRGBColorSpace);var h=hsl.h*360,s=hsl.s,l=hsl.l;
 var g=mesh.geometry;if(!g.boundingBox)g.computeBoundingBox();_box.copy(g.boundingBox).getSize(_v1);mesh.updateWorldMatrix(true,false);
 var sc=new TH.Vector3();mesh.matrixWorld.decompose(new TH.Vector3(),new TH.Quaternion(),sc);var sx=Math.abs(_v1.x*sc.x),sy=Math.abs(_v1.y*sc.y),sz=Math.abs(_v1.z*sc.z);
 var dims=[sx,sy,sz].sort(function(a,b){return b-a;}),wall=dims[0]>3&&dims[1]>1.6;
 var wy=new TH.Vector3().setFromMatrixPosition(mesh.matrixWorld).y,mx=Math.max(sx,sy,sz),flat=sy<.3*Math.min(sx,sz)&&Math.min(sx,sz)>.3;
 var type=g.type||'',prim=/Box|Plane|Cylinder/.test(type)||!/Sphere|Cone|Dodeca|Icosa|Torus|Lathe|Capsule|Circle/.test(type);
 if(!prim&&!flat)return null;
 if(mx<.45)return null; // 小物件保持原样（人物、器物、动物）
 var isCyl=/Cylinder/.test(type);
 if(s>.25&&h>=170&&h<=215&&flat)return 'water';
 if(s>.18&&h>=60&&h<170)return flat&&wy<1?'grass':null;
 if(s>.35&&(h<=22||h>=340)&&l>.15&&l<.62){if(!isCyl&&wall&&!flat)return 'plaster';return 'lacquer';}
 if(s>.12&&h>12&&h<50&&l<.36)return flat?(l<.32?'wood':'soil'):'wood';
 if(s>.12&&h>=15&&h<60&&flat)return l>.55?'bluestone':'soil';
 if(s>.12&&h>=15&&h<60&&l>.62)return 'plaster';
 if(s<=.25){if(l>.72)return 'plaster';if(wy>2.2&&l<.55)return 'roofTile';if(flat)return 'bluestone';if(wall&&l<.62)return 'brick';return 'bluestone';}
 if(s>.12&&h>=15&&h<60)return 'wood';
 return null;
}
var TINTMIX={plaster:.95,bluestone:.6,lacquer:.7,wood:.6,roofTile:.5,brick:.5,soil:.45,grass:.5,water:.3};// 保留原配色的程度
/* upgradeScene(root,{quality,tintMix,map:{origMaterialUuidOrColorHex:name},filter(mesh)->bool,includeTextured}) → 统计 */
function upgradeScene(root,opts){
 opts=opts||{};var stat={swapped:0,skipped:0,byName:{}};if(!root)return stat;
 var known=null;try{if(G.W3&&G.W3.materials){var wm=G.W3.materials;known={};if(wm['art2:stone'])known[wm['art2:stone'].uuid]=['bluestone','#cbb98e'];if(wm['art2:wood'])known[wm['art2:wood'].uuid]=['wood','#7a4a30'];if(wm['art2:path'])known[wm['art2:path'].uuid]=['bluestone','#e4d7b4'];if(wm['art2:water'])known[wm['art2:water'].uuid]=['water',null];}}catch(e){}
 root.traverse(function(o){
  if(!o.isMesh||o.userData.__tgRealOrig||o.userData.tgRealSkip||o.isPoints||Array.isArray(o.material))return;
  var m=o.material;if(!m||m.userData&&m.userData.tgReal){return;}
  if(opts.filter&&!opts.filter(o)){stat.skipped++;return;}
  if(!(m.isMeshLambertMaterial||m.isMeshStandardMaterial||m.isMeshPhongMaterial)){stat.skipped++;return;}
  var kn=known&&known[m.uuid],name=(opts.map&&(opts.map[m.uuid]||opts.map['#'+m.color.getHexString()]))||(kn&&kn[0]);
  if(!name){if(m.map&&!opts.includeTextured){stat.skipped++;return;}if(m.transparent&&m.opacity<.98){stat.skipped++;return;}if(m.emissive&&m.emissive.getHex()!==0){stat.skipped++;return;}if(o.geometry.attributes.color&&m.vertexColors){stat.skipped++;return;}name=classify(o,m);}
  if(!name){stat.skipped++;return;}
  var tint=kn?kn[1]:'#'+m.color.getHexString();
  var nm=material(name,{worldUV:true,tint:tint,tintMix:opts.tintMix==null?(TINTMIX[name]==null?.55:TINTMIX[name]):opts.tintMix,quality:opts.quality});
  o.userData.__tgRealOrig=m;o.material=nm;UPGRADED.add(o);stat.swapped++;stat.byName[name]=(stat.byName[name]||0)+1;
 });
 return stat;
}
function restoreScene(root){var n=0;(root||{traverse:function(f){UPGRADED.forEach(f);}}).traverse(function(o){if(o.userData&&o.userData.__tgRealOrig){o.material=o.userData.__tgRealOrig;delete o.userData.__tgRealOrig;UPGRADED.delete(o);n++;}});return n;}

/* ---------------- 动画 / 统计 / 释放 / 游戏挂钩 ---------------- */
function update(dt){TIME.value+=dt||0;for(var i=0;i<WATER_MATS.length;i++){var m=WATER_MATS[i];if(!m.userData.tgWorldUV){m.map.offset.x=(m.map.offset.x+dt*.012)%1;m.normalMap.offset.y=(m.normalMap.offset.y+dt*.02)%1;}}}
function stats(renderer){var r=renderer&&renderer.info&&renderer.info.render;return r?{calls:r.calls,triangles:r.triangles,textures:renderer.info.memory.textures,geometries:renderer.info.memory.geometries,programs:renderer.info.programs?renderer.info.programs.length:0}:null;}
function dispose(){restoreScene();Object.keys(MATS).forEach(function(k){var m=MATS[k];['map','normalMap','roughnessMap'].forEach(function(t){if(m[t]&&m[t].isTexture&&!isBase(m[t]))m[t].dispose();});m.dispose();delete MATS[k];});Object.keys(TEX).forEach(function(k){var s=TEX[k];s.map.dispose();s.normal.dispose();s.roughness.dispose();delete TEX[k];});WATER_MATS.length=0;}
function isBase(t){for(var k in TEX){var s=TEX[k];if(s.map===t||s.normal===t||s.roughness===t)return true;}return false;}
/* install({upgrade:true,quality,toneMapping}) —— 可选：包装游戏的 worldEnter/tgAnimate，进入场景时自动套预设、换材质。幂等。 */
function install(opts){
 opts=opts||{};if(API.installed)return true;if(typeof G.worldEnter!=='function'||!G.W3)return false;
 API._installOpts=opts;var oe=G.worldEnter;G.worldEnter=function(name){var r=oe.apply(this,arguments);if(API.enabled)applyToActive();return r;};
 if(typeof G.tgAnimate==='function'){var oa=G.tgAnimate;G.tgAnimate=function(ts,dt){var r=oa.apply(this,arguments);update(dt||0);return r;};}
 API.installed=true;return true;
}
function applyToActive(){var opts=API._installOpts||{};try{var w=G.W3;if(!w||!w.renderer||!w.active)return;applyPreset(w.renderer,w.scene,w.active,{hemi:w.hemi,sun:w.sun,keepSunPosition:true,toneMapping:opts.toneMapping});if(opts.upgrade!==false&&w.spaces[w.active])upgradeScene(w.spaces[w.active].group,{quality:opts.quality});}catch(e){try{console.warn('[TG_REAL]',e);}catch(_){}}}
function setEnabled(on){API.enabled=!!on;var w=G.W3;if(!w||!w.renderer)return;if(on){applyToActive();}else{restoreScene();resetPreset(w.renderer,w.scene);}}

var API=G.TG_REAL={version:'r6-real-1',names:NAMES,aliases:ALIAS,presets:PRESETS,textureSize:256,quality:'high',toneMapping:'neutral',enabled:true,installed:false,activePreset:null,
 texture:texture,material:material,applyPreset:applyPreset,resetPreset:resetPreset,upgradeScene:upgradeScene,restoreScene:restoreScene,classify:function(m){return classify(m,m.material);},
 update:update,stats:stats,dispose:dispose,install:install,applyToActive:applyToActive,setEnabled:setEnabled,patchWorldUV:patchWorldUV,
 _gen:GEN,_fbm:fbm,_hash:hash};
})();
