/* r8c.2: restore the v13 缘堂 art (hall only). r7 wiped the hall group and r7c rebuilt a bare room; r7 also hid the
   art3 「古朴木作」 style (朱漆柱、雕花窗棂、额枋、宫灯、红毯). Here the original objects (stashed by r7 in h.r7Legacy) come back,
   minus what r7c/r8c now own (floor collider, perimeter walls, ceiling, altar table) and minus devotional props; text is
   swapped for neutral wording only — no object is deleted for compliance. */
(()=>{
'use strict';
const T=THREE;const LOG=(window.TG_R8C2={changes:[],restored:0,skipped:[]});
const near=(a,b,e=.02)=>Math.abs(a-b)<e;
function sizeOf(o){const b=new T.Box3().setFromObject(o);return {b,s:b.getSize(new T.Vector3()),c:b.getCenter(new T.Vector3())};}
// Neutral paintings on canvas (山水 / 梅花 / 荷花): no blank placeholders.
function paint(kind,W=512,H=470){const c=document.createElement('canvas');c.width=W;c.height=H;const a=c.getContext('2d');let seed=kind*977+13;const r=()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);
 a.fillStyle='#5a3a22';a.fillRect(0,0,W,H);a.fillStyle='#d9b77a';a.fillRect(10,10,W-20,H-20);
 const x0=26,y0=26,w=W-52,h=H-52;const g=a.createLinearGradient(0,y0,0,y0+h);g.addColorStop(0,'#f1e7cf');g.addColorStop(1,'#e4d6b3');a.fillStyle=g;a.fillRect(x0,y0,w,h);
 a.save();a.beginPath();a.rect(x0,y0,w,h);a.clip();
 if(kind===0){// 青绿山水
  a.fillStyle='rgba(200,90,60,.55)';a.beginPath();a.arc(x0+w*.78,y0+h*.2,26,0,7);a.fill();
  const ridge=(base,amp,col,n)=>{a.fillStyle=col;a.beginPath();a.moveTo(x0,y0+h);for(let i=0;i<=n;i++){const x=x0+w*i/n;a.lineTo(x,y0+base-amp*Math.abs(Math.sin(i*1.7+base))-r()*amp*.35);}a.lineTo(x0+w,y0+h);a.fill();};
  ridge(h*.55,h*.32,'#9db5a0',9);ridge(h*.68,h*.28,'#6f9480',11);ridge(h*.8,h*.2,'#4e7464',13);
  a.fillStyle='#a9c3c4';a.fillRect(x0,y0+h*.82,w,h*.18);a.strokeStyle='rgba(255,255,255,.6)';a.lineWidth=2;for(let i=0;i<7;i++){a.beginPath();const y=y0+h*.85+i*9;a.moveTo(x0+r()*w*.5,y);a.lineTo(x0+w*.4+r()*w*.6,y);a.stroke();}
  a.fillStyle='#4a3a2a';a.beginPath();a.moveTo(x0+w*.3,y0+h*.9);a.lineTo(x0+w*.42,y0+h*.9);a.lineTo(x0+w*.39,y0+h*.93);a.lineTo(x0+w*.33,y0+h*.93);a.fill();
  for(let i=0;i<5;i++){a.strokeStyle='#5d4632';a.lineWidth=3;const x=x0+w*(.08+i*.05),y=y0+h*.8;a.beginPath();a.moveTo(x,y);a.lineTo(x,y-40-i*6);a.stroke();a.fillStyle='#3f6a4f';a.beginPath();a.arc(x,y-46-i*6,13,0,7);a.fill();}
 }else if(kind===1){// 梅花
  a.strokeStyle='#3e2c22';a.lineCap='round';const br=(x,y,ang,len,wd,d)=>{if(d>5||len<8)return;const x2=x+Math.cos(ang)*len,y2=y+Math.sin(ang)*len;a.lineWidth=wd;a.beginPath();a.moveTo(x,y);a.quadraticCurveTo((x+x2)/2+(r()-.5)*20,(y+y2)/2+(r()-.5)*20,x2,y2);a.stroke();
   for(let k=0;k<3;k++){const t=r();const bx=x+(x2-x)*t,by=y+(y2-y)*t;if(r()<.7){a.fillStyle=r()<.5?'#d8485a':'#e98a96';for(let p=0;p<5;p++){a.beginPath();a.arc(bx+Math.cos(p*1.256)*5,by+Math.sin(p*1.256)*5,4.5,0,7);a.fill();}a.fillStyle='#f5d36b';a.beginPath();a.arc(bx,by,2,0,7);a.fill();}}
   br(x2,y2,ang-.5+r()*.3,len*.72,wd*.68,d+1);br(x2,y2,ang+.35+r()*.3,len*.64,wd*.66,d+1);};
  br(x0+w*.1,y0+h*.95,-1.0,h*.36,14,0);
  a.fillStyle='rgba(60,40,30,.75)';a.font='bold 30px serif';a.textAlign='center';['暗','香','疏','影'].forEach((ch,i)=>a.fillText(ch,x0+w*.86,y0+50+i*36));
  a.fillStyle='#b8322d';a.fillRect(x0+w*.86-11,y0+50+4*36-14,22,22);
 }else{// 荷花
  a.fillStyle='#bcd0c4';a.fillRect(x0,y0+h*.62,w,h*.38);
  const leaf=(x,y,rr)=>{a.fillStyle='#4f7f5b';a.beginPath();a.ellipse(x,y,rr,rr*.42,0,0,7);a.fill();a.strokeStyle='#3d6648';a.lineWidth=2;for(let i=0;i<8;i++){a.beginPath();a.moveTo(x,y);a.lineTo(x+Math.cos(i*.785)*rr,y+Math.sin(i*.785)*rr*.42);a.stroke();}};
  leaf(x0+w*.25,y0+h*.72,70);leaf(x0+w*.7,y0+h*.8,58);leaf(x0+w*.5,y0+h*.9,48);
  const lotus=(x,y,s)=>{a.strokeStyle='#4d7a55';a.lineWidth=4;a.beginPath();a.moveTo(x,y);a.lineTo(x+4,y+h*.32);a.stroke();for(let i=-2;i<=2;i++){a.fillStyle=i===0?'#f3b7c3':'#e98aa0';a.save();a.translate(x,y);a.rotate(i*.38);a.beginPath();a.ellipse(0,-s*.55,s*.28,s*.6,0,0,7);a.fill();a.restore();}};
  lotus(x0+w*.42,y0+h*.42,62);lotus(x0+w*.68,y0+h*.5,44);
  a.fillStyle='#2f4c3a';a.beginPath();a.ellipse(x0+w*.2,y0+h*.36,10,18,.3,0,7);a.fill();
 }
 a.restore();a.strokeStyle='#7c5a34';a.lineWidth=4;a.strokeRect(x0,y0,w,h);
 const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;t.anisotropy=4;return t;}
function label(text,w,h,vertical){const c=document.createElement('canvas');c.width=vertical?64:512;c.height=vertical?256:128;const a=c.getContext('2d');
 if(vertical){a.fillStyle='#a64d37';a.fillRect(0,0,64,256);a.strokeStyle='#dab574';a.strokeRect(5,5,54,246);a.fillStyle='#ffe0a0';a.font='bold 42px serif';a.textAlign='center';[...text].forEach((v,i)=>a.fillText(v,32,53+i*55));}
 else{a.fillStyle='#402820';a.fillRect(0,0,512,128);a.strokeStyle='#dfb65a';a.lineWidth=8;a.strokeRect(8,8,496,112);a.fillStyle='#ffe6a1';a.font='bold 66px serif';a.textAlign='center';a.textBaseline='middle';a.fillText(text,256,66);}
 const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;return t;}
function canvasText(m){return m?.material?.map?.image?.__r8c2Text;}
// The world3d/art2 couplets and tablets carry their text only in canvas pixels; identify them by position.

// --- merged-geometry editing: enhance.js merged same-colour boxes (24 verts / 36 idx each, in order) and art2 merged
// props; we drop only the parts that r7c/r8c now own or that are devotional, and nudge a few parts out of door openings.
function rebuild(g,keepRanges,vmap){const out=new T.BufferGeometry();const attrs=Object.keys(g.attributes);const idx=g.index?g.index.array:Uint32Array.from({length:g.attributes.position.count},(_,i)=>i);let nv=0;const remap=new Int32Array(g.attributes.position.count).fill(-1);const order=[];
 for(const [v0,v1] of keepRanges.verts)for(let v=v0;v<v1;v++){remap[v]=nv++;order.push(v);}
 for(const k of attrs){const a=g.attributes[k],n=a.itemSize,arr=new a.array.constructor(nv*n);order.forEach((v,i)=>{for(let j=0;j<n;j++)arr[i*n+j]=a.array[v*n+j];});out.setAttribute(k,new T.BufferAttribute(arr,n,a.normalized));}
 const ni=[];for(let i=0;i<idx.length;i+=3){const a=remap[idx[i]],b=remap[idx[i+1]],c=remap[idx[i+2]];if(a>=0&&b>=0&&c>=0)ni.push(a,b,c);}out.setIndex(ni);
 if(vmap){const pos=out.attributes.position;order.forEach((v,i)=>{const d=vmap(v);if(d){const q=d(pos.getX(i),pos.getY(i),pos.getZ(i));pos.setXYZ(i,q[0],q[1],q[2]);}});}
 out.computeBoundingBox();out.computeBoundingSphere();return out;}
function boxChunk(m){const g=m.geometry;if(!m.isMesh||m.isInstancedMesh||!g?.attributes?.position)return 0;const pos=g.attributes.position,n=pos.count;const C=g.index?24:36;
 if(g.index&&g.index.count!==n*1.5)return 0;if(n%C||n<=C)return 0;const u=new Set();for(let i=0;i<C;i++)u.add(pos.getX(i).toFixed(4)+','+pos.getY(i).toFixed(4)+','+pos.getZ(i).toFixed(4));return u.size===8?C:0;}
function editBoxMerge(m,decide,C){const g=m.geometry,pos=g.attributes.position,n=pos.count/C;const verts=[],moves=new Map();let dropped=0;const b=new T.Box3(),v=new T.Vector3();
 for(let k=0;k<n;k++){b.makeEmpty();for(let i=k*C;i<k*C+C;i++)b.expandByPoint(v.fromBufferAttribute(pos,i));const c=b.getCenter(new T.Vector3()),sz=b.getSize(new T.Vector3());const d=decide(c,sz);
  if(d==='drop'){dropped++;continue;}verts.push([k*C,k*C+C]);if(d&&d.move)moves.set(k,d.move);}
 if(!dropped&&!moves.size)return 0;m.geometry=rebuild(g,{verts},moves.size?vi=>{const mv=moves.get(Math.floor(vi/C));return mv?((x,y,z)=>[x+(mv[0]||0),y+(mv[1]||0),z+(mv[2]||0)]):null;}:null);
 return dropped+moves.size;}
function editComponents(m,dropFn){const g=m.geometry;const pos=g.attributes.position,n=pos.count,idx=g.index?g.index.array:Uint32Array.from({length:n},(_,i)=>i),par=new Int32Array(n).map((_,i)=>i);const f=x=>{while(par[x]!==x)x=par[x]=par[par[x]];return x;};
 if(!g.index){const seen=new Map();for(let i=0;i<n;i++){const k=Math.round(pos.getX(i)*1e4)+','+Math.round(pos.getY(i)*1e4)+','+Math.round(pos.getZ(i)*1e4);const j=seen.get(k);if(j==null)seen.set(k,i);else par[f(i)]=f(j);}}
 for(let i=0;i<idx.length;i+=3){const a=f(idx[i]),b=f(idx[i+1]),c=f(idx[i+2]);par[b]=a;par[f(c)]=a;}
 const box=new Map(),v=new T.Vector3();for(let i=0;i<n;i++){const r=f(i);if(!box.has(r))box.set(r,new T.Box3());box.get(r).expandByPoint(v.fromBufferAttribute(pos,i));}
 const drop=new Set();for(const [r,b] of box)if(dropFn(b.getCenter(new T.Vector3()),b.getSize(new T.Vector3())))drop.add(r);if(!drop.size)return 0;
 const verts=[];let s0=-1;for(let i=0;i<=n;i++){const keep=i<n&&!drop.has(f(i));if(keep&&s0<0)s0=i;if(!keep&&s0>=0){verts.push([s0,i]);s0=-1;}}m.geometry=rebuild(g,{verts});return drop.size;}
function moveComponents(m,fn){const g=m.geometry,pos=g.attributes.position,n=pos.count,idx=g.index?g.index.array:Uint32Array.from({length:n},(_,i)=>i),par=new Int32Array(n).map((_,i)=>i);const f=x=>{while(par[x]!==x)x=par[x]=par[par[x]];return x;};
 if(!g.index){const seen=new Map();for(let i=0;i<n;i++){const k=Math.round(pos.getX(i)*1e4)+','+Math.round(pos.getY(i)*1e4)+','+Math.round(pos.getZ(i)*1e4);const j=seen.get(k);if(j==null)seen.set(k,i);else par[f(i)]=f(j);}}
 for(let i=0;i<idx.length;i+=3){const a=f(idx[i]),b=f(idx[i+1]),c=f(idx[i+2]);par[b]=a;par[f(c)]=a;}
 m.updateMatrixWorld(true);const box=new Map(),v=new T.Vector3();for(let i=0;i<n;i++){const r=f(i);if(!box.has(r))box.set(r,new T.Box3());box.get(r).expandByPoint(v.fromBufferAttribute(pos,i).applyMatrix4(m.matrixWorld));}
 const mv=new Map();for(const [r,b] of box){const d=fn(b.getCenter(new T.Vector3()),b.getSize(new T.Vector3()));if(d)mv.set(r,d);}if(!mv.size)return 0;
 for(let i=0;i<n;i++){const d=mv.get(f(i));if(d)pos.setXYZ(i,pos.getX(i)+d[0],pos.getY(i)+d[1],pos.getZ(i)+d[2]);}pos.needsUpdate=true;g.computeBoundingBox();g.computeBoundingSphere();return mv.size;}
const inBurner=c=>Math.abs(c.x)<1.25&&Math.abs(c.z+2.3)<1.25&&c.y<1.7;
const CPL=5.22;// couplets move out of the north door opening (r8c: x 4..5) to sit between door and corner pillar
function boxRule(c,sz){
 if(near(c.y,2.1,.05)&&near(sz.y,4.2,.05)&&Math.min(sz.x,sz.z)<.4)return 'drop';// r3 perimeter walls (r7c/r8c walls kept)
 if(near(c.y,5.5,.05)&&sz.x>10)return 'drop';// legacy ceiling
 if(near(c.z,-5.8,.05)&&(near(c.y,1.35,.05)||near(c.y,.65,.05))&&Math.abs(c.x)<2.6)return 'drop';// altar table duplicates r7c altar
 if(near(c.z,-7.2,.05)&&(near(c.y,2.8,.05)||near(c.y,1.8,.05)))return 'drop';// ancestral tablet boards/bases
 if(inBurner(c)&&sz.y>.05&&sz.x<1.5)return 'drop';// incense burner feet
 if(near(Math.abs(c.x),4.7,.05)&&near(c.z,-7.75,.05)&&near(sz.y,2.4,.05))return {move:[Math.sign(c.x)*(CPL-4.7),0,0]};// couplet boards
 if(near(Math.abs(c.x),4.7,.05)&&near(c.y,4.5,.05)&&near(sz.y,.7,.05)&&sz.x<.05)return {move:[0,.37,0]};// lantern cords end at the lantern top (r8d: bottom 4.32 m, lantern cap 4.35 m → touching, was 0.2 m inside)
 return null;}
const COUPLET={'-4.7':'花香满院','4.7':'竹影临窗'};// neutral auspicious pair (no blessing-prayer / religious wording)
function restore(){const w=W3,h=w?.spaces?.hall,L=h?.r7Legacy;if(!L||h.r8c2Done)return;h.r8c2Done=true;
 const keepOut=[];
 for(const o of L.children){const p=o.position;let why=null;
  if(o.isMesh&&o.geometry===w.geometries?.box){const sc=o.scale;
   if(near(p.y,5.5))why='legacy ceiling (r8c.1 ceiling kept)';
   else if(near(p.y,2.1)&&near(sc.y,4.2))why='r3 perimeter wall (r7c/r8c walls kept)';
   else if(near(p.y,2.7)&&near(sc.y,5.4))why='world3d wall';
   else if(near(p.z,-5.8)&&(near(p.y,1.35)||near(p.y,.65))&&Math.abs(p.x)<2.5)why='altar table duplicate of r7c';
   else if(near(p.z,-7.2)&&near(p.y,2.8))why='ancestral-tablet board (paintings occupy the wall)';
   else if(near(p.z,-7.2)&&near(p.y,1.8))why='ancestral-tablet base';
   else if(near(p.x,2.1)&&near(p.y,1.65)&&near(p.z,-3.55))why='muyu mallet (devotional)';}
  if(o.isMesh&&o.userData.wallSign){if(near(p.z,-7.05))why='ancestral tablet text';else if(near(p.z,-7.78)&&near(p.y,4.1))why='old plaque text (r7c 家和业兴 plaque kept)';}
  if(o.isMesh&&near(p.x,2.1)&&near(p.y,1.4)&&near(p.z,-3.8))why='muyu (devotional) — table kept';
  if(o.isGroup&&o.children.some(c=>c.userData?.wallSign)&&h.exits.some(e=>Math.hypot(e.x-p.x,e.z-p.z)<.5)){// door frame: keep, retitle with current scene names
   const to=h.exits.find(e=>Math.hypot(e.x-p.x,e.z-p.z)<.5).to,name=TG_SCENES.find(s=>s.id===to)?.name||'';
   for(const c of o.children)if(c.userData?.wallSign){c.material=c.material.clone();c.material.map=label(name);c.material.map.image.__r8c2Text=name;}
   LOG.changes.push({object:'door '+to,text:name});}
  const shared=o.isMesh&&Object.values(w.geometries||{}).includes(o.geometry),atOrigin=o.position.lengthSq()<1e-8;
  if(!why&&o.isMesh&&!o.isInstancedMesh&&(shared||!atOrigin)&&o.geometry!==w.geometries?.box){const c=new T.Box3().setFromObject(o).getCenter(new T.Vector3());if(inBurner(c))why='incense burner part (replaced by a planter)';}
  else if(!why&&o.isMesh&&!o.isInstancedMesh&&o.geometry!==w.geometries?.box){
   const C=boxChunk(o);if(C){const k=editBoxMerge(o,boxRule,C);if(k){LOG.changes.push({object:'enhance merged boxes #'+o.material.color.getHexString(),parts:k});if(!o.geometry.index.count)why='merged boxes emptied';}}
   else if(o.geometry.attributes.position.count>64){const k=editComponents(o,(c)=>inBurner(c));if(k){LOG.changes.push({object:'art2 merged #'+o.material.color.getHexString(),burnerParts:k});if(!o.geometry.index.count)why='merged emptied (burner only)';}}
   else{const c=new T.Box3().setFromObject(o).getCenter(new T.Vector3());if(inBurner(c))why='incense burner part (replaced by a planter)';}}
  if(o.isGroup&&near(p.x,4)&&near(p.z,-7.5))why='lotus door frame (3.3 m) wider than the r8c north opening — r7c label kept';
  if(o.isMesh&&o.geometry===w.geometries?.box&&near(p.z,-7.2)&&near(p.y,.86)){o.scale.x=4.4;LOG.changes.push({object:'back table',to:'4.4 m wide (clear of the lotus door post)'});}
  if(o.isMesh&&o.material?.map&&near(o.position.z,-7.71)&&near(Math.abs(o.position.x),4.7))o.position.x=Math.sign(o.position.x)*CPL;
  if(why){LOG.skipped.push(why);continue;}
  h.group.add(o);LOG.restored++;
  if(o.isMesh&&near(p.y,.85)&&near(p.z,-2.3)&&o.geometry?.type==='CylinderGeometry')o.userData.r8c2Vessel=true;
 }
 // couplets (art2): same boards, neutral text
 for(const o of h.group.children)if(o.isMesh&&o.material?.map&&near(o.position.z,-7.71)&&near(Math.abs(o.position.x),CPL)){const t=COUPLET[o.position.x<0?'-4.7':'4.7'];o.material=o.material.clone();o.material.map=label(t,0,0,true);o.material.map.image.__r8c2Text=t;LOG.changes.push({object:'couplet '+o.position.x,text:t});}
 // the bronze vessel becomes a flower planter (no incense)
 const pb=new T.Group();pb.name='r8c2-planter-body';pb.position.set(0,0,-2.3);h.group.add(pb);worldMesh(pb,'cylinder','#8a6d3b',0,.06,0,.95,.12,.95);worldMesh(pb,'cylinder','#9a7a45',0,.52,0,.78,.8,.78);worldMesh(pb,'cylinder','#5e4a2c',0,.925,0,.7,.01,.7);
 const fl=new T.Group();fl.name='r8c2-planter';fl.position.set(0,.93,-2.3);h.group.add(fl);
 for(let i=0;i<7;i++){const a=i*2.4,rr=.12+(i%3)*.07;worldMesh(fl,'cylinder','#6d8f57',Math.cos(a)*rr*.5,.22,Math.sin(a)*rr*.5,.025,.45,.025);worldMesh(fl,'ball',i%2?'#f0b6c2':'#f6e2a8',Math.cos(a)*rr,.48+(i%2)*.08,Math.sin(a)*rr,.13,.1,.13);}
 for(let i=0;i<5;i++){const a=i*1.26+.3;const lf=worldMesh(fl,'ball','#5f8a4e',Math.cos(a)*.28,.1,Math.sin(a)*.28,.22,.05,.12);lf.rotation.y=-a;}
 // a vase on the former muyu table
 const v=new T.Group();v.name='r8c2-vase';v.position.set(2.1,1.4,-3.8);h.group.add(v);worldMesh(v,'ball','#4f7f86',0,.2,0,.3,.4,.3);worldMesh(v,'cylinder','#4f7f86',0,.45,0,.1,.18,.1);
 for(let i=0;i<4;i++){const a=i*1.6;worldMesh(v,'cylinder','#6d8f57',Math.cos(a)*.05,.7,Math.sin(a)*.05,.02,.45,.02);worldMesh(v,'ball','#e7d6a8',Math.cos(a)*.1,.95,Math.sin(a)*.1,.1,.08,.1);}
 // colliders for restored solids (pillars, vessel, side table); r7c walls/altar colliders stay as they are
 for(const b of [{x:-4.25,X:-3.75,z:-2.25,Z:-1.75,r8c2:'pillar'},{x:3.75,X:4.25,z:-2.25,Z:-1.75,r8c2:'pillar'},{x:-.8,X:.8,z:-3.1,Z:-1.5,r8c2:'vessel'},{x:1.25,X:2.95,z:-4.4,Z:-3.2,r8c2:'side table'},{x:-2.2,X:2.2,z:-7.6,Z:-6.8,r8c2:'back table'},
  ...[[0,7.5,0],[5.6,3,1],[-5.6,3,1]].flatMap(([x,z,side])=>[-1.65,1.65].map(d=>{const px=side?x:x+d,pz=side?z+d:z;return {x:px-.2,X:px+.2,z:pz-.2,Z:pz+.2,r8c2:'door post'};}))])h.blocks.push(b);
 for(const o of h.group.children)if(o.isInstancedMesh&&o.count===10&&o.material?.color?.getHexString()==='759457'){const m4=new T.Matrix4(),pp=new T.Vector3(),q=new T.Quaternion(),sc=new T.Vector3();for(let i=0;i<o.count;i++){o.getMatrixAt(i,m4);m4.decompose(pp,q,sc);pp.y=2.7;sc.y=.32;m4.compose(pp,q,sc);o.setMatrixAt(i,m4);}o.instanceMatrix.needsUpdate=true;LOG.changes.push({object:'vase stems',to:'start at the vase mouth'});}
 // r8d: art3 pillars get colliders (the camera sample at (-5.5,.75) stood inside the pillar at (-5.62,.95))
 for(const [x,z] of [[-5.62,-7.6],[5.62,-7.6],[-5.62,.95],[5.62,.95],[-5.62,5.05],[5.62,5.05],[-2.35,7.62],[2.35,7.62]])h.blocks.push({x:x-.28,X:x+.28,z:z-.28,Z:z+.28,r8c2:'art3 pillar'});
 window.TG_R8C2.blocks=h.blocks.filter(b=>b.r8c2).length;
}
function flames(){const h=W3?.spaces?.hall;if(!h)return;// r8d: altar candle flames sit on the candle top (were 0.1 m inside the candle body)
 h.group.traverse(o=>{if(!o.isMesh||o.isInstancedMesh||o.userData.r8dFlame||o.material?.color?.getHexString?.()!=='ffffa7'||o.geometry.attributes.position.count<=64)return;o.userData.r8dFlame=true;
  const k=moveComponents(o,(c,sz)=>near(Math.abs(c.x),2.2,.08)&&near(c.z,-5.8,.08)&&c.y>2.1&&c.y<2.5&&sz.y<.5?[0,.09,0]:null);if(k)LOG.changes.push({object:'candle flames',moved:k,dy:.09});});}
function paintings(){const h=W3?.spaces?.hall;const g=h?.plaqueGroup;if(!g)return;
 for(const o of h.group.children)if(o.isMesh&&o.userData.wallSign&&near(o.position.z,-7.78)&&near(o.position.y,4)){o.position.y=4.22;o.scale.set(4.4,1.1,1);}
 // r8d3: the player's own portraits (name / uploaded or URL image / cute default face — r3PlaqueTexture) come first; only UNSET slots
 // (no image and the name empty or still the default 家和业兴 / 福泽绵长) get a neutral painting. One frame per panel entry (as v13).
 const pl=(typeof S!=='undefined'&&S?.shrine?.plaques)||[],DEF=['家和业兴','福泽绵长','家和业兴','列祖列宗之位'],n=g.children.length,sp=n>1?Math.min(2.3,7/(n-1)):0;
 const unset=p=>!p||(!String(p.img||'').trim()&&(!String(p.name||'').trim()||DEF.includes(String(p.name).trim())));LOG.portraits=[];
 g.children.forEach((m,i)=>{m.position.y=2.92;m.position.x=(i-(n-1)/2)*sp;const own=!unset(pl[i]);LOG.portraits.push(own?'portrait':'painting');
  if(own){m.scale.set(.72,.72,1);m.userData.r8d3Portrait=true;return;}m.userData.r8d3Portrait=false;m.scale.set(1.4,.65,1);
  if(m.userData.r8c2Paint===m.material?.uuid)return;const old=m.material.map;m.material=m.material.clone();m.material.map=paint(i%3);m.material.needsUpdate=true;m.userData.r8c2Paint=m.material.uuid;old?.dispose?.();});}
function styleOn(){const h=W3?.spaces?.hall,st=h?.art3Styles;if(!st)return;st.root.visible=true;
 if(!st.r8c2Pillar){st.r8c2Pillar=true;const m4=new T.Matrix4(),pp=new T.Vector3(),q=new T.Quaternion(),sc=new T.Vector3();let n=0;// NE corner pillar stood 0.3 m inside the r7c east wall (its twin is at x -5.62)
  st.wood.traverse(o=>{if(!o.isInstancedMesh)return;let ch=false;for(let i=0;i<o.count;i++){o.getMatrixAt(i,m4);m4.decompose(pp,q,sc);if(near(pp.x,5.9,.03)&&near(pp.z,-7.6,.03)){pp.x=5.62;m4.compose(pp,q,sc);o.setMatrixAt(i,m4);ch=true;n++;}}if(ch){o.instanceMatrix.needsUpdate=true;o.computeBoundingBox?.();o.computeBoundingSphere?.();}});
  if(n)LOG.changes.push({object:'art3 NE pillar',from:'x 5.9',to:'x 5.62 (symmetric, clear of the wall)',instances:n});}}
const deco=tgDecorate;tgDecorate=function(){const out=deco.apply(this,arguments);try{restore();}catch(e){LOG.err=String(e);console.warn('r8c2',e);}return out;};
const sync=worldSyncHall;worldSyncHall=function(){const out=sync.apply(this,arguments);try{styleOn();}catch(e){}return out;};
const shrine=worldSyncShrine;worldSyncShrine=function(){const out=shrine.apply(this,arguments);try{paintings();}catch(e){LOG.errP=String(e);}return out;};
// Entry view: from the yard (or a cold load) stand on the carpet with the altar + plaque ahead; the boom fits inside the room.
function chimeFix(){const h=W3.spaces.hall;if(h.r8c2Chime)return;const c=h.group.getObjectByName('r7-garden-chime');if(!c)return;h.r8c2Chime=true;c.position.set(-3.05,0,-1.15);const it=h.items.find(i=>i.label==='摇风铃');if(it){it.x=-3.05;it.z=-.3;}LOG.changes.push({object:'摇风铃 chime',from:'(-4,-1.5) inside the restored west pillar',to:'(-3.05,-1.15) / prompt (-3.05,-0.3)'});}
function entryView(prev){const w=W3;if(S.view==='fp'||w.r6Plan)return;if(['zen','study','lotus'].includes(prev))return;
 w.player.position.set(0,0,1.6);w.player.rotation.y=Math.PI;w.yaw=0;w.pitch=.15;w.radius=6.0;w.vx=w.vz=0;if(w.follow)w.follow.copy(w.player.position).y=1.1;
 try{worldCamera(1);}catch(e){}LOG.entry={prev:prev||null,at:[0,1.6],yaw:0,pitch:.15,radius:6.0};}
const enter=worldEnter;worldEnter=function(name,prev){const out=enter.apply(this,arguments);if(W3?.active==='hall'){try{styleOn();paintings();chimeFix();flames();entryView(prev);}catch(e){LOG.errE=String(e);}}return out;};
})();
