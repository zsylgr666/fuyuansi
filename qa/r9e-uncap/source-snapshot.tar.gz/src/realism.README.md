# realism.js — `window.TG_REAL`（r6）

这是程序生成的「风格化写实」材质库和 PBR 预设。美术方向参考王者荣耀的家园/农场：暖金色主光、暖色环境光和柔和的雾，颜色略饱和，带笔触细节。
文件独立，不修改任何既有代码。它只依赖 r170 的 `THREE`（兼容 `const THREE` 和 `window.THREE`）。重复加载时有守卫，不会重复执行。

## 材质名（中文别名可用）
| 名称 | 别名 | 说明 | 默认世界 UV 密度（每米平铺次数） |
|---|---|---|---|
| `roofTile` | 青瓦 | 筒瓦与板瓦交替、逐行搭接，沟里带青苔 | .55 |
| `lacquer` | 朱漆木 | 光亮的朱红漆，透出细木纹，带开片和磨损（roughness 约 .3） | .6 |
| `wood` | 木纹 | 暖蜂蜜色木板，有年轮、木节和板缝（r6 已调浅、调得不那么红） | .45 |
| `bluestone` | 青石板 | 错缝石板，石缝下凹并带青苔 | .36 |
| `brick` | 砖墙 | 青砖顺砌，灰浆缝内凹 | .45 |
| `soil` | 泥土 | 暖褐色土块和小卵石 | .4 |
| `grass` | 草地 | 暖绿色斑块加草叶笔触 | .35 |
| `water` | 水面 | 清透青绿色，带涟漪和焦散，半透明，法线会流动 | .18 |
| `plaster`（额外） | 白灰墙 | 暖白抹灰（套用红色 tint 后就是红墙） | .3 |
| `moss`（额外） | 青苔 | 用于石头和墙根 | .6 |

每种材质有 3 张贴图：color（sRGB）、normal（由高度图做 Sobel 得到）、roughness（存在 G 通道）。全部可无缝平铺。贴图默认 256px，可通过 `TG_REAL.textureSize=512` 修改，按 名称@尺寸 缓存，只生成一次。

## API
```js
TG_REAL.material(name, {
  worldUV: true|number,   // 世界空间盒式投影 UV（推荐）。缩放过的 Box 或合并几何不会拉伸；兼容 InstancedMesh
  repeat: 2 | [x,y],      // 使用模型自带 UV 时的平铺次数（clone 贴图只复制 transform，共享同一 Source，不会重复上传）
  tint: '#a94436',        // 让贴图的平均色向 tint 靠拢（保留原场景配色），同时保留纹理细节
  tintMix: .6,            // 0 = 原贴图色，1 = 完全使用 tint
  quality: 'high'|'low',  // high = MeshStandardMaterial（带 roughnessMap）；low = MeshLambertMaterial + normalMap（手机低档）
  size: 256, side, opacity
}) → Material             // 按参数缓存，相同参数返回同一个材质对象
TG_REAL.texture(name, 'map'|'normal'|'roughness'|'canvas'|'mean', {size}) → Texture
TG_REAL.applyPreset(renderer, scene, presetName, {hemi, sun, toneMapping:'neutral'|'aces'|'agx'|'none', exposure,
                    env:true, shadows:'mobile'|'soft'|false, fog:true, background:true, keepSunPosition, shadowMapSize})
TG_REAL.resetPreset(renderer, scene)     // 恢复第一次 apply 之前的雾、背景、环境、色调映射和灯光
TG_REAL.upgradeScene(root, {quality, tintMix, map:{[materialUuid|'#hex']: name}, filter(mesh), includeTextured}) → {swapped, skipped, byName}
TG_REAL.restoreScene(root?)              // 还原 material 引用（不传 root 则还原全部）
TG_REAL.install({upgrade:true, quality, toneMapping})  // 可选：包装 worldEnter 和 tgAnimate，幂等
TG_REAL.applyToActive()                  // 立即对 W3.active 场景套用预设并升级材质
TG_REAL.setEnabled(bool)                 // 总开关（关闭时还原材质和预设）
TG_REAL.update(dt)                       // 推进水面流动（install 后会自动在 tgAnimate 里调用）
TG_REAL.stats(renderer) → {calls, triangles, textures, geometries, programs}
TG_REAL.dispose()
TG_REAL.names / presets / aliases / textureSize / quality / toneMapping
```

### 预设（暖金色调）
预设包括 `gate`、`plaza`、`market`、`yard`、`lotus`、`hall`、`zen`、`study` 和 `teahouse`，其中 `tea` 是 `teahouse` 的别名（游戏里茶会小院的 id 是 `tea`）。每个预设设置以下内容：
- 背景色；
- 暖色 `THREE.Fog`（near/far 按场景调好）；
- 半球光的天空色、地面色和强度；
- 金色主光的颜色和强度；
- 曝光；
- `environmentIntensity`。

默认色调映射是 **Khronos PBR Neutral**（`NeutralToneMapping`），可以保留色相和饱和度，最接近要求的风格化写实。ACES 偏灰、偏对比，AgX 更灰，对比图见 `qa/r6-shots/tonemap-plaza-*.png`。
环境贴图优先使用 `THREE.RoomEnvironment`（r170 核心包里没有，属于 addons）。没有时用程序化的暖色天空球，经 PMREM 生成，每个 renderer 只生成一次。
阴影使用 `mobile` 档位：`PCFShadowMap`，bias -.0004，normalBias .03，不改 mapSize（除非传入 `shadowMapSize`）。

### upgradeScene 的启发式规则
- 只处理 Lambert/Standard/Phong 材质的单材质 Mesh。以下情况跳过：
  - 有 map、透明、自发光或使用顶点色的材质；
  - 尺寸小于 .45m 的小件；
  - Sphere/Cone 等非盒状几何（树冠、人物、动物）。
- art2 已知的贴图材质（`art2:stone/wood/path/water`）会映射到对应材质，并带暖色 tint。
- 按 HSL 和形状分类：
  - 蓝色且扁平 → `water`
  - 绿色、扁平且位置低 → `grass`
  - 红色：大面墙 → 红 `plaster`，柱子和梁 → `lacquer`
  - 深褐 → `wood`；扁平的暖褐 → `soil`；米色地面 → `bluestone`
  - 灰色：位置高 → `roofTile`，扁平 → `bluestone`，大面墙 → `brick`，很浅 → `plaster`
- 原材质存在 `mesh.userData.__tgRealOrig`，用 `restoreScene` 可 100% 还原（已测试，还原后剩余数量为 0）。
- 不想被处理的物体设置 `mesh.userData.tgRealSkip=true`。分类结果也可以用 `opts.map` 强制指定。

## codex 接入步骤
1. 在 `pack.mjs` 的 `__WORLD__` 拼接里加入 realism.js，放在 art3.js 之后、r6.js 之前（目前它已经在包里了）：
   `+"\n"+fs.readFileSync(path.join(dir,"realism.js"),"utf8")`
2. 在世界初始化之后（例如 r6.js 末尾）调用：
   ```js
   if(window.TG_REAL){TG_REAL.install({upgrade:true,quality:'high'});TG_REAL.applyToActive();}
   ```
   - `install` 包装 `worldEnter`：原函数每次进场都会重设雾和灯，包装后在它之后套用预设，并升级当前场景的材质。
   - `install` 也包装 `tgAnimate`，在里面调用 `TG_REAL.update(dt)`。
3. 可选：在设置面板加「写实画质」开关，调用 `TG_REAL.setEnabled(on)`；低端机用 `install({quality:'low'})`。
4. 新增的模型可以直接用 `TG_REAL.material('wood',{worldUV:true})`。

## 性能
- 材质替换只换引用，**draw call 和三角面数完全不变**（实测 plaza 62/36k、market 141/62k、gate 63→72，gate 多出来的是相机视角变化）。
- 10 种材质的贴图（256px）首次生成约 360ms，用的是 swiftshader 软件渲染，真机通常更快。贴图按需懒生成，只有用到的材质才会生成。
- 每个场景大约增加 16 个 shader program（plaza 实测 15 → 31），首次进入场景会有一次编译开销。贴图纹理数 13 → 38，其中 30 张是材质贴图，另有 1 张环境贴图。
- `update(dt)` 每帧只修改一个共享 uniform，没有任何对象分配。

## 已知限制
- 世界 UV 是盒式投影：斜屋顶按主法线轴投影，45° 附近会有接缝。圆柱侧面会按 xz/zy 切换投影。
- 分类是启发式的，个别物件可能选错材质（例如某个绿色摊位顶）。可用 `opts.map` 或 `tgRealSkip` 修正。
- 只有 Standard 材质吃环境光，未升级的 Lambert 物体相对会稍暗一点。
- 截图见 `qa/r6-shots/`：
  - `swatches-*`
  - `game-before-after-{a,b,c}.png`
  - `game-*-before/after(-overview).png`
  - `tonemap-plaza-*.png`
- 测试脚本在 `qa/r6-tools/`：`swatches.mjs`、`game-ba.mjs`、`tm.mjs`。
