# mounts.js：坐骑模型和骑乘动画（r6）

这是独立的新文件，**还没有**加进 `pack.mjs`，也没有接进游戏逻辑。现有文件一个都没改。
画风按王者荣耀家园的「精致风格化写实」来做：暖色、圆润的体块，明暗烘焙在顶点色里（上亮下暗，相当于假 AO）。不发光，也没有玄幻特效。

## 接入步骤（给 codex）

1. **pack.mjs**：把 `"mounts.js"` 加进第 14 行那个可选文件数组，放在 `animals2.js` 后面：
   ```js
   ["animals2.js","mounts.js","audio.js","r5.js"].filter(f=>fs.existsSync(path.join(dir,f)))...
   ```
   这个模块只依赖全局 `THREE`。它和 avatar.js、realism.js 谁先加载都行，因为它是在运行时才去查找 `TG_AVATAR` / `TG_REAL`。
2. **上坐骑**：坐骑挂在 `W3.player` 下面，跟着玩家走；玩家身体（`W3.body`）挂到座位上。
   ```js
   const m = TG_MOUNTS.build('whitehorse', savedDeco);      // savedDeco 可省略
   W3.player.add(m);                                        // 寻路、朝向代码不用改
   TG_MOUNTS.mount(m, W3.body, 0, {limbs: W3.limbs});       // 默认角色：limbs=[左臂,右臂,左腿,右腿]
   // TG_AVATAR 角色：TG_MOUNTS.mount(m, avatarGroup)        （会自动识别 userData.parts.legL/legR/armLJ/armRJ）
   ```
3. **每帧**（tgAnimate 里）：
   ```js
   const st = moving ? (fast ? 'trot' : 'walk') : 'idle';
   TG_MOUNTS.animate(m, st, ts, speedRatio);   // ts 用毫秒，和 tgAnimate 一样
   // 玩家走路时，现有的四肢摆动会覆盖骑姿，所以骑乘时要跳过 W3.limbs 的走路动画，
   // 或者在它后面补一句 TG_MOUNTS.reapplyPose(W3.body)。TG_AVATAR.animate 也一样。
   ```
   移动速度可以用 `TG_MOUNTS.groundSpeed(kind, st)` 拿世界速度，让脚步不打滑：马慢步 1.3、快步 3.0 单位/秒。
4. **下坐骑**：`TG_MOUNTS.dismount(m, W3.body)` 会把骑手放回原来的父节点，并恢复原来的位置和四肢角度。然后 `TG_MOUNTS.dispose(m)`。
5. **相机和碰撞**（要改现有代码，由 codex 处理）：
   - 骑乘时 `w.follow` 的 y 从 1.1 调到大约 2.0，`w.radius` 加 1–2。
   - 寻路半径：马大约 1.0；牛车大约 1.6，车身向后伸约 3 单位。
6. **联网同步**：`TG_MOUNTS.toJSON(m)` 返回 `{kind, deco}`，是纯数据。另一端用 `TG_MOUNTS.fromJSON(j)` 重建，用 `animate` 状态就能同步步态。

## API

```js
window.TG_MOUNTS = {
  __v: 1,                                   // 幂等标记，重复加载直接 return
  kinds() -> ['donkey','oxcart','chestnut','whitehorse','whitedeer','greenox'],
  info: { kind: {name, emoji, seats, cart, defaultDeco, exclusive[], speed:{walk,trot}, seatHeight} },
  decoNames, decoOptions(kind) -> {saddle[], bridle[], bells[], colors:['saddleColor','bridleColor']},
  defaultDeco(kind),
  build(kind, deco?) -> THREE.Group | null,        // 未知 kind 时 console.warn 并返回 null
  setDeco(mount, decoPatch) -> 规范化后的 deco,     // 只换装饰网格，骑手不动
  getSeats(mount) -> [Object3D...],                 // 骑手挂点；牛车有 2 个
  mount(mount, rider, seatIndex?, opts?) -> seat,   // opts: {limbs|legs/arms, hipY, legLen, lift, z, generic}
  dismount(mount, riderOrSeatIndex) -> rider,
  riders(mount) -> [rider|null...],
  animate(mount, 'idle'|'walk'|'trot', tMs, speed=1),
  groundSpeed(kind, state, speed=1) -> 单位/秒,
  poseRider(rider, 'straddle'|'bench'|null, opts), unposeRider(rider), reapplyPose(rider),
  dispose(mount),          // 先下骑手，再从场景移除；共享几何不释放
  purge(),                 // 释放全部缓存的几何和材质（切场景或退出时可选）
  stats(mount) -> {meshes, drawCalls, triangles},   // 不含骑手
  config({lambert, real, realGain, shadows}),       // 在 build 之前调用
  toJSON(mount), fromJSON(json), palette
}
```

- **坐标约定**：和 r3、animals2 一致，地面在 y=0，头朝 +Z。比例和现在的默认角色（约 1.65 高）以及 TG_AVATAR（约 2.0 高）都能配合，马背高约 1.33。
- **层级**：
  - `group`：调用方负责 position、rotation.y、scale。
  - `userData.rig`：由 animate 负责起伏、俯仰和侧摆。
  - rig 下面是 `body`、`neck → head`、`tail`、`legs[4]`（每条腿是 `hip → knee`）、座位和鞍具。
  - 牛车多一层：`group → cart`（车厢不跟牛一起起伏）`→ wheels[2]`，2 个座位挂在 cart 上。
- **animate**：步态相位累加在 `userData.anim` 里，所以中途改速度不会跳帧。dt 被限制在 0–100ms，可以暂停，也可以跳帧。
  - **腿**：walk 是四拍侧对序（后左→前左→后右→前右），trot 是对角两拍。切换时腿的相位会平滑过渡。
  - **头颈**：随步频点头。没人骑、处于 idle 时会周期性低头吃草，牛车除外，因为套着轭。待机时还会左右张望。
  - **尾巴**：甩尾，快步时会抬起来。
  - **铃铛**：按钟摆规律摆动。
  - **牛车**：车轮按移动距离滚动，车厢轻轻晃动。
- **缰绳**：每个坐骑有两份缰绳网格。没人骑时缰绳搭在颈根，低头吃草也不会穿模；`mount` 之后切换成「握在鞍桥上」，牛车则是握在车夫手里。
- **骑姿 poseRider**：
  - 如果 `TG_AVATAR.setPose / pose / applyPose` 存在，会优先调用 `fn(rider, 'ride'|'sit'|'idle', {style, mount})`，返回 truthy 就不再做通用骑姿。avatar.js 的 `TG_AVATAR.setPose` 已经实现了这个接口。
  - 通用骑姿会按以下顺序找四肢：`opts.limbs` → `userData.legs/arms` → `userData.limbs[4]`（默认角色）→ `userData.parts.legL/legR/armLJ/armRJ`（TG_AVATAR）→ 名字里带 leg/arm 的节点。
  - 传进来的 `limbs / legs / arms` 只有确实挂在 rider 节点下的才会用；不属于 rider 的会被忽略，并退回到 rider 自己的四肢（S1-10）。
  - **跨骑**：两腿外分的角度会根据「马身半宽 − 胯宽」和腿长自动算出来，保证腿不穿进马身。双手前伸握缰。
  - **车凳**：坐在车头，双腿自然下垂、略向前。
  - 原来的关节角度会存下来，`unposeRider` 时恢复。
  - 胯高通过腿关节的世界坐标自动计算，也可以手动传 `opts.hipY`。

## 种类

| kind | 名称 | 尺寸 宽×高×长（侧向摆放实测） | 座位 | 默认装饰 |
|---|---|---|---|---|
| donkey | 小毛驴 | 0.6 × 1.62 × 1.5 | 1 | 粗布鞍毯、麻绳笼头、铜项铃 |
| oxcart | 黄牛车 | 1.6 × 1.42 × 4.2 | 2（车凳） | 软垫、麻绳鼻绳、铜项铃 |
| chestnut | 枣红马（白额、白后蹄） | 0.6 × 1.83 × 2.0 | 1 | 素皮马鞍、皮革辔头 |
| whitehorse | 白马 | 0.6 × 1.83 × 2.0 | 1 | 朱红锦鞍、红缨辔头、**银鞍铃（专属）** |
| whitedeer | 白鹿（自然鹿角，不发光） | 0.5 × 2.11 × 1.5 | 1 | 青金织锦鞍、金饰辔头、串铃 |
| greenox | 青牛（水牛体型，青黑色，有新月形角和喉部浅色纹） | 0.8 × 1.46 × 2.3 | 1 | 粗布鞍毯、麻绳、铜项铃 |

## 装饰（deco）

```js
{ saddle, bridle, bells, saddleColor?: '#hex', bridleColor?: '#hex' }   // 颜色传 null 表示清除
```

| 槽位 | 骑乘类 | 牛车 |
|---|---|---|
| saddle | `none`、`blanket` 粗布鞍毯、`plain` 素皮马鞍、`red` 朱红锦鞍（金边和流苏）、`brocade` 青金织锦鞍 | `bench` 素车凳、`cushion` 软垫、`canopy` 竹篷加软垫 |
| bridle | `none`、`rope` 麻绳、`leather` 皮革、`red` 红缨辔头（牛是额前大红花）、`gold` 金饰 | 同左（牛用鼻环） |
| bells | `none`、`bronze` 铜项铃、`string` 红绳串铃、`silver` 银鞍铃加胸带（**仅限 whitehorse**） | 同左 |

非白马传 `silver` 时会 console.warn，并自动降级成 `bronze`。不支持的值会回到默认值。`setDeco` 采用合并语义，只改传进来的字段。

## 性能

- **几何**：每个可动部件只有一个合并的 BufferGeometry，包含 position、normal、uv、color 和 index。按「kind | 部件 | 装饰样式 | 颜色」全局缓存，同种坐骑共用同一份。30 只坐骑实测一共 83 份几何。
- **材质**：全局只有 3 个，coat (rough .82)、gloss (rough .5) 和 metal，都用顶点色。`config({lambert:true})` 可以换成 Lambert（低端机用）。
- **animate**：只做标量运算，不新建对象。实测平均每次调用约 2.8 µs（swiftshader，30 只 × 1000 帧）。
- **build**：首次构建某个组合需要几毫秒，之后走缓存，约 0.3 ms 一只。
- **阴影**：所有网格都 castShadow，所以阴影 pass 会再算一遍 draw call。远处的坐骑可以 `config({shadows:false})` 后再 build，或者直接把 `castShadow` 关掉。
- **TG_REAL**：`config({real:true})` 时，牛车木件会借用 `TG_REAL.material('wood')` 的贴图，同时保留顶点色。默认关闭，因为这份木纹贴图偏红偏暗，对比图见 `qa/r6-shots/mounts-real-wood-compare.png`（左边是开启，右边是关闭）。realism.js 的 `upgradeScene` 会跳过顶点色材质，不会把坐骑替换掉。

### 每只坐骑的三角面和 draw call（默认装饰，不含骑手）

| kind | draw calls（主 pass） | 三角面 |
|---|---|---|
| donkey | 17 | 5,906 |
| oxcart | 21 | 8,154 |
| chestnut | 15 | 6,298 |
| whitehorse | 19 | 9,000（银鞍铃加胸带约占 2.9k） |
| whitedeer | 17 | 7,904 |
| greenox | 17 | 6,414 |

draw call 的大头是腿（8 个），因为大腿和小腿要分开动画。如果要再省，可以去掉膝关节，改成单段腿：每只少 4 个 draw call，代价是动画会硬一些。另外 `none` 装饰会省掉 1–4 个。

## 已知限制

1. **长袍骑手会穿模**：TG_AVATAR 的长款服装（直裰、襦裙、圆领袍、广袖长袍）下摆是 torso 网格的一部分，坐下以后下摆仍然垂到地面，会穿过马身或车凳，见 `qa/r6-shots/mounts-ride-longrobe-limitation.png`。短打效果正常。需要 avatar.js 提供 `setPose(rider,'ride'|'sit')`，在骑乘时把下摆换成分开或收短的版本。本模块已经会自动调用这个接口。
2. **单段腿骑手**：默认角色和 TG_AVATAR 的腿都没有膝关节，跨骑时是直腿外分，坐车时是直腿下垂，没法做出屈膝踩镫的样子。
3. **缰绳是静态网格**：缰绳挂在颈部，点头时末端会相对鞍桥轻微漂移（≤3cm），不是物理绳。
4. **牛车不做转弯物理**：车厢和牛是刚性一体的，转弯时整车绕 group 原点旋转，没有车辕铰接。
5. **鞍具贴合**：鞍毯是贴着躯干椭球的面片。快步时腿和胸的摆动可能让鞍毯下摆边缘和前腿上端有 1–2cm 的接触。

## 测试

在 `/tmp/mounts/` 的副本上用 Playwright + 无头 Chrome（swiftshader）测试，脚本是 `qa/r6-shots/mounts-test.mjs`，参数为 `lineup | close | deco | walk | ride | checks | all`；加 `AVATAR=1` 时用真实的 TG_AVATAR 骑手。

- 所有 kind 在 idle/walk/trot 下各跑 4 秒（speed 1.3），没有 NaN。
- 包围盒 minY ≈ 0，蹄子贴地。
- `build` 不会改 group 自身的变换。
- 下马后骑手回到原父节点，位置和关节角度复原。
- 缰绳会在「搭颈」和「握持」之间正确切换。
- 控制台没有报错。
- `qa/r6-shots/mounts-s110-test.mjs`（S1-10 回归）：传入别的模型的 limbs 时，那些 limbs 不会被动，rider 自己的腿正常摆骑姿；同一时间戳再次调用 `animate`（dt=0）时，`amp/trot` 混合值保持不变，不会跳变（只有第一次调用会直接到位）。

截图在 `qa/r6-shots/mounts-*.png`：
- `lineup`、`lineup-walk`：全部种类
- `close-<kind>`：单只近景
- `deco-<kind>`：各种装饰组合
- `walk-<kind>-<walk|trot>`：同一只摆 4 个，分别停在步态周期的 0、¼、½、¾
- `ride`、`ride-close-whitehorse`、`ride-close-oxcart`（牛车坐 2 人）、`ride-trot`：TG_AVATAR 骑手
- `*-placeholder.png`：占位骑手
- `ride-longrobe-limitation`：长袍穿模问题
