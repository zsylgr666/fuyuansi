/* r7d: secular stall copy + full plaza re-layout around the center tree. */
(()=>{'use strict';
const T=typeof THREE!=='undefined'&&THREE||window.THREE;

/* ---------- 1. Secular wording for 读心笺 / 赏园景 / 诗笺 / help ---------- */
const DIR_NOTE={
  '北':'院子朝北，光线比较柔和，门口放一盆绿植很安静。',
  '南':'院子朝南，光照充足，适合晒一晒太阳。',
  '东':'院子朝东，能见到晨光，适合早起散步。',
  '西':'院子朝西，傍晚能看到晚霞，下午记得拉帘防晒。',
  '东南':'东南这一侧比较敞亮，适合放一张书桌。',
  '西南':'西南这一侧比较暖，适合放全家福或暖色灯光。',
  '东北':'东北这一侧比较安静，适合放书柜。',
  '西北':'西北这一侧保持整洁明亮，看着也舒服。'
};
const HEART=[
  '慢慢走，把眼前这一步走踏实。','心平气和，事情会一件一件清楚起来。','先照顾好自己，再去帮忙别人。',
  '遇到岔路，先停一停，再决定怎么走。','今天适合读几页书，或把桌子整理一下。','不必着急，给自己留一点空闲。',
  '和朋友说说话，心里会宽敞许多。','把小事做好，大的安排自然会来。','天气好就出去走走，天气不好就歇一歇。',
  '有人帮一把，记得说一声谢谢。','累了就休息，明天再继续。','守住自己的节奏，不必跟别人比。',
  '把想做的事写下来，一步一步做。','家里灯亮着，便是最好的方向。','笑一笑，许多烦恼会轻一些。',
  '把答应别人的事放在心里，也别忘了答应自己的。','路还长，先走好今天这一段。','喝一口水，再看看窗外。',
  '少说一句气话，多留一点余地。','愿意动手的人，总比空想更踏实。','把窗打开，让风进来。',
  '选择一条路就认真走，不必回头反复改。','安静的下午，也值得被记住。','把桌子擦干净，心情也会干净一些。',
  '给自己一点耐心，就像对待一棵树。','有欢喜就分享，有困难就慢慢想办法。','不必把所有事情一次做完。',
  '友邻近，路也不远。','花开有时，等一等也很好。','把脚步放轻，把话说软。',
  '今天适合写信，或给家里打个招呼。','看见好事，就学着做一点。','雨停之后，路会更好走。',
  '把旧的烦恼放下，腾出地方给新的计划。','午饭吃饱，人也有力气。','与人合作，先把各自的事说清楚。',
  '不必完美，认真就很好。','夜晚早点休息，明天会更清楚。','把花浇一浇，把椅子摆一摆。',
  '听到不同的声音，先听完再说话。','把想去的地方记在本子上。','小院里的光，够用一天。',
  '对别人宽一点，对自己也宽一点。','把路让给别人，自己也不吃亏。','做一点家务，心里会踏实。',
  '把今天的收获收进篮子里。','遇到难题，先把它分成小块。','站在树下，看看叶子怎么动。',
  '把感谢说出来，比放在心里更暖。','走得慢一些，才看得见路边的花。','把窗户边的尘土擦掉。',
  '有始有终，一件事做完再做下一件。','把温暖留给身边的人。','不必赶路，方向对就好。',
  '把茶泡上，坐一会儿。','愿意请教的人，进步会快一点。','把乱掉的线理顺，再继续织。',
  '今天适合安静一会儿，不必着急。','今天适合整理房间，把不用的东西收起来。','把好天气用在散步上。',
  '和家人一起吃一顿饭。','把心里的话说清楚，误会就会少。','树在这里，你也在这里，这样就很好。'
];
function heartLine(n){return HEART[Math.abs(n|0)%HEART.length];}

// r8c-clean（codex2 建议）：旧摊位模板已从 gameplay.js 删除，这里不再需要逐词替换表；函数保留为直通，供旧调用点使用。
function scrubText(s){return s;}

function secularGua(){
  const h2=$('#sheet h2');if(h2)h2.textContent='今日心语';
  const intro=$('#sheet h2 + p');if(intro)intro.textContent='轻轻摇几次铜钱，读一句今天的心语。';
  const lines=$('#guaLines');if(lines)lines.style.display='none';
  const step=$('#guaStep');
  if(step){
    const m=step.textContent.match(/(\d+)\s*\/\s*6/);
    if(/已成|读完|备/.test(step.textContent)&&!m)step.textContent='心语已备';
    else if(m)step.textContent='第 '+m[1]+' / 6 次';
    else step.textContent=scrubText(step.textContent);
  }
  const auto=$('#autoBtn');if(auto)auto.textContent='一次读完';
  const shake=$('#shakeBtn');if(shake)shake.textContent='🪙 摇一次';
  const again=$('#againBtn');if(again)again.textContent='再读一句';
  const box=$('#guaResult');
  if(box&&box.innerHTML&&!box.dataset.r7d){
    const name=box.querySelector('.gua-name');
    let no=1;
    if(name){const mm=name.textContent.match(/(\d+)/);if(mm)no=+mm[1];}
    box.dataset.r7d='1';
    box.innerHTML='<div class="card"><div class="gua-name">今日心语</div>'
      +'<p class="center" style="font-size:16px;margin:8px 0">'+heartLine(no)+'</p>'
      +'<p style="font-size:12px;color:#9a7a50;margin-bottom:0">读一句就好，不必当作预测。</p></div>'
      +'<p class="center" style="margin-top:12px"><button class="btn" id="againBtn">再读一句</button></p>';
    const b=$('#againBtn');if(b)b.onclick=openGua;
  }
}

function secularFeng(){
  const h2=$('#sheet h2');if(h2)h2.textContent='赏景小记';
  const intro=$('#sheet h2 + p');
  if(intro&&!intro.querySelector('button,select,input'))intro.textContent='选一个年份和院子朝向，写下今天的赏景小记。';
  for(const el of $('#sheet').querySelectorAll('p,div,span,label')){
    if(!el.childElementCount&&el.textContent.trim()==='大门朝向')el.textContent='院子朝向';
  }
  const btn=$('#fengBtn');if(btn)btn.textContent='写一写';
  const lab=document.querySelector('label[for="fengYear"]');if(lab)lab.textContent='出生年份';
  const box=$('#fengResult');
  if(box&&box.innerHTML&&!box.dataset.r7d){
    const dir=window.fengDir||'南';
    const tags=[...box.querySelectorAll('.tag')].map(t=>t.textContent.trim()).filter(Boolean);
    const swatches=[...box.querySelectorAll('.swatch')].map(el=>{
      const name=el.nextSibling&&el.nextSibling.textContent?el.nextSibling.textContent.trim():'';
      return '<span class="swatch" style="background:'+el.style.background+'"></span>'+(name||'');
    });
    const yi=tags.slice(0,4),ji=tags.slice(4,7);
    box.dataset.r7d='1';
    box.innerHTML='<div class="card">'
      +'<p>'+(DIR_NOTE[dir]||('院子朝向是'+dir+'。'))+'</p>'
      +(swatches.length?'<p><b>今日配色：</b>'+swatches.join('　')+'</p>':'')
      +(yi.length?'<p style="margin-bottom:2px"><b>可以试试</b></p><div class="tagrow">'+yi.map(t=>'<span class="tag yi">'+t+'</span>').join('')+'</div>':'')
      +(ji.length?'<p style="margin-bottom:2px"><b>今天不妨少做</b></p><div class="tagrow">'+ji.map(t=>'<span class="tag ji">'+t+'</span>').join('')+'</div>':'')
      +'<p style="font-size:12px;color:#9a7a50;margin-bottom:0">小记每天更新，只作欣赏，不是预测。</p></div>';
  }
}

function secularQian(){
  const h2=$('#sheet h2');if(h2&&/诗笺/.test(h2.textContent))h2.textContent='每日寄语';
  const intro=$('#sheet h2 + p');if(intro&&/所求/.test(intro.textContent))intro.textContent='读一句诗，给今天留一点从容。';
  const body=$('#tube .body');if(body)body.textContent='诗句';
  const b=$('#qianBtn');if(b)b.textContent='抽一首诗';
  const again=$('#qianAgain');if(again)again.textContent='再读一句';
  for(const st of document.querySelectorAll('#tubeWrap .outstick, .outstick')){
    const t=st.textContent||'';
    const m=t.match(/(\d+)/);
    if(m)st.textContent='第'+m[1]+'首';
  }
}

function secularHelp(){ /* r8c-clean：玩法说明已在 gameplay.js 源头改好，不再需要运行时替换 */ }

function secularAll(){
  if(!$('#sheet'))return;
  if($('#guaLines')||$('#guaResult')||$('#shakeBtn'))secularGua();
  if($('#fengYear')||$('#fengResult')||$('#fengBtn'))secularFeng();
  if($('#qianResult')||$('#tubeWrap')||$('#qianBtn'))secularQian();
  secularHelp();
}

const _openGua=openGua;openGua=function(){const o=_openGua.apply(this,arguments);secularGua();return o;};
const _shake=typeof shakeOnce==='function'?shakeOnce:null;
if(_shake){shakeOnce=function(){const o=_shake.apply(this,arguments);setTimeout(secularGua,0);setTimeout(secularGua,650);return o;};}
const _showGua=typeof showGuaResult==='function'?showGuaResult:null;
if(_showGua){showGuaResult=function(){const o=_showGua.apply(this,arguments);secularGua();return o;};}
const _openFeng=openFeng;openFeng=function(){const o=_openFeng.apply(this,arguments);secularFeng();return o;};
const _showFeng=typeof showFeng==='function'?showFeng:null;
if(_showFeng){showFeng=function(){const o=_showFeng.apply(this,arguments);secularFeng();return o;};}
const _openModal=openModal;openModal=function(){const o=_openModal.apply(this,arguments);secularAll();return o;};
const _drawQian=drawQian;drawQian=function(){const o=_drawQian.apply(this,arguments);[0,1400,1500,2300,2500].forEach(t=>setTimeout(secularQian,t));return o;};

let queued=false;
const obs=new MutationObserver(()=>{
  if(queued)return;
  queued=true;
  queueMicrotask(()=>{
    try{obs.disconnect();secularAll();}
    finally{
      if($('#sheet'))obs.observe($('#sheet'),{subtree:true,childList:true,characterData:true});
      requestAnimationFrame(()=>{queued=false;});
    }
  });
});
if($('#sheet'))obs.observe($('#sheet'),{subtree:true,childList:true,characterData:true});

/* ---------- 2. Plaza re-layout: tree at center, props move out ---------- */
const DOOR=22, LIMIT=24;
const CANOPY_R=7.1, ROOT_R=2.9, TRUNK_R=1.5;
const RING_R=10;
window.TG_R7D_PLAZA={door:DOOR,limit:LIMIT,canopy:CANOPY_R,ring:RING_R,report:null};

function moveInstances(root,ox,oz,nx,nz,rad){
  // r8 understands baked connected components as well as instances. Never move
  // parts of the central tree while relocating nearby furnishings.
  return window.TG_R8.relocate(root,ox,oz,nx,nz,rad);
}

function moveBlocks(ox,oz,nx,nz,rad){
  const dx=nx-ox,dz=nz-oz,s=W3.spaces.plaza;
  for(const b of s.blocks){
    const cx=(b.x+b.X)/2,cz=(b.z+b.Z)/2;
    if(Math.hypot(cx-ox,cz-oz)<=rad){b.x+=dx;b.X+=dx;b.z+=dz;b.Z+=dz;}
  }
}

function moveCluster(ox,oz,nx,nz,rad){
  const p=W3.spaces.plaza;
  moveInstances(p.group,ox,oz,nx,nz,rad);
  moveBlocks(ox,oz,nx,nz,rad);
}

function moveDoorGroup(oldx,oldz,nx,nz,to){
  const p=W3.spaces.plaza;
  for(const ch of p.group.children){
    if(!ch.isGroup)continue;
    if(Math.abs(ch.position.x-oldx)<.2&&Math.abs(ch.position.z-oldz)<.2){
      ch.position.set(nx,0,nz);
    }
  }
  for(const e of p.exits){
    if((to&&e.to===to&&Math.abs(e.x-oldx)<.4&&Math.abs(e.z-oldz)<.4)||(!to&&Math.abs(e.x-oldx)<.4&&Math.abs(e.z-oldz)<.4)){
      e.x=nx;e.z=nz;
    }
  }
  for(const it of p.items){
    if(Math.abs(it.x-oldx)<.5&&Math.abs(it.z-oldz)<.5&&/前往|进入/.test(it.label||'')){
      it.x=nx;it.z=nz;
    }
  }
  moveBlocks(oldx,oldz,nx,nz,2.4);
}

function moveNorthWall(dz){
  const p=W3.spaces.plaza, world=new T.Vector3();
  const seen=new Set();
  const should=node=>{
    if(!node||seen.has(node)||node.name==='art3-plaza'||node.name==='r7-wish-tree'||node.name==='r7b-wish-rack'||node.name==='r7d-tree-ring')return false;
    if(node===p.floor||node.userData&&node.userData.r7dPath)return false;
    node.getWorldPosition(world);
    const sz=node.scale&&node.scale.z||0;
    if(sz>20)return false; // long axial path
    // original ceremonial wall / lintel / roof around z=-12, or already mid-move leftovers
    if(world.z>-14.6&&world.z<-9.6&&Math.abs(world.x)<16)return true;
    return false;
  };
  const moveNode=node=>{
    if(!should(node))return;
    seen.add(node);
    if(node.isInstancedMesh){
      const m4=new T.Matrix4(),pos=new T.Vector3(),q=new T.Quaternion(),s=new T.Vector3();
      let changed=false;
      for(let i=0;i<node.count;i++){
        node.getMatrixAt(i,m4);m4.decompose(pos,q,s);
        const wz=pos.z; // art3-plaza is at origin
        if(wz>-14.6&&wz<-9.6&&Math.abs(pos.x)<16){pos.z+=dz;m4.compose(pos,q,s);node.setMatrixAt(i,m4);changed=true;}
      }
      if(changed){node.instanceMatrix.needsUpdate=true;if(node.computeBoundingSphere)node.computeBoundingSphere();}
      return;
    }
    node.position.z+=dz;
  };
  // Move groups first so children inherit, then unmoved loose meshes.
  p.group.children.forEach(ch=>{
    if(ch.isGroup&&Math.abs(ch.position.z+12)<.8&&Math.abs(ch.position.x)<1){ch.position.z+=dz;seen.add(ch);return;}
  });
  p.group.traverse(moveNode);
  for(const e of p.exits)if(e.to==='yard'&&Math.abs(e.x)<1&&e.z<-9&&e.z>-15)e.z=-DOOR;
  for(const it of p.items)if((/进入院子|心田小院/.test(it.label||''))&&it.z<-9&&it.z>-15)it.z=-DOOR;
  for(const b of p.blocks){
    const cz=(b.z+b.Z)/2;
    if(cz>-14.6&&cz<-9.6&&Math.abs((b.x+b.X)/2)<16&&(b.Z-b.z)<8){b.z+=dz;b.Z+=dz;}
  }
  // Second pass: meshes whose origin stayed at 0 but whose geometry still sits at z≈-12.
  const box=new T.Box3();
  p.group.traverse(m=>{
    if(!m.isMesh||m.isInstancedMesh||m===p.floor||m.userData.r7dPath)return;
    if(m.name==='r7-wish-tree'||m.name==='r7d-tree-ring')return;
    box.setFromObject(m);
    const cz=(box.min.z+box.max.z)/2,cx=(box.min.x+box.max.x)/2;
    if(cz>-14.6&&cz<-9.6&&Math.abs(cx)<16&&(box.max.z-box.min.z)<8&&(box.max.y-box.min.y)>0.2){
      m.position.z+=dz;
      m.updateMatrixWorld(true);
    }
  });
}

function relocateStalls(){
  const p=W3.spaces.plaza;
  const from=[{x:-11,z:2,l:'读心笺'},{x:11,z:2,l:'抽每日诗笺'},{x:11,z:9,l:'赏园景'}];
  const to=[{x:-16,z:8,l:'今日心语'},{x:16,z:8,l:'每日寄语'},{x:16,z:-8,l:'赏景小记'}];
  // also catch unmoved original stall leftovers
  const extra=[{x:-4.8,z:1},{x:4.8,z:1},{x:7,z:7}];
  from.forEach((a,i)=>{
    const b=to[i];
    moveCluster(a.x,a.z,b.x,b.z,2.4);
    extra.forEach(e=>moveCluster(e.x,e.z,b.x,b.z,2.2));
  });
  p.items=p.items.filter(it=>!/读心笺|抽每日诗笺|每日诗笺|赏园景|赏景小记/.test(it.label||''));
  p.blocks=p.blocks.filter(b=>{
    const cx=(b.x+b.X)/2,cz=(b.z+b.Z)/2;
    return !to.concat(from).some(s=>Math.hypot(cx-s.x,cz-s.z)<2.2);
  });
  const runs=[()=>openGua(),()=>openQian(),()=>openFeng()];
  to.forEach((s,i)=>{
    p.blocks.push({x:s.x-1.55,X:s.x+1.55,z:s.z-.85,Z:s.z+.85});
    worldLabel(p.group,s.l,s.x,2.1,s.z+.76,2.6);
    worldInteract(p,s.x,s.z+1.65,s.l,runs[i]);
  });
}

function relocateTreesAndFigures(){
  // world3d / art2 shade trees and art3 pines / ginkgo
  const moves=[
    // art3 pines and bases
    [-7.6,-8.4,-18,-16,2.2],
    [8.9,-3.9,18,-16,2.2],
    [-7.2,10.6,-18,16,2.2],
    // world3d / art2 trees
    [-12,-7,-18,-8,2.0],
    [12,-7,18,-8,2.0],
    [-12,8,-18,8,2.0],
    [12,10,18,12,2.0],
    // cat and seated figure
    [10,6,14,12,1.6],
    [10.4,6,14.4,12,1.2],
    [-10,5,-14,12,1.6]
  ];
  for(const [ox,oz,nx,nz,rad] of moves)moveCluster(ox,oz,nx,nz,rad);
}

function relocateArt3(){
  const art=W3.spaces.plaza.group.getObjectByName('art3-plaza');
  if(!art)return;
  // lions + old stone beasts
  moveCluster(-4,-10,-5.6,-18.6,2.2);
  moveCluster(4,-10,5.6,-18.6,2.2);
  // copper lamp + lotus inlay (subgroup was at x=5, z=-6.5)
  moveCluster(5,-6.5,0,-15.2,2.8);
  // eave lanterns follow the north wall
  for(const x of [-6,-9.5,6,9.5])moveCluster(x,-11.1,x,-21.1,1.2);
  // flag poles out of the canopy, flanking the north path
  moveCluster(-5.8,-3.2,-7,-16.5,2.0);
  moveCluster(5.8,-3.2,7,-16.5,2.0);
  // stone lanterns flank the new 里门
  moveCluster(-4.2,12.2,-5.4,19.6,1.6);
  moveCluster(4.2,12.2,5.4,19.6,1.6);
}

function addRing(){
  const p=W3.spaces.plaza;
  if(p.group.getObjectByName('r7d-tree-ring'))return;
  const g=new T.Group();g.name='r7d-tree-ring';p.group.add(g);
  const posts=[],rails=[],beds=[];
  const n=28;
  // r8a: four openings where the paths meet the ring (north to 心田小院, south from 里门, east 集市, west 茶会);
  // the rail used to be a closed walk-through ring with one wide gap. Openings: [centre angle, half span].
  const gaps=[[-Math.PI/2,.55],[Math.PI/2,.3],[0,.2],[Math.PI,.2]];
  const inGap=a=>gaps.some(([c,w])=>{let d=a-c;while(d>Math.PI)d-=Math.PI*2;while(d<-Math.PI)d+=Math.PI*2;return Math.abs(d)<w;});
  for(let i=0;i<n;i++){
    const a=-Math.PI/2+ (i+.5)/n*Math.PI*2;
    if(inGap(a))continue;
    const x=Math.cos(a)*RING_R,z=Math.sin(a)*RING_R;
    posts.push([x,.38,z,.12,.76,.12]);
    beds.push([x*.96,.08,z*.96,.7,.12,.45,0,-a,0]);
    const a2=a+Math.PI*2/n;
    if(inGap(a2))continue;
    const x2=Math.cos(a2)*RING_R,z2=Math.sin(a2)*RING_R;
    const mx=(x+x2)/2,mz=(z+z2)/2,len=Math.hypot(x2-x,z2-z)+.04,ang=Math.atan2(-(z2-z),x2-x); // r8a: box length runs along local X
    rails.push([mx,.72,mz,len,.07,.08,0,ang,0]);
    // r8a: the rail is a real fence now — colliders in short pieces so diagonal runs stay thin.
    for(let k=0;k<4;k++){const t0=k/4,t1=(k+1)/4,ax=x+(x2-x)*t0,az=z+(z2-z)*t0,bx=x+(x2-x)*t1,bz=z+(z2-z)*t1;
      p.blocks.push({x:Math.min(ax,bx)-.1,X:Math.max(ax,bx)+.1,z:Math.min(az,bz)-.1,Z:Math.max(az,bz)+.1,r8a:'ring rail'});}
  }
  const dummy=new T.Object3D();
  function inst(geo,color,rows){
    const mesh=new T.InstancedMesh(geo,new T.MeshLambertMaterial({color}),rows.length);
    rows.forEach((r,i)=>{dummy.position.set(r[0],r[1],r[2]);dummy.scale.set(r[3],r[4],r[5]);dummy.rotation.set(r[6]||0,r[7]||0,r[8]||0);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});
    mesh.frustumCulled=false;g.add(mesh);return mesh;
  }
  inst(new T.BoxGeometry(1,1,1),'#9a9380',posts);
  inst(new T.BoxGeometry(1,1,1),'#b7af9a',rails);
  inst(new T.CylinderGeometry(.5,.5,.12,8), '#6f8a52', beds);
}

function placeRack(){
  const p=W3.spaces.plaza;
  const rack=p.group.getObjectByName('r7b-wish-rack');
  if(rack)rack.position.set(-16,0,-8);
  p.items=p.items.filter(it=>!(/挂(祈|心)愿牌/.test(it.label||'')&&(Math.hypot(it.x-2.8,it.z-2.5)<2||Math.hypot(it.x,it.z-3)<.8)));
  worldInteract(p,0,3,'挂心愿牌',()=>$('#btnOffer').click(),4.5);
  worldInteract(p,-16,-7.4,'挂心愿牌',()=>$('#btnOffer').click(),2);
  p.blocks=p.blocks.filter(b=>{
    const cx=(b.x+b.X)/2,cz=(b.z+b.Z)/2;
    return Math.hypot(cx-2.8,cz-2)>.8&&Math.hypot(cx+16,cz+8)>.8;
  });
  p.blocks.push({x:-17.2,X:-14.8,z:-8.7,Z:-7.3});
}

function refreshTreeLabel(){
  const p=W3.spaces.plaza;
  // hide old labels near the trunk, add a wide one facing the default camera
  p.group.children.forEach(ch=>{
    if((ch.userData&& (ch.userData.wallSign||ch.userData.r41Label)||ch.isSprite||(ch.material&&ch.material.map))
      && Math.hypot(ch.position.x,ch.position.z-1.3)<2&&/(祈|心)愿/.test(ch.userData&&ch.userData.label||'')){
      ch.visible=false;
    }
  });
  // Remove previous 祈愿古树 sprites close to origin at y~3
  p.group.traverse(m=>{
    if(!m.material||!m.material.map||!m.material.map.image)return;
    if(Math.abs(m.position.y-3)<1.2&&Math.hypot(m.position.x,m.position.z)<3){
      const c=m.material.map.image;
      try{
        const ctx=c.getContext&&c.getContext('2d');
        // can't reliably read, just drop labels very near (0,3,1.3)
        if(Math.hypot(m.position.x,m.position.z-1.3)<.6)m.visible=false;
      }catch(e){}
    }
  });
  worldLabel(p.group,'心愿树',0,3.15,2.4,4.6);
}

function extendPath(){
  const p=W3.spaces.plaza;
  // pale path through the axis so both doors stay connected
  const path=worldBox(p,0,.012,0,3.1,.03,44,'#e4d7b4',false);
  if(path)path.userData.r7dPath=true;
}

function replanPlaza(){
  const p=W3.spaces.plaza;if(!p||p.r7dPlanned)return;
  p.r7dPlanned=true;
  p.limit={x:LIMIT,z:LIMIT};
  if(p.floor&&p.floor.scale)p.floor.scale.set(52,.3,52);

  moveNorthWall(-10);             // doorway -12 → -22
  moveDoorGroup(0,14,0,DOOR,'gate');
  moveDoorGroup(14,0,DOOR,0,'market');
  moveDoorGroup(-14,0,-DOOR,0);   // tea (was yard/r4 east, relabeled)
  relocateArt3();
  relocateTreesAndFigures();
  relocateStalls();
  placeRack();
  addRing();
  extendPath();
  refreshTreeLabel();

  // keep the central trunk collider, drop stale mid-plaza stall blocks
  p.blocks=p.blocks.filter(b=>{
    const cx=(b.x+b.X)/2,cz=(b.z+b.Z)/2,r=Math.hypot(cx,cz);
    if(r<2.2)return Math.abs(cx)<1.6&&Math.abs(cz)<1.6; // only the trunk
    return true;
  });
  if(!p.blocks.some(b=>Math.abs((b.x+b.X)/2)<.2&&Math.abs((b.z+b.Z)/2)<.2&&b.X-b.x>2)){
    p.blocks.push({x:-1.5,X:1.5,z:-1.5,Z:1.5});
  }
  window.TG_R7D_PLAZA.report=aabbReport();
}

/* ---------- AABB clearance report ---------- */
function boxFromCenter(x,z,hx,hz,y0,y1){return {x:x-hx,X:x+hx,z:z-hz,Z:z+hz,y:y0,Y:y1};}
function unionWorldBox(acc,b){
  if(!acc)return {x:b.min.x,X:b.max.x,y:b.min.y,Y:b.max.y,z:b.min.z,Z:b.max.z};
  acc.x=Math.min(acc.x,b.min.x);acc.X=Math.max(acc.X,b.max.x);
  acc.y=Math.min(acc.y,b.min.y);acc.Y=Math.max(acc.Y,b.max.y);
  acc.z=Math.min(acc.z,b.min.z);acc.Z=Math.max(acc.Z,b.max.z);
  return acc;
}
function clusterBoxes(){
  const p=W3.spaces.plaza, clusters=[];
  const named=[
    ['里门',0,DOOR,3.2,1.4],
    ['北门（心田小院）',0,-DOOR,13,1.6],
    ['集市门',DOOR,0,1.4,3.2],
    ['茶会门',-DOOR,0,1.4,3.2],
    ['今日心语摊',-16,8,1.8,1.3],
    ['每日诗签摊',16,8,1.8,1.3],
    ['赏景小记摊',16,-8,1.8,1.3],
    ['祈愿牌架',-16,-8,1.5,1.0],
    ['石狮东',5.6,-18.6,1.2,1.2],
    ['石狮西',-5.6,-18.6,1.2,1.2],
    ['石灯东',5.4,19.6,.8,.8],
    ['石灯西',-5.4,19.6,.8,.8],
    ['旗杆东',7,-16.5,.8,.8],
    ['旗杆西',-7,-16.5,.8,.8],
    ['铜灯',0,-15.2,1.6,1.6],
    ['石环',0,0,RING_R+.5,RING_R+.5]
  ];
  const m4=new T.Matrix4(),pos=new T.Vector3(),geoBox=new T.Box3(),tmp=new T.Box3();
  function addTo(name,box){
    let c=clusters.find(v=>v.name===name);
    if(!c){c={name,box:null};clusters.push(c);}
    c.box=unionWorldBox(c.box,box);
  }
  function classify(x,z){
    let best=null,d=1.8;
    for(const [n,cx,cz,hx,hz] of named){
      if(n==='石环')continue;
      const r=Math.hypot(x-cx,z-cz);
      if(r<Math.max(hx,hz)+.6&&r<d+1){d=r;best=n;}
    }
    return best;
  }
  p.group.updateMatrixWorld(true);
  p.group.traverse(m=>{
    if(!m.isMesh||m.userData.r7Particle||m.userData.r7TreeSoft)return;
    let o=m;while(o){if(o.name==='r7-wish-tree'||o.userData&&o.userData.r7dPath)return;o=o.parent;}
    if(m===p.floor)return;
    if(m.isInstancedMesh){
      const geom=m.geometry;if(!geom.boundingBox)geom.computeBoundingBox();
      for(let i=0;i<m.count;i++){
        m.getMatrixAt(i,m4);
        const world=new T.Matrix4().multiplyMatrices(m.matrixWorld,m4);
        tmp.copy(geom.boundingBox).applyMatrix4(world);
        pos.setFromMatrixPosition(world);
        const name=classify(pos.x,pos.z);
        if(name)addTo(name,tmp);
      }
    }else{
      geoBox.setFromObject(m);
      pos.setFromMatrixPosition(m.matrixWorld);
      const name=classify(pos.x,pos.z)||(m.name==='r7d-tree-ring'|| (m.parent&&m.parent.name==='r7d-tree-ring')?'石环':null);
      if(name)addTo(name,tmp.copy(geoBox));
    }
  });
  // ensure named clusters exist even if mesh classify missed them
  for(const [n,cx,cz,hx,hz] of named){
    if(!clusters.some(c=>c.name===n)){
      clusters.push({name:n,box:{x:cx-hx,X:cx+hx,y:0,Y:3,z:cz-hz,Z:cz+hz},estimated:true});
    }
  }
  return clusters;
}
function clearanceToTree(box){
  const cx=(box.x+box.X)/2,cz=(box.z+box.Z)/2;
  const hx=(box.X-box.x)/2,hz=(box.Z-box.z)/2,hy=((box.Y??3)-(box.y??0))/2,cy=((box.Y??3)+(box.y??0))/2;
  // horizontal gap to a cylinder of radius R, plus vertical overlap test
  function gap(R,y0,y1){
    const horiz=Math.hypot(Math.max(0,Math.abs(cx)-hx)-0, Math.max(0,Math.abs(cz)-hz)-0);
    // distance from box to circle in XZ: distance of closest point to origin, minus R
    const dx=Math.max(0,Math.abs(cx)-hx),dz=Math.max(0,Math.abs(cz)-hz);
    const outside=Math.hypot(dx,dz);
    const inside=outside===0; // origin is inside the xz box
    const hgap=inside?-(R-Math.min(Math.abs(box.x),Math.abs(box.X),Math.abs(box.z),Math.abs(box.Z))):outside-R;
    const vOverlap=!(box.Y<y0||box.y>y1);
    if(!vOverlap)return {gap:Math.max(hgap, Math.min(Math.abs(box.Y-y0),Math.abs(box.y-y1))), overlap:false};
    return {gap:hgap, overlap:hgap<0};
  }
  const trunk=gap(TRUNK_R,0,9.5), roots=gap(ROOT_R,-.2,1.5), canopy=gap(CANOPY_R,5.6,11.4);
  const worst=[ ['trunk',trunk],['roots',roots],['canopy',canopy] ].reduce((a,b)=>b[1].gap<a[1].gap?b:a);
  return {trunk:trunk.gap, roots:roots.gap, canopy:canopy.gap, overlap:trunk.overlap||roots.overlap||canopy.overlap, nearest:worst[0], min:worst[1].gap};
}
function boxesOverlap(a,b){
  return a.x<b.X&&a.X>b.x&&a.z<b.Z&&a.Z>b.z&&(a.y??0)<(b.Y??3)&&(a.Y??3)>(b.y??0);
}
function aabbReport(){
  const clusters=clusterBoxes();
  const rows=clusters.map(c=>{
    const cl=clearanceToTree(c.box);
    return {
      object:c.name,
      box:[+c.box.x.toFixed(2),+c.box.X.toFixed(2),+c.box.y.toFixed(2),+c.box.Y.toFixed(2),+c.box.z.toFixed(2),+c.box.Z.toFixed(2)],
      trunk:+cl.trunk.toFixed(2),
      roots:+cl.roots.toFixed(2),
      canopy:+cl.canopy.toFixed(2),
      min:+cl.min.toFixed(2),
      nearest:cl.nearest,
      overlap:cl.overlap
    };
  });
  const pairs=[];
  for(let i=0;i<clusters.length;i++)for(let j=i+1;j<clusters.length;j++){
    const a=clusters[i],b=clusters[j];
    if(a.name==='石环'||b.name==='石环')continue; // ring is a circle; AABB would false-positive against everything in the square
    if(boxesOverlap(a.box,b.box))pairs.push([a.name,b.name]);
  }
  return {rows,pairs,tree:{trunk:TRUNK_R,roots:ROOT_R,canopy:CANOPY_R}};
}
window.TG_R7D_AABB=aabbReport;

/* ---------- 3. Camera + spawn for the new layout ---------- */
const spawn=r3Spawn;r3Spawn=function(n,p){
  if(n==='plaza'){
    if(!p||p==='gate')return [0,16,0];
    if(p==='yard')return [0,-19,Math.PI];
    if(p==='market')return [19,0,-Math.PI/2];
    if(p==='tea'||p==='home')return [-19,0,Math.PI/2];
  }
  return spawn.apply(this,arguments);
};
let entry=null;
const enter=worldEnter;worldEnter=function(n){
  entry=null;
  const out=enter.apply(this,arguments);
  if(n==='plaza'){entry=W3.player.position.clone();W3.pitch=.38;W3.yaw=0;W3.radius=18;}
  return out;
};
window.TG_R7D_SHOT=null;
const camera=worldCamera;worldCamera=function(){
  const w=W3;
  if(w?.active==='plaza'&&window.TG_R7D_SHOT==='top'&&S.view!=='fp'){
    w.camera.up.set(0,0,-1);
    w.camera.position.set(0,52,0.02);
    w.camera.lookAt(0,0,0);
    if(w.scene.fog){w.scene.fog.near=70;w.scene.fog.far=160;}
    return;
  }
  if(w)w.camera.up.set(0,1,0);
  if(w?.active==='plaza'&&entry&&S.view!=='fp'&&!w.r6Plan){
    if(w.player.position.distanceTo(entry)<.18){
      const land=w.camera.aspect>1;
      if(land)w.camera.position.set(0,10.5,16.5);
      else w.camera.position.set(0,11.2,18.5);
      w.camera.lookAt(0,4.4,0);
      if(w.scene.fog){w.scene.fog.near=48;w.scene.fog.far=110;}
      return;
    }
    entry=null;
  }
  return camera.apply(this,arguments);
};

const iw=typeof initWorld==='function'?initWorld:null;
if(iw){
  initWorld=function(){const r=iw.apply(this,arguments);try{replanPlaza();}catch(e){console.warn('r7d replan',e);}return r;};
}
})();
