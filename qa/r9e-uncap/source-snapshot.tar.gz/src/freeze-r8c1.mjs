#!/usr/bin/env node
// r8c.1 freeze: node v4/_src/freeze-r8c1.mjs [--no-freeze]
//  1. re-pack (v4/_src/pack.mjs → v4/index.html)
//  2. grep the bundle for 宜 忌 吉凶 运势 吉利方位 大吉 诗签 灵签 求签 算卦 风水 六爻 祠堂 炷香 → every hit with line, source file:line, context
//  3. smoke test portrait 390×844 + landscape 844×390: load each scene, page errors, draw calls
//     + plaza stalls: 读心笺 / 抽每日诗笺 / 赏园景, and 赏景小记 写一写 ×5 (visible-text scan for the banned words)
//  4. copy → v4/index.r8c1.html, sha256, v4/r8c1.patch (diff -u index.r8c.html → index.r8c1.html), v4/r8c1-src.patch (qa/r8c1-base-src → v4/_src)
// Never touches index.r8c.html or any earlier frozen build. Report: v4/_src/freeze-r8c1-report.json (+ stdout).
// Exit code 1 if smoke shows page errors (freeze is skipped then unless --force).
import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import crypto from 'node:crypto';
import {execFileSync,spawnSync} from 'node:child_process';import {createRequire} from 'node:module';import {fileURLToPath} from 'node:url';
const SRC=path.dirname(fileURLToPath(import.meta.url)),V4=path.resolve(SRC,'..'),ROOT=path.resolve(V4,'..');
const args=new Set(process.argv.slice(2));const report={date:new Date().toString()};
const FROZEN=['index.r8c.html','index.r8b.html','index.r8a2.html','index.r8a1.html','index.r8a.html'].map(f=>path.join(V4,f)).filter(f=>fs.existsSync(f));
const shaOf=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const frozenBefore=Object.fromEntries(FROZEN.map(f=>[path.basename(f),shaOf(f)]));

// 1. pack
console.log('== 1. pack');console.log(execFileSync(process.execPath,[path.join(SRC,'pack.mjs')],{cwd:SRC,encoding:'utf8'}).trim());
const BUILD=path.join(V4,'index.html');report.build={size:fs.statSync(BUILD).size,sha256:shaOf(BUILD)};

// 2. grep
console.log('== 2. grep');const RX=/宜|忌|吉凶|运势|吉利方位|大吉|诗签|灵签|求签|算卦|风水|六爻|祠堂|炷香/g;
const lines=fs.readFileSync(BUILD,'utf8').split('\n');const srcIdx=new Map();
for(const f of fs.readdirSync(SRC).filter(f=>/\.(js|css|html)$/.test(f)&&!/\.pre/.test(f))){fs.readFileSync(path.join(SRC,f),'utf8').split('\n').forEach((l,i)=>{if(RX.test(l)){const k=l.trim();if(!srcIdx.has(k))srcIdx.set(k,f+':'+(i+1));}RX.lastIndex=0;});}
const CODEX2=/^(audio|npc|avatar|art3|teahouse-assets|realism|mounts|animals2|suggest|manual)\.js/;const OURS={test:f=>f!=='?'&&!CODEX2.test(f)}; // codex2-owned modules vs ours (base files, r3–r8c)
const hits=[];
lines.forEach((l,i)=>{for(const m of l.matchAll(RX)){const src=srcIdx.get(l.trim())||'?';hits.push({line:i+1,word:m[0],src,ours:OURS.test(src),ctx:l.slice(Math.max(0,m.index-36),m.index+m[0].length+30).replace(/\s+/g,' ')});}});
report.grep={total:hits.length,ours:hits.filter(h=>h.ours).length,byFile:hits.reduce((a,h)=>(a[h.src.split(':')[0]]=(a[h.src.split(':')[0]]||0)+1,a),{}),hits};
for(const h of hits)console.log(`${h.line}\t${h.word}\t${h.src}${h.ours?'  [OURS]':''}\t${h.ctx}`);console.log('grep total',hits.length,'ours',report.grep.ours,JSON.stringify(report.grep.byFile));

// 3. smoke
console.log('== 3. smoke');const require=createRequire(path.join(ROOT,'qa/r8-audit/package.json'));const {chromium}=require('playwright-core');
const buf=fs.readFileSync(BUILD);const srv=http.createServer((q,r)=>{r.setHeader('content-type','text/html; charset=utf-8');r.end(buf);}).listen(0,'127.0.0.1');await new Promise(r=>srv.on('listening',r));
const URL=`http://127.0.0.1:${srv.address().port}/`;const SCENES=['plaza','gate','hall','yard','zen','study','market','tea','lotus'];
const VPS={portrait:{width:390,height:844},landscape:{width:844,height:390}};
const br=await chromium.launch({executablePath:process.env.CHROME||'/usr/bin/google-chrome',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
const ignore=/AudioContext|autoplay|supabase\.co|ERR_FAILED|Failed to load resource|net::|GPU stall|WebGL: |ERR_BLOCKED/i;report.smoke={};let errTotal=0;
try{for(const [vn,vp] of Object.entries(VPS)){const ctx=await br.newContext({viewport:vp,deviceScaleFactor:1,isMobile:true,hasTouch:true});await ctx.route(u=>!String(u).startsWith(URL),r=>r.abort());
  await ctx.addInitScript(()=>{try{if(!localStorage.getItem('templeGarden.nickname'))localStorage.setItem('templeGarden.nickname','smoke');}catch(e){}window.TG_BACKEND_CONFIG=Object.assign({publicRoomSuffix:'~test'},window.TG_BACKEND_CONFIG||{});});
  const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push('pageerror: '+e.message));p.on('console',m=>{if(m.type()==='error'&&!ignore.test(m.text()))errs.push('console: '+m.text());});p.on('dialog',d=>d.dismiss());
  await p.goto(URL);await p.waitForFunction(()=>window.W3?.player&&W3.active,null,{timeout:180000});await p.evaluate(()=>{try{S.unlocked=true;closeModal();}catch(e){}});
  const r={};for(const n of SCENES){const e0=errs.length;await p.evaluate(async n=>{await go(n,true);},n);await p.waitForTimeout(2500);
   await p.waitForFunction(()=>!window.TG_R8C||(W3.spaces[W3.active]?.r8c&&!W3.spaces[W3.active].r8c.pend&&W3.spaces[W3.active].r8c.batches.length>0),null,{timeout:60000,polling:500}).catch(()=>{});
   const vis=await p.evaluate(()=>{const rx=/宜|忌|吉凶|运势|吉利方位|大吉|诗签|灵签|求签|算卦|风水|六爻|祠堂|炷香/;const out=new Set();const tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let x;while(x=tw.nextNode()){const e=x.parentElement;if(x.nodeValue&&rx.test(x.nodeValue)&&e&&e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden'&&!e.closest('script,style'))out.add(x.nodeValue.trim().slice(0,40));}
    for(const it of W3.spaces[W3.active].items||[])if(rx.test(String(it.label)))out.add('[prompt] '+it.label);document.querySelectorAll('[title],[aria-label]').forEach(e=>{for(const k of ['title','aria-label']){const v=e.getAttribute(k);if(v&&rx.test(v)&&e.getClientRects().length)out.add('['+k+'] '+v);}});return [...out];});
   r[n]=await p.evaluate(()=>{const w=W3,R=w.renderer;R.info.autoReset=false;R.info.reset();R.render(w.scene,w.camera);const c=R.info.render.calls;R.info.autoReset=true;return {active:w.active,calls:c};});r[n].errors=errs.slice(e0);r[n].bannedVisible=vis;
   console.log(vn,n,'calls',r[n].calls,'errors',r[n].errors.length,'bannedVisible',JSON.stringify(vis),r[n].active!==n?'(scene mismatch '+r[n].active+')':'');}
  // stalls + 赏景小记 ×5
  {const e0=errs.length;await p.evaluate(async()=>{await go('plaza',true);});await p.waitForTimeout(2000);
   const BAN='宜|忌|吉|凶|运势|黄历|卦|爻|风水|算命|占卜|签|方位|幸运|五行|生肖|属相|大吉|祠堂|炷香|☯|🔮';
   const scan=()=>p.evaluate(B=>{const rx=new RegExp(B);const out=[];const tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;while(n=tw.nextNode()){const t=n.nodeValue;if(t&&rx.test(t)&&n.parentElement&&n.parentElement.getClientRects().length&&getComputedStyle(n.parentElement).visibility!=='hidden')out.push(t.trim().slice(0,50));}return out;},BAN);
   const stalls=[];
   for(const [label,re] of [['今日心语','读|再'],['每日寄语','抽|再'],['赏景小记','写一写']]){const ok=await p.evaluate(l=>{const it=W3.spaces.plaza.items.find(i=>i.label===l);if(!it)return false;try{closeModal();}catch(e){}it.run();return true;},label);await p.waitForTimeout(900);
    const title=await p.evaluate(()=>document.querySelector('#sheet h2')?.textContent||null);const hits=new Set(await scan());const res=[];
    const reps=label==='赏景小记'?5:3;for(let k=0;k<reps;k++){if(label==='赏景小记')await p.evaluate(k=>{const d=[...document.querySelectorAll('#fengDirs button,#fengDirs [data-dir],#fengDirs .dir')].filter(b=>b.getClientRects().length);d[(k*3)%Math.max(1,d.length)]?.click();},k);
     const b=await p.evaluate(rs=>{const rx=new RegExp(rs);const b=[...document.querySelectorAll('#sheet button')].filter(b=>b.getClientRects().length&&!b.disabled&&rx.test(b.textContent)&&!/关闭|×|✕/.test(b.textContent));const x=b[b.length-1];if(!x)return null;x.click();return x.textContent.trim().slice(0,12);},re);
     if(label==='今日心语'){if(b&&/再/.test(b)){await p.waitForTimeout(500);await p.evaluate(()=>document.querySelector('#autoBtn')?.click());}await p.waitForFunction(()=>(document.querySelector('#guaResult')?.innerText||'').trim().length>0,null,{timeout:12000}).catch(()=>{});await p.waitForTimeout(400);}else await p.waitForTimeout(1500);(await scan()).forEach(h=>hits.add(h));const txt=await p.evaluate(()=>(document.querySelector('#fengResult,#qianResult,#guaResult')?.innerText||'').replace(/\s+/g,' ').slice(0,60));res.push({clicked:b,result:txt});}
    stalls.push({stall:label,found:ok,title,runs:res,bannedVisible:[...hits]});console.log(vn,'stall',label,ok?'ok':'MISSING',title,'banned',hits.size,'last:',res[res.length-1]?.result);}
   try{await p.evaluate(()=>closeModal());}catch(e){}r.stalls=stalls;r.stallErrors=errs.slice(e0);}
  r.errorsTotal=errs.length;errTotal+=errs.length;report.smoke[vn]=r;await ctx.close();}}
finally{await br.close();srv.close();}
const maxCalls=Math.max(...Object.values(report.smoke).flatMap(r=>SCENES.map(n=>r[n]?.calls||0)));report.smoke.maxCalls=maxCalls;
console.log('smoke errors',errTotal,'max draw calls',maxCalls);

// 4. freeze
const frozenAfter=Object.fromEntries(FROZEN.map(f=>[path.basename(f),shaOf(f)]));report.frozenUntouched=JSON.stringify(frozenBefore)===JSON.stringify(frozenAfter);
if(args.has('--no-freeze')){console.log('== 4. skipped (--no-freeze)');}
else if(errTotal&&!args.has('--force')){console.log('== 4. NOT frozen: smoke errors (use --force to freeze anyway)');process.exitCode=1;}
else{console.log('== 4. freeze');const OUT=path.join(V4,'index.r8c1.html');if(path.resolve(OUT)===path.join(V4,'index.r8c.html'))throw new Error('refusing');fs.copyFileSync(BUILD,OUT);
 const sha=shaOf(OUT);fs.writeFileSync(OUT+'.sha256',`${sha}  index.r8c1.html\n`);
 const d=spawnSync('diff',['-u','index.r8c.html','index.r8c1.html'],{cwd:V4,encoding:'utf8',maxBuffer:1<<28});fs.writeFileSync(path.join(V4,'r8c1.patch'),d.stdout);
 const base=path.join(ROOT,'qa/r8c1-base-src');let srcBytes=null;if(fs.existsSync(base)){const d2=spawnSync('diff',['-ruN','-x','*.md','-x','freeze-r8c1*','qa/r8c1-base-src','v4/_src'],{cwd:ROOT,encoding:'utf8',maxBuffer:1<<28});fs.writeFileSync(path.join(V4,'r8c1-src.patch'),d2.stdout);srcBytes=Buffer.byteLength(d2.stdout);}
 report.freeze={file:'v4/index.r8c1.html',size:fs.statSync(OUT).size,sha256:sha,patch:'v4/r8c1.patch',patchBytes:Buffer.byteLength(d.stdout),srcPatch:'v4/r8c1-src.patch',srcPatchBytes:srcBytes};console.log(JSON.stringify(report.freeze));}
fs.writeFileSync(path.join(SRC,'freeze-r8c1-report.json'),JSON.stringify(report,null,1));console.log('report v4/_src/freeze-r8c1-report.json; frozen builds untouched:',report.frozenUntouched);
