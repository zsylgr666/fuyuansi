import {chromium} from '/workspace/temple-garden/node_modules/playwright-core/index.mjs';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const ROOT='/workspace/temple-garden/v4';
const SHOTS=path.join(ROOT,'shots');
fs.mkdirSync(SHOTS,{recursive:true});
const html=fs.readFileSync(path.join(ROOT,'index.html'));
const server=http.createServer((req,res)=>{
  res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});
  res.end(html);
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const origin=`http://127.0.0.1:${server.address().port}`;
const chromeArgs=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'];
const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:chromeArgs});

const fails=[];
const note=(ok,msg)=>{console.log(ok?'PASS':'FAIL',msg); if(!ok)fails.push(msg);};

async function newPage(size={width:390,height:844}, storage=undefined){
  const ctx=await browser.newContext({viewport:size,deviceScaleFactor:1});
  const p=await ctx.newPage();
  p.on('pageerror',e=>console.log('PAGEERROR',e.message));
  if(storage!==undefined){
    await ctx.addInitScript(data=>{
      if(data===null) localStorage.removeItem('templeGarden.v1');
      else if(data) localStorage.setItem('templeGarden.v1', JSON.stringify(data));
    }, storage);
  }
  return {ctx,p};
}
async function ready(p, scene, timeout=12000){
  await p.waitForFunction(s=>window.W3?.renderer && window.W3?.active && (!s || W3.active===s) && typeof current!=='undefined' && current, scene||'', {timeout});
  await p.waitForTimeout(400);
}
function dmMarkup(){
  return `<div class="tgg-mask tgs-dm" id="tgsDmMock">
    <div class="tgg-box">
      <div class="tgg-hd">私信 <button class="tgg-btn alt" id="tgsClose">关闭</button></div>
      <div class="tgg-bd">
        <div class="tgs-thread">
          <div class="tgs-msgs" id="tgsMsgs">
            <div class="tgs-msg">你好，昨天的香火好旺。</div>
            <div class="tgs-msg me">有空来院里坐坐。</div>
          </div>
          <div class="tgs-compose"><input id="tgsText" placeholder="写一句问候"><button class="tgg-btn">发送</button></div>
        </div>
        <p class="tgg-empty" hidden>从邻居里找人</p>
      </div>
    </div>
  </div>`;
}

// 1. migration
{
  const cases=[
    [null, {coins:50, hasStarter:true}, 'new save'],
    [{v:1,coins:0,merit:1}, {coins:0, hasStarter:false}, 'old coins:0'],
    [{v:1,merit:2}, {coins:0, hasStarter:false}, 'pre-economy missing coins'],
    [{v:1,coins:37,backpack:{bench:2}}, {coins:37, hasStarter:false, bench:2}, 'old coins:37'],
  ];
  for(const [raw, expect, label] of cases){
    const {ctx,p}=await newPage({width:390,height:844}, raw);
    await p.goto(origin+'/#plaza');
    await ready(p,'plaza');
    const got=await p.evaluate(()=>({coins:S.coins, backpack:{...S.backpack}}));
    note(got.coins===expect.coins, `${label} coins=${got.coins} expected ${expect.coins}`);
    if(expect.hasStarter) note(got.backpack.cushion===1 && got.backpack.vase===1, `${label} starter furniture ${JSON.stringify(got.backpack)}`);
    else note(!got.backpack.cushion && !got.backpack.vase, `${label} no gifted furniture ${JSON.stringify(got.backpack)}`);
    if(expect.bench) note(got.backpack.bench===2, `${label} kept bench`);
    await ctx.close();
  }
}

async function firstLoad(size, hash, shot){
  const {ctx,p}=await newPage(size, null);
  await p.goto(`${origin}/#${hash}`, {waitUntil:'domcontentloaded'});
  await p.waitForFunction(()=>window.W3?.renderer, {timeout:12000});
  await p.waitForTimeout(700);
  const info=await p.evaluate(()=>{
    const a=document.getElementById('app');
    const sz=W3.renderer.getSize(new THREE.Vector2());
    const pix=W3.renderer.getContext().drawingBufferWidth;
    const pih=W3.renderer.getContext().drawingBufferHeight;
    return {
      active:W3.active, current,
      app:[a.clientWidth,a.clientHeight],
      setSize:[sz.x,sz.y],
      buffer:[pix,pih],
      aspect:W3.camera.aspect,
      expectAspect:a.clientWidth/Math.max(1,a.clientHeight),
    };
  });
  await p.screenshot({path:shot, type:'png'});
  const aspectOk=Math.abs(info.aspect-info.expectAspect)<0.03;
  const sizeOk=Math.abs(info.buffer[0]-info.app[0])<=2 && Math.abs(info.buffer[1]-info.app[1])<=4;
  const notTiny=info.app[1]>400;
  note(!!info.active && notTiny && aspectOk && sizeOk, `first-load ${hash} ${size.width}x${size.height} active=${info.active} app=${info.app} buf=${info.buffer} aspect=${info.aspect.toFixed(3)}/${info.expectAspect.toFixed(3)}`);
  const variety=await p.evaluate(()=>document.getElementById('view').toDataURL('image/png').length);
  note(variety>8000, `first-load ${hash} canvas data length ${variety}`);
  await ctx.close();
  return info;
}

await firstLoad({width:390,height:844},'plaza', path.join(SHOTS,'r4.1-phone-hash-plaza.png'));
await firstLoad({width:390,height:844},'hall', path.join(SHOTS,'r4.1-phone-hash-hall.png'));
await firstLoad({width:1280,height:800},'plaza', path.join(SHOTS,'r4.1-desktop-hash-plaza.png'));
await firstLoad({width:1280,height:800},'hall', path.join(SHOTS,'r4.1-desktop-hash-hall.png'));
{
  const {ctx,p}=await newPage({width:390,height:844}, null);
  await p.goto(origin+'/#plaza',{waitUntil:'domcontentloaded'});
  await p.waitForFunction(()=>window.W3?.active,{timeout:12000});
  await p.waitForTimeout(200);
  await p.click('#btnMenu');
  await p.waitForTimeout(500);
  await p.screenshot({path:path.join(SHOTS,'r4.1-phone-menu-first.png'), type:'png'});
  const info=await p.evaluate(()=>{
    const a=document.getElementById('app');
    return {active:W3.active, app:[a.clientWidth,a.clientHeight], buf:[W3.renderer.getContext().drawingBufferWidth,W3.renderer.getContext().drawingBufferHeight], aspect:W3.camera.aspect};
  });
  note(Math.abs(info.buf[1]-info.app[1])<=4 && Math.abs(info.aspect-info.app[0]/info.app[1])<0.03, `menu-first layout app=${info.app} buf=${info.buf} aspect=${info.aspect.toFixed(3)}`);
  await ctx.close();
}

// return to plaza camera
{
  const {ctx,p}=await newPage({width:390,height:844}, null);
  await p.goto(origin+'/#yard');
  await ready(p,'yard');
  await p.evaluate(()=>{switching=false;});
  await p.click('#backToPlaza');
  await p.waitForFunction(()=>W3.active==='plaza',{timeout:8000});
  await p.waitForTimeout(500);
  const cam=await p.evaluate(()=>({
    player:[W3.player.position.x,W3.player.position.z,W3.yaw],
    camera:[W3.camera.position.x,W3.camera.position.y,W3.camera.position.z],
    pitch:W3.pitch, radius:W3.radius, fov:W3.camera.fov
  }));
  note(cam.camera[2] > -11.0, `return-plaza camera z=${cam.camera[2].toFixed(3)} player=${JSON.stringify(cam.player)}`);
  note(Math.abs(cam.pitch-0.42)<0.001 && Math.abs(cam.radius-8.8)<0.001 && cam.fov===55, `camera constants pitch=${cam.pitch} r=${cam.radius} fov=${cam.fov}`);
  await p.screenshot({path:path.join(SHOTS,'r4.1-phone-return-plaza.png'), type:'png'});
  await ctx.close();
}

const {ctx,p}=await newPage({width:390,height:844}, null);
await p.goto(origin+'/#plaza');
await ready(p,'plaza');

const hooks=await p.evaluate(()=>({
  TG_STORAGE:!!window.TG_STORAGE, TG_SCENES:Array.isArray(window.TG_SCENES),
  TG_RERENDER:typeof window.TG_RERENDER, TG_DOG_ON_DUTY:typeof window.TG_DOG_ON_DUTY,
  TG_DOG_IN_GARDEN:typeof window.TG_DOG_IN_GARDEN,
  SAVE_KEY: typeof SAVE_KEY==='string'?SAVE_KEY:'',
  worldEnter:typeof worldEnter, harvest:typeof harvest, renderYard:typeof renderYard,
  worldSyncYard:typeof worldSyncYard, go:typeof go, addMerit:typeof addMerit, renderTop:typeof renderTop,
  r4Steal:typeof r4Steal, r3CanEdit:typeof r3CanEdit,
}));
note(hooks.TG_SCENES && hooks.worldEnter==='function' && hooks.SAVE_KEY==='templeGarden.v1', 'hooks present '+JSON.stringify(hooks));

async function shotScene(name, file){
  await p.evaluate(async s=>{switching=false; await go(s,true);}, name);
  await p.waitForFunction(s=>W3.active===s, name);
  await p.waitForTimeout(600);
  await p.screenshot({path:path.join(SHOTS,file), type:'png'});
}

const perf={};
for(const scene of ['gate','plaza','market','yard','lotus','hall','zen','study']){
  await p.evaluate(async s=>{switching=false; await go(s,true);}, scene);
  await p.waitForFunction(s=>W3.active===s, scene);
  await p.waitForTimeout(300);
  const m=await p.evaluate(async ()=>{
    let max=0, tris=0;
    const yaws=[W3.yaw, W3.yaw+Math.PI/2, W3.yaw+Math.PI, W3.yaw-Math.PI/2];
    for(const y of yaws){
      W3.yaw=y; worldCamera(1);
      W3.renderer.info.reset();
      W3.renderer.render(W3.scene,W3.camera);
      const c=W3.renderer.info.render.calls;
      if(c>max){max=c; tris=W3.renderer.info.render.triangles;}
    }
    const t0=performance.now();
    await new Promise(res=>{
      let n=0; const step=()=>{n++; if(n>=24) return res(); requestAnimationFrame(step);};
      requestAnimationFrame(step);
    });
    const fps=24/((performance.now()-t0)/1000);
    return {max,tris,fps:+fps.toFixed(1), pitch:W3.pitch, radius:W3.radius};
  });
  perf[scene]=m;
  note(m.max<120, `${scene} draw calls ${m.max} (cap 120) tris=${m.tris} fps~${m.fps}`);
}
console.log('PERF', JSON.stringify(perf,null,2));
fs.writeFileSync('/tmp/codex-v4-r41/perf.json', JSON.stringify(perf,null,2));

await shotScene('plaza','r4.1-phone-plaza.png');
const wp=await p.evaluate(()=>({
  texts:[...document.querySelectorAll('#r41Waypoints button')].map(b=>b.textContent),
}));
note(wp.texts.some(t=>t.includes('山门')) && wp.texts.some(t=>t.includes('集市')), 'plaza waypoints '+JSON.stringify(wp.texts));

await p.click('#r41Waypoints button[data-exit="market"]');
await p.waitForFunction(()=>W3.active==='market',{timeout:8000});
await p.waitForTimeout(500);
await p.screenshot({path:path.join(SHOTS,'r4.1-phone-market.png'), type:'png'});
note(true, 'waypoint to market ok');

await shotScene('gate','r4.1-phone-gate.png');
await shotScene('lotus','r4.1-phone-lotus.png');
await shotScene('yard','r4.1-phone-yard.png');

const hud=await p.evaluate(()=>{
  const app=document.getElementById('app').getBoundingClientRect();
  const seeds=[...document.querySelectorAll('#seedBar .seed')].map(el=>{
    const r=el.getBoundingClientRect();
    return {t:el.textContent.replace(/\s+/g,' ').trim(), left:r.left-app.left, right:r.right-app.left, w:r.width, visible:r.width>0 && r.right>app.left+2 && r.left<app.right-2};
  });
  const bar=document.getElementById('seedBar');
  return {
    seeds, seedCount:seeds.length,
    scroll:{scrollWidth:bar.scrollWidth, clientWidth:bar.clientWidth}
  };
});
const visibleSeeds=hud.seeds.filter(s=>s.visible).length;
const xiGua=hud.seeds.find(s=>s.t.includes('西瓜'));
note(hud.seedCount>=6, 'six seed cards exist '+hud.seedCount);
note(visibleSeeds>=5 || hud.scroll.scrollWidth>hud.scroll.clientWidth+4, `seed visibility visible=${visibleSeeds} scroll ${hud.scroll.scrollWidth}/${hud.scroll.clientWidth}`);
if(xiGua) note(xiGua.visible || hud.scroll.scrollWidth>hud.scroll.clientWidth+4, '西瓜 visible or scrollable '+JSON.stringify(xiGua));

await shotScene('hall','r4.1-phone-hall.png');
const hallUI=await p.evaluate(()=>{
  const prompt=document.getElementById('promptBtn');
  const shown=prompt.classList.contains('show') && getComputedStyle(prompt).visibility!=='hidden' && getComputedStyle(prompt).opacity!=='0';
  return {shown, promptText:prompt.textContent, incenseVisible:!!document.getElementById('btnIncense') && getComputedStyle(document.getElementById('btnIncense')).display!=='none'};
});
note(!(hallUI.shown && hallUI.promptText.includes('上香')), 'no duplicate 上香 prompt '+JSON.stringify(hallUI));
note(hallUI.incenseVisible, 'hall #btnIncense visible');

const merit=await p.evaluate(()=>{
  const before=S.merit;
  S.incense.sticks=[];
  document.querySelector('#btnIncense').click();
  const stats=document.getElementById('hallStats').textContent;
  return {before, after:S.merit, stats, top:document.getElementById('meritNum').textContent};
});
note(merit.after===merit.before+3 && merit.stats.includes('功德 '+merit.after) && merit.top===String(merit.after), 'immediate merit '+JSON.stringify(merit));

await p.evaluate(()=>{S.coins=0; S.shrine.style='wood'; S.shrine.owned=['wood']; openShrineStudio();});
await p.waitForTimeout(200);
await p.click('[data-style="zen"]');
await p.waitForTimeout(300);
const preview=await p.evaluate(()=>({
  coins:S.coins, style:S.shrine.style, preview:window.r41PreviewStyle,
  status:document.getElementById('r41StyleStatus')?.textContent,
  buyHidden:document.getElementById('r41BuyStyle')?.hidden,
  toast: document.querySelector('.toast')?.textContent||''
}));
note(preview.coins===0 && preview.style==='wood' && preview.preview==='zen' && preview.buyHidden===false, 'preview zen at 0 coins '+JSON.stringify(preview));
note(!/铜钱不足$/.test(preview.toast), 'no covering 铜钱不足 toast on preview');
await p.screenshot({path:path.join(SHOTS,'r4.1-phone-studio-preview.png'), type:'png'});
await p.click('#r41BuyStyle');
await p.waitForTimeout(200);
const buy0=await p.evaluate(()=>({coins:S.coins, style:S.shrine.style, status:document.getElementById('r41StyleStatus')?.textContent}));
note(buy0.coins===0 && buy0.style==='wood' && /铜钱不足/.test(buy0.status||''), 'buy blocked inline '+JSON.stringify(buy0));

await p.evaluate(()=>{closeModal(); S.backpack={};});
await p.evaluate(()=>{switching=false; return go('hall',true);});
await p.waitForFunction(()=>W3.active==='hall');
await p.evaluate(()=>enterPlacement('hall'));
await p.waitForTimeout(400);
const place=await p.evaluate(()=>{
  const shop=document.getElementById('r41PlanShop');
  return {hasShop:!!shop, shopText:shop?.textContent, tray:document.getElementById('planTray')?.innerText||''};
});
note(place.hasShop && /购置|商店|家具/.test(place.shopText||''), 'placement shop button '+JSON.stringify(place));
await p.screenshot({path:path.join(SHOTS,'r4.1-phone-placement.png'), type:'png'});
await p.click('#r41PlanShop');
await p.waitForTimeout(400);
note(!!(await p.evaluate(()=>!!document.querySelector('[data-buy]'))), '购置家具 opens shop');
await p.screenshot({path:path.join(SHOTS,'r4.1-phone-placement-shop.png'), type:'png'});

await p.evaluate(()=>{document.getElementById('planDone')?.click(); closeModal();});
await p.waitForTimeout(200);
await p.evaluate((html)=>{document.body.insertAdjacentHTML('beforeend', html);}, dmMarkup());
await p.waitForTimeout(200);
const dm=await p.evaluate(()=>{
  const el=document.querySelector('.tgg-mask.tgs-dm');
  const app=document.getElementById('app');
  const er=el?.getBoundingClientRect();
  const ar=app.getBoundingClientRect();
  const cs=el?getComputedStyle(el):{};
  const box=document.querySelector('.tgg-box');
  const bcs=box?getComputedStyle(box):{};
  return {
    parent: el?.parentElement?.id, pos: cs.position,
    contained: el?.classList.contains('r41-contained'),
    app:[Math.round(ar.width),Math.round(ar.height)],
    mask:[Math.round(er?.width||0),Math.round(er?.height||0)],
    boxBg:bcs.backgroundColor
  };
});
note(dm.parent==='app' && dm.pos==='absolute' && dm.contained, 'DM reparented inside #app '+JSON.stringify(dm));
note(dm.mask[0]>200 && dm.mask[1]>300 && dm.app[0]>=380, 'DM covers phone frame without squeezing app');
await p.screenshot({path:path.join(SHOTS,'r4.1-phone-dm.png'), type:'png'});
await ctx.close();

// framed visitor yard furniture + remote sit
{
  const {ctx,p}=await newPage({width:390,height:844}, null);
  await p.goto(origin+'/#yard');
  await ready(p,'yard');
  await p.evaluate(()=>{
    window.TG_VISIT={ownerId:'owner',name:'测试主人',canEdit:false,steal:true};
    S.decor.yard=[{id:'bench',x:0,z:0},{id:'bench',x:2,z:0,rot:0}];
    TG_RERENDER();
    W3.player.position.set(0,0,6.2);
    W3.player.rotation.y=Math.PI;
    W3.yaw=0; W3.pitch=0.42; W3.radius=8.8;
    worldCamera(1);
    W3.renderer.render(W3.scene,W3.camera);
  });
  await p.waitForTimeout(400);
  const vis=await p.evaluate(()=>{
    const items=S.decor.yard||[];
    const group=W3.spaces.yard.decorGroup;
    let meshes=0; group?.traverse(m=>{if(m.isMesh||m.isInstancedMesh)meshes++;});
    return {ids:items.map(v=>v.id+':'+(v.rot??'na')+'@'+v.x+','+v.z), meshes, visiting:r3IsVisiting()};
  });
  note(vis.visiting && vis.ids.some(s=>s.startsWith('bench:0@0,0')) && vis.meshes>0, 'visit yard decor visible '+JSON.stringify(vis));
  await p.screenshot({path:path.join(SHOTS,'r4.1-phone-visit-yard-decor.png'), type:'png'});
  await p.evaluate(()=>{
    applyRemotePlayers([{id:'sitter',name:'坐客',scene:'yard',pos:{x:0,y:0,z:0},rot:0,anim:'sit'}]);
    worldCamera(1);
    W3.renderer.render(W3.scene,W3.camera);
  });
  await p.waitForTimeout(300);
  const sit=await p.evaluate(()=>{
    const r=W3.remotes.get('sitter');
    return {has:!!r, x:r?.mesh.position.x, z:r?.mesh.position.z, bodyY:r?.mesh.children[0]?.position.y, anim:r?.anim||r?.mesh?.userData};
  });
  note(sit.has && Math.abs(sit.x)<.05 && Math.abs(sit.z)<.05, 'remote sit at bench '+JSON.stringify(sit));
  await p.screenshot({path:path.join(SHOTS,'r4.1-phone-visit-remote-sit.png'), type:'png'});
  await ctx.close();
}

// desktop plaza + DM
{
  const {ctx,p}=await newPage({width:1280,height:800}, null);
  await p.goto(origin+'/#plaza');
  await ready(p,'plaza');
  const layout=await p.evaluate(()=>{
    const r=document.getElementById('app').getBoundingClientRect();
    return {app:[Math.round(r.width),Math.round(r.height)], left:Math.round(r.left)};
  });
  note(layout.app[0]>=500 && layout.app[0]<=600, 'desktop frame width '+JSON.stringify(layout));
  await p.screenshot({path:path.join(SHOTS,'r4.1-desktop-plaza.png'), type:'png'});
  await p.evaluate((html)=>document.body.insertAdjacentHTML('beforeend', html), dmMarkup());
  await p.waitForTimeout(250);
  const dm=await p.evaluate(()=>{
    const el=document.querySelector('.tgg-mask.tgs-dm');
    const app=document.getElementById('app');
    const er=el.getBoundingClientRect(), ar=app.getBoundingClientRect();
    return {
      parent:el.parentElement.id, pos:getComputedStyle(el).position,
      maskInApp: er.left>=ar.left-1 && er.right<=ar.right+1 && er.top>=ar.top-1 && er.bottom<=ar.bottom+1,
      app:[Math.round(ar.width),Math.round(ar.height)],
      squeezed: ar.width<500
    };
  });
  note(dm.parent==='app' && dm.maskInApp && !dm.squeezed, 'desktop DM inside frame '+JSON.stringify(dm));
  await p.screenshot({path:path.join(SHOTS,'r4.1-desktop-dm.png'), type:'png'});
  await ctx.close();
}

await browser.close();
server.close();
console.log(fails.length?('FAILED '+fails.length+'\n- '+fails.join('\n- ')):'ALL PASS');
process.exit(fails.length?1:0);
