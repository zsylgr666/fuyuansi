/* r8b: 心田小院 (yard) + 集市 (market) + 茶会小院 (tea).
   Runs once per scene, after r8.js (dress/fixScene) on worldEnter. Uses r8.js helpers via TG_R8.lib.
   Every change is pushed to TG_R8.changes (scene, object, from, to). */
(function(){
if(!window.TG_R8||!TG_R8.lib)return;
const T=THREE,L=TG_R8.lib,changes=TG_R8.changes;
const box3=(x,X,z,Z,tag)=>({x,X,z,Z,r8b:tag});
const centre=b=>b.getCenter(new T.Vector3()),size=b=>b.getSize(new T.Vector3());
const inRect=(b,x,X,z,Z)=>{const c=centre(b);return c.x>x&&c.x<X&&c.z>z&&c.z<Z;};
// shrink an over-sized ground plane (it hid the distance) to the scene footprint
function trimGround(s,name,half){s.group.traverse(m=>{if(!m.isMesh||m.isInstancedMesh)return;const g=m.geometry;if(!g.boundingBox)g.computeBoundingBox();const z=size(g.boundingBox.clone().applyMatrix4(m.matrixWorld));
 if(z.x>80&&z.z>80&&z.y<.5){const k=(2*half)/z.x;m.scale.x*=k;m.scale.z*=k;if(m.scale.y!==1&&Math.abs(m.rotation.x)>1)m.scale.y*=k;m.updateMatrixWorld(true);changes.push({scene:name,object:'oversized ground plane trimmed to the scene footprint (it hid the distant scenery)',from:Math.round(z.x),to:2*half});}});}
const SCENES={
 yard:{dist:{inner:25,square:23.6,seed:43,valley:Math.PI/2,villages:[[-1.1,40,5],[1.0,46,6],[2.6,38,5],[4.4,44,5]]}},
 market:{dist:{inner:19.5,square:17.2,seed:57,valley:Math.PI,villages:[[.3,34,6],[1.9,38,5],[4.0,36,6],[5.3,30,4]]}},
 tea:{dist:{inner:23,square:21.5,seed:61,valley:0,villages:[[1.6,34,5],[3.3,40,6],[4.6,33,5]]}},
};
const fixes={};

// Audit instrumentation upkeep: when r8b edits a merged (batched) geometry, the codex2 audit's ghost parts
// (window.__R8.ghosts, only present under the audit) are re-linked to the edited geometry, moved/scaled with
// their piece, or dropped if the piece was removed — so the audit sees exactly what is rendered.
function ghostSync(fn){return function(a,...rest){const R8=window.__R8;if(!R8||!R8.ghosts?.length)return fn.call(this,a,...rest);
 const root=a&&a.group?a.group:a;root.updateMatrixWorld(true);const snap=[];
 root.traverse(m=>{if(!m.isMesh||m.isInstancedMesh||!m.geometry?.userData?.__r8merged)return;const gs=R8.ghosts.filter(g=>g.geo===m.geometry);if(!gs.length)return;
  const g=m.geometry,pos=g.attributes.position,comps=L.components(g),v=new T.Vector3(),boxes=comps.map(ids=>{const b=new T.Box3();for(const i of ids)b.expandByPoint(v.fromBufferAttribute(pos,i).applyMatrix4(m.matrixWorld));return b;});
  const rows=[];for(const gh of gs){const gg=gh.mesh.geometry;if(!gg.boundingBox)gg.computeBoundingBox();const gb=gg.boundingBox.clone().applyMatrix4(gh.world),gc=C(gb),gz=Z(gb);
   let k=-1,bd=1e9;boxes.forEach((b,i)=>{const d=C(b).distanceTo(gc)+Z(b).distanceTo(gz);if(d<bd){bd=d;k=i;}});if(k>=0&&bd<.02)rows.push({gh,ids:comps[k],box:boxes[k]});}
  snap.push({m,geo:g,rows,gs});});
 const out=fn.call(this,a,...rest);root.updateMatrixWorld(true);
 for(const {m,geo,rows,gs}of snap){if(m.geometry===geo&&m.visible)continue;const g=m.geometry,pos=g.attributes.position,v=new T.Vector3();
  if(m.visible)for(const gh of gs)if(gh.geo===geo)gh.geo=g; // untouched parts follow the cloned geometry too
  let live=null;if(g.index){live=new Set();const ix=g.index;for(let i=0;i<ix.count;i++)live.add(ix.getX(i));}
  for(const r of rows){const gh=r.gh;if(!m.visible||(live&&!r.ids.some(i=>live.has(i)))){const k=R8.ghosts.indexOf(gh);if(k>=0)R8.ghosts.splice(k,1);continue;}
   gh.geo=g;const nb=new T.Box3();for(const i of r.ids)nb.expandByPoint(v.fromBufferAttribute(pos,i).applyMatrix4(m.matrixWorld));
   const os=Z(r.box),ns=Z(nb),sc=new T.Vector3(os.x>1e-6?ns.x/os.x:1,os.y>1e-6?ns.y/os.y:1,os.z>1e-6?ns.z/os.z:1);
   if(nb.min.distanceTo(r.box.min)<1e-5&&sc.distanceTo(new T.Vector3(1,1,1))<1e-5)continue;
   const M=new T.Matrix4().makeTranslation(nb.min.x,nb.min.y,nb.min.z).multiply(new T.Matrix4().makeScale(sc.x,sc.y,sc.z)).multiply(new T.Matrix4().makeTranslation(-r.box.min.x,-r.box.min.y,-r.box.min.z));
   gh.world=M.multiply(gh.world);}}
 return out;};}
for(const k of ['pruneParts','shiftParts','xformParts'])L[k]=ghostSync(L[k]);
const relocateG=ghostSync(TG_R8.relocate);

// ---------- yard (心田小院) ----------
const C=b=>b.getCenter(new T.Vector3()),Z=b=>b.getSize(new T.Vector3());
const isInst=m=>!!m.isInstancedMesh,geoType=m=>m.geometry?.type||'';
const mv=(dx,dy,dz)=>()=>new T.Matrix4().makeTranslation(dx,dy,dz);
function moveBlocks(s,test,dx,dz){for(const b of s.blocks)if(test(b)){b.x+=dx;b.X+=dx;b.z+=dz;b.Z+=dz;}}
const bc=b=>[(b.x+b.X)/2,(b.z+b.Z)/2];
function dropBlocks(s,test,name,what){const n=s.blocks.length;s.blocks=s.blocks.filter(b=>!test(b));if(n!==s.blocks.length)changes.push({scene:name,object:what+' colliders removed',from:n-s.blocks.length,to:0});}
// extra instances of an existing instanced mesh (same geometry/material), template = instance i0, rows = [[x,z],...]
function moreInstances(s,src,i0,rows,name){const mat=new T.Matrix4(),q=new T.Quaternion(),sc=new T.Vector3(),pos=new T.Vector3();src.getMatrixAt(i0,mat);mat.decompose(pos,q,sc);
 const im=new T.InstancedMesh(src.geometry,src.material,rows.length);im.name=name;im.receiveShadow=src.receiveShadow;
 rows.forEach(([x,z,k],i)=>{const S=sc.clone();if(k)S.multiply(new T.Vector3(k,1,1));im.setMatrixAt(i,new T.Matrix4().compose(new T.Vector3(x,pos.y,z),q,S));});
 src.parent.add(im);im.position.copy(src.position);im.rotation.copy(src.rotation);im.scale.copy(src.scale);im.instanceMatrix.needsUpdate=true;im.computeBoundingSphere?.();return im;}
fixes.yard=function(s,name){
 const log=(object,from,to)=>changes.push({scene:name,object,from,to});
 // 1. North gate: the 27 m hall eave (moved here by r6) floated 0.7 m above a 3 m wall with nothing under it.
 //    Fold it into a proper 6.6 m gate roof sitting on the lintel; brackets that pierced the lintel go.
 const eave=(b,m)=>{const c=C(b),z=Z(b);return c.z>-23&&c.z<-19&&b.min.y>3.6&&b.max.y<4.6&&z.x>20;};
 const caps=(b,m)=>{const c=C(b),z=Z(b);return c.z>-23.2&&c.z<-18.8&&b.min.y>3.9&&b.max.y<5.2&&Math.abs(c.x)>12&&Math.abs(c.x)<14.5&&z.x<2.2;};
 // enhance.js laid a second, curved 27 m eave (plates + end caps) over the doorway's own roof: keep one roof.
 L.pruneParts(s,(b,m)=>eave(b,m)&&Math.abs(Z(b).x-27)<.1&&Z(b).z<.6);L.pruneParts(s,caps);
 const k=6.6/27,kz=.7;
 L.xformParts(s,eave,()=>new T.Matrix4().makeTranslation(0,0,-21).multiply(new T.Matrix4().makeScale(k,1,kz)).multiply(new T.Matrix4().makeTranslation(0,0,21)));
 L.pruneParts(s,(b,m)=>isInst(m)&&L.hex(m)!=='f6f9fb'&&C(b).z>-21.4&&C(b).z<-20.2&&b.min.y>3.3&&b.max.y<3.9&&Z(b).x<.9&&Math.abs(C(b).x)<12.5); // brackets
 L.pruneParts(s,b=>Z(b).x>20&&b.min.y>4.1&&C(b).z>-11&&C(b).z<-9.8); // stray 27 m eave plate over mid-yard at 4.3 m
 // gate lanterns: hang them from the new eave ends, on hooks that reach it.
 L.xformParts(s,b=>{const c=C(b),z=Z(b);return Math.abs(Math.abs(c.x)-2.9)<.1&&Math.abs(c.z+20.2)<.1&&z.x<.08&&b.min.y>2.6&&b.max.y<3.7;},L.spanY(3.06,3.78));
 log('north gate eave (27 m, floating over the wall)','x ±13.5, y 4.0–4.5','one gate roof x ±3.3 on the lintel (duplicate enhance eave + end caps removed); brackets that pierced the lintel removed; lantern hooks reach the eave');
 // 2. Stream + plank bridge (art2) dug through the legacy pond's rock ring; one water feature only (the pond).
 L.pruneParts(s,(b,m)=>{const c=C(b);if(geoType(m).startsWith('Dodeca'))return false;
  if(c.x>7.75&&c.x<10.25&&c.z>-5.05&&c.z<-2.95&&b.max.y<.7)return true; // water, deck planks, rails, rail posts
  return isInst(m)&&c.x>8.1&&c.x<10.1&&c.z>-6.3&&c.z<-1.7&&b.max.y<.3;});// bank stones
 dropBlocks(s,b=>Math.abs(b.x-8.375)<.02&&Math.abs(b.X-9.625)<.02,name,'stream');
 log('art2 stream + plank bridge through the pond rock ring','x 9, z −6…−2','removed (pond at (6,−3) kept)');
 // 3. Trees: r3 trunks at (13,6)/(10,12) lost their crowns (r5 drop) and stood as bare poles inside other trees;
 //    the (13,5) tree's crown went through the 心安小筑 roof.
 for(const [x,z]of [[13,6],[10,12]]){L.pruneParts(s,(b,m)=>{const c=C(b),q=Z(b);return Math.hypot(c.x-x,c.z-z)<.2&&q.y>2&&q.x<.4&&b.max.y<2.7;});dropBlocks(s,b=>{const [cx,cz]=bc(b);return Math.hypot(cx-x,cz-z)<.05;},name,'bare r3 trunk');}
 log('bare trunks (crown dropped) at (13,6) and (10,12)','pole 2.4 m','removed');
 relocateG(s.group,13,5,15.6,5,1.9);moveBlocks(s,b=>{const [cx,cz]=bc(b);return Math.hypot(cx-13,cz-5)<1;},2.6,0);
 log('tree whose crown pierced the house roof',[13,0,5],[15.6,0,5]);
 // 4. enhance.js fence posts/rails at x ±21 stood inside the yard walls.
 L.pruneParts(s,(b,m)=>isInst(m)&&Math.abs(Math.abs(C(b).x)-21)<.3&&b.max.y<1.35&&C(b).z>-10.6&&C(b).z<15.6&&Z(b).x<.2);
 log('fence posts/rails inside the east/west walls','x ±21, z −10…14','removed');
 // 5. Plot beds: soil slab lowered to a 0.1 m tilth so the ridges read as furrows (they were buried flush);
 //    ridge end-boards trimmed inside the plot frame.
 L.xformParts(s,(b,m)=>{const q=Z(b);return !isInst(m)&&Math.abs(q.x-2.4)<.02&&Math.abs(q.z-2.3)<.02&&Math.abs(q.y-.2)<.02&&b.min.y> -.01&&b.min.y<.02;},L.spanY(0,.1));
 L.xformParts(s,(b,m)=>{const q=Z(b);return isInst(m)&&Math.abs(q.x-2.5)<.02&&Math.abs(q.z-.12)<.02&&b.min.y>.03&&b.max.y<.33&&C(b).x< -1;},b=>{const c=C(b);return new T.Matrix4().makeTranslation(c.x,0,0).multiply(new T.Matrix4().makeScale(2.34/2.5,1,1)).multiply(new T.Matrix4().makeTranslation(-c.x,0,0));});
 log('plot soil slab / ridge end boards','soil 0.2 m (ridges buried), end boards 2.5 m into the frame','tilth 0.1 m, ridges stand 0.1 m proud; end boards 2.34 m');
 // 6. Path-side gravel sat on the plot frames: move it to the path edge.
 L.shiftParts(s,(b,m)=>geoType(m).startsWith('Dodeca')&&isInst(m)&&C(b).x< -1.85&&C(b).x> -2.2&&b.max.y<.2,[.27,0,0]);
 L.shiftParts(s,(b,m)=>geoType(m).startsWith('Dodeca')&&isInst(m)&&C(b).x>1.85&&C(b).x<2.2&&b.max.y<.2,[-.27,0,0]);
 // 7. r3 flower clumps at (±2.2,−3) grew inside a plot; double lanterns at (±2.2/±2.6,−4): keep the hanging ones.
 L.pruneParts(s,(b,m)=>{const c=C(b),q=Z(b);if(geoType(m).startsWith('Dodeca'))return false;return Math.hypot(Math.abs(c.x)-2.2,c.z+3)<.75&&b.max.y<.5&&Math.max(q.x,q.z)<.4;});
 const stoneLamp=(x,z)=>(b,m)=>{const c=C(b),q=Z(b);return Math.hypot(c.x-x,c.z-z)<.12&&b.max.y<1.9&&Math.max(q.x,q.z)<1.3;};
 for(const [x,z]of [[-2.6,-4],[2.6,-4],[-2.6,9]]){L.pruneParts(s,stoneLamp(x,z));dropBlocks(s,b=>{const [cx,cz]=bc(b);return Math.hypot(cx-x,cz-z)<.05;},name,'stone lantern');}
 log('stone lanterns doubled with the hanging lanterns at (±2.6,−4) and one in the path/pen margin at (−2.6,9)','3 lanterns','removed (hanging lanterns ±2.2 and stone lantern (2.6,9) kept)');
 // 8. Flower pots on the plot frames / in the grass strip: set them clear of the beds.
 for(const [x,z,nz]of [[-3,-7,-8.05],[3,-7,-8.05],[-3,6,6.4],[3,6,6.4]]){
  L.shiftParts(s,(b,m)=>{const c=C(b),q=Z(b);return !isInst(m)&&Math.hypot(c.x-x,c.z-z)<.5&&Math.max(q.x,q.z)<1&&b.max.y<1.2;},[0,0,nz-z]);
  moveBlocks(s,b=>{const [cx,cz]=bc(b);return Math.hypot(cx-x,cz-z)<.05;},0,nz-z);
  L.pruneParts(s,(b,m)=>isInst(m)&&geoType(m)==='SphereGeometry'&&b.max.y<.5&&Math.hypot(C(b).x-x,C(b).z-nz)<.62);
 }
 L.pruneParts(s,(b,m)=>isInst(m)&&geoType(m)==='SphereGeometry'&&b.max.y<.5&&Math.hypot(C(b).x-2.6,C(b).z-9)<.55);
 log('flower pots (on plot frames / in the grass)','z −7 / 6','z −8.05 / 6.4; grass under them cleared');
 // 9. Pen signs hung over the pen gates at head height: put them on the fence beside the gate.
 for(const p of (window.R3_PENS||[])){const mid=(p.x+p.X)/2,nx=(p.x+mid-.9)/2;
  s.group.traverse(m=>{if(!m.isMesh||!m.userData.wallSign)return;const b=new T.Box3().setFromObject(m),c=C(b);if(Math.abs(c.x-mid)<.05&&Math.abs(c.z-p.Z-.02)<.05&&b.max.y<1.8){m.position.x+=nx-mid;m.updateMatrixWorld(true);log('pen sign over the gate ('+p.name+')',[mid,1.45,p.Z],[nx,1.45,p.Z]);}});}
 // 10. South gate: the 福缘里·大厅 frame stood in mid-yard (z 14) while the wall opening is at z 21.
 const dz=7;
 L.shiftParts(s,(b,m)=>{const c=C(b);return Math.abs(c.x)<2&&Math.abs(c.z-14)<.4&&b.max.y>2.5&&L.hex(m)!=='f6f9fb';},[0,0,dz]);
 moveBlocks(s,b=>Math.abs(Math.abs((b.x+b.X)/2)-1.65)<.05&&Math.abs((b.z+b.Z)/2-14)<.05,0,dz);
 for(const e of s.exits)if(e.to==='plaza'&&e.z===14)e.z=20.9;
 for(const it of s.items)if(it.label==='回大厅'&&it.z===14){it.z=20.1;}
 log('south gate frame + exit + 回大厅 prompt',[0,0,14],[0,0,21]);
 // 11. Path: continue the stone walk to both gates.
 let path=null;s.group.traverse(m=>{if(!path&&m.isInstancedMesh&&L.hex(m)==='f6f9fb')path=m;});
 if(path){const rows=[];for(const zc of [14.6,15.7,16.8,17.9,19.0,20.1,-14.7,-15.8,-16.9,-18.0,-19.1])for(const x of [-.68,.68])rows.push([x,zc]);moreInstances(s,path,0,rows,'r8b-yard-path');log('stone path','z −13.5…13.5','z −19.6…20.6 (reaches both gates)');}
 s.r8bSpawnZ=18.8;

 // 12. Furniture. The "bench" was a 2.8×1×1 m solid block (players sat inside it): a real 条凳 facing the house.
 L.pruneParts(s,(b,m)=>{const c=C(b),q=Z(b);return !isInst(m)&&Math.abs(c.x-12)<.05&&Math.abs(c.z-8)<.05&&Math.abs(q.x-2.8)<.05&&Math.abs(q.y-1)<.05;});
 {const box=new T.BoxGeometry(1,1,1),parts=[],add=(c,x,y,z,a,h,d)=>parts.push({geo:box,color:c,at:[12+x,y,8+z],scale:[a,h,d]});
  add('#886043',0,.5,0,2,.12,.5);for(const x of [-.88,.88])for(const z of [-.13,.13])add('#624532',x,.22,z,.13,.44,.13);add('#624532',0,.18,0,1.6,.06,.06);
  L.baked(s.group,'r8b-yard-bench',parts);}
 dropBlocks(s,b=>Math.abs(b.x-10.6)<.02&&Math.abs(b.X-13.4)<.02,name,'old bench block');s.blocks.push(box3(11,13,7.75,8.25,'bench'));
 // 罗汉榻 blocked the house door; set it against the front wall beside the door (back to the wall, door path free).
 const BX=5.3-8,BZ=4.9-5;
 L.shiftParts(s,(b,m)=>{const c=C(b),q=Z(b);return isInst(m)&&c.x>6.6&&c.x<9.4&&c.z>4.2&&c.z<5.8&&b.min.y> -.01&&q.y>.1&&q.y<1.5;},[BX,0,BZ]);
 moveBlocks(s,b=>b.r4Bed,BX,BZ);
 // 13. North wall ran through the gate jambs: stop each run at the jamb's outer face.
 L.xformParts(s,(b,m)=>{const c=C(b),q=Z(b);return !isInst(m)&&Math.abs(c.z+21)<.2&&Math.abs(q.x-18)<.05&&q.z<.4&&q.y>2;},b=>{const sg=Math.sign(C(b).x),inner=sg*2,outer=sg*20,ni=sg*2.6,k=(outer-ni)/(outer-inner);return new T.Matrix4().makeTranslation(outer,0,0).multiply(new T.Matrix4().makeScale(k,1,1)).multiply(new T.Matrix4().makeTranslation(-outer,0,0));});
 log('north wall runs into the gate jambs','x ±2','x ±2.6 (ends at the jamb face)');

 L.crownBlocks(s,name);
 s.r8bFurniture={daybed:{x:5.3,z:4.9,rot:0},bench:{x:12,z:8,rot:Math.PI}};
 log('yard furniture','bench = 1 m solid block at (12,8); 卧榻 in front of the door (8,5)','条凳 (seat 0.56 m) facing the house; 卧榻 at (5.3,4.9) against the wall');
};
const sp=r3Spawn;r3Spawn=function(n,p){const r=sp.apply(this,arguments);if(n==='yard'&&Array.isArray(r)&&Math.abs(r[0])<.01&&Math.abs(r[1]-11)<.01)return [0,18.8,r[2]];return r;};

function fixScene(name){const s=W3.spaces[name],cfg=SCENES[name];if(!s||!cfg||s.r8bFixed)return;
 if(!s.r8bBase){s.r8bBase=true;if(name==='market')trimGround(s,name,40);if(!s.group.getObjectByName('r8a-distance'))L.horizon(s,name,cfg.dist);}
 let ok=true;try{ok=fixes[name]?.(s,name)!==false;}catch(e){console.warn('r8b fix',name,e);}
 if(ok)s.r8bFixed=true; // not ready yet (e.g. the tea courtyard is built a moment after a direct load into #tea): retried from the frame loop
}

// r6FixTeaInteracts (r6-art.js) rebuilds the tea items on a later enter/sync — re-apply the item fixes after it.
function teaItems(s){if(!s)return;const tbl=s.r6Tea?.parts?.tables?.[0];
 for(const it of s.items)if(it.label==='放河灯'){it.z=9.05;it.range=1.6;}
 if(tbl)for(const it of s.items)if(it.label==='落座品茶'&&!it.r8bSeat&&Math.hypot(it.x-tbl.position.x,it.z-tbl.position.z)<1.5){const x=it.x,z=it.z,rot=Math.atan2(tbl.position.x-x,tbl.position.z-z);it.run=()=>r4Use({id:'cushion',x,z,rot,depth:.5},'tea');it.range=1.6;it.r8bSeat=true;}}
if(typeof window.r6FixTeaInteracts==='function'){const f=window.r6FixTeaInteracts;window.r6FixTeaInteracts=function(){const r=f.apply(this,arguments);try{const t=W3.spaces?.tea;if(t?.r8bFixed)teaItems(t);}catch(e){}return r;};}
// ---------- market (集市) ----------
const upHit=(s,x,y,z,skip)=>{const r=new T.Raycaster(new T.Vector3(x,y,z),new T.Vector3(0,1,0),0,3);let best=null;for(const h of r.intersectObject(s.group,true)){if(skip&&skip(h))continue;if(!h.object.visible||h.object.isSprite)continue;let far=false;for(let q=h.object;q;q=q.parent)if(q.name==='r8a-distance'||q===W3.player)far=true;if(far)continue;best=h.point.y;break;}return best;};
fixes.market=function(s,name){
 const log=(object,from,to)=>changes.push({scene:name,object,from,to});
 const art3=m=>L.ancestor(m,'art3-market');
 // 1. Stalls: the r3 counters were gone, leaving r3 posts floating 0.5 m up, an r3 awning slab jammed under the
 //    art3 tiled roof, and baskets/fruit hovering at counter height. One stall = art3 roof + a real counter.
 L.pruneParts(s,(b,m)=>!art3(m)&&Math.abs(C(b).z+5)<.1&&Math.abs(Z(b).x-4.8)<.05&&Math.abs(Z(b).z-3)<.05&&b.min.y>2.8); // r3 awning
 L.pruneParts(s,(b,m)=>!art3(m)&&isInst(m)&&Math.abs(C(b).z+4.25)<.05&&Math.abs(Z(b).y-.04)<.01&&b.min.y>2.9); // stripes inside it
 L.pruneParts(s,(b,m)=>!art3(m)&&isInst(m)&&Math.abs(C(b).z+5)<.05&&Math.abs(Z(b).y-2.6)<.02&&Z(b).x<.14&&b.min.y>.4); // floating posts
 {const box=new T.BoxGeometry(1,1,1),parts=[];for(const x of [-7,0,7]){parts.push({geo:box,color:'#8a5d3e',at:[x,.66,-4.97],scale:[3.8,1.32,1.52]},{geo:box,color:'#9a6b48',at:[x,1.36,-4.97],scale:[3.9,.08,1.6]},{geo:box,color:'#6e4630',at:[x,.06,-4.97],scale:[3.9,.12,1.6]});}
  L.baked(s.group,'r8b-market-counters',parts);}
 for(const b of s.blocks)if(b.z===-6&&b.Z===-4&&Math.abs(b.X-b.x-4)<.01){b.x+=.05;b.X-=.05;b.z=-5.8;b.Z=-4.15;}
 log('market stalls','r3 posts floating at y 0.5, awning slab under the tiled roof, goods hovering at 1.4 m','3 counters (1.4 m) carry the baskets/fruit; r3 awning, stripes and floating posts removed');
 // lantern poles at the counter front become the roof's front posts (they stopped 0.7 m short of the eave)
 L.xformParts(s,(b,m)=>!art3(m)&&isInst(m)&&Math.abs(C(b).z+3.7)<.05&&Math.abs(Z(b).y-2.6)<.02&&Z(b).x<.13,b=>{const c=C(b);const top=upHit(s,c.x,2.75,c.z,h=>Math.abs(h.point.x-c.x)<.08&&h.point.y<2.7)??3.2;return L.spanY(0,top+.01)(b);});
 // ridge-end ornaments sat inside the ridge: set them at the ends
 for(const x of [-7,0,7])for(const sg of [-1,1])L.shiftParts(s,(b,m)=>art3(m)&&L.hex(m)==='b8bdc0'&&Z(b).x<.5&&b.min.y>3.85&&Math.abs(C(b).z+5)<.3&&Math.abs(C(b).x-(x+sg*2.4))<.12,[sg*.26,0,0]);
 // goods were pushed into the shelf back panels
 L.shiftParts(s,(b,m)=>art3(m)&&Math.abs(C(b).z+6)<.06&&Math.max(Z(b).x,Z(b).z)<.45&&b.min.y>.5&&b.max.y<2.7&&Math.abs(C(b).x)<9.2,[0,0,.09]);
 // 2. Tea stall (-6,6.5): parasol 3.8 m wide cut through the 点心铺 roof; table/stools ran into its counter.
 const dz=-1.6;L.shiftParts(s,(b,m)=>art3(m)&&Math.hypot(C(b).x+6,C(b).z-6.5)<1.95&&b.max.y<3.6,[0,0,dz]);
 L.xformParts(s,(b,m)=>art3(m)&&Math.abs(Z(b).x-3.8)<.1&&b.min.y>2.6&&Math.hypot(C(b).x+6,C(b).z-6.5-dz)<.3,b=>{const c=C(b);return new T.Matrix4().makeTranslation(c.x,0,c.z).multiply(new T.Matrix4().makeScale(.7,1,.7)).multiply(new T.Matrix4().makeTranslation(-c.x,0,-c.z));});
 moveBlocks(s,b=>Math.abs(b.x+7.3)<.02&&Math.abs(b.X+4.7)<.02&&Math.abs(b.z-5.2)<.02,0,dz);
 log('tea stall (table, stools, parasol)',[-6,0,6.5],[-6,0,4.9]+' parasol 3.8→2.66 m');

 // parasol pole ran through the table top (the table has its own leg): the pole starts on the table
 L.xformParts(s,(b,m)=>art3(m)&&Math.hypot(C(b).x+5.95,C(b).z-4.95)<.1&&Z(b).x<.1&&b.max.y>3&&b.min.y<.2,L.spanY(.77,2.27)); // up to the hub under the (lowered) canopy rim 2.22, not through the canopy
 // the teapot sat in the middle of the table, where the parasol pole stands: moved to the free side between the cups
 L.shiftParts(s,(b,m)=>art3(m)&&!isInst(m)&&L.hex(m)==='5d7f86'&&Math.hypot(C(b).x+5.96,C(b).z-4.9)<.25&&b.min.y>.74&&b.max.y<1.1,[.11,0,-.27]);
 // the parasol crown poked through the hanging-lantern line (y 2.88–3.13): lower it 0.55 m (rim still 2.2 m)
 L.shiftParts(s,(b,m)=>art3(m)&&Math.abs(Z(b).x-2.66)<.12&&b.min.y>2.6&&Math.hypot(C(b).x+6,C(b).z-4.9)<.3,[0,-.55,0]);
 L.shiftParts(s,(b,m)=>art3(m)&&Z(b).x<.2&&b.min.y>3.2&&b.max.y<3.5&&Math.hypot(C(b).x+5.95,C(b).z-4.95)<.1,[0,-.55,0]);
 // fruit cart: the two pull shafts ran 0.13 m into the cart bed — they start at the bed's end board
 L.xformParts(s,(b,m)=>!isInst(m)&&Z(b).x>1&&Z(b).x<1.4&&Z(b).y<.1&&Z(b).z<.35&&b.min.x>6.1&&b.min.x<6.33&&Math.abs(C(b).y-.85)<.06&&C(b).z>6&&C(b).z<7.6,b=>{const x0=b.min.x,x1=b.max.x,n0=6.375,k=(x1-n0)/(x1-x0);return new T.Matrix4().makeTranslation(x1,0,0).multiply(new T.Matrix4().makeScale(k,1,1)).multiply(new T.Matrix4().makeTranslation(-x1,0,0));});
 // 幌子 sign poles stood inside each stall's eave: plant them just outside the roof line
 for(const x of [-7,0,7]){L.shiftParts(s,(b,m)=>art3(m)&&Math.abs(C(b).z+3.6)<.06&&C(b).x>x+1.75&&C(b).x<x+2.75&&b.max.y>2.3,[1.1,0,0]);moveBlocks(s,b=>Math.abs((b.x+b.X)/2-(x+2.6))<.05&&Math.abs((b.z+b.Z)/2+3.6)<.05,1.1,0);}
 // lantern-stall globes sat 6 cm down inside their cup stands
 L.shiftParts(s,(b,m)=>art3(m)&&isInst(m)&&geoType(m)==='SphereGeometry'&&Math.abs(C(b).z+5.91)<.04&&Math.abs(Z(b).x-.31)<.03&&C(b).x>4.5&&C(b).x<9.5,[0,.06,0]);
 log('market props','parasol pole through the table top; sign poles inside the eaves; globes sunk in their stands','pole on the table; sign poles 1.1 m out past the roof line; globes seated');
 // 3. Snack / consignment stalls: their roofs overhang the counter colliders (walk-under → walk-through).
 for(const b of s.blocks){if(b.x===-8.8&&b.X===-5.2&&b.z===7&&b.Z===9){b.x=-9;b.X=-5;b.z=6.7;b.Z=9.3;}if(b.x===-2&&b.X===2&&b.z===7&&b.Z===9){b.x=-2.4;b.X=2.4;b.z=6.7;b.Z=9.4;}}
 // shop signs read mirrored from behind: single-sided (the board behind shows from the back)
 s.group.traverse(m=>{if(m.isMesh&&m.userData.wallSign&&m.material&&m.material.side!==T.FrontSide){m.material=m.material.clone();m.material.side=T.FrontSide;}});
 // 4. West gate: posts ran 0.33 m through the lintel.
 L.xformParts(s,(b,m)=>{const c=C(b),q=Z(b);return Math.abs(c.x+14)<.4&&Math.abs(Math.abs(c.z)-1.65)<.1&&Math.abs(q.y-3.2)<.02&&b.min.y<.01;},L.spanY(0,2.875));
 log('west gate posts through the lintel','post top 3.2','2.875 (lintel underside)');
};

// ---------- tea (茶会小院) ----------
// helpers: world boxes of instances / merged pieces
function instBoxes(m){const out=[];if(!m.isInstancedMesh)return out;m.updateMatrixWorld(true);const b=m.geometry.boundingBox||(m.geometry.computeBoundingBox(),m.geometry.boundingBox),mat=new T.Matrix4();for(let i=0;i<m.count;i++){m.getMatrixAt(i,mat);if(Math.abs(mat.determinant())<1e-12){out.push(null);continue;}out.push(b.clone().applyMatrix4(m.matrixWorld.clone().multiply(mat)));}return out;}
function pieceBoxes(root){const out=[],v=new T.Vector3();root.updateMatrixWorld(true);root.traverse(m=>{if(!m.isMesh||!m.visible||!m.geometry?.attributes?.position)return;if(m.isInstancedMesh){for(const b of instBoxes(m))if(b)out.push(b);return;}const p=m.geometry.attributes.position;for(const ids of L.components(m.geometry)){const b=new T.Box3();for(const i of ids)b.expandByPoint(v.fromBufferAttribute(p,i).applyMatrix4(m.matrixWorld));out.push(b);}});return out;}
const ov=(a,b,e=.02)=>a.min.x<b.max.x-e&&a.max.x>b.min.x+e&&a.min.y<b.max.y-e&&a.max.y>b.min.y+e&&a.min.z<b.max.z-e&&a.max.z>b.min.z+e;
function zeroInst(m,i){const z=new T.Matrix4().makeScale(0,0,0);m.setMatrixAt(i,z);m.instanceMatrix.needsUpdate=true;}
fixes.tea=function(s,name){
 const log=(object,from,to)=>changes.push({scene:name,object,from,to});const c=s.r6Tea;if(!c||!c.parts?.tree||!c.parts?.plants)return false;
 s.group.updateMatrixWorld(true);
 const tree=c.parts.tree,wall=c.parts.wall,bam=(c.parts.bamboo||[]).map(g=>{const ims=g.children.filter(m=>m.isInstancedMesh);return {g,cul:ims[0],lv:ims[1]};});
 // 1. Bamboo × osmanthus / message-wall roof: bamboo leaf clusters (and any culm) that ran into the crown or the roof are thinned out.
 const keepOut=[...pieceBoxes(tree).filter(b=>b.max.y>1.2),...pieceBoxes(wall).filter(b=>b.max.y>3)];let nl=0,nc=0;
 for(const B of bam){if(!B.cul||!B.lv)continue;const cb=instBoxes(B.cul),lb=instBoxes(B.lv),per=Math.round(B.lv.count/B.cul.count)||4;
  cb.forEach((b,i)=>{if(b&&keepOut.some(k=>ov(k,b))){zeroInst(B.cul,i);nc++;for(let k=0;k<per;k++)if(lb[i*per+k]){zeroInst(B.lv,i*per+k);lb[i*per+k]=null;}}});
  lb.forEach((b,i)=>{if(b&&keepOut.some(k=>ov(k,b))){zeroInst(B.lv,i);nl++;}});B.cul.computeBoundingSphere();B.lv.computeBoundingSphere();}
 log('bamboo into the osmanthus crown / wall roof','leaf clusters through the crown',`${nl} leaf clusters + ${nc} culms thinned`);
 // 2. River: the little bridge led straight into the south bamboo — removed; the banks become the river collider; 放河灯 from the north bank.
 if(c.parts.bridge){c.parts.bridge.visible=false;c.parts.bridge.traverse(m=>{if(m.isMesh)m.visible=false;});}
 const rb=pieceBoxes(c.parts.river).filter(b=>Z(b).x<30);const rv=s.blocks.find(b=>Math.abs(b.x+9.72)<.05&&Math.abs(b.z-10)<.05);
 if(rv){rv.z=9.45;rv.Z=12.35;}
 teaItems(s);
 log('river','bridge to nowhere (into the bamboo); bank stones walk-through; 放河灯 on the far bank','bridge removed; collider 9.45–12.35 (banks); 放河灯 at the north bank');
 // south bamboo culms standing in the bank stones: step them back
 const bank=rb.filter(b=>b.max.y>.1);for(const B of bam){if(!B.cul)continue;const cb=instBoxes(B.cul),lb=B.lv?instBoxes(B.lv):[],per=B.lv?Math.round(B.lv.count/B.cul.count):0,mat=new T.Matrix4(),inv=B.cul.matrixWorld.clone().invert();
  cb.forEach((b,i)=>{if(!b||!bank.some(k=>ov(k,b,.0)))return;const lowB=b.clone();let dz=0;for(const k of bank)if(ov(k,lowB,0))dz=Math.max(dz,k.max.z-b.min.z+.04);if(!dz)return;
   const d=new T.Vector3(0,0,dz).applyMatrix4(inv).sub(new T.Vector3().applyMatrix4(inv));for(const [m,j] of [[B.cul,i],...Array.from({length:per},(_,k)=>[B.lv,i*per+k])]){m.getMatrixAt(j,mat);if(Math.abs(mat.determinant())<1e-12)continue;mat.elements[12]+=d.x;mat.elements[13]+=d.y;mat.elements[14]+=d.z;m.setMatrixAt(j,mat);m.instanceMatrix.needsUpdate=true;}});}
 // still touching a bank stone after the step-back (low leaf sprays, leaning culms): thinned out
 let nbk=0;for(const B of bam){if(!B.cul)continue;const per=B.lv?Math.round(B.lv.count/B.cul.count):0;instBoxes(B.cul).forEach((b,i)=>{if(b&&bank.some(k=>ov(k,b,.03))){zeroInst(B.cul,i);nbk++;for(let k=0;k<per;k++)zeroInst(B.lv,i*per+k);}});
  if(B.lv)instBoxes(B.lv).forEach((b,i)=>{if(b&&bank.some(k=>ov(k,b,.03))){zeroInst(B.lv,i);nbk++;}});B.cul.computeBoundingSphere();B.lv?.computeBoundingSphere();}
 log('south/north bamboo on the river bank stones','culms/leaf sprays through the bank stones',`stepped back; ${nbk} sprays/culms thinned`);
 // 3. Pots beside the message wall stood inside its frame: 0.5 m further out.
 for(const sg of [-1,1]){relocateG(s.group,sg*2.6,-10.7,sg*3.1,-10.7,.45);moveBlocks(s,b=>Math.abs((b.x+b.X)/2-sg*2.6)<.05&&Math.abs((b.z+b.Z)/2+10.7)<.05,sg*.5,0);}
 log('wall pots','pots at x ±2.6 inside the wall frame','x ±3.1');
 // pot plants: flower heads buried in the bush → on its surface; bonsai trunk / bamboo culms stop at their foliage
 for(const p of c.parts.pots||[]){const px=p.position.x,pz=p.position.z;
  L.xformParts(s,(b,m)=>{const q=Z(b),cc=C(b);return !isInst(m)&&q.x<.12&&q.y<.12&&cc.y>.5&&cc.y<.75&&Math.hypot(cc.x-px,cc.z-pz)<.26&&Math.hypot(cc.x-px,cc.z-pz)>.12;},b=>{const cc=C(b),dx=cc.x-px,dz=cc.z-pz,r=Math.hypot(dx,dz),k=.3/r;return new T.Matrix4().makeTranslation(px+dx*k-cc.x,.02,pz+dz*k-cc.z);});}
 L.xformParts(s,(b,m)=>{const q=Z(b),cc=C(b);return !isInst(m)&&Math.abs(cc.x+3.1)<.1&&Math.abs(cc.z+10.7)<.1&&q.y>.4&&q.y<.6&&q.x<.3&&b.min.y>.25&&b.min.y<.35;},L.spanY(.3,.72));
 L.xformParts(s,(b,m)=>{const q=Z(b),cc=C(b);return !isInst(m)&&Math.abs(cc.x-3.1)<.16&&Math.abs(cc.z+10.7)<.1&&q.y>.8&&q.y<1.2&&q.x<.1&&b.min.y>.25;},b=>{const cc=C(b),i=Math.round((cc.x-3.1)/.05)+2;return L.spanY(b.min.y,1.2+i*.04-.03)(b);});
 log('pot plants','flowers buried in the bush; bonsai trunk / bamboo culms through their leaf pads','flowers on the bush surface; stems end at the foliage');
 // bonsai (r3) side branch poking out through the pot plant's leaf pad
 L.pruneParts(s,(b,m)=>!m.isInstancedMesh&&Math.abs(C(b).x+2.98)<.08&&Math.abs(C(b).z+10.7)<.06&&Math.abs(C(b).y-.78)<.06&&Z(b).x<.35&&Z(b).y<.3);
 // 4. Plants (shrubs/grass/rocks) growing through bamboo, pickets, wall, pots, lanterns: removed where they collide.
 const solid=[...bank,...bam.flatMap(B=>B.cul?instBoxes(B.cul).filter(Boolean):[]),...pieceBoxes(wall),...(c.parts.pots||[]).map(p=>new T.Box3().setFromObject(p)),...pieceBoxes(c.parts.chess)];
 s.group.traverse(m=>{if(m.isInstancedMesh&&m.parent===c.group&&m.count>=100&&m.count<=300&&geoType(m).startsWith('Cylinder'))solid.push(...instBoxes(m).filter(Boolean));});
 if(c.parts.lanterns?.isInstancedMesh)solid.push(...instBoxes(c.parts.lanterns).filter(Boolean));else s.group.traverse(m=>{if(m.isInstancedMesh&&m.count===4)solid.push(...instBoxes(m).filter(Boolean));});
 let np=0;for(const m of c.parts.plants.children){if(!m.isInstancedMesh)continue;instBoxes(m).forEach((b,i)=>{if(b&&solid.some(k=>ov(k,b,.01))){zeroInst(m,i);np++;}});m.computeBoundingSphere();}
 log('plants through bamboo / pickets / wall / pots / lanterns','undergrowth inside solids',`${np} pruned`);
 // 5. Colliders for what you could walk through.
 const add=(x,X,z,Z,tag)=>s.blocks.push({x,X,z,Z,r8b:tag});
 // tree: root flare + low branches
 const tb=s.blocks.find(b=>Math.abs((b.x+b.X)/2-tree.position.x)<.05&&Math.abs((b.z+b.Z)/2-tree.position.z)<.05);if(tb){tb.x=tree.position.x-.6;tb.X=tree.position.x+.6;tb.z=tree.position.z-.6;tb.Z=tree.position.z+.6;}
 // shrubs and rocks taller than 0.3 m: their own small colliders
 let nb=0;for(const m of c.parts.plants.children){if(!m.isInstancedMesh)continue;for(const b of instBoxes(m)){if(!b||Z(b).y<.3||b.max.y<.3)continue;const cc=C(b),q=Z(b),hx=q.x*.32,hz=q.z*.32;if(s.blocks.some(k=>cc.x>k.x&&cc.x<k.X&&cc.z>k.z&&cc.z<k.Z))continue;add(cc.x-hx,cc.x+hx,cc.z-hz,cc.z+hz,'plant');nb++;}}
 // chess table + its stone stools; tea-table cushions; east door posts
 const cb=new T.Box3().setFromObject(c.parts.chess),ck=s.blocks.find(b=>Math.abs(b.x-4.7)<.05&&Math.abs(b.z+2.32)<.05);if(ck){ck.x=cb.min.x+.08;ck.X=cb.max.x-.08;ck.z=cb.min.z+.08;ck.Z=cb.max.z-.08;}
 const tbl=c.parts.tables?.[0];if(tbl)for(const st of tbl.userData.seats||[]){const v=new T.Vector3(st.x,0,st.z).applyAxisAngle(new T.Vector3(0,1,0),tbl.rotation.y).add(tbl.position);add(v.x-.24,v.x+.24,v.z-.24,v.z+.24,'cushion');}
 for(const sg of [-1,1])add(13.65,14.35,sg*1.7-.2,sg*1.7+.2,'door-post');
 // bamboo rows: the walk boundary is the inner face of the grove (x −12.1 / z −12.1 / z 12.3). The old row colliders
 // (and the strip behind them, which was walkable inside the foliage) are replaced by that boundary.
 const strip=b=>(Math.abs(b.z+13.3)<.02&&b.Z-b.z>1&&b.Z-b.z<1.3)||(Math.abs(b.x+13.3)<.02&&b.X-b.x>1&&b.X-b.x<1.3)||(Math.abs(b.Z-13.5)<.02&&Math.abs(b.z-12.3)<.02);
 const ns=s.blocks.length;s.blocks=s.blocks.filter(b=>!strip(b));s.r8bBounds={x0:-12.1,z0:-12.1,z1:12.3};
 log('bamboo grove edge','row colliders 1.2 m deep, walkable strip behind the culms (inside the foliage)',`${ns-s.blocks.length} row colliders → walk boundary at the grove face`);
 // low leaf sprays hanging into the walkway at chest height: lifted to 1.45 m (or thinned if that would float them)
 let nlift=0,nthin=0;const inWalk=b=>b.max.x>-12.1+.15&&b.max.z>-12.1+.15&&b.min.z<12.3-.15;
 for(const B of bam){if(!B.lv)continue;const mat=new T.Matrix4(),inv=B.lv.matrixWorld.clone().invert();instBoxes(B.lv).forEach((b,i)=>{if(!b||b.min.y>=1.42||!inWalk(b))return;
  const crop=b.clone();crop.min.x=Math.max(crop.min.x,-12.1);crop.min.z=Math.max(crop.min.z,-12.1);crop.max.z=Math.min(crop.max.z,12.3);if(Z(crop).x<.15||Z(crop).z<.15)return;
  const dy=1.45-b.min.y;if(dy>.6){zeroInst(B.lv,i);nthin++;return;}
  const d=new T.Vector3(0,dy,0).applyMatrix4(inv).sub(new T.Vector3().applyMatrix4(inv));B.lv.getMatrixAt(i,mat);mat.elements[12]+=d.x;mat.elements[13]+=d.y;mat.elements[14]+=d.z;B.lv.setMatrixAt(i,mat);B.lv.instanceMatrix.needsUpdate=true;nlift++;});B.lv.computeBoundingSphere();}
 log('bamboo leaf sprays over the walkway','down to 1.0 m (chest height)',`${nlift} lifted to 1.45 m, ${nthin} thinned`);
 if(rv)rv.X=7.6; // east end of the bank stones
 log('walk-through','tree, shrubs, chess table, cushions, door posts, river banks, behind the bamboo',`${nb} plant colliders; chess table/cushion/door-post/bamboo-strip colliders`);
 // 6. Tea seats: r6 passed the cushion's ry (pointing away from the table) — sit facing the table.
 teaItems(s);
 log('tea cushions','seated facing away from the table','face the table');
 // the vase stem shared one mesh with the four floor cushions (a 0.64 m tall block over the whole mat): moved into the flower-head mesh
 {const tg=s.group.getObjectByName('tea:table');const mt=tg&&tg.children.find(m=>m.isMesh&&m.name==='tea:tea:vc-matte'),st=tg&&tg.children.find(m=>m.isMesh&&m.name==='tea:tea:vc-satin');
  if(mt&&st&&!mt.geometry.index&&!st.geometry.index){tg.updateMatrixWorld(true);const g=mt.geometry,P=g.attributes.position,v=new T.Vector3(),drop=new Set();
   for(const ids of L.components(g)){const b=new T.Box3();for(const i of ids)b.expandByPoint(v.fromBufferAttribute(P,i).applyMatrix4(mt.matrixWorld));if(b.min.y>.4)ids.forEach(i=>drop.add(i));}
   const names=Object.keys(st.geometry.attributes).filter(k=>g.attributes[k]);if(drop.size&&names.length===Object.keys(st.geometry.attributes).length){
    const M=new T.Matrix4().copy(st.matrixWorld).invert().multiply(mt.matrixWorld),N=new T.Matrix3().getNormalMatrix(M),keepTri=[],moveTri=[];
    for(let t=0;t<P.count/3;t++)(drop.has(3*t)?moveTri:keepTri).push(t);
    const build=(src,tris,extra,xf)=>{const out=new T.BufferGeometry();for(const k of names){const A=src.attributes[k],n=A.itemSize,E=extra?extra.attributes[k]:null,len=(tris.length*3+(E?E.count:0))*n,arr=new Float32Array(len);let o=0;
      if(E){arr.set(E.array.subarray(0,E.count*n),0);o=E.count*n;}for(const t of tris)for(let q=0;q<3;q++){const i=3*t+q;if(xf&&k==='position'){v.fromBufferAttribute(A,i).applyMatrix4(M);arr[o++]=v.x;arr[o++]=v.y;arr[o++]=v.z;}else if(xf&&k==='normal'){v.fromBufferAttribute(A,i).applyMatrix3(N).normalize();arr[o++]=v.x;arr[o++]=v.y;arr[o++]=v.z;}else for(let c=0;c<n;c++)arr[o++]=A.array[i*n+c];}
      out.setAttribute(k,new T.BufferAttribute(arr,n));}out.computeBoundingBox();out.computeBoundingSphere();return out;};
    const ng=build(g,keepTri,null,false);for(const k of Object.keys(g.attributes))if(!ng.attributes[k]){const A=g.attributes[k],n=A.itemSize,arr=new Float32Array(keepTri.length*3*n);let o=0;for(const t of keepTri)for(let q=0;q<3;q++)for(let c=0;c<n;c++)arr[o++]=A.array[(3*t+q)*n+c];ng.setAttribute(k,new T.BufferAttribute(arr,n));}
    const sg=build(g,moveTri,st.geometry,true);mt.geometry=ng;st.geometry=sg;
    log('tea table vase stem','in the cushion mesh (one 0.64 m block over the mat)','in the flower-head mesh');}}}
};

// per-scene walk boundary tighter than the square limit (tea: the bamboo grove faces)
{const cm0=worldCanMove;worldCanMove=function(x,z){const s=W3.spaces[W3.active],B=s&&s.r8bBounds,r=.28;if(B&&((B.x0!=null&&x<B.x0+r)||(B.x1!=null&&x>B.x1-r)||(B.z0!=null&&z<B.z0+r)||(B.z1!=null&&z>B.z1-r)))return false;return cm0(x,z);};}
// ---------- furniture: walk to it, turn, sit / lie down, get up (all scenes) ----------
const SEAT_IDS=['daybed','bed','bench','chair','stool','cushion','rocking-chair'];
function yardFurniture(item,scene){const f=W3.spaces[scene]?.r8bFurniture;if(!f)return item;const k=f[item.id];if(k&&((item.id==='daybed'&&item.x===8&&item.z===5)||(item.id==='bench'&&item.x===12&&item.z===8)))return {...item,...k};return item;}
const syncDecor=worldSyncDecor;worldSyncDecor=function(){const r=syncDecor.apply(this,arguments);const w=W3,s=w?.spaces?.[w.active];
 if(s?.r8bFurniture)for(const it of s.items){if(!it.r4Furniture||it.r8bFix)continue;const id=it.label==='睡觉'?'daybed':it.label==='坐下'?'bench':null;if(!id)continue;const base={id,x:it.x,z:it.z},f=yardFurniture(base,w.active);if(f===base)continue;
  it.r8bFix=true;it.x=f.x+(id==='daybed'?0:0);it.z=f.z+(id==='daybed'?.9:-.6);it.range=1.9;it.run=()=>r4Use(f,w.active);}
 return r;};
function seatDepth(item){if(item.depth)return item.depth;const c=(typeof r3Item==='function')&&r3Item(item.id);return c?.d||(item.id==='stool'?.5:.6);}
function seatWidth(item){const c=(typeof r3Item==='function')&&r3Item(item.id);return c?.w||.6;}
function freeAt(x,z){try{return worldCanMove(x,z);}catch(e){return true;}}
function approachPoint(item,from){const rot=item.rot||0,fx=Math.sin(rot),fz=Math.cos(rot),rx=Math.cos(rot),rz=-Math.sin(rot),d=seatDepth(item)/2+.45,wd=seatWidth(item)/2+.45;
 const lying=['bed','daybed'].includes(item.id);
 // front first (you sit down with the seat behind you); beds: the open long side. Then the ends, then behind.
 const c=[[fx*d,fz*d,0],[rx*wd,rz*wd,1],[-rx*wd,-rz*wd,1],[-fx*d,-fz*d,2]];
 const ok=c.map(([dx,dz,rank])=>({x:item.x+dx,z:item.z+dz,rank})).filter(p=>freeAt(p.x,p.z));
 if(!ok.length)return null;ok.sort((a,b)=>a.rank-b.rank||Math.hypot(a.x-from.x,a.z-from.z)-Math.hypot(b.x-from.x,b.z-from.z));
 return lying?ok[0]:ok.find(p=>p.rank===0)||ok.sort((a,b)=>Math.hypot(a.x-from.x,a.z-from.z)-Math.hypot(b.x-from.x,b.z-from.z))[0];}
let seat=null; // {phase:'walk'|'turn'|'down'|'sat'|'up', item, scene, P, t, from, to, yaw0}
const angDiff=(a,b)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
const use=r4Use;r4Use=function(item,scene){
 if(!item||!SEAT_IDS.includes(item.id)||seat?.bypass)return use.apply(this,arguments);
 item=yardFurniture(item,scene);const w=W3,p=w.player.position;
 const P=approachPoint(item,p);
 if(!P){seat={phase:'down',item,scene,P:{x:p.x,z:p.z},t:0};return sitNow();}
 seat={phase:'walk',item,scene,P,t:0};w.target={x:P.x,z:P.z};w.path=[];w.r5SeatBounds=null;
};
const rc=new T.Raycaster();
function seatTop(item){const w=W3,g=w.spaces[w.active]?.group;if(!g)return null;let top=null;const rot=item.rot||0,fx=Math.sin(rot),fz=Math.cos(rot);
 for(const [a,b]of [[0,0],[.12,0],[-.12,0],[0,.12],[0,-.12]]){rc.set(new T.Vector3(item.x+a*fz+b*fx,1.25,item.z-a*fx+b*fz),new T.Vector3(0,-1,0));rc.far=1.3;
  for(const h of rc.intersectObject(g,true)){let o=h.object,skip=false;for(let q=o;q;q=q.parent)if(q===w.player||q.name==='r8a-distance'){skip=true;break;}if(skip||!h.object.visible||h.object.isSprite)continue;const y=h.point.y;if(y<1.1&&y>.05){top=Math.max(top??0,y);}break;}}
 return top;}
function sitNow(){const w=W3,s=seat;if(!s)return;const before=w.player.position.clone(),rotBefore=w.player.rotation.y;s.bypass=true;try{use(s.item,s.scene);}finally{s.bypass=false;}
 if(w.pose==='sit'){try{const av=w.r6Avatar,A=window.TG_AVATAR,top=seatTop(s.item);if(av&&A?.setPose&&top!=null){A.setPose(av,'sit');const P=av.userData.parts;const by=w.body.position.y;w.body.position.y=-.28;w.player.updateMatrixWorld(true);
   const hip=P.legL.getWorldPosition(new T.Vector3()).y-w.player.position.y,len=.85*P.legL.getWorldScale(new T.Vector3()).y;w.body.position.y=by;
   const lift=s.item.id==='cushion'?.02:.07; // floor cushion: sit low so the legs pass under the low tea table
   w.player.position.y=top+lift-hip;s.legA=Math.max(.35,Math.acos(Math.min(.98,(top+lift)/len)));s.top=top;s.lift=lift;}}catch(e){}}
 if(w.pose==='sleep'&&['bed','daybed'].includes(s.item.id)){try{if(bedPlan(s,before,rotBefore))return;}catch(e){}}
 const after=w.player.position.clone();s.from=before;s.to=after;s.rotTo=w.player.rotation.y;s.rot0=s.item.rot||0;s.phase='down';s.t=0;w.player.position.copy(before);}
// r8c beds / 榻: walk to the long side → turn (back to the bed) → sit on the edge → lie down (head on the pillow, body along the
// long axis = r6's sleep transform) ; getting up runs the same in reverse (lie → edge → stand at the approach point).
function bedPlan(s,before,rotBefore){const w=W3,av=w.r6Avatar,A=window.TG_AVATAR,B=w.body;if(!B)return false;const it=s.item,rot=it.rot||0,fx=Math.sin(rot),fz=Math.cos(rot),d=seatDepth(it);
 const L={pos:w.player.position.clone(),rotY:w.player.rotation.y,by:0,bz:.65,bs:.9,brx:-Math.PI/2}; // r6 sleep body (r6.js r4Pose wrapper)
 const ex=it.x+fx*Math.max(.12,d/2-.2),ez=it.z+fz*Math.max(.12,d/2-.2);const top=seatTop({...it,x:ex,z:ez})??seatTop(it)??.45;
 let hip=.55,legA=1.2;if(av&&A?.setPose){const r0=B.rotation.x,y0=B.position.y,z0=B.position.z,s0=B.scale.x;A.setPose(av,'sit');B.rotation.x=0;B.position.set(B.position.x,-.28,0);B.scale.setScalar(1);w.player.updateMatrixWorld(true);const P=av.userData.parts;hip=P.legL.getWorldPosition(new T.Vector3()).y-w.player.position.y;const len=.85*P.legL.getWorldScale(new T.Vector3()).y;legA=Math.max(.35,Math.acos(Math.min(.98,(top+.07)/len)));A.setPose(av,'stand');B.rotation.x=r0;B.position.y=y0;B.position.z=z0;B.scale.setScalar(s0);}
 const E={pos:new T.Vector3(ex,top+.07-hip,ez),rotY:rot,by:-.28,bz:0,bs:1,brx:0,legA};
 Object.assign(s,{bed:true,lie:L,edge:E,from:before,rot0:rotBefore??w.player.rotation.y,phase:'edge',t:0,legA:null,top:null});w.player.position.copy(before);w.player.rotation.y=s.rot0;return true;} // r8d: rot0 = facing before r4Use (no 90° snap)
function bedBody(s,a,b,k,legs){const w=W3,B=w.body,P=w.r6Avatar?.userData?.parts;B.rotation.x=a.brx+(b.brx-a.brx)*k;B.position.y=a.by+(b.by-a.by)*k;B.position.z=a.bz+(b.bz-a.bz)*k;B.scale.setScalar(a.bs+(b.bs-a.bs)*k);
 if(P&&legs!=null){P.legL.rotation.set(-legs,0,.06);P.legR.rotation.set(-legs,0,-.06);}}
function bedTick(s,dt){const w=W3,p=w.player.position,A=window.TG_AVATAR,av=w.r6Avatar,sm=k=>k*k*(3-2*k);w.vx=w.vz=0;
 const STAND={brx:0,by:0,bz:0,bs:1};
 if(s.phase==='edge'){s.t+=dt;const k=Math.min(1,s.t/.45),e=sm(k);if(!s.sitPose){try{A?.setPose(av,'sit');}catch(_){}s.sitPose=true;}p.lerpVectors(s.from,s.edge.pos,e);w.player.rotation.y=s.rot0+angDiff(s.rot0,s.edge.rotY)*e;bedBody(s,STAND,s.edge,e,s.edge.legA*e);if(k>=1){s.phase='lie';s.t=0;}}
 else if(s.phase==='lie'){s.t+=dt;const k=Math.min(1,s.t/.7),e=sm(k);p.lerpVectors(s.edge.pos,s.lie.pos,e);w.player.rotation.y=s.edge.rotY+angDiff(s.edge.rotY,s.lie.rotY)*e;bedBody(s,s.edge,s.lie,e,s.edge.legA*(1-e));if(k>=1){try{A?.setPose(av,'stand');}catch(_){}s.sitPose=false;s.phase='sat';p.copy(s.lie.pos);w.player.rotation.y=s.lie.rotY;}}
 else if(s.phase==='sat'){if(w.pose!=='sleep'){s.phase='rise';s.t=0;bedTick(s,0);}}
 else if(s.phase==='rise'){s.t+=dt;const k=Math.min(1,s.t/.6),e=sm(k);if(!s.sitPose){try{A?.setPose(av,'sit');}catch(_){}s.sitPose=true;}p.lerpVectors(s.lie.pos,s.edge.pos,e);w.player.rotation.y=s.lie.rotY+angDiff(s.lie.rotY,s.edge.rotY)*e;bedBody(s,s.lie,s.edge,e,s.edge.legA*e);if(k>=1){s.phase='stand';s.t=0;}}
 else if(s.phase==='stand'){s.t+=dt;const k=Math.min(1,s.t/.35),e=sm(k),to=new T.Vector3(s.P.x,0,s.P.z);p.lerpVectors(s.edge.pos,to,e);bedBody(s,s.edge,STAND,e,s.edge.legA*(1-e));if(k>=1){try{A?.setPose(av,'stand');}catch(_){}p.copy(to);bedBody(s,STAND,STAND,1,0);seat=null;w.r5SeatBounds=null;}}}
// lie with the head on the pillow: r6 lays the body along local −x of the bed; the pillow is at −x too (r3 daybed) — checked in qa.
const anim=tgAnimate;tgAnimate=function(ts,dt){const out=anim.apply(this,arguments);const w=W3;if(!w)return out;
 try{
 if(seat){const p=w.player.position,s=seat;
  if(w.active!==s.scene){seat=null;}
  else if(s.bed&&s.phase!=='walk'&&s.phase!=='turn'){bedTick(s,dt);}
  else if(s.phase==='walk'){s.t+=dt;const d=Math.hypot(p.x-s.P.x,p.z-s.P.z);
   if(!w.target&&d>.3){seat=null;} // player steered away: cancel
   else if(d<.25||s.t>4){worldStop();s.phase='turn';s.t=0;s.yaw0=w.player.rotation.y;}}
  else if(s.phase==='turn'){s.t+=dt;const goal=s.item.rot||0,k=Math.min(1,s.t/.35);w.player.rotation.y=s.yaw0+angDiff(s.yaw0,goal)*k;if(k>=1)sitNow();}
  else if(s.phase==='down'){s.t+=dt;const k=Math.min(1,s.t/.32),e=k*k*(3-2*k);if(s.from&&s.to){p.lerpVectors(s.from,s.to,e);}if(s.rotTo!=null)w.player.rotation.y=s.rot0+angDiff(s.rot0,s.rotTo)*e;w.vx=w.vz=0;if(k>=1){s.phase='sat';if(s.to)p.copy(s.to);}}
  else if(s.phase==='sat'){if(w.pose==='idle'||!w.r5Seat&&w.pose!=='sit'&&w.pose!=='sleep'){s.phase='up';s.t=0;s.from=p.clone();s.legUp=s.legA;s.legA=null;}} // r8d: rise from where the hips are now; legs ease out below
  else if(s.phase==='up'){s.t+=dt;const k=Math.min(1,s.t/.32),e=k*k*(3-2*k),to=new T.Vector3(s.P.x,0,s.P.z);p.lerpVectors(s.from,to,e);w.vx=w.vz=0;
   if(s.legUp!=null){const P=w.r6Avatar?.userData?.parts;if(P){const l=s.legUp*(1-e);P.legL.rotation.set(-l,0,.06*(1-e));P.legR.rotation.set(-l,0,-.06*(1-e));}}
   if(k>=1){p.copy(to);if(s.legUp!=null){try{TG_AVATAR.setPose(w.r6Avatar,'stand');}catch(e){}}seat=null;w.r5SeatBounds=null;}}
 if(seat&&seat.legA!=null&&(seat.phase==='down'||seat.phase==='sat')){const P=w.r6Avatar?.userData?.parts;if(P){const kd=seat.phase==='down'?Math.min(1,seat.t/.32):1,ed=kd*kd*(3-2*kd),la=seat.legA*ed;P.legL.rotation.set(-la,0,.06*ed);P.legR.rotation.set(-la,0,-.06*ed); // r8d: legs fold over the 'down' phase
   // hips exactly on the seat whatever body offset the pose code applied this frame
   if(seat.top!=null){w.player.updateMatrixWorld(true);const p=w.player.position,off=P.legL.getWorldPosition(new T.Vector3()).y-p.y,goal=seat.top+(seat.lift??.07)-off;
    if(seat.phase==='sat')p.y=goal;else if(seat.from){const k=Math.min(1,seat.t/.32),e=k*k*(3-2*k);p.y=seat.from.y+(goal-seat.from.y)*e;}}}}
 }
 }catch(e){seat=null;}
 return out;};
const enter2=worldEnter;worldEnter=function(){if(seat?.legA!=null){try{TG_AVATAR.setPose(W3.r6Avatar,'stand');}catch(e){}}seat=null;return enter2.apply(this,arguments);};
window.TG_R8B_SEAT=()=>seat&&{phase:seat.phase,id:seat.item.id,P:seat.P,rot:seat.item.rot||0};

// ---------- prompt priority (all scenes): nearest in the facing direction; exits win ties ----------
const EXIT=/^(回|前往|进入|去|出|离开)|大厅$|回院子/;
function pickPrompt(){const w=W3,s=w.spaces[w.active];if(!s||worldBlocked())return;if(seat&&seat.phase!=='sat')return;
 if(seat&&seat.phase==='sat'){const b=document.getElementById('promptBtn');if(b){w.action=()=>{w.pose='idle';};if(b.textContent!=='起身')b.textContent='起身';b.classList.add('show');w.r8bPrompt='起身';}return;} // seated: the prompt offers getting up
 const p=w.player.position,r=w.player.rotation.y,fx=Math.sin(r),fz=Math.cos(r);let best=null,bs=Infinity;
 for(const it of s.items){if(it.r3Edit&&!r3CanEdit())continue;if(w.active==='hall'&&['上香','上供','敲木鱼'].includes(it.label))continue;
  const dx=it.x-p.x,dz=it.z-p.z,d=Math.hypot(dx,dz);if(d>=it.range)continue;
  const label=typeof it.label==='function'?it.label():it.label;const dot=d>.05?(dx*fx+dz*fz)/d:1;
  let score=d*(1.35-.45*dot);if(EXIT.test(label||''))score*=.7;
  if(score<bs-1e-6||(Math.abs(score-bs)<1e-6&&String(label)<String(best?.label)))best={it,label},bs=score;}
 const btn=document.getElementById('promptBtn');if(!btn)return;
 if(!best){return;}
 w.action=best.it.run;if(btn.textContent!==best.label)btn.textContent=best.label;btn.classList.add('show');w.r8bPrompt=best.label;}
let retryT=0;const anim2=tgAnimate;tgAnimate=function(ts,dt){const out=anim2.apply(this,arguments);try{const sp=W3.spaces?.[W3.active];if(sp&&SCENES[W3.active]&&!sp.r8bFixed&&ts-retryT>400){retryT=ts;fixScene(W3.active);}pickPrompt();}catch(e){}return out;};
// ---------- UI (r8b): drawer buttons ≥ 44 px; 赏景小记 as one gentle sentence (no daily-advice lists) ----------
{const css=document.createElement('style');css.id='r8b-css';css.textContent='#r7Drawer button{min-height:var(--tg-hit,44px)}#r6Placement summary{min-height:var(--tg-hit,44px);display:flex;align-items:center;cursor:pointer}.tgfb-root label.tgfb-lab{display:flex;align-items:center;min-height:var(--tg-hit,44px)}';document.head.append(css);}
{// 赏景小记 (来福): one gentle sentence — a small everyday suggestion or the view — instead of any paired do/don't list
 const LINES={'北':['院子朝北，光线柔和，今天适合在窗边读几页书。','北边的院子很安静，今天适合给绿植浇一次水。'],
  '南':['院子朝南，阳光正好，今天适合把被子拿出来晒一晒。','南边光照足，今天适合在院里慢慢散步。'],
  '东':['院子朝东，早上能看到晨光，今天适合早起走一走。','东边的晨光很干净，今天适合泡一壶茶慢慢喝。'],
  '西':['院子朝西，傍晚的晚霞很好看，今天适合出门看看天。','西边下午暖洋洋的，今天适合把书桌收拾一下。'],
  '东南':['东南这一侧很敞亮，今天适合在那里写几行字。','东南角风很轻，今天适合听一首喜欢的歌。'],
  '西南':['西南这一侧比较暖，今天适合和家人一起吃顿饭。','西南角的光很柔，今天适合翻翻旧照片。'],
  '东北':['东北这一侧很安静，今天适合整理一层书架。','东北角清清爽爽，今天适合早点休息。'],
  '西北':['西北这一侧整洁明亮，今天适合擦一擦窗台。','西北角视野开阔，今天适合看一会儿云。']};
 const BAN=/宜|忌|吉|凶|运势|签|卦|命|算|测|预测|五行|生肖|属相|方位|幸运/;
 const fix=()=>{const box=document.getElementById('fengResult');if(!box||!box.innerHTML.trim()||box.dataset.r8b==='1')return;
  const dir=(typeof fengDir!=='undefined'&&fengDir)||'南',d=new Date(),day=d.getFullYear()*372+d.getMonth()*31+d.getDate(),pool=LINES[dir]||LINES['南'];
  let line=pool[day%pool.length];if(BAN.test(line))line='今天适合慢慢散步。';
  box.dataset.r8b='1';box.dataset.r7d='1';box.innerHTML='<div class="card r8b-feng"><p style="margin:0;font-size:16px;line-height:1.7">'+line+'</p></div>';};
 // 写一写 again in the same panel: the original renderer writes its raw result again — re-arm so it is replaced every time
 document.addEventListener('click',e=>{if(!e.target.closest?.('#fengBtn'))return;const box=document.getElementById('fengResult');if(box){box.dataset.r8b='';}},true);
 new MutationObserver(()=>{const mid=document.querySelector('#fengDirs .mid');if(mid&&mid.textContent!=='🏡')mid.textContent='🏡'; /* the centre tile showed ☯️ */
  const box=document.getElementById('fengResult');if(box&&box.dataset.r8b==='1'&&box.innerHTML.trim()&&!box.querySelector('.r8b-feng'))box.dataset.r8b='';fix();}).observe(document.body,{childList:true,subtree:true,characterData:true});}
// camera easing uses the frame's own dt (r8CameraDt was never set, so r8.js fell back to wall-clock time between camera calls)
{const wf=worldFrame;worldFrame=function(ts){const w=W3;if(w)w.r8CameraDt=w.last&&ts>w.last?Math.min(.05,Math.max(.001,(ts-w.last)/1000)):undefined;return wf.apply(this,arguments);};}
// yard: hitched mounts stood 0.6–1 m from the 拴马桩 (range 3) — every stand point picked the wrong one. Hitch them west of the post.
if(typeof r6SyncMounts==='function'){const sync=r6SyncMounts;r6SyncMounts=function(){const r=sync.apply(this,arguments);try{const y=W3?.spaces?.yard;if(y?.r6MountGroup){const its=y.items.filter(i=>i.r6Mount),models=y.r6MountGroup.children;let k=0;
  its.forEach((it,i)=>{const m=models[i];if(!m||it.x<8.7||it.x>11||it.z<9||it.z>16)return;const x=5-(k%2)*1.8,z=12.8+Math.floor(k/2)*1.8;k++;it.x=x;it.z=z;it.range=1.6;m.position.x=x;m.position.z=z;});
  const post=y.items.find(i=>/拴马桩/.test(typeof i.label==='function'?i.label():i.label));if(post)post.range=1.8;}}catch(e){}return r;};}
// buttons with no feedback (button audit, r8b build): daily claim, 回院子 while already in the yard
document.addEventListener('click',e=>{const b=e.target.closest?.('#r5Claim');if(!b)return;try{const d=typeof r6Daily==='function'?r6Daily():S.daily;if(!d)return;
  if(d.claimed){e.stopImmediatePropagation();toast('今天的铜钱已经领过了，明天再来');return;}
  const left=Object.entries({feed:'喂食',harvest:'收获',incense:'点灯',collect:'收取产物'}).filter(([k])=>!d.tasks?.[k]).map(([,v])=>v);if(left.length){e.stopImmediatePropagation();toast('还差：'+left.join('、')+'，做完再领');}}catch(_){}},true);
document.addEventListener('click',e=>{const b=e.target.closest?.('button');if(!b||!/^←\s*回院子$/.test(b.textContent.trim())||W3?.active!=='yard')return;e.stopImmediatePropagation();toast('你已经在心田小院');},true);
window.TG_R8B={version:'r8b',fixes,SCENES,fixScene};
const enter=worldEnter;worldEnter=function(){const r=enter.apply(this,arguments);fixScene(W3.active);return r;};
})();
