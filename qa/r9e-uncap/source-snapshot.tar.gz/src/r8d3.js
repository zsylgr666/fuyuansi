/* r8d3: fallback render mapping of the two retired avatar options. codex2's avatar.js (r8d3, sha 16044003…) maps them itself inside update()/build()
   (sengpao → 直裰 daopao, beads → none + 玉串 rosary when the hand is empty), so this installs ONLY if that avatar.js mapping is absent
   (detected by the hide flag on OPT.outfit sengpao). Same targets, idempotent, render-only: configs / templeGarden.v1 are never mutated. */
(()=>{
'use strict';
const R=window.TG_R8D3={version:'r8d3',mapped:0,fallback:false};
const map=c=>{if(!c||typeof c!=='object')return c;const sp=c.outfit==='sengpao',bd=!!c.acc&&c.acc.neck==='beads';if(!sp&&!bd)return c;
 const o={...c,acc:{...(c.acc||{})}};if(sp)o.outfit='daopao';if(bd){o.acc.neck='none';if(!o.acc.hand||o.acc.hand==='none')o.acc.hand='rosary';}R.mapped++;return o;};
R.map=map;
function install(){const A=window.TG_AVATAR;if(!A)return false;if(A._r8d3)return true;A._r8d3=true;
 const native=!!A.options?.outfit?.find(o=>o.id==='sengpao')?.hide;R.native=native;if(native)return true;
 const b=A.build,u=A.update;A.build=function(cfg,...r){return b.call(this,map(cfg),...r);};A.update=function(g,cfg,...r){return u.call(this,g,map(cfg),...r);};R.fallback=true;return true;}
if(!install()){let n=0;const t=setInterval(()=>{if(install()||++n>100)clearInterval(t);},100);}
})();
/* r8d3 (来福 iPhone, 缘堂): portrait 390×844 — the 4 location buttons wrapped into 2 rows and covered the 家和业兴 plaque.
   Portrait now keeps them on ONE row (equal widths, 12 px, 40 px tall hit area); landscape keeps r7's right-hand column. */
(()=>{const st=document.createElement('style');st.id='r8d3-style';
st.textContent=`@media (orientation:portrait){#r41Waypoints{flex-wrap:nowrap!important;gap:3px!important}#r41Waypoints button{flex:1 1 0;min-width:0;white-space:nowrap;overflow:hidden;font-size:12px!important;padding:0 2px!important;min-height:40px!important;letter-spacing:-.2px}}`;
document.head.appendChild(st);})();
/* r8d3 (来福 iPhone, 缘堂):
   (3) the floating exit billboards (荷塘's — no header — moves 0.4 m left, clear of the 竹影临窗 couplet) 「静室 / 书房 / 小院」 (r41Label, y 2.57–3.02) sat right under the door header signs (y 2.79–3.41) with the same
       text → overlapping text. Exits that have a header sign no longer show the billboard (荷塘 has no header and keeps it).
   (4) props between the camera and the player (copper lamp, planter, side table, player decor …) fade to 30 % while they block the view
       (ray camera → chest / head every 2nd frame, eased; same draw calls — only opacity / transparent change, original material restored). */
(()=>{
'use strict';
const T=THREE,R=window.TG_R8D3;R.fade={now:0,max:0,hits:{}};R.billboards=[];
function billboards(h){const now=performance.now();if(h._r8d3B&&now-h._r8d3B<1000)return;h._r8d3B=now;h.group.updateMatrixWorld(true);
 const signs=[];h.group.traverse(o=>{if(o.isMesh&&o.material?.map&&o.geometry?.attributes?.position?.count===4&&(o.userData.r41Label||o.userData.wallSign||o.material.map.image?.__r8c2Text!=null))signs.push(o);});
 for(const e of h.exits||[]){const at=o=>{const c=new T.Box3().setFromObject(o).getCenter(new T.Vector3());return c;};
  const hdr=signs.find(o=>o.parent!==h.group&&(()=>{const c=at(o);return Math.hypot(c.x-e.x,c.z-e.z)<1.2&&c.y>2.7&&c.y<3.6;})());if(!hdr)continue;
  for(const o of signs){if(o.parent!==h.group||o.userData.r8d3Hidden)continue;const c=at(o);if(Math.hypot(c.x-e.x,c.z-e.z)<.5&&c.y>2.3&&c.y<3.3){o.userData.r8d3Hidden=true;o.layers.set(31);R.billboards.push(e.to);}}}
 for(const o of signs){if(o.parent!==h.group||o.userData.r8d3Shift)continue;const c=new T.Box3().setFromObject(o).getCenter(new T.Vector3());if(Math.abs(c.x-4)<.3&&Math.abs(c.z+7.5)<.3&&c.y>2.3&&c.y<3.3){o.userData.r8d3Shift=true;o.position.x-=.4;R.billboards.push('lotus shifted -0.4 (clear of 竹影临窗)');}}}
const ray=new T.Raycaster(),o0=new T.Vector3(),tg=new T.Vector3(),dir=new T.Vector3(),bx=new T.Box3(),sz=new T.Vector3();
let props=null,propsAt=0,frame=0;const state=new Map();// top-level prop → {a: current alpha, want, mats:[[mesh,orig,clone]]}
const tb=new T.Box3(),ts=new T.Vector3();function unitOf(o,top){if(o===top)return o;tb.setFromObject(top);tb.getSize(ts);return Math.max(ts.x,ts.z)<=2.6&&ts.y<=2.6?top:o;}/* fade a small prop group whole (lamp + flame), but only the hit mesh of big containers (art3-shrine) */
function propList(h){const now=performance.now();if(props&&now-propsAt<1500)return props;propsAt=now;props=[];const w=W3;const rem=new Set();for(const r of w.remotes?.values?.()||[])if(r.mesh)rem.add(r.mesh);
 h.group.updateMatrixWorld(true);
 for(const top of h.group.children){if(top===w.player||rem.has(top)||top===h.plaqueGroup||top.name==='r8c-batch'||top.userData.r8cBatch||top.userData.r8cShell||top.name==='r8c-room-shell'||top.isInstancedMesh)continue;
  top.traverse(o=>{if(!o.isMesh||o.isInstancedMesh||o.userData.r41Label||o.userData.wallSign||o.userData.r8cIn)return;for(let q=o;q;q=q.parent)if(!q.visible)return;bx.setFromObject(o);bx.getSize(sz);
   if(bx.min.y>1.6||sz.y<.15||sz.y>2.6||(Math.max(sz.x,sz.z)>2.6&&sz.y>1.8)||Math.max(sz.x,sz.z)>6.5)return;/* low long furniture (altar table) fades too */props.push({o,top:unitOf(o,top),box:bx.clone()});});}
 return props;}
function fadeTo(top,want){let st=state.get(top);if(!st){if(want>=1)return;st={a:1,want,mats:[]};top.traverse(o=>{if(o.isMesh&&o.material&&!Array.isArray(o.material)){const c=o.material.clone();c.transparent=true;c.depthWrite=false;st.mats.push([o,o.material,c]);o.material=c;}});state.set(top,st);}st.want=want;}
function step(){for(const [top,st] of state){st.a+=(st.want-st.a)*.25;if(Math.abs(st.a-st.want)<.02)st.a=st.want;for(const [o,orig,c] of st.mats)c.opacity=(orig.opacity??1)*st.a;
  if(st.a>=1&&st.want>=1){for(const [o,orig,c] of st.mats){if(o.material===c)o.material=orig;c.dispose();}state.delete(top);}}}
function occlude(){R.ticks=(R.ticks||0)+1;const w=W3,h=w?.spaces?.hall;if(w?.active!=='hall'||!h||S.view==='fp'){for(const st of state.values())st.want=1;step();return;}
 billboards(h);if((frame++&1)===0){const list=propList(h),cam=w.camera,pp=w.player.position;const hit=new Set();
  for(const y of [1.0,1.55]){o0.copy(cam.position);tg.set(pp.x,y,pp.z);dir.subVectors(tg,o0);const L=dir.length();if(L<.5)continue;ray.set(o0,dir.normalize());ray.near=.05;ray.far=L-.45;
   for(const x of ray.intersectObjects(list.map(p=>p.o),false)){const p=list.find(q=>q.o===x.object);if(p)hit.add(p.top);}}
  for(const q of list)if(q.box.distanceToPoint(cam.position)<1.9)hit.add(q.top);/* props right next to the camera (they fill a bottom corner of the frame) */
  for(const top of hit)fadeTo(top,top.userData.r8d4Alpha??.3);/* r8d4: the altar top fades further (camera right above it) */for(const [top,st] of state)if(!hit.has(top))st.want=1;R.fade.now=hit.size;R.fade.max=Math.max(R.fade.max,hit.size);for(const t of hit){const k=t.name||t.uuid.slice(0,6);R.fade.hits[k]=(R.fade.hits[k]||0)+1;}}
 step();}
const anim=tgAnimate;tgAnimate=function(ts,dt){const out=anim.apply(this,arguments);try{occlude();}catch(e){R.fadeErr=String(e);}return out;};
R.occlude=occlude;
})();
/* r8d3 (来福, live r8c2d screenshot): a RANDOM look must never read as a monk — bald + long robe whose main colour is orange / yellow / brown.
   Random generation only (TG_AVATAR.randomConfig — used by r8c2b's hash-based remote looks — and the editor's 随机 button via r8d2's reroll loop).
   Fix is deterministic: the robe's main colour is swapped for a non-warm palette colour chosen from the config's own hash (same seed → same look).
   Players' own choices, saves and the option lists are untouched; 光头 and 玉串 stay. */
(()=>{
'use strict';
const R=window.TG_R8D3;R.monk={wrapped:false,fixed:0};
const hsl=hex=>{const n=parseInt(String(hex).replace('#',''),16);if(!isFinite(n))return null;const r=(n>>16&255)/255,g=(n>>8&255)/255,b=(n&255)/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2,d=mx-mn;
 if(!d)return {h:0,s:0,l};const s=d/(1-Math.abs(2*l-1));let h=mx===r?((g-b)/d)%6:mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;if(h<0)h+=360;return {h,s,l};};
const warm=hex=>{const c=hsl(hex);return !!c&&c.h>=15&&c.h<=60&&c.s>=.25&&c.l<.85&&c.l>.12;};// orange, yellow, ochre, brown (not red, not cream / grey)
const longOf=id=>!!window.TG_AVATAR?.options?.outfit?.find(o=>o.id===id)?.long;
const highOf=id=>!!window.TG_AVATAR?.options?.outfit?.find(o=>o.id===id)?.high;
const mainKey=c=>highOf(c.outfit)?'color2':'color1';
const isMonk=c=>!!c&&c.hair==='bald'&&longOf(c.outfit)&&warm(c[mainKey(c)]);
const hashOf=c=>{let h=2166136261;for(const ch of JSON.stringify([c.skin,c.face,c.hairColor,c.outfit,c.color1,c.color2,c.trim,c.height]))h=Math.imul(h^ch.charCodeAt(0),16777619);return h>>>0;};
function unmonk(c,h){if(!isMonk(c))return c;const pal=(window.TG_AVATAR?.palette?.cloth||[]).filter(x=>!warm(x)),k=mainKey(c),other=k==='color1'?'color2':'color1';
 const list=pal.filter(x=>x!==c[other]);if(!list.length)return c;c[k]=list[((h==null?hashOf(c):h)>>>0)%list.length];R.monk.fixed++;return c;}
R.isMonk=isMonk;R.unmonk=unmonk;R.warm=warm;
function install(){const A=window.TG_AVATAR;if(!A?.randomConfig)return false;if(A._r8d3Monk)return true;const rc=A.randomConfig;
 A.randomConfig=function(seed,...rest){const c=rc.call(this,seed,...rest);return c&&typeof c==='object'?unmonk(c,typeof seed==='number'?seed:null):c;};A._r8d3Monk=true;R.monk.wrapped=true;return true;}
if(!install()){let n=0;const t=setInterval(()=>{if(install()||++n>100)clearInterval(t);},100);}
})();
