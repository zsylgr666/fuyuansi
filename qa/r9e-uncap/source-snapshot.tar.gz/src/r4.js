/* r4 adds the merged private courtyard without replacing the r3 game. */
function r3CanEdit(){return !r3IsVisiting()||window.TG_VISIT?.canEdit===true;}
function sanitizeR4(d){
 r3NormalizeDecor(d);
 if(d.scene==='home')d.scene='yard';d.decor||={};d.decor.yard||=[];
 for(const v of d.decor.home||[])d.decor.yard.push({...v,x:v.x+8,z:v.z+5,r4Migrated:true});d.decor.home=[];
 r3SanitizeAnimals(d);
}
$('#plantAll').onclick=()=>{if(r3DenyVisit())return;let n=0;const now=Date.now();for(let i=0;i<S.plots.length;i++)if(!S.plots[i]){S.plots[i]={crop:S.selectedSeed,plantedAt:now,boost:0,lastWater:0};n++;}if(n){save();renderYard();worldSyncYard();tgFeedback('plant');}toast(n?`种下了 ${n} 块地`:'没有空地可以播种');};
window.TG_DOG_IN_GARDEN=window.TG_DOG_ON_DUTY=()=> (S.animals||[]).some(a=>a?.kind==='dog'&&a.post==='garden');
function r4Bark(){const r=W3?.spaces.yard.animalRecords?.find(r=>r.animal.kind==='dog'&&r.animal.post==='garden');if(r)r.barkUntil=performance.now()+1300;toast('汪！被看门狗发现了');}
var r4Stealing=new Set();
async function r4Steal(i,el){
 if(r4Stealing.has(i))return;const p=S.plots[i];if(!p||plotProgress(p,Date.now())<1)return;
 r4Stealing.add(i);
 try{const result=await harvest(i,el);
 if((typeof result==='string'&&/caught/i.test(result))||result?.caught===true||[result?.error,result?.reason].some(v=>typeof v==='string'&&/caught/i.test(v))){r4Bark();return 'caught';}
 return result;
 }catch(e){toast('暂时无法摘取，请稍后再试');}finally{r4Stealing.delete(i);}
}
function r4SetPost(a,post){if(r3DenyVisit())return;a.post=post;W3.spaces.yard.animalKey=undefined;worldSyncAnimals();save();toast(a.name+'：'+({garden:'看菜园',follow:'跟着我',home:'回窝'}[post]));}
function r4Guard(){if(r3DenyVisit())return;const dogs=(S.animals||[]).filter(a=>a.kind==='dog'),a=dogs.find(a=>a.post!=='garden')||dogs[0];if(!a)return toast('请先领养一只小狗');r4SetPost(a,'garden');}
var r4Pet=r3PetAnimal;r3PetAnimal=function(id){const a=(S.animals||[]).find(a=>a.id===id);if(a?.kind!=='dog'||!r3CanEdit())return r4Pet(id);openModal(`<h2>🐕 ${r3Esc(a.name)}</h2><div class="r3-actions"><button class="btn" data-post="garden">看菜园</button><button class="btn" data-post="follow">跟着我</button><button class="btn" data-post="home">回窝</button><button class="btn" id="r4Pet">抚摸</button></div>`);$('#sheet').querySelectorAll('[data-post]').forEach(b=>b.onclick=()=>{r4SetPost(a,b.dataset.post);closeModal();});$('#r4Pet').onclick=()=>{closeModal();r4Pet(id);};};
{const hud=$('.r3-animal-hud');$('#yard').append(hud);hud.insertAdjacentHTML('beforeend','<div><button class="big-btn wood" onclick="enterPlacement(\'yard\')">布置</button><button class="big-btn wood" data-r3-edit onclick="r4Guard()">派狗看菜园</button></div>');}
$('#btnMenu').addEventListener('click',()=>{const b=document.createElement('button');b.className='btn ghost';b.textContent='家庭';b.onclick=()=>{if(typeof window.TG_FAMILY?.open==='function')window.TG_FAMILY.open();else toast('家庭未连接');};$('#sheet').append(b);});
var r4Spawn=r3Spawn;r3Spawn=function(name,prev){if(name==='yard'&&(window.r4EastArrival||prev==='home')){window.r4EastArrival=false;return [11.5,0,Math.PI/2];}if(name==='plaza'&&prev==='yard'&&W3?.player?.position.x>10)return [-11,0,-Math.PI/2];return r4Spawn(name,prev);};
var r4Build=r3Build;r3Build=function(){r4Build();const y=W3.spaces.yard;y.limit={x:14,z:14};W3.spaces.home.group.visible=false;
 // Bed sits on the open south veranda; house and pond remain separate.
 const g=new THREE.Group();y.group.add(g);r3Furniture(g,{id:'daybed',x:8,z:5,rot:0});g.updateMatrixWorld(true);r3BatchDecor(g);y.blocks.push({x:6.75,X:9.25,z:4.25,Z:5.75,r4Bed:true});
};
var r4Placement=r3PlacementError;r3PlacementError=function(scene,item,ignore=-1,restoring=false){const b=r3Bounds(item);if(scene==='yard'&&b){const zones=[...R3_PENS,{x:-1.7,X:1.7,z:-14,Z:14},{x:10.5,X:14,z:-1.8,Z:1.8},...Array.from({length:12},(_,i)=>({x:-11.3+i%3*3.3,X:-8.7+i%3*3.3,z:-7.3+Math.floor(i/3)*3.5,Z:-4.7+Math.floor(i/3)*3.5}))];if(zones.some(v=>r3Overlap(b,v)))return '田地、牧栏和门前通道需要留空';}return r4Placement(scene,item,ignore,restoring);};
window.TG_CATALOG.push({id:'rocking-chair',name:'摇椅',cat:'furniture',price:85,w:1.2,d:1.5,emoji:'🪑'});
var r4Furniture=r3Furniture;r3Furniture=function(g,item){if(item.id==='rocking-chair'){r4Furniture(g,{...item,id:'bench'});return;}r4Furniture(g,item);};
function r4Pose(body,limbs,pose,moving,ts){if(!body)return;body.rotation.x=0;if(moving)return;if(pose==='sit'){body.position.y=-.28;limbs.forEach((l,i)=>l.rotation.x=i<2?-.45:-1.35);}else if(pose==='sleep'){body.rotation.x=-Math.PI/2;body.position.y=.35;limbs.forEach(l=>l.rotation.x=0);}}
var r4Quotes=['采菊东篱下，悠然见南山。','明月松间照，清泉石上流。','草长莺飞二月天，拂堤杨柳醉春烟。','行到水穷处，坐看云起时。','行到水穷处，坐看云起时。','绿树村边合，青山郭外斜。','春有百花秋有月，夏有凉风冬有雪。','静坐常思己过。','海内存知己，天涯若比邻。','知足常乐，心安即是家。'],r4Cooldown={};
function r4Use(item,scene){const id=item.id,w=W3;worldStop();
 if(id==='cabinet')return $('#pillInv').click();
 if(id==='lantern'){if(r3DenyVisit())return;item.on=!item.on;save();worldSyncDecor();return toast(item.on?'灯已点亮':'灯已熄灭');}
 if(id==='daybed'){w.pose='sleep';document.body.classList.add('r4-rest');setTimeout(()=>{document.body.classList.remove('r4-rest');if(w.pose==='sleep')w.pose='idle';toast('精神恢复');},1600);return;}
 if(['bench','cushion'].includes(id)){w.pose='sit';return toast('坐下歇歇，移动即可起身');}
 if(id==='bookshelf')return toast(r4Quotes[rand(r4Quotes.length)]);
 if(id==='rocking-chair'){w.pose='sit';w.r4Rock=performance.now()+2400;return toast('轻轻摇，慢慢歇');}
 if(id==='altar-table'&&scene==='hall')return $('#btnIncense').click();
 const key=id==='altar-table'?'incense':'tea',now=Date.now();if(now-(r4Cooldown[key]||0)<8000)return toast('静心片刻，再来品味');r4Cooldown[key]=now;if(key==='tea')w.r4SipUntil=performance.now()+1300;addMerit(key==='tea'?1:3);toast(key==='tea'?'清茶一盏，善缘 +1':'灯光一盏，善缘 +3');
}
var r4SyncDecor=worldSyncDecor;worldSyncDecor=function(){
 if(!r3IsVisiting()&&r3CanEdit()&&W3?.active==='yard')for(const item of S.decor.yard||[]){if(!item.r4Migrated)continue;delete item.r4Migrated;
 // Apply the migration offset first, then rescue only furniture that collides with new fixed facilities.
 if(r3PlacementError('yard',item,S.decor.yard.indexOf(item),true)){let found=false;const old={x:item.x,z:item.z};for(let z=5;z<=12&&!found;z+=.5)for(let x=3;x<=13&&!found;x+=.5){item.x=x;item.z=z;if(!r3PlacementError('yard',item,S.decor.yard.indexOf(item),true))found=true;}if(!found){item.x=old.x;item.z=old.z;S.backpack[item.id]=(S.backpack[item.id]||0)+1;S.decor.yard=S.decor.yard.filter(v=>v!==item);}}
 }
 r4SyncDecor();const w=W3,s=w?.spaces[w.active];if(!s)return;const key=JSON.stringify(S.decor[w.active]||[]);if(s.r4InteractKey===key)return;s.r4InteractKey=key;s.items=s.items.filter(i=>!i.r4Furniture);if(s.r4Lights){s.group.remove(s.r4Lights);}s.r4Lights=new THREE.Group();s.group.add(s.r4Lights);
 const list=[...(S.decor[w.active]||[])];if(w.active==='yard')list.push({id:'daybed',x:8,z:5},{id:'bench',x:12,z:8});if(w.active==='study')list.push({id:'bookshelf',x:-4,z:-6},{id:'bookshelf',x:4,z:-6});if(w.active==='zen')list.push({id:'cushion',x:-1.5,z:-2},{id:'cushion',x:1.5,z:-2});
 const labels={daybed:'睡觉',bench:'坐下',cushion:'坐下','wood-table':'喝茶','tea-cup':'喝茶',lantern:'开关灯',bookshelf:'读书','altar-table':'点灯','rocking-chair':'摇',cabinet:'打开背包'};
 for(const item of list){if(!labels[item.id])continue;s.items.push({x:item.x,z:item.z,range:2.6,label:labels[item.id],run:()=>r4Use(item,w.active),r4Furniture:true});if(item.id==='lantern'&&item.on){const l=new THREE.PointLight('#ffd795',1.1,5);l.position.set(item.x,1.3,item.z);s.r4Lights.add(l);}}
};
var r4Rerender=window.TG_RERENDER;window.TG_RERENDER=function(){r3SyncOwnSpace();sanitizeR4(S);for(const s of Object.values(W3?.spaces||{}))s.r4InteractKey=undefined;r4Rerender();};
