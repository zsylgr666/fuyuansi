# r8c result (2026-11-14, UTC+8)
- Build: v4/index.r8c.html — 1,745,102 B — sha256 a97278fe0bc5de57d1d8979cfc9980e500b70279628cac1a85a408b915f79b12 (base r8b a81a5383…, untouched)
- Patches: v4/r8c.patch (index.r8b → index.r8c, 41,006 B); v4/r8c-src.patch (qa/r8c-base-src → v4/_src, 43,387 B: pack.mjs, r8.js, r8b.js, r8c.js only — no codex2 file)
- Evidence: qa/r8c-shots/{audit,bed,seats,rooms,perf,trim}

## codex2 r8b recheck items (done first)
1. H null.trim: three.js calls getProgramInfoLog()/getShaderInfoLog().trim() on a lost WebGL context (捏脸 preview renderer uses forceContextLoss; SwiftShader drops contexts) → null. r8c-0 makes both null-safe ('' on a lost context). Proof (trim.mjs): r8b lost-context render THROWS "Cannot read properties of null (reading 'trim')"; r8c no throw. 捏脸×3 + 留笺/采莲/河灯/锦鲤: 0 pageerrors. codex2 crawler, tea+lotus portrait, on the r8c dev build: 105 actions, 0 pageerrors (the r8b crawl also had 0 this time, so the bug is flaky).
2. Fortune text: none left in our files apart from the r8b.js BAN filter regex, which is never displayed (comment reworded). Remaining hits are in codex2 files: gameplay.js 39/50/63/64/65/74/86/113/114/455/456/459/460 (原 六爻/灵签/风水 data and templates; unreachable, replaced at runtime); r7d.js 45/46/53/54/62/149 (replacement/filter tables); npc.js 25 「便宜卖啦」 (innocuous). The packed grep is in qa/r8c-shots/trim/grep-r8c.txt.
   - **Correction (r8c.1):** the ownership above was wrong. gameplay.js is a base file and r7c.js / r7d.js are ours; only audio/npc/avatar/art3/teahouse-assets/realism/mounts/animals2 (+suggest/manual) are codex2 modules. The gameplay.js / r7d.js hits listed were therefore in our own files; codex2 cleaned them in qa/r8c-clean (gameplay.js data neutral, r7c/r7d 诗签→诗笺, patches A+B), and r8c.1 carries those edits plus the remaining r7.js / gameplay.js cleanup — see r8c1-result.md.
3. zen 坐下喝茶 facing: fixed in r8c.js furnish() (rot = x<0 ? +π/2 : −π/2); r7b.js not touched. r8b faces away (149° from table centre); r8c sits square to the table's long side (0° to the nearest table edge). Shots: qa/r8c-shots/seats.
4. 每日诗签 → 每日诗笺 on every display surface (text nodes, aria/placeholder/title, canvas labels, prompt labels) via r8c-0b.

## Audit (qa/r8-audit run.mjs, 8 scenes, normalised)
- r8c: hall 0/0/3, zen 0/0/6, study 0/0/4, plaza 1/0/16, yard 0/0/5, market 0/0/5, tea 0/0/1, gate 0/0/5
- vs codex2 r8b.json: new H0 M0 L10 (all hall/zen/study camera L), fixed M12 (zen 6, study 6); PLAZA-001 H still (structural art3 lion legs, pre-existing)
- vs baseline: new H0 M0 L28; fixed H46 M82 L106
- walk: 53/50/50/53/51/50/50/50 legs, 0 stuck
