# r8d result (frozen 14:16 UTC+8)
- v4/index.r8d.html 1,796,698 B, sha256 4d791e71201e1ded5ab676f828715d2c4f5d76e257fcf27713abae3356b0a7f9
- v4/r8d.patch (vs index.r8c2c.html, 59,734 B), v4/r8d-src.patch (vs qa/r8c2c/src, 63,611 B), report v4/_src/freeze-r8d-report.json
- Smoke test, 9 scenes × portrait/landscape: 0 page errors; most draw calls 80 (limit 150). Frozen builds unchanged (r8c2c still d456a527…).
- Metrics: qa/r8d/r8d-metrics.md (from qa/r8d/metrics.mjs). Frame times are noisy because other agents' Chrome loads this box (load 6–15). Use program, upload, joint and camera counts as the main numbers.

## Fixes
- r8c2c H-1/H-2 merged (r8c2c.js loads before r8d.js). The raised indoor camera now covers hall, zen and study (M-2). The raised view now blends in at 8/s and is limited to ≤13 m/s and ≤230°/s. Before this, zen and study had 3 jumps and 23 spins as the camera entered the raised view.
- M-1: the HUD fade no longer includes the joystick. The hit margin is 10/12 px. The top bar, coins and menu fade to .55 and still take clicks.
- M-3: false alarm. The toast shows in both viewports. One small issue remains (L): the text says "点灯 +3" but the real gain is +1.
- Hall candle M (HALL-001): fixed. Flames sit 0.09 m higher on the candle tops. Lantern cords and pillar colliders are also fixed.
- Walk cadence: rate = √(v/1.77), clamped to .9–1.4. Walking is 2.28 steps/s with a 0.77 m stride, the same as r8c1. Running is 3.48 steps/s with a 1.14 m stride.
- Shared hall lights are OFF by default. Turning them on saves 39 programs, but play frames cost 25–100 % more (opt-in: R8D_OPTS.sharedLights=true).
- audio.js comes from qa/audio-lazy. The first menu click now takes 1.7 ms (r8c1: 109.6 ms).

## bgm='0' reset (found; not changed here)
On load, r5.js:56 calls `audio.setOn(!tgMuted)`, and tgMuted comes from the old templeGarden.mute key (enhance.js:3). audio.js setOn() calls writePref(), so the stored '0' becomes '1' and music turns on.
Proposed one-line fix: in r5.js:56, replace `audio.setOn(!tgMuted)` with `tgMuted=!audio.isOn()` (or leave setOn out entirely).
