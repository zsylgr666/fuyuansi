/* npc.js — 福缘里 · 心田小院 集市摊主 NPC   window.TG_NPC
 * 依赖：THREE（r170）。有 TG_AVATAR 时用它建模（精致写实比例），否则用内置简易模型。
 * 功能：多套摊主预设、待机动作（呼吸/张望/招手/吆喝/整理货物）、点击说话气泡（DOM，跟随头顶）、按摊位放置。
 * 性能：每个 NPC = TG_AVATAR 低细节（detail:0）7~8 次 draw call；update() 每帧零分配（气泡显示时才写 DOM）。 */
(function(){
'use strict';
if(window.TG_NPC&&window.TG_NPC.__v)return;
var T=(typeof THREE!=='undefined')?THREE:window.THREE;if(!T){console.warn('[TG_NPC] THREE 不存在');return;}

var PRESETS={
 tea:{name:'陆羽生',title:'茶商',avatar:{outfit:'daopao',hair:'bun',face:'oval',skin:'#f0cba8',color1:'#6f9a72',color2:'#9a5b34',trim:'#efd79a',acc:{head:'hairpin',waist:'pouch',hand:'teapot'}},
  lines:['新焙的明前龙井，客官尝一盏？','茶要七分满，留三分人情。','山泉煮茶，今日水正好。','喝完这盏，再去院里转转。'],calls:['好茶——刚出锅的好茶！','龙井、碧螺春，香得很嘞！'],
  weights:{idle:3,look:2,arrange:3,call:1,wave:1}},
 herb:{name:'孙百草',title:'药铺',avatar:{outfit:'yuanling',hair:'bun',face:'square',skin:'#e3b18b',hairColor:'#8d8a86',color1:'#3f5d6b',color2:'#2b2d38',trim:'#d8ae55',height:97,acc:{head:'crown',waist:'gourd',hand:'herb'}},
  lines:['当归、黄芪，都是今年的新货。','脸色不错，多喝热水，少熬夜。','药补不如食补，食补不如心补。'],calls:['草药香包，安神助眠喽！'],weights:{idle:4,look:2,arrange:3,call:1,wave:.5}},
 cloth:{name:'绣娘阿缨',title:'布庄',avatar:{outfit:'ruqun',hair:'long',face:'heart',skin:'#f7dfc8',color1:'#c79bb0',color2:'#2f3a5a',trim:'#efd79a',height:95,build:'slim',acc:{head:'hairpin',waist:'jade',hand:'bolt'}},
  lines:['这匹云锦，织了整整三个月。','颜色挑人，客官肤色配月白正好。','新到的苏绣帕子，要不要看看？'],calls:['绫罗绸缎，看一看嘞！'],weights:{idle:3,look:3,arrange:2,call:1,wave:1}},
 snack:{name:'王大勺',title:'小吃摊',avatar:{outfit:'duanda',hair:'short',face:'round',skin:'#cd946b',color1:'#d9773a',color2:'#7a7368',trim:'#f1e6cf',build:'sturdy',height:103,acc:{waist:'pouch',hand:'bowl'}},
  lines:['桂花糖藕，甜而不腻！','馄饨现包现煮，三文一碗。','吃饱了才有力气种地嘛。'],calls:['热乎的桂花糕——','馄饨嘞，皮薄馅大！'],weights:{idle:2,look:2,arrange:2,call:2,wave:1.5}},
 incense:{name:'灯娘',title:'灯彩铺',avatar:{outfit:'daopao',hair:'bun',face:'oval',skin:'#f0cba8',color1:'#9e2f4a',color2:'#e3b25a',trim:'#d8ae55',acc:{head:'hairpin',neck:'none',hand:'flowerpot'}},
  lines:['宫灯、花灯、走马灯，照亮小院每个角落。','彩纸一折，便是一盏花灯。','今晚把灯挂上，巷口就会亮起来。'],calls:['花灯、宫灯、彩灯喽！'],weights:{idle:4,look:2,arrange:3,call:1,wave:.5}},
 painting:{name:'沈墨白',title:'书画摊',avatar:{outfit:'yuanling',hair:'ponytail',face:'oval',skin:'#f0cba8',color1:'#f1e6cf',color2:'#4f8a7a',trim:'#2b2d38',height:104,acc:{head:'crown',waist:'jade',hand:'brush'}},
  lines:['山水一幅，可题客官的名号。','字如其人，心静笔自稳。','这幅《福缘里春晓》，画了一整个春天。'],calls:['写春联、画扇面喽！'],weights:{idle:3,look:3,arrange:2,call:.5,wave:1}},
 flower:{name:'花婆婆',title:'花木铺',avatar:{outfit:'ruqun',hair:'twin',face:'round',skin:'#f0cba8',color1:'#f0d58c',color2:'#6f9a72',trim:'#b8322a',height:94,acc:{head:'flower',waist:'pouch',hand:'flowerpot'}},
  lines:['这盆兰花，放在心田小院最雅致。','花要勤浇水，人要常微笑。','种子都是今春新收的。'],calls:['鲜花盆景，便宜卖啦！'],weights:{idle:3,look:2,arrange:3,call:1,wave:1}},
 furniture:{name:'鲁师傅',title:'家具铺',avatar:{outfit:'duanda',hair:'ponytail',face:'square',skin:'#cd946b',color1:'#9a5b34',color2:'#3f5d6b',trim:'#d8ae55',build:'sturdy',height:106,acc:{waist:'gourd'}},
  lines:['榫卯结构，一根钉子都不用。','老榆木的桌子，越用越亮。','院子大了，添张石凳如何？'],calls:['桌椅板凳，结实耐用！'],weights:{idle:3,look:2,arrange:3,call:1,wave:1}},
 fruit:{name:'果农小满',title:'水果摊',avatar:{outfit:'duanda',hair:'short',face:'oval',skin:'#e3b18b',color1:'#6f9a72',color2:'#9a5b34',trim:'#efd79a',height:99,acc:{head:'hat',waist:'pouch'}},
  lines:['刚摘的柿子，甜得很！','秋梨润肺，带两个回去？'],calls:['新鲜瓜果——不甜不要钱！'],weights:{idle:2,look:2,arrange:3,call:2,wave:1.5}},
 consign:{name:'钱掌柜',title:'寄售摊',avatar:{outfit:'yuanling',hair:'bun',face:'round',skin:'#f0cba8',color1:'#6b3a4a',color2:'#2b2420',trim:'#d8ae55',build:'sturdy',acc:{head:'crown',waist:'jade',hand:'scroll'}},
  lines:['想卖什么，交给我挂牌便是。','童叟无欺，价钱你自己定。','好货不愁卖，耐心等等。'],calls:['寄售收货，价钱公道！'],weights:{idle:4,look:2,arrange:2,call:1,wave:1}}
};
/* 集市默认摊位（与 r3.js / art3.js / r5.js 的集市布局对应；场景坐标，ry 为朝向） */
var MARKET_STALLS=[
 {stallId:'market:flower',preset:'flower',x:-4.65,z:-4.75,ry:-.35},
 {stallId:'market:furniture',preset:'furniture',x:2.35,z:-4.75,ry:-.35},
 {stallId:'market:incense',preset:'incense',x:9.35,z:-4.75,ry:-.35},
 {stallId:'market:tea',preset:'tea',x:-4.25,z:6.0,ry:-2.72},
 {stallId:'market:fruit',preset:'fruit',x:7.25,z:6.2,ry:-2.72},
 {stallId:'market:consign',preset:'consign',x:2.45,z:7.7,ry:-.35,needBlock:[0,8]}
];

/* r8：气泡配色与 ui-kit 的 --tg-* 一致（这里写死数值，因为气泡层不在 .tg-ui 作用域里）。 */
var CSS='.tgnpc-layer{position:fixed;left:0;top:0;width:0;height:0;z-index:60;pointer-events:none}'
+'.tgnpc-bubble{position:absolute;left:0;top:0;width:max-content;max-width:min(240px,70vw);min-width:96px;padding:8px 12px;border-radius:12px;background:#fffdf8;border:1px solid #c9ab72;box-shadow:0 4px 12px rgba(60,35,15,.18);color:#3b2a1e;font:14px/1.5 "PingFang SC","Hiragino Sans GB","Noto Sans CJK SC","Noto Sans SC","Microsoft YaHei",sans-serif;opacity:0;transition:opacity .18s;will-change:transform;white-space:normal}'
+'.tgnpc-bubble.on{opacity:1}.tgnpc-bubble:after{content:"";position:absolute;left:50%;bottom:-7px;margin-left:-7px;border:7px solid transparent;border-bottom:0;border-top-color:#c9ab72}'
+'.tgnpc-bubble:before{content:"";position:absolute;left:50%;bottom:-6px;margin-left:-6px;border:6px solid transparent;border-bottom:0;border-top-color:#fffdf8;z-index:1}'
+'.tgnpc-name{margin:0 0 2px;font-size:14px;font-weight:600;color:#7c2d20}'
+'.tgnpc-text{font-size:14px}'
+'.tgnpc-bubble.shout .tgnpc-text{font-weight:600}';

var npcs=[],seq=0,view={camera:null,canvas:null,container:null,layer:null,target:null,maxDist:12,occlude:true,occluders:null,occludeEvery:4,nearIgnore:1.6,minOccluder:1.2},frame=0,occRay=new T.Raycaster(),_h=new T.Vector3(),_d=new T.Vector3(),_nm=new T.Vector3(),_hits=[],OCC=new Map(),ray=new T.Raycaster(),ndc=new T.Vector2(),
 _p=new T.Vector3(),_q=new T.Vector3(),hitGeo=null,hitMat=null,api;
function rnd(){return Math.random();}
function defaults(){var W=window.W3;if(!view.camera&&W&&W.camera)view.camera=W.camera;if(!view.canvas&&W)view.canvas=W.canvas||(W.renderer&&W.renderer.domElement)||null;}
function layer(){if(view.layer&&view.layer.isConnected)return view.layer;if(!document.getElementById('tgnpc-css')){var s=document.createElement('style');s.id='tgnpc-css';s.textContent=CSS;document.head.appendChild(s);}
 var l=document.createElement('div');l.className='tgnpc-layer';(view.container||document.body).appendChild(l);view.layer=l;return l;}
function defaultParent(){var W=window.W3;if(W&&W.spaces&&W.spaces.market)return W.spaces.market.group;if(W&&W.scene)return W.scene;return null;}
function fallbackModel(cfg){ // 无 TG_AVATAR 时的简易模型（与 avatar 同骨架名，animate 用内置简易版）
 var g=new T.Group(),m=function(c){return new T.MeshStandardMaterial({color:c,roughness:.8});};g.name='tg-npc-simple';
 var body=new T.Mesh(new T.CylinderGeometry(.17,.3,1.35,12),m(cfg.color1||'#9a5b34'));body.position.y=.68;g.add(body);
 var head=new T.Mesh(new T.SphereGeometry(.13,14,10),m(cfg.skin||'#f0cba8'));head.position.y=1.58;g.add(head);
 var hair=new T.Mesh(new T.SphereGeometry(.135,14,8,0,Math.PI*2,0,1.4),m(cfg.hairColor||'#1b1512'));hair.position.y=1.6;g.add(hair);
 var belt=new T.Mesh(new T.CylinderGeometry(.19,.19,.07,12),m(cfg.color2||'#3f5d6b'));belt.position.y=1.05;g.add(belt);
 g.userData={simple:true,head:head,body:body,phase:rnd()*100};return g;}
function buildModel(cfg){if(window.TG_AVATAR&&window.TG_AVATAR.build)return window.TG_AVATAR.build(cfg,{detail:0});return fallbackModel(cfg);}
function animModel(m,state,tms){if(window.TG_AVATAR&&m.userData.tgAvatar)return window.TG_AVATAR.animate(m,state,tms);
 var u=m.userData,s=tms/1000+u.phase;u.body.scale.set(1+.01*Math.sin(s*2),1,1);u.head.rotation.y=state==='look'?.6*Math.sin(s*.9):.1*Math.sin(s*.5);m.position.y=state==='wave'||state==='call'?.02*Math.abs(Math.sin(s*6)):0;}

function spawn(o){o=o||{};var pr=PRESETS[o.preset]||PRESETS.tea,base=pr.avatar,acc=Object.assign({},base.acc||{},(o.avatar&&o.avatar.acc)||{});
 var cfg=Object.assign({},base,o.avatar||{},{acc:acc,name:o.name!=null?o.name:pr.name,title:o.title!=null?o.title:pr.title});if(o.plate===false){cfg.name='';cfg.title='';}
 if(o.stallId!=null){var old=find(o.stallId);if(old)remove(old);}
 var root=new T.Group();root.name='tg-npc';var model=buildModel(cfg);root.add(model);
 if(!hitGeo){hitGeo=new T.CylinderGeometry(.38,.38,1.9,8);hitMat=new T.MeshBasicMaterial({visible:false});}
 var hit=new T.Mesh(hitGeo,hitMat);hit.position.y=.95;hit.name='tg-npc-hit';root.add(hit);
 var p=o.position||[0,0,0];if(p.isVector3)root.position.copy(p);else root.position.set(+p[0]||+p.x||0,+p[1]||+p.y||0,+p[2]||+p.z||0);
 var ry=o.rotation!=null?(typeof o.rotation==='number'?o.rotation:(o.rotation.y||0)):0;root.rotation.y=ry;
 var n={id:o.id||('npc'+(++seq)),preset:o.preset in PRESETS?o.preset:'tea',name:cfg.name||pr.name,title:cfg.title,stallId:o.stallId!=null?o.stallId:null,lines:(o.lines&&o.lines.length?o.lines:pr.lines).slice(),calls:(o.calls||pr.calls||[]).slice(),
  weights:Object.assign({},pr.weights,o.weights||{}),root:root,model:model,hit:hit,cfg:cfg,homeYaw:ry,yaw:ry,t:rnd()*5000,action:'idle',left:1+rnd()*2,line:0,bubble:null,bubbleLeft:0,talkLeft:0,onTalk:o.onTalk||null,
  height:((window.TG_AVATAR&&model.userData.cfg)?model.userData.cfg.height:100)/100};
 hit.userData.tgNpc=n;root.userData.tgNpc=n;
 var parent=o.parent||defaultParent();if(parent)parent.add(root);
 if(o.block&&o.space&&o.space.blocks){n.block={x:root.position.x-.3,X:root.position.x+.3,z:root.position.z-.3,Z:root.position.z+.3,tgNpc:true};o.space.blocks.push(n.block);n.space=o.space;}
 npcs.push(n);animModel(model,'idle',n.t);return n;}
function find(idOrStall){for(var i=0;i<npcs.length;i++)if(npcs[i].id===idOrStall||npcs[i].stallId===idOrStall||npcs[i]===idOrStall)return npcs[i];return null;}
function remove(x){var n=typeof x==='object'&&x&&x.root?x:find(x);if(!n)return false;var i=npcs.indexOf(n);if(i>=0)npcs.splice(i,1);
 if(n.bubble&&n.bubble.parentNode)n.bubble.parentNode.removeChild(n.bubble);if(n.space&&n.block){var k=n.space.blocks.indexOf(n.block);if(k>=0)n.space.blocks.splice(k,1);}
 if(window.TG_AVATAR&&n.model.userData.tgAvatar)window.TG_AVATAR.dispose(n.model);else n.model.traverse(function(o){if(o.isMesh){o.geometry.dispose();o.material.dispose();}});
 if(n.root.parent)n.root.parent.remove(n.root);return true;}
function clear(){while(npcs.length)remove(npcs[npcs.length-1]);}
function list(){return npcs.slice();}
function blocked(space,x,z){if(!space||!space.blocks)return false;for(var i=0;i<space.blocks.length;i++){var b=space.blocks[i];if(x>b.x&&x<b.X&&z>b.z&&z<b.Z)return true;}return false;}
function placeAtStalls(stalls,opts){opts=opts||{};var W=window.W3,out=[],space=opts.space||(W&&W.spaces&&W.spaces.market)||null,parent=opts.parent||(space&&space.group)||defaultParent();
 if(!Array.isArray(stalls)){var rootObj=opts.root||parent,found=[];
  if(rootObj)rootObj.traverse(function(o){var u=o.userData||{};if(u.stallId||u.npcStall||/^stall[:_-]/.test(o.name||'')){o.updateWorldMatrix(true,false);o.getWorldPosition(_p);var off=u.npcOffset||[0,0,-1.2];
   found.push({stallId:u.stallId||u.npcStall||o.name,preset:u.npcPreset||guessPreset(u.stallId||o.name||''),x:_p.x+off[0],z:_p.z+off[2],ry:u.npcRy!=null?u.npcRy:0,name:u.npcName,lines:u.npcLines});}});
  stalls=found.length?found:MARKET_STALLS.filter(function(s){if(!s.needBlock)return true;return blocked(space,s.needBlock[0],s.needBlock[1]);});}
 stalls.forEach(function(s){var pos=s.position||[s.x||0,s.y||0,s.z||0];if(opts.skipBlocked!==false&&space&&blocked(space,pos[0],pos[2])){console.warn('[TG_NPC] 摊位点被占用，跳过',s.stallId);return;}
  out.push(spawn({preset:s.preset||guessPreset(s.stallId||''),name:s.name,title:s.title,lines:s.lines,calls:s.calls,position:pos,rotation:s.ry!=null?s.ry:(s.rotation||0),stallId:s.stallId,parent:s.parent||parent,avatar:s.avatar,block:opts.block,space:space,plate:opts.plate}));});
 return out;}
function guessPreset(id){id=String(id);var map=[['茶','tea'],['tea','tea'],['药','herb'],['herb','herb'],['布','cloth'],['cloth','cloth'],['吃','snack'],['snack','snack'],['香','incense'],['incense','incense'],['书','painting'],['画','painting'],['paint','painting'],['花','flower'],['flower','flower'],['家具','furniture'],['furn','furniture'],['果','fruit'],['fruit','fruit'],['寄售','consign'],['consign','consign']];
 for(var i=0;i<map.length;i++)if(id.indexOf(map[i][0])>=0)return map[i][1];return 'tea';}

function pick(w,near){var tot=0,k;for(k in w){var v=w[k]*(near&&(k==='wave'||k==='call')?2.2:1);tot+=v;}var r=rnd()*tot;for(k in w){r-=w[k]*(near&&(k==='wave'||k==='call')?2.2:1);if(r<=0)return k;}return 'idle';}
var DUR={idle:[2,5],look:[3,5],arrange:[3,6],call:[2,3],wave:[1.6,2.4]};
function worldVisible(o){while(o){if(!o.visible)return false;o=o.parent;}return true;}
function say(x,text,o){var n=typeof x==='object'&&x&&x.root?x:find(x);if(!n)return null;o=o||{};var b=n.bubble;
 if(!b){b=document.createElement('div');b.className='tgnpc-bubble';b.setAttribute('role','status');var nm=document.createElement('div');nm.className='tgnpc-name';var tx=document.createElement('div');tx.className='tgnpc-text';b.appendChild(nm);b.appendChild(tx);layer().appendChild(b);n.bubble=b;}
 b.firstChild.textContent=n.name+(n.title?' · '+n.title:'');b.lastChild.textContent=String(text);n.occ=null;b.classList.toggle('shout',!!o.shout);b.classList.add('on');b.style.display='';
 n.bubbleLeft=o.duration||Math.min(7,2.6+String(text).length*.12);return n;}
function talk(n){if(!n.lines.length)return n;var text=n.lines[n.line%n.lines.length];n.line++;say(n,text);n.talkLeft=n.bubbleLeft;n.action='talk';n.left=n.bubbleLeft;
 if(n.onTalk)try{n.onTalk(n,text);}catch(e){console.warn(e);}if(api.onTalk)try{api.onTalk(n,text);}catch(e){console.warn(e);}return n;}
/* ---- 气泡可见性：距离（以玩家/目标为准）+ 遮挡（只认竖直的墙面，忽略雨棚/屋顶/地面这类水平面和 NPC 自己摊位附近的东西） ---- */
function targetObj(){if(view.target)return view.target;var W=window.W3;return W&&W.player||null;}
function occluderList(parent){if(view.occluders)return view.occluders;if(!parent)return null;var e=OCC.get(parent);
 if(e&&e.sig===parent.children.length)return e.list;var list=[];
 parent.traverse(function(o){if(!o.isMesh||o.isSprite||o.isInstancedMesh&&false)return;for(var p=o;p&&p!==parent;p=p.parent){if(p.userData&&(p.userData.tgNpc||p.userData.npcNoOcclude))return;}
  var u=o.userData||{};if(u.r41Label||u.wallSign||u.npcNoOcclude||o.material&&o.material.visible===false)return;
  // 小物件（布帘、灯笼、幌子、杆子）不挡气泡：世界尺寸半径 < minOccluder 的跳过
  var g=o.geometry;if(g&&view.minOccluder>0){if(!g.boundingSphere)g.computeBoundingSphere();o.updateWorldMatrix(true,false);var sc=o.matrixWorld.getMaxScaleOnAxis();if(g.boundingSphere&&g.boundingSphere.radius*sc<view.minOccluder)return;}
  list.push(o);});
 OCC.set(parent,{sig:parent.children.length,list:list});return list;}
function occluded(n,cam){var list=occluderList(n.root.parent);if(!list||!list.length)return false;
 _d.copy(_h).sub(cam.position);var len=_d.length();if(len<.5)return false;_d.multiplyScalar(1/len);
 occRay.set(cam.position,_d);occRay.near=.3;occRay.far=Math.max(.31,len-view.nearIgnore);occRay.camera=cam;_hits.length=0;occRay.intersectObjects(list,false,_hits);
 for(var i=0;i<_hits.length;i++){var h=_hits[i];if(!worldVisible(h.object))continue;
  if(h.face){_nm.copy(h.face.normal).transformDirection(h.object.matrixWorld);if(Math.abs(_nm.y)>.6)continue;}   // 水平面（雨棚、屋顶、地面）不算遮挡
  _hits.length=0;return true;}
 _hits.length=0;return false;}
function update(dt,camera){dt=Math.min(.1,Math.max(0,+dt||0));if(camera)view.camera=camera;defaults();var cam=view.camera,rect=null,tg=targetObj();frame++;
 for(var i=0;i<npcs.length;i++){var n=npcs[i];var vis=worldVisible(n.root);if(!vis){if(n.bubble&&n.bubbleLeft>0){n.bubbleLeft=0;n.bubble.classList.remove('on');}continue;}
  n.t+=dt*1000;n.left-=dt;n.root.getWorldPosition(_p);var near=false,dx=0,dz=0;
  if(cam){dx=cam.position.x-_p.x;dz=cam.position.z-_p.z;near=dx*dx+dz*dz<110;}
  if(n.talkLeft>0)n.talkLeft-=dt;
  if(n.left<=0){var a=n.talkLeft>0?'talk':pick(n.weights,near);n.action=a;var d=DUR[a]||[2,4];n.left=d[0]+rnd()*(d[1]-d[0]);
   if(a==='call'&&n.calls.length&&near&&!(n.bubbleLeft>0)&&rnd()<.6)say(n,n.calls[(rnd()*n.calls.length)|0],{shout:true,duration:2.2});}
  // 朝向：说话/招手时转向镜头（限制在 ±1.2 rad 内），否则回到摊位朝向
  var target=n.homeYaw;if(cam&&(n.talkLeft>0||n.action==='wave'||n.action==='call')){var want=Math.atan2(dx,dz),diff=Math.atan2(Math.sin(want-n.homeYaw),Math.cos(want-n.homeYaw));target=n.homeYaw+Math.max(-1.2,Math.min(1.2,diff));}
  var dd=Math.atan2(Math.sin(target-n.yaw),Math.cos(target-n.yaw));n.yaw+=dd*Math.min(1,dt*5);n.root.rotation.y=n.yaw;
  animModel(n.model,n.action,n.t);
  if(n.bubble&&n.bubbleLeft>0){n.bubbleLeft-=dt;if(n.bubbleLeft<=0){n.bubble.classList.remove('on');continue;}
   if(view.maxDist>0){var ref=tg?tg.getWorldPosition(_d):(cam?cam.position:null);if(ref){var ex=ref.x-_p.x,ez=ref.z-_p.z;if(ex*ex+ez*ez>view.maxDist*view.maxDist){n.bubbleLeft=0;n.talkLeft=0;n.bubble.classList.remove('on');continue;}}}
   if(!cam||!view.canvas)continue;if(!rect)rect=view.canvas.getBoundingClientRect();
   _h.copy(_p);_h.y+=(n.cfg.name||n.cfg.title?2.4:2.05)*n.height;
   if(view.occlude&&((frame+i)%Math.max(1,view.occludeEvery|0)===0||n.occ==null))n.occ=occluded(n,cam);
   if(n.occ){n.bubble.style.visibility='hidden';continue;}
   _q.copy(_h).project(cam);
   if(_q.z>1||_q.z<-1||Math.abs(_q.x)>1.2||Math.abs(_q.y)>1.2){n.bubble.style.visibility='hidden';continue;}
   n.bubble.style.visibility='';n.bubble.style.transform='translate3d('+Math.round(rect.left+(_q.x+1)/2*rect.width)+'px,'+Math.round(rect.top+(1-_q.y)/2*rect.height)+'px,0) translate(-50%,-100%)';}
 }}
function handleTap(a,camera,canvas){defaults();var cam=camera||view.camera,cv=canvas||view.canvas,r=null;
 if(a&&a.ray&&typeof a.intersectObject==='function')r=a;   // r170 的 Raycaster 没有 isRaycaster，按鸭子类型判断
else if(a&&a.clientX!=null&&cv&&cam){var rc=cv.getBoundingClientRect();ndc.set((a.clientX-rc.left)/rc.width*2-1,-(a.clientY-rc.top)/rc.height*2+1);ray.setFromCamera(ndc,cam);r=ray;}
 else if(a&&a.x!=null&&cam){ndc.set(a.x,a.y);ray.setFromCamera(ndc,cam);r=ray;}if(!r)return null;
 var best=null,bd=Infinity;for(var i=0;i<npcs.length;i++){var n=npcs[i];if(!worldVisible(n.root))continue;n.hit.updateWorldMatrix(true,false);var hits=r.intersectObject(n.hit,false);if(hits.length&&hits[0].distance<bd){bd=hits[0].distance;best=n;}}
 if(best)talk(best);return best;}
function setView(o){o=o||{};if(o.camera)view.camera=o.camera;if(o.canvas)view.canvas=o.canvas;if('target' in o)view.target=o.target||null;if(o.maxDist!=null)view.maxDist=+o.maxDist||0;if(o.occlude!=null)view.occlude=!!o.occlude;if('occluders' in o)view.occluders=o.occluders||null;if(o.occludeEvery!=null)view.occludeEvery=o.occludeEvery|0||1;if(o.nearIgnore!=null)view.nearIgnore=+o.nearIgnore;if(o.minOccluder!=null){view.minOccluder=+o.minOccluder||0;OCC.clear();}if(o.container&&o.container!==view.container){view.container=o.container;if(view.layer){view.layer.remove();view.layer=null;npcs.forEach(function(n){if(n.bubble){n.bubble.remove();n.bubble=null;}});}}return view;}
function stats(){var tris=0,calls=0;npcs.forEach(function(n){n.model.traverse(function(o){if(o.isMesh&&o.visible&&o.material.visible!==false){calls++;if(o.geometry.index)tris+=o.geometry.index.count/3;}if(o.isSprite){calls++;tris+=2;}});});return {npcs:npcs.length,triangles:tris,drawCalls:calls};}

api=window.TG_NPC={__v:1,presets:PRESETS,marketStalls:MARKET_STALLS,spawn:spawn,placeAtStalls:placeAtStalls,update:update,handleTap:handleTap,talk:function(x){var n=find(x);return n?talk(n):null;},say:say,
 refreshOccluders:function(){OCC.clear();},hideBubbles:function(){npcs.forEach(function(n){n.bubbleLeft=0;n.talkLeft=0;if(n.bubble)n.bubble.classList.remove('on');});},remove:remove,clear:clear,list:list,get:find,setView:setView,stats:stats,onTalk:null};
})();
