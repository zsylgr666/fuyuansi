/* r8c.2b (+r8c.2d remote hotfix: per-id look fallback, clone rebuild, readable plates, buffered interpolation): (1) remote players get their own avatar + plate instead of a clone of the local player (which carried MY plate);
   (2) name plates draw with the native fillText and user strings are registered as raw so r7's rewrite never touches them. */
(()=>{
'use strict';
const T=THREE,A=()=>window.TG_AVATAR;const LOG=(window.TG_R8C2B={built:0,disposed:0,errs:[]});
// --- (2) plates: every avatar build/update draws its plate under r7Raw (native fillText)
const av=A();if(av&&!av.r8c2Raw){av.r8c2Raw=true;for(const k of ['build','update']){const f=av[k];av[k]=function(){return window.r7Raw?window.r7Raw(()=>f.apply(this,arguments)):f.apply(this,arguments);};}}
const regTea=()=>{try{for(const m of S?.tea?.messages||[])window.r7RawText?.(m.name,m.text);}catch(e){}};
// --- (1) remote players
const hash=s=>{let h=2166136261;for(const ch of String(s))h=Math.imul(h^ch.charCodeAt(0),16777619);return h>>>0;};
// r8c2d: a look counts only if it carries real appearance fields; {name:''} / text-only / acc-only objects fall back to a stable per-id look
const LOOK=['hair','outfit','color1','color2'];
const hasLook=a=>!!a&&typeof a==='object'&&LOOK.some(k=>a[k]!=null&&a[k]!=='');
const RND=new Map();// per-id random look, computed once (randomConfig's free-accessory filter depends on MY catalog state)
// r8c2d/r8d3: no retired options in random remote looks (monk robe sengpao, prayer beads, NPC incense; 光头 / 玉串 stay) → deterministic swap from the same hash
const SAFE={outfit:['daopao','ruqun','yuanling','duanda'],hair:['bun','long','ponytail','twin','short'],hand:['none','fan','scroll']};
function secular(c,h){if(c.outfit==='sengpao')c.outfit=SAFE.outfit[h%4];/* r8d3: 光头 / 玉串 are ordinary again — only sengpao / beads / incense */
 if(c.acc){if(c.acc.neck==='beads')c.acc.neck='none';if(c.acc.hand==='incense')c.acc.hand=SAFE.hand[(h>>>7)%3];}try{window.TG_R8D3?.unmonk?.(c,h);}catch(e){}/* r8d3: no bald + orange/yellow/brown long robe */return c;}
const rnd=id=>{let c=RND.get(id);if(!c){const h=hash(id);c=secular({...A().randomConfig(h),acc:{...(A().randomConfig(h).acc||{})}},h);RND.set(id,c);}return c;};
const nameOf=p=>String(p.name||p.nickname||'同行访客'),titleOf=p=>String(p.title||p.avatar?.title||'');
const lookKey=p=>JSON.stringify([titleOf(p),hasLook(p.avatar)?p.avatar:null]);
function cfgFor(p){const a=A();const base=hasLook(p.avatar)?{...p.avatar}:{...rnd(String(p.id))};
 return a.normalize({...base,name:nameOf(p),title:titleOf(p)},{checkOwned:false});}
// --- r8c2d plates: own sprite (avatar plate off), dark backing + outline, ~1.5x text, depthTest off, full name (no 12-char cut), native fillText via r7Raw
const PF='"Noto Sans CJK SC","Noto Sans SC","PingFang SC","Microsoft YaHei",sans-serif',PX=.003;// world metres per canvas px (name 72px → .216 m)
function rr(x,X,Y,W,H,R){x.beginPath();x.moveTo(X+R,Y);x.arcTo(X+W,Y,X+W,Y+H,R);x.arcTo(X+W,Y+H,X,Y+H,R);x.arcTo(X,Y+H,X,Y,R);x.arcTo(X,Y,X+W,Y,R);x.closePath();}
function drawPlate(name,title){const cv=document.createElement('canvas'),x=cv.getContext('2d');let nf=72;const tf=44;
 const draw=()=>{x.font='700 '+nf+'px '+PF;let nw=x.measureText(name).width;x.font='600 '+tf+'px '+PF;const tw=title?x.measureText('【'+title+'】').width:0;return Math.max(nw,tw);};
 let w=draw();while(w>1100&&nf>40){nf-=4;w=draw();}
 const pad=28,W=Math.min(1200,Math.ceil(w+pad*2)),th=title?tf+14:0,H=nf+30+th;cv.width=W;cv.height=H+8;
 x.textAlign='center';x.textBaseline='middle';
 rr(x,4,4,W-8,H,Math.min(34,H/2));x.fillStyle='rgba(30,20,12,.78)';x.fill();x.lineWidth=4;x.strokeStyle='rgba(240,205,130,.95)';x.stroke();
 if(title){x.font='600 '+tf+'px '+PF;x.fillStyle='#f3cf7a';x.fillText('【'+title+'】',W/2,4+12+tf/2);}
 x.font='700 '+nf+'px '+PF;x.lineJoin='round';x.lineWidth=10;x.strokeStyle='rgba(20,10,4,.95)';const ny=4+th+(nf+30)/2;x.strokeText(name,W/2,ny);x.fillStyle='#fffaf0';x.fillText(name,W/2,ny);
 const t=new T.CanvasTexture(cv);t.colorSpace=T.SRGBColorSpace;t.anisotropy=2;return {t,w:cv.width,h:cv.height};}
function setPlate(r,p){const name=nameOf(p),title=titleOf(p),key=name+'\u0001'+title;if(r.plateKey===key&&r.plate)return;
 window.r7RawText?.(name,title);const d=window.r7Raw?window.r7Raw(()=>drawPlate(name,title)):drawPlate(name,title);
 if(!r.plate){const m=new T.SpriteMaterial({map:d.t,transparent:true,depthTest:false,depthWrite:false,fog:false});r.plate=new T.Sprite(m);r.plate.name='r8c2d-plate';r.plate.center.set(.5,0);r.plate.renderOrder=20;r.plate.frustumCulled=false;}
 else{r.plate.material.map?.dispose();r.plate.material.map=d.t;r.plate.material.needsUpdate=true;}
 r.plateW=d.w*PX;r.plateH=d.h*PX;r.plate.scale.set(r.plateW,r.plateH,1);r.plateKey=key;}
function dropPlate(r){if(!r?.plate)return;r.plate.parent?.remove(r.plate);r.plate.material.map?.dispose();r.plate.material.dispose();r.plate=null;r.plateKey=null;}
function makeRemote(p){const a=A();const mesh=new T.Group();mesh.name='r8c2-remote';mesh.userData.r8c2Remote=String(p.id);
 const body=new T.Group();body.name='r8c2-remote-body';mesh.add(body);// enhance/r6 animate children[0] (bob, mount lift); kept empty so their limb swing hits nothing
 const cfg=cfgFor(p),model=a.build(cfg,{plate:false,detail:1,shadow:false});model.userData.r8c2Key=lookKey(p);mesh.add(model);
 mesh.position.set(p.pos.x,p.pos.y,p.pos.z);const yaw=typeof p.rot==='number'?p.rot:p.rot?.y||0;mesh.rotation.y=yaw;W3.scene.add(mesh);
 // enhance's own label path stays wired to an off-scene dummy (it disposes it on leave)
 const c=document.createElement('canvas');c.width=c.height=4;const label=new T.Sprite(new T.SpriteMaterial({map:new T.CanvasTexture(c)}));
 const r={mesh,label,c,name:p.name,model,r8c2d:true};setPlate(r,p);mesh.add(r.plate);r.plateBase=2.02*cfg.height/100+(cfg.acc?.head==='hat'?.08:0);
 LOG.built++;return r;}
// a remote entry without .model is enhance's clone of MY player (my avatar + my plate): drop it without touching the shared geometry/materials
function dropClone(w,id,r){try{w.scene.remove(r.mesh);r.label?.material?.map?.dispose();r.label?.material?.dispose();}catch(e){}w.remotes.delete(id);LOG.clones=(LOG.clones||0)+1;}
// --- r8c2d buffered interpolation: samples stamped with sender time (p.st / p.t from new backends) or local receive time; render 140 ms behind
const camR=new T.Vector3();const DELAY=140,WALK_REF=1.77,BUF=new Map();// WALK_REF: local full walk speed (m/s) = cadence 1.0 (r8d line: 1.77)
LOG.samples=0;
const yawOf=p=>typeof p.rot==='number'?p.rot:(p.rot?.y||0);
function sample(p){const id=String(p.id),now=performance.now();let b=BUF.get(id);if(!b){b={s:[],off:null,lastRecv:now,lastSt:null,key:''};BUF.set(id,b);}
 const st=Number.isFinite(p.st)?p.st:null;const key=[p.pos.x,p.pos.y,p.pos.z,yawOf(p),p.anim,p.scene].join(',');
 if(key===b.key&&(st==null||st===b.lastSt))return;// presence resync / unchanged: no new sample
 if(st!=null&&b.lastSt!=null&&st<b.lastSt)return;// stale (older than what we already have)
 let t=Number.isFinite(p.t)&&Math.abs(Date.now()-p.t)<2000?now-(Date.now()-p.t):now;// no st: local receive time (p.t from the backend, else now)
 if(st!=null){const o=now-st;b.off=b.off==null?o:Math.min(b.off+(now-b.lastRecv)*.002,o);t=st+b.off;b.lastSt=st;}
 const last=b.s[b.s.length-1];
 if(st==null&&last&&p.scene===last.scene)t=Math.min(Math.max(now,last.t+100),now+400);// no sender clock: the sender sends ≤10 Hz, so packets closer than 100 ms are jitter/bursts → re-space them (lead capped at 400 ms; the render clock catches up at ≤1.25x)
 if(last&&(p.scene!==last.scene||Math.hypot(p.pos.x-last.x,p.pos.z-last.z)>6))b.s.length=0;// scene change / teleport: snap
 else if(last&&t-last.t>250){const pv=b.s[b.s.length-2],still=last.anim!=='walk'||(pv&&pv.x===last.x&&pv.z===last.z);if(still)b.s.push({...last,t:t-100});}// motion after a real pause starts ~one send interval before this sample (moving remotes: plain interpolation across the gap)
 const prev=b.s[b.s.length-1];if(prev&&t<=prev.t)t=prev.t+1;
 b.s.push({t,x:p.pos.x,y:p.pos.y,z:p.pos.z,rot:yawOf(p),anim:p.anim,scene:p.scene});b.key=key;b.lastRecv=now;LOG.samples++;
 while(b.s.length>24||(b.s.length>2&&b.s[1].t<now-3000))b.s.shift();}
const angLerp=(a,b,k)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*k;
// render clock per remote: follows now-DELAY at rate 1 (±25 % to absorb drift), never runs past the newest sample (hold instead of
// extrapolating) and resumes from where it held, so a late packet slows the remote briefly instead of making it jump
function interp(id,now){const b=BUF.get(id);if(!b||!b.s.length)return null;const s=b.s,L=s[s.length-1],target=now-DELAY;
 if(b.rt==null||Math.abs(target-b.rt)>1000)b.rt=target;else{const dt=Math.max(0,now-(b.lastNow??now));b.rt+=dt*(1+Math.max(-.25,Math.min(.25,(target-b.rt)/400)));}
 b.lastNow=now;if(b.rt>L.t)b.rt=L.t;const rt=b.rt;
 if(rt<=s[0].t)return s[0];if(rt>=L.t)return L;
 for(let i=s.length-2;i>=0;i--)if(s[i].t<=rt){const a=s[i],c=s[i+1],k=(rt-a.t)/(c.t-a.t);return {x:a.x+(c.x-a.x)*k,y:a.y+(c.y-a.y)*k,z:a.z+(c.z-a.z)*k,rot:angLerp(a.rot,c.rot,k),anim:k<.5?a.anim:c.anim};}
 return L;}
const applyR=window.applyRemotePlayers;
window.applyRemotePlayers=window.TG_NET.applyRemotePlayers=function(list){for(const p of list||[])if(p){window.r7RawText?.(p.name,p.nickname,p.nameWithTitle,p.title);try{if(p.id!=null&&p.pos&&[p.pos.x,p.pos.y,p.pos.z].every(Number.isFinite))sample(p);}catch(e){}}return applyR.apply(this,arguments);};
const camV=new T.Vector3();
const inner=tgRemotes;tgRemotes=function(dt){const w=W3;if(!w?.player||!A()?.build)return inner.apply(this,arguments);w.remotes=w.remotes||new Map();
 const ids=new Set(tgRemoteList.map(p=>String(p.id)));
 for(const [id,r] of w.remotes)if(!ids.has(id)){if(r.model){try{A().dispose(r.model);}catch(e){}r.model=null;LOG.disposed++;}dropPlate(r);BUF.delete(id);}
 for(const p of tgRemoteList){const id=String(p.id);let r=w.remotes.get(id);
  if(r&&!r.model){dropClone(w,id,r);r=null;}
  if(!r){try{r=makeRemote(p);w.remotes.set(id,r);}catch(e){LOG.errs.push(String(e));}continue;}
  const key=lookKey(p);if(r.model.userData.r8c2Key!==key){const cfg=cfgFor(p);A().update(r.model,cfg);r.model.userData.r8c2Key=key;r.plateBase=2.02*cfg.height/100+(cfg.acc?.head==='hat'?.08:0);}
  setPlate(r,p);}
 const out=inner.apply(this,arguments);
 const now=performance.now(),cam=w.camera,H=w.renderer?.domElement?.clientHeight||innerHeight;const plates=[];
 for(const p of tgRemoteList){const id=String(p.id),r=w.remotes.get(id);if(!r?.model)continue;const body=r.mesh.children[0];
  // position / yaw: buffered interpolation replaces enhance's exponential lerp
  const q=interp(id,now);if(q){r.mesh.position.set(q.x,q.y,q.z);r.mesh.rotation.y=q.rot;}
  // displayed speed → walk/idle with hysteresis + min hold; cadence follows speed
  const ft=now-(r.lastNow||now);r.lastNow=now;
  if(ft>4){const lp=r.lastPos||r.mesh.position.clone(),v=Math.hypot(r.mesh.position.x-lp.x,r.mesh.position.z-lp.z)/(ft/1000);r.spd=(r.spd||0)+(Math.min(v,12)-(r.spd||0))*(1-Math.exp(-ft/120));(r.lastPos||(r.lastPos=new T.Vector3())).copy(r.mesh.position);
   const walking=r.walk?r.spd>.15:r.spd>.35;if(walking!==!!r.walk&&now-(r.walkSince||0)>180){r.walk=walking;r.walkSince=now;LOG.switches=(LOG.switches||0)+1;}
   r.animT=(r.animT||0)+ft*(r.walk?Math.max(.45,Math.min(1.4,r.spd/WALK_REF)):1);}
  // no double bob: the avatar rig bobs itself; body only carries r6's mount lift
  r.model.position.y=p.mount?.kind?.9:0;r.model.rotation.x=body.rotation.x;body.rotation.x=0;body.position.y=0;
  const want=p.mount?.kind?'ride':(p.anim==='sit'?'sit':'stand');if(A().getPose?.(r.model)!==want)A().setPose(r.model,want);
  A().animate(r.model,r.walk&&want!=='sit'?'walk':'idle',r.animT||now);
  // plate: above the head (mount-aware); r8d2: name glyphs ≥ 17 css px em (≥ 14 px visible) in both orientations (cap 2.6 → 6 so far landscape views reach it too)
  if(r.plate){if(r.plate.parent!==r.mesh)r.mesh.add(r.plate);r.plate.position.set(0,r.model.position.y+(r.plateBase||2.02),0);
   let f=1,ppm=0,d=0;if(cam&&cam.isPerspectiveCamera){r.plate.getWorldPosition(camV);d=camV.distanceTo(cam.position);ppm=H/(2*d*Math.tan(cam.fov*Math.PI/360));f=Math.max(1,Math.min(6,17/(.216*ppm)));}
   r.plate.scale.set(r.plateW*f,r.plateH*f,1);if(ppm)plates.push({r,d,ppm,f});}}
 // r8d2: plates of players standing close never overlap — nearest plate keeps its place, farther ones step up by the overlap (screen space)
 // r8d3: the stack is bounded — a plate may rise at most 2 plate heights and never above the top margin (8 px); otherwise it moves beside the
 // conflicting plate (right, then left); if no free slot exists it fades to .35. (r8d2 stacked without bound: 6 close players in landscape pushed 2 plates off the top.)
 if(plates.length>1&&cam){plates.sort((a,b)=>a.d-b.d);const W=w.renderer.domElement.clientWidth||innerWidth,placed=[],TOP=8;camR.setFromMatrixColumn(cam.matrixWorld,0);
  const hitOf=rc=>placed.find(o=>rc.l<o.r-2&&rc.r>o.l+2&&rc.t<o.b-2&&rc.b>o.t+2);
  for(const e of plates){const pl=e.r.plate;pl.getWorldPosition(camV);camV.project(cam);if(camV.z>1)continue;
   const cx=(camV.x+1)/2*W,by=(1-camV.y)/2*H,pw=e.r.plateW*e.f*e.ppm,ph=e.r.plateH*e.f*e.ppm;const base={l:cx-pw/2,r:cx+pw/2,b:by,t:by-ph};
   const at=(dx,dy)=>({l:base.l+dx,r:base.r+dx,b:base.b-dy,t:base.t-dy});let best=null;
   // candidate slots: stay; then rising steps (bounded); then beside each conflicting plate at the same height
   if(!hitOf(base))best={dx:0,dy:0};
   if(!best){let dy=0;for(let it=0;it<6&&!best;it++){const rc=at(0,dy),h=hitOf(rc);if(!h){best={dx:0,dy};break;}dy+=rc.b-h.t+3;if(dy>2*ph+1||base.t-dy<TOP)break;}}
   if(!best){for(const o of placed){if(!(base.l<o.r-2&&base.r>o.l+2))continue;for(const dx of [o.r+3-base.l,o.l-3-base.r]){for(const dy of [0,Math.max(0,base.b-o.b)]){const rc=at(dx,dy);if(rc.l>=2&&rc.r<=W-2&&rc.t>=TOP&&!hitOf(rc)){best={dx,dy};break;}}if(best)break;}if(best)break;}}
   const fade=!best;if(fade)best={dx:0,dy:0};
   const ly=best.dy/e.ppm,lx=best.dx/e.ppm;e.r.plateLift=(e.r.plateLift||0)+(ly-(e.r.plateLift||0))*.35;e.r.plateShift=(e.r.plateShift||0)+(lx-(e.r.plateShift||0))*.35;/* eased so plates glide instead of popping */
   if(Math.abs(e.r.plateLift)<.002)e.r.plateLift=0;if(Math.abs(e.r.plateShift)<.002)e.r.plateShift=0;
   pl.position.y+=e.r.plateLift;if(e.r.plateShift){const inv=e.r.mesh.quaternion.clone().invert();camV.copy(camR).applyQuaternion(inv).multiplyScalar(e.r.plateShift/Math.max(1e-3,e.r.mesh.scale.x||1));pl.position.x+=camV.x;pl.position.z+=camV.z;}
   pl.material.opacity=fade?.35:1;if(!fade)placed.push(at(best.dx,best.dy));}
  LOG.plateStack=placed.length;}
 else for(const e of plates){e.r.plateLift=0;e.r.plateShift=0;e.r.plate.material.opacity=1;}
 return out;};
// net-delivered titles/names may arrive before the first frame: register what is already known
setTimeout(regTea,0);document.addEventListener('click',()=>setTimeout(regTea,0),true);
})();
