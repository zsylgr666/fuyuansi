/* mounts.js — 福缘里 · 心田小院：坐骑模型 + 骑乘动画（独立模块，未接入 pack.mjs）
 * window.TG_MOUNTS = { kinds(), info, build(kind,deco), setDeco(m,deco), getSeats(m),
 *                      mount(m,rider,seat,opts), dismount(m,riderOrSeat), animate(m,state,t,speed),
 *                      poseRider(rider,pose,opts), unposeRider(rider), dispose(m), purge(), stats(m), config(o) }
 * 画风：王者荣耀家园式「风格化写实」——暖色、圆润体块、顶亮底暗的烘焙明暗（顶点色），不发光、不玄幻。
 * 性能：每个可动部件 = 1 个合并 BufferGeometry（顶点色）+ 全局共享 3 个材质；几何按 kind/部件/装饰 缓存复用；
 *       animate 只做标量运算，不分配对象。坐标：地面 y=0，头朝 +Z（与 r3 / animals2 相同）。
 * 结构：group(调用方拥有 position/rotation.y) → userData.rig(动画拥有) → body/neck→head/tail/legs(hip→knee)
 *       牛车：group → rig(牛) + cart(车厢，不随牛起伏) → wheels[2]
 */
(function(){
'use strict';
var G=typeof window!=='undefined'?window:globalThis;
if(G.TG_MOUNTS&&G.TG_MOUNTS.__v)return;                 // 幂等加载
var T=(typeof THREE!=='undefined')?THREE:G.THREE;
if(!T){console.warn('[mounts] THREE 未加载，跳过');return;}
var PI=Math.PI,TAU=PI*2;

// ---------------------------------------------------------------- 配置 / 材质
var CFG={lambert:false,real:false,shadows:true,realGain:1.9};   // real:true 时牛车木件借用 TG_REAL 木纹贴图（默认关：贴图偏红偏暗）
var MAT={};
function mats(){
  if(MAT.coat)return MAT;
  if(CFG.lambert){
    MAT.coat=new T.MeshLambertMaterial({vertexColors:true});
    MAT.gloss=MAT.coat;
    MAT.metal=new T.MeshLambertMaterial({vertexColors:true,emissive:'#2a2418'});
  }else{
    MAT.coat=new T.MeshStandardMaterial({vertexColors:true,roughness:.82,metalness:0});
    MAT.gloss=new T.MeshStandardMaterial({vertexColors:true,roughness:.5,metalness:0});
    MAT.metal=new T.MeshStandardMaterial({vertexColors:true,roughness:.32,metalness:.45,emissive:'#1c160c'});
  }
  MAT.coat.name='tg-mount-coat';MAT.gloss.name='tg-mount-gloss';MAT.metal.name='tg-mount-metal';
  return MAT;
}
var realWood;   // TG_REAL 木纹（可选，仅用于牛车车厢/车轮）：借用它的 map/normal/roughness 贴图，保留本模块的顶点色
function woodMat(){
  if(realWood!==undefined)return realWood||mats().gloss;
  realWood=null;
  var R=G.TG_REAL;
  if(CFG.real&&!CFG.lambert&&R&&typeof R.material==='function'&&R.enabled!==false){
    try{var m=R.material('wood',{});
      if(m&&m.isMaterial&&m.map){
        realWood=new T.MeshStandardMaterial({vertexColors:true,map:m.map,normalMap:m.normalMap||null,roughnessMap:m.roughnessMap||null,roughness:1,metalness:0});
        realWood.color.setScalar(CFG.realGain);   // 贴图本身偏棕，顶点色 × 贴图会变暗，这里补回亮度
        if(m.normalScale)realWood.normalScale.copy(m.normalScale);
        realWood.name='tg-mount-wood-real';
      }}catch(e){console.warn('[mounts] TG_REAL.material(wood) 失败，用纯色',e);realWood=null;}
  }
  return realWood||mats().gloss;
}

// ---------------------------------------------------------------- 合并几何构建器（只在 build 首次时运行）
var _m4=new T.Matrix4(),_q=new T.Quaternion(),_e=new T.Euler(),_v=new T.Vector3(),_v2=new T.Vector3(),_s=new T.Vector3(),
    _n3=new T.Matrix3(),_c1=new T.Color(),_c2=new T.Color(),UP=new T.Vector3(0,1,0),ZAX=new T.Vector3(0,0,1);
function PB(){this.parts=[];}
// col: '#hex' 或 [顶色, 底色]；opt.shade=明暗强度（默认 .22），opt.flat 不做明暗
PB.prototype.push=function(geo,mtx,col,opt){this.parts.push({g:geo,m:mtx.clone(),c:col,o:opt||{}});return this;};
function M(x,y,z,rx,ry,rz,sx,sy,sz){_e.set(rx||0,ry||0,rz||0);_q.setFromEuler(_e);_v.set(x,y,z);_s.set(sx==null?1:sx,sy==null?1:sy,sz==null?1:sz);return _m4.compose(_v,_q,_s);}
PB.prototype.ell=function(x,y,z,rx,ry,rz,col,rot,seg,o){rot=rot||[];var s=seg||12;
  return this.push(new T.SphereGeometry(1,s,Math.max(5,Math.round(s*.66))),M(x,y,z,rot[0],rot[1],rot[2],rx,ry,rz),col,o);};
PB.prototype.box=function(x,y,z,sx,sy,sz,col,rot,o){rot=rot||[];return this.push(new T.BoxGeometry(1,1,1),M(x,y,z,rot[0],rot[1],rot[2],sx,sy,sz),col,o);};
PB.prototype.cone=function(x,y,z,r,h,col,rot,seg,o){rot=rot||[];return this.push(new T.ConeGeometry(r,h,seg||8),M(x,y,z,rot[0],rot[1],rot[2]),col,o);};
PB.prototype.cyl=function(x,y,z,rt,rb,h,col,rot,seg,o){rot=rot||[];return this.push(new T.CylinderGeometry(rt,rb,h,seg||10),M(x,y,z,rot[0],rot[1],rot[2]),col,o);};
// 两点间锥台（a 端半径 ra，b 端 rb），cap=在 b 端补球
PB.prototype.seg=function(a,b,ra,rb,col,seg,cap,o){
  _v.set(b[0]-a[0],b[1]-a[1],b[2]-a[2]);var len=_v.length()||1e-4;_v.multiplyScalar(1/len);_q.setFromUnitVectors(UP,_v);
  _v2.set((a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2);_s.set(1,1,1);
  this.push(new T.CylinderGeometry(rb,ra,len,seg||8,1,true),_m4.compose(_v2,_q,_s),col,o);
  if(cap)this.ell(b[0],b[1],b[2],rb,rb,rb,col,null,seg||8,o);
  return this;};
PB.prototype.chain=function(pts,r0,r1,col,seg,o){var n=pts.length-1;for(var i=0;i<n;i++){var ra=r0+(r1-r0)*i/n,rb=r0+(r1-r0)*(i+1)/n;this.seg(pts[i],pts[i+1],ra,rb,col,seg,true,o);}if(pts.length)this.ell(pts[0][0],pts[0][1],pts[0][2],r0,r0,r0,col,null,seg||8,o);return this;};
PB.prototype.tor=function(x,y,z,R,r,col,rot,sc,arc,o,segs){rot=rot||[];sc=sc||[1,1,1];segs=segs||[5,14];
  return this.push(new T.TorusGeometry(R,r,segs[0],segs[1],arc||TAU),M(x,y,z,rot[0],rot[1],rot[2],sc[0],sc[1],sc[2]),col,o);};
// 环带：圆环轴线沿 dir（单位向量 [x,y,z]），用于鼻革 / 项圈
PB.prototype.ring=function(c,dir,R,r,col,sc,o){_v.set(dir[0],dir[1],dir[2]).normalize();_q.setFromUnitVectors(ZAX,_v);_v2.set(c[0],c[1],c[2]);_s.set(sc?sc[0]:1,sc?sc[1]:1,1);
  return this.push(new T.TorusGeometry(R,r,5,16),_m4.compose(_v2,_q,_s),col,o);};
// 沿 Z 轴的椭圆柱面片（鞍毯/肚带/车篷）：中心 c，半径 rx/ry，长 len，顶部为中心张开 ±half 弧度
PB.prototype.sheet=function(c,rx,ry,len,half,col,o){var g=new T.CylinderGeometry(1,1,len,20,1,true,PI-half,half*2);
  return this.push(g,M(c[0],c[1],c[2],PI/2,0,0,rx,1,ry),col,o);};   // 旋转后 y 轴尺度落在 Z 上
PB.prototype.sub=function(fn,x,y,z){var t=new PB();fn(t);var o=new T.Matrix4().makeTranslation(x,y,z);for(var i=0;i<t.parts.length;i++){t.parts[i].m.premultiply(o);this.parts.push(t.parts[i]);}return this;};
PB.prototype.build=function(){
  var nV=0,nI=0,i,p;
  for(i=0;i<this.parts.length;i++){p=this.parts[i];if(!p.g.index)p.g=p.g.index?p.g:indexify(p.g);nV+=p.g.attributes.position.count;nI+=p.g.index.count;}
  var pos=new Float32Array(nV*3),nor=new Float32Array(nV*3),uv=new Float32Array(nV*2),col=new Float32Array(nV*3),idx=(nV>65535?new Uint32Array(nI):new Uint16Array(nI));
  var vo=0,io=0;
  for(i=0;i<this.parts.length;i++){
    p=this.parts[i];var g=p.g,P=g.attributes.position,N=g.attributes.normal,U=g.attributes.uv,I=g.index,c=p.c,o=p.o;
    _n3.getNormalMatrix(p.m);
    var top=_c1.set(Array.isArray(c)?c[0]:c),bot=_c2.set(Array.isArray(c)?c[1]:c),sh=o.shade==null?.24:o.shade;
    for(var v=0;v<P.count;v++){
      _v.fromBufferAttribute(P,v).applyMatrix4(p.m);pos[(vo+v)*3]=_v.x;pos[(vo+v)*3+1]=_v.y;pos[(vo+v)*3+2]=_v.z;
      _v.fromBufferAttribute(N,v).applyMatrix3(_n3).normalize();nor[(vo+v)*3]=_v.x;nor[(vo+v)*3+1]=_v.y;nor[(vo+v)*3+2]=_v.z;
      if(U){uv[(vo+v)*2]=U.getX(v);uv[(vo+v)*2+1]=U.getY(v);}
      var f=_v.y*.5+.5,k=o.flat?1:(1-sh)+sh*f;      // 烘焙：顶亮底暗（假 AO）
      col[(vo+v)*3]=(bot.r+(top.r-bot.r)*f)*k;col[(vo+v)*3+1]=(bot.g+(top.g-bot.g)*f)*k;col[(vo+v)*3+2]=(bot.b+(top.b-bot.b)*f)*k;
    }
    for(var j=0;j<I.count;j++)idx[io+j]=I.getX(j)+vo;
    vo+=P.count;io+=I.count;g.dispose();
  }
  var out=new T.BufferGeometry();
  out.setAttribute('position',new T.BufferAttribute(pos,3));out.setAttribute('normal',new T.BufferAttribute(nor,3));
  out.setAttribute('uv',new T.BufferAttribute(uv,2));out.setAttribute('color',new T.BufferAttribute(col,3));
  out.setIndex(new T.BufferAttribute(idx,1));out.computeBoundingSphere();out.computeBoundingBox();
  this.parts.length=0;return out;
};
function indexify(g){var n=g.attributes.position.count,a=new Uint32Array(n);for(var i=0;i<n;i++)a[i]=i;g.setIndex(new T.BufferAttribute(a,1));return g;}

var GEO={};  // 几何缓存：key → BufferGeometry
function cached(key,k,make){
  var kk=key+'@'+k;if(GEO[kk])return GEO[kk];
  var pb=new PB();make(pb);var g=pb.build();if(k!==1)g.scale(k,k,k);g.computeBoundingSphere();g.name='tg-mount:'+key;return GEO[kk]=g;
}
function mesh(parent,geo,mat,name){var o=new T.Mesh(geo,mat);o.castShadow=CFG.shadows;o.receiveShadow=true;if(name)o.name=name;parent.add(o);return o;}
function grp(parent,x,y,z,name){var g=new T.Group();g.position.set(x||0,y||0,z||0);if(name)g.name=name;if(parent)parent.add(g);return g;}
function lerp3(a,b,t){return [a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}
function sc3(a,k){return [a[0]*k,a[1]*k,a[2]*k];}

// ---------------------------------------------------------------- 色板（暖调、低饱和、写实）
var C={
  eye:'#1e1612',eyeHi:'#fff6e8',nose:'#3a2a24',hoofDark:'#3a2e27',hoofLight:'#8d8478',
  leather:'#6b3d22',leatherDark:'#3e2416',rope:'#b99a68',ropeDark:'#8c6f45',
  red:'#b3302a',redDeep:'#86211f',gold:'#d8a845',goldDeep:'#a87a2a',teal:'#2f5d62',tealDeep:'#1f4247',
  cloth:'#c9a36c',clothStripe:'#8a5636',cream:'#efe4cc',bronze:'#b07a3a',silver:'#dfe2e2',
  wood:'#9a6a3e',woodDark:'#64422a',woodLight:'#b98d5c',iron:'#4b4642',bamboo:'#bf9c5d',bambooDark:'#8f6e3b'
};

// ---------------------------------------------------------------- 物种参数（单位：马的尺度；k 为整体缩放）
// torso/chest/rump/belly: [cx,cy,cz,rx,ry,rz]；legF/legB: 髋枢轴 x,z,y + 粗细；neck.at=颈枢轴（肩隆），neck.to=颈端（局部）
var HORSE_BODY={
  torso:[0,1.0,-.02,.26,.29,.62],chest:[0,.97,.42,.25,.3,.3],rump:[0,1.05,-.42,.275,.285,.3],belly:[0,.9,0,.24,.22,.45],
  legF:{x:.14,z:.42,y:.9,rU:.085,rL:.048,hoof:.075,thigh:[.1,.2,.14]},
  legB:{x:.14,z:-.44,y:.93,rU:.09,rL:.048,hoof:.075,thigh:[.125,.26,.19],hock:.06},
  neck:{at:[0,1.13,.5],to:[0,.46,.3],r0:.19,r1:.115},tailAt:[0,1.22,-.7],seatZ:.02
};
function ext(a,b){var o={},k;for(k in a)o[k]=a[k];for(k in b)o[k]=b[k];return o;}
var SPEC={
  donkey:ext(HORSE_BODY,{name:'小毛驴',emoji:'🫏',k:.8,head:'donkey',mane:'brush',tail:'tuft',
    torso:[0,1.0,-.02,.29,.3,.6],belly:[0,.88,0,.27,.24,.45],
    coat:['#9a8c7c','#7d7064'],belly2:['#d6cdbd','#e3dccd'],mane2:'#4e443c',hoof:C.hoofDark,muzzle:'#e2d9c8',stripe:'#5d534a',
    freq:[.0,1.15,1.9],speed:[0,1.0,2.2],deco:{saddle:'blanket',bridle:'rope',bells:'bronze'}}),
  chestnut:ext(HORSE_BODY,{name:'枣红马',emoji:'🐎',k:1,head:'horse',mane:'flow',tail:'horse',
    coat:['#a5582f','#7c3d20'],belly2:['#b06a3e','#94522d'],mane2:'#3a2116',hoof:C.hoofDark,muzzle:'#6a3822',blaze:'#f2ece0',socks:'#efe9dc',
    freq:[0,.92,1.55],speed:[0,1.3,3.0],deco:{saddle:'plain',bridle:'leather',bells:'none'}}),
  whitehorse:ext(HORSE_BODY,{name:'白马',emoji:'🐴',k:1,head:'horse',mane:'flow',tail:'horse',
    coat:['#f3f0e8','#d9d3c7'],belly2:['#f7f4ee','#e4dfd5'],mane2:'#fbf9f3',hoof:C.hoofLight,muzzle:'#c7b4a8',
    freq:[0,.92,1.55],speed:[0,1.3,3.0],exclusive:['silver'],deco:{saddle:'red',bridle:'red',bells:'silver'}}),
  whitedeer:{name:'白鹿',emoji:'🦌',k:1,head:'deer',mane:'none',tail:'deer',
    torso:[0,1.0,0,.2,.24,.52],chest:[0,.98,.35,.2,.25,.25],rump:[0,1.03,-.36,.21,.24,.25],belly:[0,.92,0,.18,.17,.38],
    legF:{x:.11,z:.36,y:.92,rU:.062,rL:.032,hoof:.055,thigh:[.08,.18,.12]},
    legB:{x:.11,z:-.38,y:.96,rU:.07,rL:.034,hoof:.055,thigh:[.1,.24,.16],hock:.07},
    neck:{at:[0,1.12,.42],to:[0,.44,.17],r0:.135,r1:.085},tailAt:[0,1.18,-.6],seatZ:0,
    coat:['#f1ece2','#ddd5c7'],belly2:['#fbf9f4','#efeae1'],mane2:'#f6f2ea',hoof:'#5d544c',muzzle:'#2f2926',antler:'#cfb48c',
    freq:[0,.98,1.65],speed:[0,1.2,2.8],deco:{saddle:'brocade',bridle:'gold',bells:'string'}},
  greenox:{name:'青牛',emoji:'🐃',k:1.03,head:'buffalo',mane:'none',tail:'ox',
    torso:[0,.96,0,.36,.37,.72],chest:[0,.92,.46,.34,.39,.34],rump:[0,1.0,-.46,.34,.35,.34],belly:[0,.82,0,.33,.31,.55],hump:[0,1.24,.36,.19,.12,.24],
    legF:{x:.2,z:.5,y:.72,rU:.11,rL:.068,hoof:.07,thigh:[.13,.22,.17],cloven:1},
    legB:{x:.2,z:-.5,y:.76,rU:.115,rL:.068,hoof:.07,thigh:[.15,.27,.21],hock:.05,cloven:1},
    neck:{at:[0,1.05,.68],to:[0,.06,.3],r0:.28,r1:.21},tailAt:[0,1.2,-.8],seatZ:-.06,
    coat:['#4d5853','#2f3734'],belly2:['#5a6460','#454d4a'],mane2:'#262c2a',hoof:'#2a2624',muzzle:'#3a3f3c',horn:'#8f8574',chevron:'#b9b6a8',
    freq:[0,.72,1.2],speed:[0,1.0,2.1],deco:{saddle:'blanket',bridle:'rope',bells:'bronze'}},
  oxcart:{name:'黄牛车',emoji:'🐂',k:1,head:'ox',mane:'none',tail:'ox',cart:true,
    torso:[0,.95,0,.35,.36,.7],chest:[0,.9,.45,.33,.38,.33],rump:[0,.99,-.45,.33,.34,.33],belly:[0,.82,0,.32,.3,.54],hump:[0,1.22,.38,.17,.11,.22],
    legF:{x:.2,z:.5,y:.72,rU:.105,rL:.066,hoof:.07,thigh:[.12,.21,.16],cloven:1},
    legB:{x:.2,z:-.5,y:.76,rU:.11,rL:.066,hoof:.07,thigh:[.14,.26,.2],hock:.05,cloven:1},
    neck:{at:[0,1.05,.68],to:[0,.06,.28],r0:.27,r1:.2},tailAt:[0,1.19,-.78],seatZ:0,
    coat:['#cd9450','#a8703a'],belly2:['#e0b67f','#cfa06a'],mane2:'#6b4528',hoof:'#3b2e26',muzzle:'#ead8bd',horn:'#d9c9a6',
    freq:[0,.72,1.15],speed:[0,1.0,2.0],deco:{saddle:'cushion',bridle:'rope',bells:'bronze'}}
};
var KINDS=['donkey','oxcart','chestnut','whitehorse','whitedeer','greenox'];

// 装饰选项
var DECO={
  saddle:{none:'无',blanket:'粗布鞍毯',plain:'素皮马鞍',red:'朱红锦鞍',brocade:'青金织锦鞍',cushion:'车凳软垫',canopy:'竹篷+软垫',bench:'素车凳'},
  bridle:{none:'无',rope:'麻绳笼头',leather:'皮革辔头',red:'红缨辔头',gold:'金饰辔头'},
  bells:{none:'无',bronze:'铜项铃',string:'串铃',silver:'银鞍铃（白马专属）'}
};
function decoOptions(kind){var s=SPEC[kind];if(!s)return null;
  var sad=s.cart?['bench','cushion','canopy']:['none','blanket','plain','red','brocade'];
  var bells=['none','bronze','string'];if(s.exclusive)bells=bells.concat(s.exclusive);
  return {saddle:sad,bridle:['none','rope','leather','red','gold'],bells:bells,colors:['saddleColor','bridleColor']};}
function normDeco(kind,d){
  var s=SPEC[kind],o=decoOptions(kind),out={},base=s.deco;d=d||{};
  ['saddle','bridle','bells'].forEach(function(slot){var v=d[slot]!=null?d[slot]:base[slot];
    if(o[slot].indexOf(v)<0){
      if(slot==='bells'&&v==='silver')console.warn('[mounts] 银鞍铃是白马专属，'+kind+' 改用铜项铃');
      else console.warn('[mounts] '+kind+' 不支持 '+slot+'='+v+'，用默认');
      v=slot==='bells'&&v==='silver'?'bronze':base[slot];}
    out[slot]=v;});
  if(d.saddleColor)out.saddleColor=String(d.saddleColor);if(d.bridleColor)out.bridleColor=String(d.bridleColor);
  return out;
}

// ---------------------------------------------------------------- 部件几何
function bodyGeo(pb,s){
  var t=s.torso,c=s.chest,r=s.rump,b=s.belly;
  pb.ell(t[0],t[1],t[2],t[3],t[4],t[5],s.coat,null,14);
  pb.ell(c[0],c[1],c[2],c[3],c[4],c[5],s.coat,null,12);
  pb.ell(r[0],r[1],r[2],r[3],r[4],r[5],s.coat,null,12);
  pb.ell(b[0],b[1],b[2],b[3],b[4],b[5],s.belly2,null,12);
  if(s.hump)pb.ell(s.hump[0],s.hump[1],s.hump[2],s.hump[3],s.hump[4],s.hump[5],s.coat,null,10);
  if(s.stripe){  // 驴背深色十字纹
    pb.box(0,t[1]+t[4]-.012,t[2],.05,.02,t[5]*1.6,s.stripe,[0,0,0],{shade:.1});
    pb.sheet([0,s.chest[1],s.chest[2]+.02],s.chest[3]+.004,s.chest[4]+.004,.05,.55,s.stripe,{shade:.1});
  }
}
function legGeo(pb,s,L,front,lower){
  var U=(L.y-L.hoof)*.52,Lo=L.y-L.hoof-U,dz=front?0:-(L.hock||0),col=s.coat;
  if(!lower){
    pb.ell(0,-.02,0,L.thigh[0],L.thigh[1],L.thigh[2],col,null,9);
    pb.seg([0,-.05,0],[0,-U,dz],L.rU,L.rU*.62,col,7,true);
  }else{
    var sock=s.socks&&!front?s.socks:null,lc=s.coat;
    pb.seg([0,0,0],[0,-Lo*.82,-dz*.3],L.rL*1.15,L.rL,lc,7,false);
    pb.ell(0,0,0,L.rL*1.25,L.rL*1.25,L.rL*1.25,lc,null,7);
    var fet=[0,-Lo*.82,-dz*.3];
    pb.ell(fet[0],fet[1],fet[2]+.008,L.rL*1.2,L.rL*1.15,L.rL*1.3,sock||lc,null,7);
    pb.seg(fet,[0,-Lo,-dz*.15+.01],L.rL,L.rL*1.05,sock||lc,7,false);
    if(sock)pb.seg([0,-Lo*.6,-dz*.2],fet,L.rL*1.03,L.rL*1.06,sock,7,false);
    var hy=-Lo-L.hoof/2,hz=-dz*.15+.015;
    if(L.cloven){for(var sx=-1;sx<=1;sx+=2)pb.cyl(sx*L.rL*.5,hy,hz,L.rL*.55,L.rL*.75,L.hoof,s.hoof,[0,0,0],7);}
    else pb.cyl(0,hy,hz,L.rL*1.05,L.rL*1.4,L.hoof,s.hoof,[.08,0,0],8);
  }
}
function legLen(L,front){var U=(L.y-L.hoof)*.52;return {U:U,dz:front?0:-(L.hock||0)};}

// 颈（局部：原点=肩隆枢轴）
function neckGeo(pb,s){
  var n=s.neck,a=[0,0,0],b=n.to;
  pb.seg(a,b,n.r0,n.r1,s.coat,12,true);
  pb.ell(0,-n.r0*.35,n.r0*.25,n.r0*.95,n.r0*.9,n.r0*.95,s.coat,null,10);   // 颈根填充
  var d=[b[0],b[1],b[2]],L=Math.hypot(d[1],d[2]),dy=d[1]/L,dz=d[2]/L,nb=[0,dz,-dy];   // 颈后法线（朝上后）
  if(s.mane==='flow'){
    for(var i=0;i<8;i++){var t=i/7,p=lerp3(a,b,.05+t*.92),r=n.r0+(n.r1-n.r0)*t;
      pb.ell(.035,p[1]+nb[1]*r*.75,p[2]+nb[2]*r*.75,.05,.085,.07,s.mane2,[.5,0,.18],7);
      if(i%2)pb.ell(.075,p[1]+nb[1]*r*.4,p[2]+nb[2]*r*.4-.01,.035,.1,.05,s.mane2,[.3,0,.35],7);}
  }else if(s.mane==='brush'){
    for(var j=0;j<9;j++){var t2=j/8,p2=lerp3(a,b,.02+t2*.95),r2=n.r0+(n.r1-n.r0)*t2;
      pb.box(0,p2[1]+nb[1]*(r2+.02),p2[2]+nb[2]*(r2+.02),.045,.07,.07,s.mane2,[Math.atan2(dz,dy)*0-(.6-t2*.3),0,0],{shade:.15});}
  }
  if(s.head==='ox'||s.head==='buffalo'){  // 垂皮
    pb.ell(0,-n.r0*.55,n.r0*.55,n.r0*.42,n.r0*.75,n.r0*.75,s.belly2,null,8);
    if(s.chevron)pb.ell(0,-n.r0*.22,n.r0*.92,n.r0*.6,n.r0*.14,n.r0*.2,s.chevron,[.5,0,0],8);
  }
  if(s.head==='deer')pb.ell(0,n.r0*.3,n.r0*.7,n.r0*.7,n.r0*.6,n.r0*.35,'#fbf9f4',[-.6,0,0],8);   // 喉部浅色
}
// 头部尺寸（局部：原点=枕骨，与颈端重合）；a→b 为面部轴线
var HEAD={
  horse:{skull:[0,-.02,.06,.115,.125,.145],a:[0,-.05,.1],b:[0,-.21,.36],ra:.1,rb:.074,eye:[.1,-.01,.11],ear:[.06,.11,.0]},
  donkey:{skull:[0,-.02,.05,.13,.135,.15],a:[0,-.05,.09],b:[0,-.23,.33],ra:.112,rb:.09,eye:[.112,-.01,.1],ear:[.065,.1,-.01]},
  deer:{skull:[0,0,.04,.088,.092,.1],a:[0,-.02,.08],b:[0,-.13,.25],ra:.075,rb:.045,eye:[.078,.0,.075],ear:[.07,.06,-.02]},
  ox:{skull:[0,-.02,.06,.155,.14,.15],a:[0,-.05,.08],b:[0,-.21,.27],ra:.14,rb:.12,eye:[.14,0,.1],ear:[.17,-.01,0]},
  buffalo:{skull:[0,-.02,.05,.16,.14,.16],a:[0,-.06,.08],b:[0,-.25,.3],ra:.145,rb:.115,eye:[.145,-.01,.1],ear:[.18,-.03,-.01]}
};
function headGeo(pb,s){
  var h=HEAD[s.head],sk=h.skull,co=s.coat;
  pb.ell(sk[0],sk[1],sk[2],sk[3],sk[4],sk[5],co,null,12);
  pb.seg(h.a,h.b,h.ra,h.rb,co,12,false);
  pb.ell(h.a[0],h.a[1],h.a[2],h.ra*1.02,h.ra,h.ra*1.05,co,null,10);
  var mz=s.muzzle,b=h.b;
  // 眼（深色 + 高光）
  for(var sx=-1;sx<=1;sx+=2){var e=h.eye,er=s.head==='deer'?.028:.024;
    pb.ell(sx*e[0],e[1],e[2],er*.7,er,er*1.1,C.eye,null,8,{shade:.05});
    pb.ell(sx*(e[0]+er*.55),e[1]+er*.4,e[2]+er*.35,er*.22,er*.22,er*.22,C.eyeHi,null,6,{flat:1});
    if(s.head==='donkey')pb.ell(sx*(e[0]-.004),e[1],e[2],er*1.15,er*1.5,er*1.6,'#d8cfbf',null,8);}
  if(s.head==='horse'||s.head==='donkey'){
    pb.ell(b[0],b[1]-.005,b[2]-.005,h.rb*1.08,h.rb*1.0,h.rb*1.18,mz,null,12);
    pb.ell(0,b[1]-.055,b[2]-.04,h.rb*.8,h.rb*.45,h.rb*.9,mz,null,8);              // 下唇
    pb.ell(0,-.1,.02,h.ra*.95,h.ra*1.05,h.ra*1.05,co,null,10);                  // 腮
    for(var n=-1;n<=1;n+=2)pb.ell(n*.042,b[1]+.012,b[2]+h.rb*1.05,.016,.022,.01,C.nose,null,6,{shade:0});
    if(s.head==='horse'){
      for(var q=-1;q<=1;q+=2){pb.cone(q*h.ear[0],h.ear[1]+.06,h.ear[2],.036,.13,co,[-.25,0,-q*.22],7);
        pb.cone(q*h.ear[0],h.ear[1]+.055,h.ear[2]+.012,.022,.09,'#2b1d16',[-.25,0,-q*.22],6,{shade:0});}
      pb.ell(0,.08,.1,.045,.045,.09,s.mane2,[-.6,0,.15],8);pb.ell(.02,.03,.16,.03,.03,.07,s.mane2,[-.9,0,.2],7);  // 额发
      if(s.blaze)pb.seg([0,.04,.15],[0,-.15,.395],.03,.026,s.blaze,8,true,{shade:.1});
    }else{
      for(var q2=-1;q2<=1;q2+=2){var e0=[q2*h.ear[0],h.ear[1],h.ear[2]],e1=[q2*.13,.38,-.07];
        pb.seg(e0,e1,.042,.03,co,8,true);pb.ell(e1[0],e1[1]+.005,e1[2],.03,.04,.03,'#3a312b',null,6);
        pb.seg(lerp3(e0,e1,.1),lerp3(e0,e1,.85),.026,.018,'#e8d9cc',6,false,{shade:.05});
      }
      pb.ell(0,.09,.07,.04,.05,.05,s.mane2,[-.4,0,0],7);
    }
  }else if(s.head==='deer'){
    pb.ell(b[0],b[1]-.006,b[2]+.005,.034,.028,.026,mz,null,8,{shade:.1});
    pb.ell(0,b[1]-.012,b[2]-.03,h.rb*.95,h.rb*.65,h.rb*1.0,'#fbf9f4',null,8);
    for(var q3=-1;q3<=1;q3+=2){pb.ell(q3*.115,.07,-.015,.03,.085,.046,co,[0,-q3*.2,-q3*1.0],8);
      pb.ell(q3*.12,.071,-.002,.018,.06,.024,'#e7c9be',[0,-q3*.2,-q3*1.0],6,{shade:0});
      var A=s.antler,x=q3;
      pb.chain([[x*.04,.08,-.01],[x*.1,.21,-.04],[x*.15,.34,-.03],[x*.17,.47,.01]],.022,.012,A,7);
      pb.chain([[x*.09,.18,-.035],[x*.065,.27,.06]],.015,.009,A,6);
      pb.chain([[x*.14,.31,-.03],[x*.23,.4,-.07]],.014,.008,A,6);
      pb.chain([[x*.165,.44,0],[x*.12,.54,.04]],.012,.007,A,6);
      pb.ell(x*.04,.08,-.01,.03,.02,.03,'#8f7a5c',null,6);   // 角座
    }
  }else{ // ox / buffalo
    pb.ell(b[0],b[1]-.01,b[2]+.01,h.rb*1.1,h.rb*.85,h.rb*.85,mz,null,12);
    pb.ell(0,b[1]+.005,b[2]+h.rb*.75,h.rb*.68,h.rb*.44,h.rb*.26,C.nose,null,8,{shade:.05});
    for(var n2=-1;n2<=1;n2+=2)pb.ell(n2*.04,b[1]+.01,b[2]+h.rb*.97,.018,.014,.008,'#1c1512',null,6,{shade:0});
    for(var q4=-1;q4<=1;q4+=2){
      pb.ell(q4*h.ear[0],h.ear[1],h.ear[2],.1,.035,.055,co,[0,0,-q4*.3],8);
      pb.ell(q4*(h.ear[0]+.01),h.ear[1]-.004,h.ear[2]+.012,.07,.02,.035,'#e2bfa8',[0,0,-q4*.3],6,{shade:0});
      var H=s.horn,x2=q4;
      if(s.head==='ox')pb.chain([[x2*.1,.09,.03],[x2*.2,.13,.04],[x2*.27,.21,.07],[x2*.26,.29,.12]],.045,.012,[H,'#a99878'],8);
      else pb.chain([[x2*.11,.07,.01],[x2*.27,.11,-.04],[x2*.4,.14,-.16],[x2*.42,.21,-.3],[x2*.34,.28,-.38]],.062,.012,[H,'#6b6355'],8);
    }
    pb.ell(0,.11,.04,.08,.05,.06,s.mane2,null,7);  // 顶毛
  }
}
function tailGeo(pb,s){
  var m=s.mane2;
  if(s.tail==='horse'){
    pb.seg([0,0,0],[0,-.09,-.12],.055,.045,s.coat,8,true);
    pb.ell(0,-.18,-.17,.07,.13,.07,m,[.5,0,0],9);
    pb.chain([[0,-.12,-.14],[0,-.34,-.2],[0,-.55,-.2],[0,-.7,-.16]],.075,.03,m,8);
    pb.ell(.025,-.45,-.22,.05,.17,.05,m,[.15,0,.1],7);pb.ell(-.03,-.5,-.18,.045,.16,.045,m,[.05,0,-.1],7);
  }else if(s.tail==='tuft'||s.tail==='ox'){
    var L=s.tail==='ox'?.62:.42;
    pb.chain([[0,0,0],[0,-.08,-.07],[0,-L*.6,-.1],[0,-L,-.08]],.04,.022,s.coat,7);
    pb.ell(0,-L-.07,-.08,.045,.1,.045,m,null,8);pb.ell(0,-L-.13,-.08,.03,.05,.03,m,null,6);
  }else{ // deer
    pb.ell(0,-.04,-.04,.055,.09,.04,'#fbf9f4',[.5,0,0],8);
  }
}

// ---------------------------------------------------------------- 装饰几何
function seatSection(s){var t=s.torso,z=s.seatZ,f=Math.sqrt(Math.max(.05,1-Math.pow((z-t[2])/t[5],2)));return {cy:t[1],cz:z,rx:t[3]*f,ry:t[4]*f,top:t[1]+t[4]*f};}
function saddleGeo(pb,s,style,col){
  var q=seatSection(s),c=[0,q.cy,q.cz];
  if(style==='blanket'){
    var b=col||C.cloth;
    pb.sheet(c,q.rx+.014,q.ry+.014,.52,1.2,b,{shade:.3});
    for(var i=-1;i<=1;i++)pb.sheet([0,q.cy,q.cz+i*.16],q.rx+.018,q.ry+.018,.045,1.2,C.clothStripe,{shade:.3});
    pb.ell(0,q.top+.04,q.cz,.17,.045,.16,[ '#d9b98a','#b08d5e'],null,10);           // 软垫
    pb.chain([[-.2,q.top+.05,q.cz-.2],[.2,q.top+.05,q.cz-.2]],.035,.035,'#a3804f',8);   // 后侧卷包
    pb.sheet(c,q.rx+.006,q.ry+.006,.05,2.55,C.ropeDark,{shade:.2});                    // 肚带
  }else if(style==='plain'||style==='red'||style==='brocade'){
    var blanketCol=style==='plain'?(col||'#7c5a3a'):style==='red'?(col||C.red):(col||C.teal),
        trim=style==='plain'?'#4d3523':C.gold,seatC=style==='plain'?C.leather:style==='red'?'#5b2a1c':C.leatherDark;
    pb.sheet(c,q.rx+.012,q.ry+.012,.56,1.12,blanketCol,{shade:.3});
    pb.sheet([0,q.cy,q.cz+.27],q.rx+.016,q.ry+.016,.035,1.12,trim,{shade:.25});
    pb.sheet([0,q.cy,q.cz-.27],q.rx+.016,q.ry+.016,.035,1.12,trim,{shade:.25});
    for(var sd=-1;sd<=1;sd+=2){   // 下摆边
      var ang=1.12,hx=Math.sin(ang)*(q.rx+.016),hy=q.cy+Math.cos(ang)*(q.ry+.016);
      pb.seg([sd*hx,hy,q.cz-.28],[sd*hx,hy,q.cz+.28],.012,.012,trim,6);
      if(style!=='plain'){pb.cone(sd*hx,hy-.05,q.cz+.27,.022,.09,trim,[PI,0,0],6);pb.cone(sd*hx,hy-.05,q.cz-.27,.022,.09,trim,[PI,0,0],6);}
      if(style==='brocade')for(var k=0;k<3;k++)pb.ell(sd*(Math.sin(.75)*(q.rx+.017)),q.cy+Math.cos(.75)*(q.ry+.017),q.cz-.16+k*.16,.01,.04,.04,C.gold,[0,0,-sd*.75],6,{shade:.1});
    }
    pb.sheet([0,q.cy+.02,q.cz],q.rx+.03,q.ry+.012,.38,.72,seatC,{shade:.35});        // 鞍座
    pb.ell(0,q.top+.055,q.cz+.17,.075,.065,.05,style==='plain'?C.leather:C.gold,null,9);   // 前鞍桥
    pb.ell(0,q.top+.05,q.cz-.17,.13,.055,.045,seatC,null,9);                          // 后鞍桥
    for(var s2=-1;s2<=1;s2+=2){
      var sx=s2*(q.rx+.03),sy=q.cy+q.ry*.25;
      pb.box(sx,sy-.18,q.cz+.04,.012,.36,.03,C.leatherDark,[0,0,0],{shade:.1});
      pb.tor(sx,sy-.38,q.cz+.04,.045,.01,style==='plain'?C.iron:C.gold,[0,PI/2,0],[1,.8,1]);
    }
    pb.sheet(c,q.rx+.006,q.ry+.006,.05,2.6,C.leatherDark,{shade:.2});
  }
  return q;
}
function cartDecoGeo(pb,style,col){
  var cc=col||C.red;
  for(var sx=-1;sx<=1;sx+=2){pb.ell(sx*CART.seatX,CART.benchY+.025,CART.benchZ+.02,.21,.04,.16,[cc,'#7a1e1a'],null,10);pb.ell(sx*CART.seatX,CART.benchY+.065,CART.benchZ+.02,.03,.012,.03,C.gold,null,6);}
  if(style==='canopy'){   // 竹篷：拱形面片 + 4 道篷骨（Torus 弧居中向上）
    var z0=CART.bedZ1+.43;pb.sheet([0,1.02,z0],.66,.78,.82,1.42,[C.bamboo,C.bambooDark],{shade:.35});
    for(var i=0;i<4;i++)pb.tor(0,1.02,z0+.38-i*.25,1,.016,C.bambooDark,[0,0,PI/2-1.42],[.675,.795,1],2.84);
  }
}
function bridleGeo(pb,s,style,col){
  var h=HEAD[s.head],strap=col||(style==='rope'?C.rope:style==='leather'?C.leather:style==='red'?C.red:C.leatherDark),
      th=style==='rope'?.014:.011,metal=style==='gold'||style==='red'?C.gold:C.iron;
  var dir=[h.b[0]-h.a[0],h.b[1]-h.a[1],h.b[2]-h.a[2]],L=Math.hypot(dir[1],dir[2]);
  var bovine=s.head==='ox'||s.head==='buffalo';
  var tN=bovine?.55:.62,pN=lerp3(h.a,h.b,tN),rN=h.ra+(h.rb-h.ra)*tN+.008;
  pb.ring(pN,dir,rN,th,strap,[1,1.0]);                                            // 鼻革
  var crown=[0,h.skull[1]+h.skull[4]*.95,h.skull[2]-.02];
  for(var sx=-1;sx<=1;sx+=2){
    var cheekA=[sx*(rN*.92),pN[1]+.01,pN[2]],cheekB=[sx*(h.skull[3]*.98),crown[1]-.03,crown[2]];
    pb.seg(cheekA,cheekB,th,th,strap,5);pb.seg(cheekB,[0,crown[1]+.004,crown[2]],th,th,strap,5);
    pb.seg([sx*h.skull[3]*.92,h.skull[1]+h.skull[4]*.45,h.skull[2]+h.skull[5]*.6],[0,h.skull[1]+h.skull[4]*.62,h.skull[2]+h.skull[5]*.95],th*.9,th*.9,strap,5);   // 额带
    if(!bovine){var bit=lerp3(h.a,h.b,.92);pb.tor(sx*(h.rb*.95),bit[1]-.02,bit[2],.022,.006,metal,[0,PI/2,0]);}
    if(style==='gold'||style==='red')pb.ell(sx*(rN*.95),pN[1]+.012,pN[2],.016,.016,.016,C.gold,null,6,{flat:1});
  }
  if(bovine){var nr=[0,h.b[1]-.03,h.b[2]+h.rb*.82];pb.tor(nr[0],nr[1],nr[2],.032,.007,style==='rope'?C.bronze:metal,[0,PI/2,0]);}
  if(style==='red'){   // 红缨 / 大红花
    var top=[0,h.skull[1]+h.skull[4]*.9,h.skull[2]+h.skull[5]*.55];
    if(bovine){for(var p=0;p<6;p++){var a=p/6*TAU;pb.ell(Math.cos(a)*.05,top[1]+.03+Math.sin(a)*.05,top[2]+.07,.04,.04,.02,C.red,null,7);}
      pb.ell(0,top[1]+.03,top[2]+.09,.025,.025,.02,C.gold,null,6);}
    else{pb.cone(0,top[1]+.06,top[2]+.02,.055,.12,[ '#d8463a',C.redDeep],[-.35,0,0],9);pb.ell(0,top[1]+.02,top[2]+.01,.025,.02,.025,C.gold,null,6);}
  }
  if(style==='gold')pb.ell(0,h.skull[1]+h.skull[4]*.6,h.skull[2]+h.skull[5]*.97,.03,.036,.012,C.gold,null,8,{flat:1});
}
// 缰绳：在颈局部坐标里，从衔铁连到鞍桥/车夫手
function reinsGeo(pb,s,style,col,target){
  var h=HEAD[s.head],n=s.neck,strap=col||(style==='rope'?C.rope:style==='leather'?C.leather:style==='red'?C.red:C.leatherDark);
  var bovine=s.head==='ox'||s.head==='buffalo',bit=bovine?[0,h.b[1]-.06,h.b[2]+h.rb*.82]:lerp3(h.a,h.b,.92);
  for(var sx=-1;sx<=1;sx+=2){
    var p0=[n.to[0]+(bovine?0:sx*h.rb*.95),n.to[1]+bit[1]-.02,n.to[2]+bit[2]],
        p2=[target[0]+sx*(bovine?.04:.07),target[1],target[2]],
        p1=[(p0[0]+p2[0])/2,Math.min(p0[1],p2[1])-(bovine?.18:.08),(p0[2]+p2[2])/2];
    pb.seg(p0,p1,.009,.009,strap,5,true);pb.seg(p1,p2,.009,.009,strap,5,true);
  }
}
function bellGeo(pb,r,col,clap){  // 一只铃：原点=挂点，向下
  pb.ell(0,-.012,0,r*.25,r*.25,r*.25,col,null,5);
  pb.cyl(0,-r*.75,0,r*.45,r,r*1.2,col,[0,0,0],8);
  pb.ell(0,-r*.2,0,r*.46,r*.35,r*.46,col,null,7);
  pb.tor(0,-r*1.35,0,r*.95,r*.12,col,[PI/2,0,0],null,null,null,[3,10]);
  pb.ell(0,-r*1.45,0,r*.3,r*.3,r*.3,clap||'#4a3a24',null,5);
}
function collarGeo(pb,s,style){
  var n=s.neck,t=.24,p=lerp3([0,0,0],n.to,t),r=n.r0+(n.r1-n.r0)*t+.012,col=style==='string'?C.red:C.leatherDark;
  pb.ring(p,n.to,r,.018,col);
  return p;
}

// ---------------------------------------------------------------- 牛车
var CART={bedZ0:-1.5,bedZ1:-3.0,bedW:.6,bedY:.68,wheelR:.5,wheelX:.74,wheelZ:-2.35,benchZ:-1.47,seatZ:-1.35,seatX:.28,benchY:.97,yokeLocal:[0,.27,.1]};
function cartGeo(pb,s){
  var c=CART,zc=(c.bedZ0+c.bedZ1)/2,len=c.bedZ0-c.bedZ1,W=c.wheelR;
  pb.box(0,c.bedY,zc,c.bedW*2,.07,len,[C.woodLight,C.wood]);
  for(var i=0;i<6;i++)pb.box(0,c.bedY+.037,c.bedZ1+.12+i*.25,c.bedW*2-.04,.006,.02,C.woodDark,null,{shade:.05});
  for(var sx=-1;sx<=1;sx+=2){
    pb.box(sx*c.bedW,c.bedY+.14,zc-.08,.05,.2,len-.2,C.wood);
    for(var p=0;p<5;p++)pb.box(sx*c.bedW,c.bedY+.11,c.bedZ1+.1+p*(len-.25)/4,.06,.26,.06,C.woodDark);
    pb.box(sx*c.bedW,c.bedY+.255,zc-.08,.07,.035,len-.16,C.woodDark);
    // 车辕：从车厢前端到轭端
    var yk=[sx*.5,s.neck.at[1]+c.yokeLocal[1],s.neck.at[2]+c.yokeLocal[2]];
    pb.seg([sx*.5,c.bedY-.06,c.bedZ0-.45],[yk[0],yk[1]-.02,yk[2]-.03],.032,.026,[C.wood,C.woodDark],7,true);
  }
  pb.box(0,c.bedY+.11,c.bedZ1+.03,c.bedW*2,.22,.05,C.wood);       // 后挡板
  pb.box(0,c.bedY+.1,c.bedZ0-.02,c.bedW*2,.2,.05,C.wood);         // 前挡板
  // 车凳：架在前挡板上、向前探出（乘客坐在车头，双腿垂在车前，和传统牛车一样）
  pb.box(0,c.benchY-.035,c.benchZ,1.16,.06,.34,[C.woodLight,C.wood]);
  for(var lx=-1;lx<=1;lx+=2){pb.box(lx*.5,(c.benchY+c.bedY)/2,c.benchZ-.12,.05,c.benchY-c.bedY-.03,.05,C.woodDark);
    pb.seg([lx*.5,c.bedY+.2,c.bedZ0+.01],[lx*.5,c.benchY-.07,c.benchZ+.13],.018,.018,C.woodDark,5);}   // 斜撑
  pb.seg([-c.wheelX-.03,W,c.wheelZ],[c.wheelX+.03,W,c.wheelZ],.035,.035,C.iron,8);  // 车轴
  pb.box(0,W+.07,c.wheelZ,1.2,.1,.12,C.woodDark);                  // 轴托
}
function wheelGeo(pb){
  var R=CART.wheelR;
  pb.tor(0,0,0,R-.03,.04,[C.wood,C.woodDark],[0,PI/2,0],[1,1,1.4],null,null,[5,22]);
  pb.tor(0,0,0,R-.005,.018,C.iron,[0,PI/2,0],[1,1,2.6],null,null,[3,22]);
  pb.cyl(0,0,0,.07,.07,.13,C.woodDark,[0,0,PI/2],10);
  pb.cyl(0,0,0,.035,.035,.16,C.iron,[0,0,PI/2],8);
  for(var i=0;i<10;i++){var a=i/10*TAU;pb.box(0,Math.cos(a)*R*.5,Math.sin(a)*R*.5,.03,R*.86,.04,C.wood,[a,0,0]);}
}
function yokeGeo(pb,s){
  var y=CART.yokeLocal,n=s.neck;
  pb.chain([[-.55,y[1]+.06,y[2]],[-.3,y[1]+.01,y[2]],[0,y[1],y[2]],[.3,y[1]+.01,y[2]],[.55,y[1]+.06,y[2]]],.035,.035,[C.woodLight,C.wood],8);
  for(var sx=-1;sx<=1;sx+=2)pb.seg([sx*(n.r0*.9+.03),y[1],y[2]],[sx*(n.r0*.9+.02),y[1]-.32,y[2]],.02,.018,C.woodDark,6,true);
}

// ---------------------------------------------------------------- 构建
var seq=0;
function build(kind,deco){
  var s=SPEC[kind];if(!s){console.warn('[mounts] 未知坐骑 '+kind);return null;}
  var k=s.k,M_=mats(),root=new T.Group();root.name='tg-mount-'+kind;
  var u=root.userData={tgMount:true,kind:kind,info:info[kind],k:k,phase:(seq++*1.93)%TAU,riders:[],seats:[],legs:[],bellPivots:[],decoObjs:[],
    anim:{ph:0,lt:null,amp:0,trot:0,wheel:0,gait:0}};
  var rig=u.rig=grp(root,0,0,0,'rig');
  u.body=mesh(rig,cached(kind+'|body',k,function(pb){bodyGeo(pb,s);}),M_.coat,'body');
  // 腿：FL FR BL BR
  [['F',-1],['F',1],['B',-1],['B',1]].forEach(function(d){
    var L=d[0]==='F'?s.legF:s.legB,front=d[0]==='F',ll=legLen(L,front);
    var hip=grp(rig,d[1]*L.x*k,L.y*k,L.z*k,'hip'+d[0]+(d[1]<0?'L':'R'));
    mesh(hip,cached(kind+'|legU'+d[0],k,function(pb){legGeo(pb,s,L,front,false);}),M_.coat);
    var knee=grp(hip,0,-ll.U*k,ll.dz*k,'knee');
    mesh(knee,cached(kind+'|legL'+d[0],k,function(pb){legGeo(pb,s,L,front,true);}),M_.coat);
    u.legs.push({hip:hip,knee:knee,front:front});
  });
  var neck=u.neck=grp(rig,s.neck.at[0]*k,s.neck.at[1]*k,s.neck.at[2]*k,'neck');
  mesh(neck,cached(kind+'|neck',k,function(pb){neckGeo(pb,s);}),M_.coat);
  var head=u.head=grp(neck,s.neck.to[0]*k,s.neck.to[1]*k,s.neck.to[2]*k,'head');
  mesh(head,cached(kind+'|head',k,function(pb){headGeo(pb,s);}),M_.coat);
  var tail=u.tail=grp(rig,s.tailAt[0]*k,s.tailAt[1]*k,s.tailAt[2]*k,'tail');
  mesh(tail,cached(kind+'|tail',k,function(pb){tailGeo(pb,s);}),M_.coat);
  if(s.cart){
    var cart=u.cart=grp(root,0,0,0,'cart');
    mesh(cart,cached('cart|'+kind,1,function(pb){cartGeo(pb,s);}),woodMat(),'cartBody');
    u.wheels=[-1,1].map(function(sx){var w=grp(cart,sx*CART.wheelX,CART.wheelR,CART.wheelZ,'wheel');mesh(w,cached('cart|wheel',1,wheelGeo),woodMat());return w;});
    mesh(neck,cached(kind+'|yoke',k,function(pb){yokeGeo(pb,s);}),M_.gloss,'yoke');
    for(var i=0;i<2;i++){var seat=grp(cart,(i?1:-1)*CART.seatX,CART.benchY,CART.seatZ,'seat'+i);seat.userData={seatIndex:i,pose:'bench'};u.seats.push(seat);}
  }else{
    var seat0=grp(rig,0,0,s.seatZ*k,'seat0');seat0.userData={seatIndex:0,pose:'straddle',bodyRx:0};u.seats.push(seat0);
  }
  setDeco(root,deco);
  return root;
}
function syncReins(u){var held=!!(u.riders&&u.riders.some(Boolean))||!u.reinsLoose;if(u.reinsHeld)u.reinsHeld.visible=held;if(u.reinsLoose)u.reinsLoose.visible=!held;}
function clearDeco(u){u.reinsHeld=u.reinsLoose=null;for(var i=0;i<u.decoObjs.length;i++){var o=u.decoObjs[i];if(o.parent)o.parent.remove(o);}u.decoObjs.length=0;u.bellPivots.length=0;}
function setDeco(root,deco){
  var u=root&&root.userData;if(!u||!u.tgMount)return null;
  var kind=u.kind,s=SPEC[kind],k=u.k,M_=mats(),d=normDeco(kind,ext(u.deco||{},deco||{}));
  if(deco&&deco.saddleColor===null)delete d.saddleColor;if(deco&&deco.bridleColor===null)delete d.bridleColor;
  u.deco=d;clearDeco(u);
  function add(parent,key,kk,make,mat,name){var o=mesh(parent,cached(key,kk,make),mat||M_.coat,name);u.decoObjs.push(o);return o;}
  // 鞍
  var pommel;
  if(s.cart){
    if(d.saddle!=='bench')add(u.cart,'cartdeco|'+d.saddle+'|'+(d.saddleColor||''),1,function(pb){cartDecoGeo(pb,d.saddle,d.saddleColor);},M_.coat,'cartDeco');
    var sy=CART.benchY+(d.saddle==='bench'?0:.05);u.seats.forEach(function(st){st.position.y=sy;});
  }else{
    var q=seatSection(s),lift=d.saddle==='none'?.0:d.saddle==='blanket'?.075:.075;
    if(d.saddle!=='none')add(u.rig,kind+'|saddle|'+d.saddle+'|'+(d.saddleColor||''),k,function(pb){saddleGeo(pb,s,d.saddle,d.saddleColor);},d.saddle==='blanket'?M_.coat:M_.gloss,'saddle');
    var st0=u.seats[0];st0.position.y=(q.top+lift)*k;st0.userData.bodyRx=q.rx*k+.035;st0.userData.saddle=d.saddle;
    pommel=[0,q.top+(d.saddle==='none'?.02:.08),q.cz+(d.saddle==='none'?.3:.17)];
  }
  // 辔头 + 缰绳
  if(d.bridle!=='none'){
    add(u.head,kind+'|bridle|'+d.bridle+'|'+(d.bridleColor||''),k,function(pb){bridleGeo(pb,s,d.bridle,d.bridleColor);},M_.gloss,'bridle');
    var target;
    if(s.cart)target=[-CART.seatX/k,(CART.benchY+.3)/k,(CART.seatZ+.3)/k];else target=pommel;
    var tl=[target[0]-s.neck.at[0],target[1]-s.neck.at[1],target[2]-s.neck.at[2]];
    u.reinsHeld=add(u.neck,kind+'|reins|'+d.bridle+'|'+(d.bridleColor||'')+'|'+d.saddle,k,function(pb){reinsGeo(pb,s,d.bridle,d.bridleColor,tl);},M_.gloss,'reinsHeld');
    if(!s.cart){   // 无人骑时缰绳搭在颈根（随颈运动，吃草时不穿模）
      var n0=s.neck,lp=[0,n0.r0*.92,-n0.r0*.05];
      u.reinsLoose=add(u.neck,kind+'|reinsLoose|'+d.bridle+'|'+(d.bridleColor||''),k,function(pb){reinsGeo(pb,s,d.bridle,d.bridleColor,lp);},M_.gloss,'reinsLoose');
    }else u.reinsLoose=null;
    syncReins(u);
  }
  // 铃
  if(d.bells==='bronze'||d.bells==='string'){
    var cp=null;
    add(u.neck,kind+'|collar|'+d.bells,k,function(pb){cp=collarGeo(pb,s,d.bells);},M_.gloss,'collar');
    var n=s.neck,t=.24,p=lerp3([0,0,0],n.to,t),r=n.r0+(n.r1-n.r0)*t;
    var piv=grp(u.neck,p[0]*k,(p[1]-r*.92)*k,(p[2]+r*.35)*k,'bellPivot');u.decoObjs.push(piv);u.bellPivots.push(piv);
    if(d.bells==='bronze')add(piv,'bell|bronze',1,function(pb){bellGeo(pb,.055*Math.max(.85,k),C.bronze);},M_.metal);
    else add(piv,'bell|string|'+kind,1,function(pb){var rr=r*k;for(var i=-2;i<=2;i++){var a=i*.42,x=Math.sin(a)*rr*.9,z=(Math.cos(a)-1)*rr*.55;
      pb.seg([0,.01,0],[x,-.025,z],.006,.006,C.red,4);pb.sub(function(t){bellGeo(t,.028,C.gold);},x,-.025,z);}},M_.metal);
  }else if(d.bells==='silver'){
    var q2=seatSection(s);
    [-1,1].forEach(function(sx){
      var a=1.0,px=sx*(Math.sin(a)*(q2.rx+.02)),py=q2.cy+Math.cos(a)*(q2.ry+.02);
      var pv=grp(u.rig,px*k,py*k,(q2.cz-.26)*k,'bellPivot');u.decoObjs.push(pv);u.bellPivots.push(pv);
      add(pv,'bell|silverSide',1,function(pb){pb.seg([0,0,0],[0,-.12,0],.007,.007,C.red,4,true);
        for(var i=0;i<3;i++)pb.sub(function(t){bellGeo(t,.032-i*.003,C.silver,'#6d6a64');},0,-.12-i*.08,0);
        pb.cone(0,-.4,0,.018,.07,C.red,[PI,0,0],6);},M_.metal);
    });
    var ch=s.chest,by=ch[1]+.04;   // 胸带：水平半圈绕过前胸
    add(u.rig,kind+'|breast',k,function(pb){pb.tor(ch[0],by,ch[2],1,.022,C.red,[PI/2,0,0],[ch[3]+.012,ch[5]+.012,1],PI);
      for(var i=0;i<5;i++){var a=(i+1)/6*PI;pb.ell(Math.cos(a)*(ch[3]+.03),by,ch[2]+Math.sin(a)*(ch[5]+.03),.014,.014,.014,C.gold,null,6,{flat:1});}},M_.gloss,'breastplate');
    var pv2=grp(u.rig,0,(by-.02)*k,(ch[2]+ch[5]+.03)*k,'bellPivot');u.decoObjs.push(pv2);u.bellPivots.push(pv2);
    add(pv2,'bell|silverChest',1,function(pb){for(var i=-1;i<=1;i++)pb.sub(function(t){bellGeo(t,i?.03:.04,C.silver,'#6d6a64');},i*.085,-.01,-Math.abs(i)*.035);
      pb.ell(0,0,0,.03,.03,.02,C.gold,null,8,{flat:1});},M_.metal);
  }
  return d;
}

// ---------------------------------------------------------------- 动画（无分配；相位在 userData.anim 里累加，变速不跳帧）
var WALK_OFF=[.25,.75,0,.5],TROT_OFF=[0,.5,.5,0];   // FL FR BL BR：慢步=四拍侧对序；快步=对角两拍
function sm(x){return x<=0?0:x>=1?1:x*x*(3-2*x);}
function animate(root,state,t,speed){
  var u=root&&root.userData;if(!u||!u.tgMount)return;
  var s=SPEC[u.kind],A=u.anim,k=u.k;
  if(speed==null)speed=1;if(!(speed>=0))speed=0;
  var first=A.lt==null,dt=first?0:(t-A.lt)/1000;A.lt=t;if(!(dt>0))dt=0;else if(dt>.1)dt=.1;
  // 首帧直接到位；之后 dt=0（同帧二次调用/时间未前进）保持上一帧混合值，不跳变（S1-10 / S1-6 兜底）
  var gait=state==='trot'?2:state==='walk'?1:0,f=first?1:Math.min(1,dt*6);
  A.amp+=((gait?1:0)-A.amp)*f;A.trot+=((gait===2?1:0)-A.trot)*f;
  if(gait)A.gait=gait;
  var freq=(s.freq[1]+(s.freq[2]-s.freq[1])*A.trot)*speed;
  A.ph=(A.ph+dt*freq)%1000;
  var amp=A.amp,tr=A.trot,ph=A.ph,ts=t*.001,P=u.phase,ridden=u.riders.length&&u.riders.some(Boolean);
  // 腿
  var swing=(.3+.18*tr)*amp,flex=(.55+.4*tr)*amp;
  for(var i=0;i<4;i++){var L=u.legs[i],off=WALK_OFF[i]+(TROT_OFF[i]-WALK_OFF[i])*tr,ang=TAU*(ph+off),sn=Math.sin(ang),cs=Math.cos(ang);
    L.hip.rotation.x=-swing*sn;L.knee.rotation.x=flex*Math.max(0,cs)*(L.front?1:.75)+(L.front?0:-.08*amp*sn);}
  // 身体：起伏 / 俯仰 / 呼吸
  var rig=u.rig,beat=TAU*ph*2;
  var bob=(1-tr)*.012*Math.cos(beat)+tr*.034*Math.abs(Math.sin(TAU*ph))-tr*.02;
  rig.position.y=bob*amp*k+Math.sin(ts*1.6+P)*.003*k*(1-amp);
  rig.rotation.x=Math.sin(beat+.6)*(.012+.01*tr)*amp;
  rig.rotation.z=Math.sin(TAU*ph+P*0)*.012*amp*(1-tr);
  // 颈 / 头：走路点头，待机吃草（无人骑时）与张望
  var graze=0;
  if(!ridden&&!s.cart&&amp<.05){var cyc=((ts+P*3)%14)/14;graze=sm((cyc-.55)/.08)*(1-sm((cyc-.85)/.08));}
  var gz=s.head==='ox'||s.head==='buffalo'?.55:s.head==='deer'?1.0:.95;
  u.neck.rotation.x=Math.sin(beat+.4)*(.055-.02*tr)*amp+graze*gz+(1-amp)*Math.sin(ts*.7+P)*.03;
  u.neck.rotation.y=(1-amp)*(1-graze)*Math.sin(ts*.31+P*2)*.22;
  u.head.rotation.x=-Math.sin(beat+.9)*.04*amp+graze*.35;
  u.head.rotation.z=(1-amp)*Math.sin(ts*.53+P)*.06;
  // 尾
  u.tail.rotation.z=Math.sin(ts*(2.1+1.5*amp)+P)*(.22-.1*amp)+(amp*Math.sin(TAU*ph)*.08);
  u.tail.rotation.x=-.1*amp-.25*tr*amp+Math.sin(ts*1.3+P)*.04;
  // 铃：钟摆
  for(var b=0;b<u.bellPivots.length;b++){var bp=u.bellPivots[b];
    bp.rotation.x=-Math.sin(beat+1.2+b)*.25*amp-(.12*tr*amp)+Math.sin(ts*1.9+b+P)*.04*(1-amp);
    bp.rotation.z=Math.sin(TAU*ph+b*1.7)*.18*amp+Math.sin(ts*1.3+b)*.03*(1-amp);}
  // 骑手：抵消一部分身体俯仰，坐得更稳
  for(var r=0;r<u.seats.length;r++){var st=u.seats[r];if(st.userData.pose==='straddle')st.rotation.x=-rig.rotation.x*.6;}
  // 牛车：轮子按距离转动，车厢轻晃
  if(u.cart){var v=(s.speed[1]+(s.speed[2]-s.speed[1])*tr)*speed*amp;A.wheel=(A.wheel+dt*v/CART.wheelR)%TAU;
    u.wheels[0].rotation.x=u.wheels[1].rotation.x=A.wheel;
    u.cart.rotation.z=Math.sin(TAU*ph*.5)*.012*amp;u.cart.position.y=Math.abs(Math.sin(TAU*ph))*.008*amp;
    for(var r2=0;r2<u.seats.length;r2++)u.seats[r2].rotation.z=u.cart.rotation.z*.5;}
}
// 世界移动速度（单位/秒），供寻路同步步频：groundSpeed(kind,state,speed)
function groundSpeed(kind,state,speed){var s=SPEC[kind];if(!s)return 0;return (state==='trot'?s.speed[2]:state==='walk'?s.speed[1]:0)*(speed==null?1:speed);}

// ---------------------------------------------------------------- 座位 / 上下坐骑 / 骑姿
function getSeats(root){return root&&root.userData&&root.userData.seats?root.userData.seats.slice():[];}
var _hv=new T.Vector3();
function riderHipY(rider,opts){
  if(opts&&opts.hipY!=null)return opts.hipY;var u=rider.userData||{};
  if(u.hipY!=null)return u.hipY;if(u.seatHeight!=null)return u.seatHeight;
  var L=findLimbs(rider,opts);
  if(L.legs.length){rider.updateMatrixWorld(true);L.legs[0].getWorldPosition(_hv);rider.worldToLocal(_hv);
    var sc=rider.scale.y||1;return _hv.y*sc;}   // worldToLocal 已除去 rider 自身缩放，这里乘回（rider 挂到座位后保持自身 scale）
  return .42;
}
function belongsTo(o,root){for(var p=o;p;p=p.parent)if(p===root)return true;return false;}
function findLimbs(rider,opts){
  var out={arms:[],legs:[]},u=rider.userData||{};
  // 只接受确实挂在 rider 之下的四肢（S1-10：误传别的模型的 limbs 时忽略，按 rider 自身计算，避免悬空）
  var own=function(o){return o&&belongsTo(o,rider);};
  if(opts&&opts.limbs){var l=opts.limbs;out.arms=[l[0],l[1]].filter(own);out.legs=[l[2],l[3]].filter(own);if(out.legs.length)return out;out.arms=[];}
  if(opts&&(opts.legs||opts.arms)){out.legs=(opts.legs||[]).filter(own);out.arms=(opts.arms||[]).filter(own);if(out.legs.length)return out;out.legs=[];out.arms=[];}
  if(u.legs||u.arms){out.legs=u.legs||[];out.arms=u.arms||[];return out;}
  if(u.limbs&&u.limbs.length>=4){out.arms=[u.limbs[0],u.limbs[1]];out.legs=[u.limbs[2],u.limbs[3]];return out;}
  var p=u.parts;   // TG_AVATAR：parts.legL/legR 为腿关节，armLJ/armRJ 为臂关节
  if(p&&(p.legL||p.legR)){out.legs=[p.legL,p.legR].filter(Boolean);out.arms=[p.armLJ||p.armL,p.armRJ||p.armR].filter(Boolean);return out;}
  rider.traverse(function(o){if(o===rider)return;var n=(o.name||'').toLowerCase();
    if(/(^|[^a-z])(leg|thigh)/.test(n)&&!/lower|shin|calf|foot/.test(n))out.legs.push(o);
    else if(/(^|[^a-z])(arm|upperarm)/.test(n)&&!/fore|lower|hand/.test(n))out.arms.push(o);});
  return out;
}
function sideOf(o){return o.position.x<0?-1:1;}
// pose: 'straddle'（跨骑）| 'bench'（坐车凳）| null（还原）
function poseRider(rider,pose,opts){
  if(!rider)return false;opts=opts||{};var u=rider.userData||(rider.userData={});
  var AV=G.TG_AVATAR;
  if(AV&&!opts.generic){var fn=AV.setPose||AV.pose||AV.applyPose;
    if(typeof fn==='function'){try{var ok=fn.call(AV,rider,pose?(pose==='bench'?'sit':'ride'):'idle',{style:pose,mount:opts.mount||null});if(ok){u._tgPosedBy='avatar';return true;}}catch(e){console.warn('[mounts] TG_AVATAR.setPose 出错，改用通用骑姿',e);}}}
  if(!pose)return unposeRider(rider);
  var L=findLimbs(rider,opts);if(!u._tgPoseSaved){u._tgPoseSaved=[];L.legs.concat(L.arms).forEach(function(o){u._tgPoseSaved.push([o,o.rotation.x,o.rotation.y,o.rotation.z]);});}
  var hipY=opts.hipY||riderHipY(rider,opts),legLen=opts.legLen||u.legLen||hipY*.95,hipX=L.legs.length?Math.abs(L.legs[0].position.x*(L.legs[0].parent&&L.legs[0].parent.scale?L.legs[0].parent.scale.x:1)):.19;
  var tgt=[];
  if(pose==='straddle'){
    var rx=opts.bodyRx!=null?opts.bodyRx:.32,need=(rx-hipX)/legLen,spl=Math.asin(Math.max(.12,Math.min(.95,need)))+.06;
    L.legs.forEach(function(o){tgt.push([o,-.3,0,sideOf(o)*spl]);});
    L.arms.forEach(function(o){tgt.push([o,-.8,0,-sideOf(o)*.15]);});
  }else{   // bench：坐在车头，双腿自然下垂略向前
    L.legs.forEach(function(o){tgt.push([o,-.5,0,sideOf(o)*.06]);});
    L.arms.forEach(function(o){tgt.push([o,-.55,0,-sideOf(o)*.1]);});
  }
  u._tgPose=tgt;reapplyPose(rider);
  u._tgPosedBy='generic';return true;
}
// 若骑手每帧还会被自己的动画（如 TG_AVATAR.animate）重置关节，在其后调用本函数即可恢复骑姿（零分配）
function reapplyPose(rider){var p=rider&&rider.userData&&rider.userData._tgPose;if(!p)return;for(var i=0;i<p.length;i++){var a=p[i];a[0].rotation.set(a[1],a[2],a[3]);}}
function unposeRider(rider){
  var u=rider&&rider.userData;if(!u)return false;
  if(u._tgPosedBy==='avatar'){var AV=G.TG_AVATAR,fn=AV&&(AV.setPose||AV.pose||AV.applyPose);if(typeof fn==='function')try{fn.call(AV,rider,'idle',{style:null});}catch(e){}}
  if(u._tgPoseSaved){u._tgPoseSaved.forEach(function(a){a[0].rotation.set(a[1],a[2],a[3]);});u._tgPoseSaved=null;}u._tgPose=null;
  u._tgPosedBy=null;return true;
}
function mount(root,rider,seatIndex,opts){
  var u=root&&root.userData;if(!u||!u.tgMount||!rider)return null;opts=opts||{};
  var i=seatIndex==null?u.riders.findIndex(function(r,j){return !r;}):seatIndex;if(i<0)i=u.riders.length;
  var seat=u.seats[i];if(!seat){console.warn('[mounts] '+u.kind+' 没有第 '+i+' 个座位');return null;}
  if(u.riders[i]&&u.riders[i]!==rider)dismount(root,i);
  var ru=rider.userData||(rider.userData={});
  if(ru._tgMount&&ru._tgMount.mount!==root)dismount(ru._tgMount.mount,rider);
  if(!ru._tgMount)ru._tgMount={prevParent:rider.parent,pos:rider.position.clone(),rot:rider.rotation.clone(),mount:root,seat:i};
  else{ru._tgMount.seat=i;ru._tgMount.mount=root;}
  var hip=riderHipY(rider,opts);
  seat.add(rider);rider.position.set(0,-hip+(opts.lift||0),opts.z||0);rider.rotation.set(0,0,0);
  poseRider(rider,seat.userData.pose,ext(opts,{bodyRx:seat.userData.bodyRx,mount:root}));
  u.riders[i]=rider;syncReins(u);return seat;
}
function dismount(root,which){
  var u=root&&root.userData;if(!u||!u.tgMount)return null;
  var i=typeof which==='number'?which:u.riders.indexOf(which);if(i<0||!u.riders[i])return null;
  var rider=u.riders[i],ru=rider.userData,m=ru._tgMount;u.riders[i]=null;
  unposeRider(rider);if(rider.parent)rider.parent.remove(rider);
  if(m){if(m.prevParent)m.prevParent.add(rider);rider.position.copy(m.pos);rider.rotation.copy(m.rot);}
  ru._tgMount=null;syncReins(u);return rider;
}
function riders(root){return root&&root.userData&&root.userData.riders?root.userData.riders.slice():[];}

// ---------------------------------------------------------------- 释放 / 统计
function dispose(root){
  var u=root&&root.userData;if(!u||!u.tgMount)return;
  for(var i=0;i<u.riders.length;i++)if(u.riders[i])dismount(root,i);
  if(root.parent)root.parent.remove(root);u.tgMount=false;   // 几何/材质为全局共享缓存，不在这里释放
}
function purge(){for(var k in GEO){GEO[k].dispose();delete GEO[k];}for(var m in MAT){if(MAT[m]&&MAT[m].dispose)MAT[m].dispose();delete MAT[m];}realWood=undefined;}
function stats(root){var meshes=0,tris=0;if(!root)return null;
  root.traverse(function(o){if(o.isMesh&&o.visible&&!isRiderPart(root,o)){meshes++;var g=o.geometry;tris+=(g.index?g.index.count:g.attributes.position.count)/3;}});
  return {meshes:meshes,drawCalls:meshes,triangles:tris|0};}   // 不含骑手；阴影 pass 另计
function isRiderPart(root,o){var u=root.userData;for(var p=o;p&&p!==root;p=p.parent){if(u.riders&&u.riders.indexOf(p)>=0)return true;}return false;}
function config(o){o=o||{};var reset=false;if(o.lambert!=null&&o.lambert!==CFG.lambert){CFG.lambert=!!o.lambert;reset=true;}
  if(o.real!=null){CFG.real=!!o.real;realWood=undefined;}if(o.realGain!=null){CFG.realGain=+o.realGain;realWood=undefined;}if(o.shadows!=null)CFG.shadows=!!o.shadows;
  if(reset){for(var m in MAT)delete MAT[m];realWood=undefined;}return ext(CFG,{});}

var info={};KINDS.forEach(function(k){var s=SPEC[k];info[k]={name:s.name,emoji:s.emoji,seats:s.cart?2:1,cart:!!s.cart,
  defaultDeco:ext(s.deco,{}),exclusive:s.exclusive||[],speed:{walk:s.speed[1],trot:s.speed[2]},
  seatHeight:+((seatSection(s).top+.075)*s.k).toFixed(3)};});
if(info.oxcart)info.oxcart.seatHeight=CART.benchY+.05;

G.TG_MOUNTS={__v:1,
  kinds:function(){return KINDS.slice();},
  info:info,decoNames:DECO,decoOptions:decoOptions,defaultDeco:function(k){return SPEC[k]?ext(SPEC[k].deco,{}):null;},
  build:build,setDeco:setDeco,getSeats:getSeats,mount:mount,dismount:dismount,riders:riders,
  animate:animate,groundSpeed:groundSpeed,poseRider:poseRider,unposeRider:unposeRider,reapplyPose:reapplyPose,
  dispose:dispose,purge:purge,stats:stats,config:config,palette:C,
  toJSON:function(m){var u=m&&m.userData;return u&&u.tgMount?{kind:u.kind,deco:ext(u.deco,{})}:null;},
  fromJSON:function(j){return j&&j.kind?build(j.kind,j.deco):null;}
};
})();
