# suggest.js：意见箱界面 `window.TG_FEEDBACK`

给玩家写意见、查看官方回复和追加说明的面板。菜单入口由 Codex 挂上，调用 `window.TG_FEEDBACK.open()` / `close()`。

**本文件不定义网络层。** `window.TG_SUGGEST` 由 `backend/tg-suggest.js` 在打包时注入。界面只在调用时读取 `window.TG_SUGGEST`，不缓存引用，方便网络层后加载或热替换。不要在 `v4/_src/suggest.js` 里再写一份 mock 或 stub。

## 快速上手

```html
<script src="backend/tg-suggest.js"></script>
<script src="v4/_src/suggest.js"></script>
<script>
  // 菜单项「意见箱」
  btn.onclick = function () { window.TG_FEEDBACK.open(); };

  // 红点：有未读官方回复时亮起
  window.TG_FEEDBACK.onBadge(function (has, n) {
    dot.hidden = !has;           // has === (TG_SUGGEST.count() > 0)
    // n 为未读条数，可选用
  });
</script>
```

`init({ bannedWords, onBadge })` 可选。不调用 `init` 也可以直接 `open()`。

## 给 Codex 的接入步骤

1. 打包时先注入 `backend/tg-suggest.js`（提供 `window.TG_SUGGEST`），再接入 `v4/_src/suggest.js`。不要改本文件，也不要在本文件之前定义会挡住后端模块的 `TG_SUGGEST` stub（后端文件用 `window.__TG_SUGGEST_NET` 防重复，并会覆盖先前的 stub）。
2. 菜单增加「意见箱」，点击调用 `window.TG_FEEDBACK.open()`。关闭用 `close()`，或点面板右上角的关闭按钮、点遮罩、按 Esc。r8 起外观和提示依赖 `ui-kit.js`（`TG_UI`），见 `qa/r8-ui/README.md`。提交按钮文字是「提交」（原「送 出」），字数不足时在输入框下方直接提示。
3. 红点：优先 `TG_FEEDBACK.onBadge(cb)` / `TG_FEEDBACK.hasUnread()`，二者分别包装 `TG_SUGGEST.onUnread` 与 `TG_SUGGEST.count()`。`onBadge` 的回调签名是 `cb(hasUnreadBoolean, count)`。
4. 打开其他模态（捏脸、商铺等）时，如有需要可先 `TG_FEEDBACK.close()`，避免叠两层。
5. 显示文案一律走网络层的 `statusText` / `reasonText`，类别与字数上限走 `categories` / `limits`，不要在菜单或提示里写死旧的「待审核 / 已采纳已上线」。

## `window.TG_FEEDBACK` API

| 方法 | 说明 |
|---|---|
| `open(opts?)` | 打开面板。`opts.tab` 为 `'write'`（默认）或 `'list'` / `'mine'`；`opts.expand` 可直接展开某条「需要补充」的追加框；`opts.container` 可挂到指定节点。 |
| `close()` | 关闭面板。 |
| `init(opts?)` | 可选。`bannedWords: string[]` 追加前端屏蔽词；`onBadge` 等同于再注册一次 `onBadge`。 |
| `hasUnread()` | 同步，包装 `TG_SUGGEST.count() > 0`。网络层未加载时为 `false`。 |
| `unreadCount()` | 同步，包装 `TG_SUGGEST.count()`。 |
| `onBadge(cb)` | 包装 `TG_SUGGEST.onUnread`。`cb(has, n)`，注册时立即回调一次。 |
| `checkText(text, kind?)` | 前端预检。`kind` 为 `'submit'`（默认，最少 `limits.min`）或 `'followup'`（最少 `limits.followMin`）。返回 `{ok:true,text}` 或 `{ok:false,reason,hits?}`。 |
| `categories` / `limits` | 只读，来自当前 `TG_SUGGEST`，缺失时用与后端一致的兜底值。 |

面板样式与捏脸面板同一套暖色纸笺风，移动端底部滑出（390 宽可用），桌面（≥700px）居中卡片。点击目标高度 ≥ 44px。`__v` 为版本号，重复加载幂等。

## 网络层契约（`window.TG_SUGGEST`，以 `backend/tg-suggest.js` 为准）

所有方法返回 Promise，**不抛异常**。失败为 `{ok:false, reason}`；未登录或断网为 `reason:'offline'`。

```
categories  -> [{id,name}, ...]
             现为 decor 装饰 / gameplay 玩法 / ui 界面 / bug 问题反馈 / other 其他
limits      -> {perDay:3, min:10, max:500, followMin:5}
statusText(s) / reasonText(r)   中文状态与失败原因，界面直接使用
submit(category, text) -> {ok:true, id, left} | {ok:false, reason}
list()                 -> {ok:true, items} | {ok:false, reason}
                         items 新到旧，最多 50 条，仅自己的
followup(id, text)     -> {ok:true, id, status:'pending'} | {ok:false, reason}
                         仅当 status === 'need_info'；成功后回到待审阅
unread()               -> Promise<number>     未读官方回复数（离线为 0）
count()                -> number              同步的最近一次未读数
markSeen(id?)          -> {ok:true, n}        省略 id 则全部标已读
onUnread(cb)           -> cb(n)               未读数变化时（含轮询）
```

`list()` 的 item 字段：

```
{id, category, body, status, reply, reply_at, follow_up, created_at, updated_at, unread}
```

`status`：`pending` | `need_info` | `accepted_live` | `rejected` | `escalated`  
对应文案（`statusText`）：待审阅、需要补充、已上线、未采纳、已转交。

`submit` / `followup` 的 `reason` 包括：`bad_category`、`too_short`、`too_long`、`link`、`number`、`blocked`、`empty`、`daily`、`offline`、`error`；追加时还有 `not_found`、`not_need_info`。`reasonText` 会把它们翻成中文（`too_short` 且 `min===5` 时用「至少 5 个字」）。

参数是位置参数：`submit(category, text)`、`followup(id, text)`，不是对象。`id` 为数字。

## 前端过滤

送出和追加前会先跑一层屏蔽词（广告拉群、链接、手机号/邮箱、粗口等，可用 `init({bannedWords})` 扩展）。命中后按 `blocked` / `number` 处理，并显示 `reasonText`。长度与每日 3 条仍以网络层为准，前端只用 `limits` 做即时提示。

## 测试

不要在源文件里带 mock。本地截图和面板联调把 mock 放在 `/tmp` 测试页里，先挂上符合上述契约的 `window.TG_SUGGEST`，再加载本文件。截图见 `qa/r7-shots/`。

## 已知说明

- 类别显示名以 `TG_SUGGEST.categories` 为准（「装饰 / 问题反馈」），不是早期需求里的「新装饰 / Bug」。
- 状态文案以 `statusText` 为准（「待审阅 / 已上线 / 已转交」），不是「待审核 / 已采纳已上线」。
- 「已转交」（`escalated`）按 `statusText` 展示，并用单独的石青色标签，不提供追加框。
- 未接入 `TG_SUGGEST` 时，面板仍可打开，但列表和提交提示「需联网才能提交」。
