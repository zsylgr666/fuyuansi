# r6 economy (backend alignment)

Client revision: `S.economyRev = 6`. On upgrade, in-progress crop timers keep their fractional progress (same migrate pattern as r5). Existing animals keep hunger/stage; only future produce uses the new intervals (`lastCollect` is not rewritten). Yield stays **3** per mature plot (server-fixed). Crop ids still match `^[a-z][a-z0-9_-]{1,23}$`.

Date rolls use Asia/Shanghai (UTC+8), same `date()` as r5. All daily counters live under `S.daily` and reset together when `S.daily.date` changes.

Stealing (`r4Steal`) is unchanged as a visitor interaction and is **not** counted against the owner’s daily coin cap. A thief is limited by `S.daily.stealCoins` (see coin caps).

There is still **no coins→merit pack**. Merit is earned only from the sources below (plus any existing one-off visitor pet if retained; that is not a designed faucet).

---

## 1. Crops

Grow times: cabbage 15 min, peach 6 h, melon 12 h; other vegetables scale ×5 from r5, fruits as specified. Sell prices are lower than r5.

| id | name | grow | yield | sell (coins / unit) | coins / harvest (×3) |
|---|---|---:|---:|---:|---:|
| cabbage | 白菜 | 15 min | 3 | 1 | 3 |
| carrot | 萝卜 | 25 min | 3 | 1 | 3 |
| tomato | 番茄 | 40 min | 3 | 2 | 6 |
| corn | 玉米 | 100 min (1 h 40) | 3 | 2 | 6 |
| peach | 仙桃 | 6 h | 3 | 5 | 15 |
| melon | 西瓜 | 12 h | 3 | 8 | 24 |

`growMs`: 900000, 1500000, 2400000, 6000000, 21600000, 43200000.

---

## 2. Animal produce

Intervals lengthened in step with short crops (×5 from r5). Sell prices lowered.

| animal kind | item id | name | interval | sell (coins / unit) |
|---|---|---|---:|---:|
| chicken | egg | 鸡蛋 | 40 min | 4 |
| duck | duck-egg | 鸭蛋 | 50 min | 4 |
| goose | goose-egg | 鹅蛋 | 75 min | 5 |
| cow | milk | 牛奶 | 60 min | 6 |
| rabbit | fur | 兔毛 | 100 min | 6 |
| sheep | wool | 羊毛 | 150 min (2 h 30) | 8 |
| alpaca | wool | 羊驼毛 | 150 min (2 h 30) | 8 |
| beehive | honey | 蜂蜜 | 150 min (2 h 30) | 7 |
| fishpond | fish | 鲜鱼 | 100 min | 6 |

`intervalMs`: 2400000, 3000000, 4500000, 3600000, 6000000, 9000000, 9000000, 9000000, 6000000.

Hunger / feeding / stages stay as r5. Produce still requires hunger > 0. Animal **purchase** coin prices are unchanged (they are sinks, not faucets).

---

## 3. Merit sources (lower yield + daily cap)

After a source’s daily cap is reached, the action may still be performed for flavor (burn incense, knock the wooden fish, sit in meditation) but **grants 0 further merit** and toasts that today’s回向 is complete. Altar expiry grants `min(row.merit, remaining daily offering cap)`; overflow is lost, never deferred to the next day.

| source | per-action merit | daily cap | max merit / day | `S.daily` counter |
|---|---:|---|---:|---|
| incense (上香) | 1 (was 3) | 5 sticks that grant merit | 5 | `meritIncense` (stick count) |
| altar offerings (供品到期回向) | see §3.1 (lowered) | 40 merit | 40 | `meritOffer` (merit granted) |
| wooden fish (木鱼) | 1 per knock | 5 granting knocks | 5 | `meritMuyu` (knock count) |
| copy sutras (书房抄经) | 3 per completed copy (~2 min) | 3 copies | 9 | `meritSutra` (copy count) |
| meditation (禅房静坐) | 4 per completed 3-min session (木鱼音效) | 2 sessions | 8 | `meritZen` (session count) |
| koi release (莲池放生) | 2 per release | 3 releases | 6 | `meritKoi` (release count) |

Honest daily ceiling if every cap is filled: **73 merit**. No other repeating merit faucets should be added without updating this table.

### 3.1 Offering merit and altar duration

Durations are unchanged from r5 so existing placed rows remain valid. Merit at expiry is lowered. `S.shrine.altar = [{item, placedAt, dur, merit}]` still applies; new placements write the new merit value. Rows already on the altar keep the `merit` stored at placement time.

| id | from | duration | merit at expiry (r6) | r5 was |
|---|---|---:|---:|---:|
| cabbage | crop | 3 min | 1 | 2 |
| carrot | crop | 5 min | 1 | 3 |
| tomato | crop | 6 min | 2 | 4 |
| corn | crop | 10 min | 2 | 6 |
| peach | crop | 20 min | 3 | 10 |
| melon | crop | 30 min | 5 | 15 |
| egg | produce | 5 min | 1 | 3 |
| milk | produce | 8 min | 2 | 5 |
| duck-egg | produce | 6 min | 1 | 4 |
| goose-egg | produce | 8 min | 2 | 5 |
| fur | produce | 10 min | 2 | 6 |
| wool | produce | 12 min | 3 | 8 |
| honey | produce | 15 min | 3 | 8 |
| fish | produce (altar) | 30 min | 6 | 20 |
| white_chicken | chicken via 供品店 | 40 min | 12 | 36 |
| roast_duck | duck | 50 min | 16 | 48 |
| roast_goose | goose | 60 min | 20 | 60 |
| roast_pork | pig | 75 min | 18 | 56 |
| beef | cow | 120 min | 28 | 90 |
| offering_fish | produce fish via 供品店 | 40 min | 10 | 28 |
| fruit-plate / incense-set / tea-cup | legacy catalog | 20 min | 4 | 10 |

Livestock exchange mappings are unchanged (no 屠宰 wording; dogs/cats/sheep/rabbit/horse/alpaca ineligible; fish consumes produce, not the pond).

---

## 4. Merit shop (功德阁) — scarce sinks

Prices raised so a full-cap day (~73 merit) still takes many days to buy the rare decor. No sell-back to coins or merit.

| id | name | merit price | r5 was |
|---|---|---:|---:|
| glazed_lamp | 琉璃灯 | 1000 | 800 |
| ginkgo_bonsai | 千年银杏盆景 | 1400 | 1000 |
| guqin | 古琴 | 1800 | 1200 |
| koi_screen | 锦鲤屏风 | 2200 | 1500 |
| golden_buddha | 金身佛像 | 2800 | 1800 |

### 4.1 Wearable accessories and titles (also merit sinks)

| id | name | merit | type |
|---|---|---:|---|
| beads | 念珠 | 400 | accessory |
| hairpin | 发簪 | 500 | accessory |
| cape | 云肩 | 700 | accessory |
| jade_pendant | 玉佩 | 600 | accessory |
| title_shanxin | 善信 | 150 | title |
| title_jushi | 居士 | 300 | title |
| title_xingzhe | 修行者 | 600 | title |
| title_gongdezhu | 功德主 | 1200 | title |

Owned accessories / titles stay in `S.avatar` (see avatar schema in the r6 report). Buying is visit-blocked unless `canEdit`.

---

## 5. Merit → coins exchange

- Rate: **25 merit → 1 coin** (was 20:1). 24 merit fails.
- Path cap: **8 coins / day** (200 merit), `S.daily.meritCoins`.
- These coins also count toward the daily coin cap in §6.
- No coins→merit button or pack. Offerings remain the only way to turn goods into merit, and that path is loss-making (see §7).

---

## 6. Daily coin cap

| faucet | counts toward cap? | notes |
|---|---|---|
| Selling crops / produce | yes | sale refused (no deduct) if even 1 more coin would exceed the cap; toast 今日铜钱已达上限 |
| Daily task reward | yes | reward reduced to **10** coins (was 20); granted only if cap has room (partial grant allowed) |
| Merit → coins | yes | also limited by the 8-coin path cap |
| Stealing (visitor `r4Steal`) | **no** (owner); thief uses `stealCoins` | keep stealing; thief cap **15** coins / day |
| Animal / furniture / seed purchases | n/a (sinks) | unchanged |

- Owner cap: **40 coins / day**, counter `S.daily.coinsEarned`.
- Thief cap: **15 coins / day**, counter `S.daily.stealCoins`.

---

## 7. Anti-arbitrage (updated for r6)

25 merit = 1 coin, and offering merit was cut, so livestock / crop → offering → merit → coins is strictly worse than selling or keeping the animal, and selling itself is boxed by the 40-coin daily cap.

| path | coins in | merit out | coins back at 25:1 |
|---|---:|---:|---:|
| chicken 40c → white_chicken | 40 | 12 | 0 |
| duck 65c → roast_duck | 65 | 16 | 0 |
| goose 85c → roast_goose | 85 | 20 | 0 |
| pig 80c → roast_pork | 80 | 18 | 0 |
| cow 120c → beef | 120 | 28 | 1 |
| fish sell 6c vs offering_fish 10m | — | 10 | 0 |
| 3 cabbage sell 3c vs 3×1 merit | — | 3 | 0 |

Daily 8-coin merit-exchange cap and 40-coin overall cap stop merit or crop farming from becoming an uncapped faucet. Rare decor and wearables are one-way merit sinks.

---

## 8. `S.daily` fields (additive; reset on date change)

```
S.daily = {
  date,                    // Asia/Shanghai YYYY-MM-DD
  tasks: { feed, harvest, incense, collect },  // 0/1, unchanged keys
  claimed,                 // daily task chest; reward 10 coins
  meritCoins,              // coins already taken from 25:1 exchange (max 8)
  coinsEarned,             // coins from sell + task + merit exchange (max 40)
  stealCoins,              // coins the local player stole today (max 15)
  meritIncense,            // granting incense sticks today (max 5)
  meritOffer,              // merit actually granted from altar expiry (max 40)
  meritMuyu,               // granting wooden-fish knocks today (max 5)
  meritSutra,              // completed sutra copies today (max 3)
  meritZen,                // completed meditation sessions today (max 2)
  meritKoi                 // koi releases today (max 3)
}
```

Missing fields migrate to `0`. `r5Daily` / r6 sanitize must initialize all of the above when rolling a new date.

Lotus extras that cost coins (coin-toss wish slips) spend coins and do not grant merit; they are not a faucet. Picked lotus pods are offering items (see gameplay), using the crop/produce offer path and the offering daily cap.

---

## 9. Mounts (长期铜钱 / 功德沉洞)

codex2 will ship `v4/_src/mounts.js` as `window.TG_MOUNTS`. Feature-detect and use it when present; otherwise in-house simple merged models. Draw calls stay <150. Do not edit `mounts.js`.

Mounts are one-way sinks and **physical objects in the yard**. They do not produce coins or merit. Speed bonuses apply only while the player is actually riding, and never as an earning multiplier.

These hitching-post rules supersede any earlier “auto-mount / dismount for yard work” draft:

1. A hitching post (拴马桩) stands in the yard. Owned mounts are tethered there by default and are visible. Inside the yard the character **walks** (no lingering ride).
2. The player must walk to the post and interact 「牵出/骑上」. The mount comes along **only if the player is riding when leaving through a yard gate**. If they leave without taking it, they walk in the hall and in every public scene. **Never auto-mount.**
3. Entering the shrine hall or any indoor scene (`hall`, `zen`, `study`) auto-dismounts. The mount waits **parked outside that door**; the player can re-mount there.
4. Riding back into the yard auto-tethers the mount to the hitching post.
5. Persist per-mount location: `'yard-post' | 'following' | {scene,x,z}` (parked). The network-synced `mount` field has a value **only while riding**; otherwise it is `null`.

Purchase is visit-blocked unless `canEdit`. Only one mount may be `following` / ridden at a time. 黄牛车 may carry one family passenger while riding. Only the owner (or `canEdit` family for the passenger) may 牵出, decorate, or ride.

### 9.1 Mount catalog

Daily coin cap is 40 and honest daily merit ceiling is ~73, so prices are multi-week to multi-month goals.

| id | name | currency | price | speed | special |
|---|---|---|---:|---:|---|
| donkey | 小毛驴 | coins | 480 | +15% | starter mount (~12 cap-days) |
| ox_cart | 黄牛车 | coins | 960 | +10% | carries 1 passenger; family use (~24 cap-days) |
| chestnut_horse | 枣红马 | coins | 2400 | +30% | mid-late coin goal (~60 cap-days) |
| white_horse | 白马 | merit | 5000 | +35% | exclusive 鞍铃 (`saddle_bell`); ~68 full-merit days |
| white_deer | 白鹿 | merit | 9000 | +40% | auspicious, not fantasy; ~123 full-merit days |
| green_ox | 青牛 | merit | 9000 | +40% | auspicious, not fantasy; ~123 full-merit days |

### 9.2 Mount decorations (purchased, applied per owned mount)

| id | name | currency | price | notes |
|---|---|---|---:|---|
| saddle | 鞍具 | coins | 600 | usable on any owned mount except as noted |
| reins | 缰绳 | coins | 400 | any owned mount |
| bell | 铜铃 | coins | 500 | any owned mount |
| saddle_bell | 鞍铃 | merit | 2000 | **exclusive to 白马**; ignored on other kinds |

Decor is a sink; unequipping returns it to the mount’s `decor` off-state or to backpack (choose one, document in globals; prefer staying on the mount record so it cannot be sold back). No sell-back for mounts or decor.

### 9.3 Save fields (additive)

```
S.mounts = {
  owned: [
    {
      id, kind,
      decor: { saddle, bell, reins, saddle_bell },
      location: 'yard-post' | 'following' | { scene, x, z }
    }
  ],
  riding: null | ownedId,   // set only while the local player is currently riding
  passenger: null | { userId, name }  // only when riding an ox_cart with a family passenger
}
```

- `id` is a regex-safe instance id (`^[a-z][a-z0-9_-]{1,23}$` plus a short unique suffix is fine, e.g. `donkey_k3f`).
- `kind` is one of the catalog ids above.
- `location`:
  - `'yard-post'` — tethered at the yard hitching post (default after purchase and after re-entering the yard while riding).
  - `'following'` — the player is riding this mount outdoors (and only then).
  - `{scene, x, z}` — parked outside an indoor door (or another explicit park point) in that scene.
- Each `decor` flag is `true`/`false` (owned-and-applied). Missing `S.mounts` migrates to `{owned:[], riding:null, passenger:null}`. A legacy `active` field, if present, is migrated: if the player is in the yard it becomes a tethered `yard-post` mount with `riding:null`; never auto-start a ride from a save.

### 9.4 Network / backend `mount` field (other players)

Synced on the same avatar / presence channel as position. **`mount` is non-null only while that player is currently riding.** Tethered or parked mounts are local-scene objects (the owner’s yard post, or a parked model at a door) and are not written to the presence `mount` field. Other clients render a ridden mount under the remote player when the field is present, and hide it when `null`.

```
mount: null | {
  id: string,              // instance id
  kind: 'donkey'|'ox_cart'|'chestnut_horse'|'white_horse'|'white_deer'|'green_ox',
  decor: { saddle?: boolean, bell?: boolean, reins?: boolean, saddle_bell?: boolean },
  passenger?: { userId: string, name?: string } | null
}
```

Suggested presence payload addition (backend): include `mount` next to existing position / yaw / anim / avatar. Client sends `mount: r6MountNet()` (payload or `null`) whenever riding starts or stops, on world enter, and on the existing ~100 ms movement net tick. Family passenger sit/leave should be a small backend RPC (see r6 report “backend changes needed”); until that RPC exists, passenger is local/family-only and still stored on `S.mounts.passenger` for the owner.

### 9.5 Anti-sink note

Mounts and their decor cannot be sold or converted back to coins or merit. Speed is a convenience, not an earning multiplier (produce intervals, crop times, and daily caps are unchanged while riding).

---

## 10. Server-aligned limits (backend/tg-r6.js, 2026-11-13)

The live server is the source of truth when `TG_ECON` / `TG_LOTUS` / `TG_TEAHOUSE` / `TG_MERIT` / `TG_AVATAR_NET` / `TG_MOUNT_NET` are present. Offline, the client applies the same numbers locally.

### 10.1 Daily coins (unchanged totals; routing)

- Owner cap **40** coins/day from `sell` + `task` + `merit` combined (`S.daily.coinsEarned`).
- Merit→coins path cap **8**/day (`S.daily.meritCoins`).
- Steal cap **15**/day (`S.daily.stealCoins`); not counted on the owner 40.
- When `TG_ECON` exists, all coin grants go through `TG_ECON.earn(coins, 'sell'|'task'|'merit'|'steal', exact?)` and the game must credit **only the returned amount**. `exact=true` is all-or-nothing (use this for sales). Offline, `TG_ECON.earn` returns the full amount and the local caps still apply.

### 10.2 Lotus and 茶会小院 social caps

| action | cap | notes |
|---|---|---|
| koi release | 3 / day | `TG_LOTUS.koi()` → `{ok, left \| reason:'daily'}`; client grants merit only on `ok` (2 merit, already in §3) |
| coin-toss wish slips | 3 / day | `TG_LOTUS.wish(text)`; spend coins, **no merit** |
| river lanterns | 3 / day | `TG_TEAHOUSE.release(text, color?)` (and lotus night lanterns if the same faucet); spend coins or free flavor, **no merit** |
| message wall posts | 30 / day, **20 s** interval, **120** chars | `TG_TEAHOUSE.post(text)` reasons: empty, too_long, link, number, blocked, slow(wait_s), daily |

`S.daily` additive counters for the offline path: `wishSlips`, `lanterns`, `wallPosts`, `wallAt` (timestamp of last post). `meritKoi` remains the koi counter.

The shared public scene id is **`teahouse`** (`TG_SCENES` entry `{id:'teahouse', name:'茶会小院', public:true}`). `#tea` / `go('tea')` are aliases of `teahouse`.

### 10.3 Consignment market (backend-enforced; client must not exceed)

| limit | value |
|---|---:|
| Crop unit listing price cap | 50 coins |
| Offering / decor listing price cap | 2000 coins |
| Market daily income | 500 coins (excess is carried over, not lost) |

### 10.4 Watering

Each watering still adds 0.25 of a grow cycle, but **total `plot.boost` is capped at 0.25** per plant (clients cannot stack watering to skip the whole growth). Cooldown unchanged.

### 10.5 Merit hook the game provides

- `window.TG_MERIT_GET() → number` current `S.merit`
- `window.TG_MERIT_ADD(n) → bool` adds `n` (negative spends); returns false and does not change state if the balance would go below 0.

Merit-shop / mount ids `white_horse` / `white_deer` / `green_ox` are the catalog / `S.mounts.owned[].kind` ids. When talking to `TG_MOUNTS` they map to `whitehorse` / `whitedeer` / `greenox`. `TG_MERIT.spend` uses the catalog ids.

## Phase-2 addendum · 莲池（既有数值不变）

- `lotus_pod`（清莲蓬）是 `cat: 'offering'` 的正则安全目录 id；采摘直接进入 `S.backpack`，按上海日期每日最多 3 枚（`S.lotus.date/pods`）。不可出售、不可购买或兑换铜钱。
- 每枚上供 **10 分钟 / 2 功德**，占一个供台位；到期并入原有 `S.daily.meritOffer` **40 功德**上限，溢出丢弃，不增加每日功德天花板。
- 投钱心愿笺每次花 **2 铜钱**，河灯每盏花 **3 铜钱**；两者均不返还钱或功德。夜间河灯显示采用上海时间 18:00–05:59。
- 放生仍为 **2 功德 / 每日 3 次**；封顶后可继续看放生动画，不再奖励。抄经 120 秒、静坐 180 秒，仍用原有 3 次 / 2 次日上限。关闭功课面板或离开房间中止本次计时。
- 莲池采摘、寄愿、放生、功课及功德阁均需 `canEdit`；访客不消耗或奖励主人的资产。
- 穿戴与称号的实际持有字段是 `S.avatarInv.accessories/titles`（保留 phase-1 模块接线事实）；外观继续使用 `S.avatar`。
