# audio.js · 背景音乐与音效模块

全部声音都用 WebAudio 在代码里实时合成，没有任何外链音频文件或 URL。本文件独立，不依赖也不修改其他模块（有 `worldEnter` / `W3` 时会自动跟随场景，没有也能单独运行）。

## API（`window.TG_AUDIO`）

| 方法 | 说明 |
|---|---|
| `unlock()` | 在用户手势里调用：创建 / resume AudioContext，并播放 1 个采样的静音 buffer（iOS Safari 必须这样）。可重复调用，返回 `true/false`。模块加载时已经自动挂了一次性的 `pointerdown / touchend / mousedown / keydown / click`（capture）监听，首次点击就会自动 unlock，成功后监听自动移除。 |
| `toggle()` | 开 / 关（音乐和音效一起），返回新的状态。关闭时 0.4 秒淡出后 `suspend()` 掉 AudioContext，不占 CPU。状态存进 `localStorage['templeGarden.bgm']`（`'1'` / `'0'`）。 |
| `setScene(id)` | 切换场景氛围，约 3 秒平滑交叉淡化。未知 id 按 `plaza` 处理。unlock 之前调用也可以，会记下来。 |
| `playSfx(name)` | 播放音效，返回是否播出。未知名字按 `click` 处理。关闭状态下不发声。 |
| `isOn()` | 当前的开关偏好（`true` = 开）。 |

另外还有几个可选的辅助方法：`setOn(bool)`、`setVolume(0~1.5)`（默认 1，总音量已经很柔和）、`getScene()`、`isRunning()`、`bindButton(elOrSelector, onText='♫', offText='静')`、`scenes`、`sfx`，以及测试用的 `renderOffline(id, 秒)` 和 `renderSfxOffline(name, 秒)`（返回离线渲染的 AudioBuffer），调试状态在 `_state`。会派发 `window` 事件 `tg-audio`（`detail.on`）。

默认是开。没有 `templeGarden.bgm` 时，会参考 enhance.js 的 `templeGarden.mute === '1'`，这时默认关。

## 场景 id（与 gameplay.js 的 `TG_SCENES` 一致）

| id | 名称 | 氛围 |
|---|---|---|
| `gate` | 里门 | 进门先响一阵风铃；山风、鸟鸣、稀疏的古琴 |
| `plaza` | 大厅广场 | 默认：古琴中速、风铃、鸟鸣、轻微流水 |
| `market` | 集市 | 最热闹：96 bpm 的琵琶式快弹、梆子节奏、人声嘈杂底噪，偶尔风铃 |
| `yard` | 心田小院 | 鸟鸣多、小水滴、流水、古琴 |
| `lotus` | 荷塘 | 水面和流水底噪、密集水滴、偶尔蛙鸣、泛音多 |
| `hall` | 缘堂 | 安静：风铃、鸟鸣、细流、古琴拨弦 |
| `zen` | 静室 | 最静：风、水面、风铃、鸟鸣、稀疏古琴 |
| `study` | 书房 | 安静：稀疏古琴、窗外偶尔鸟鸣 |

别名：`home / garden → yard`，`shrine / temple → hall`，`pond → lotus`，`square → plaza`。

## 音效名（`playSfx`）

`click`（点击，木质轻响）、`coin`（金币叮）、`water`（浇水）、`plant`（播种 / 种植）、`harvest`（收获，上行琶音加风铃）、`incense`（点灯，风铃；内部键名保留）、`bell`（庭院钟）、`muyu`（摇风铃；内部键名保留）、`offer`（摆放，古琴加风铃）、`chime`（风铃）、`qian`（摇筒轻响）、`result`（结果）、`unlock`（解锁）、`error`（失败 / 不可用）、`pop`（弹窗）。

覆盖 enhance.js `tgFeedback(kind)` 用到的所有 kind：plant / water / harvest / coin / result / qian / incense / offer / muyu / unlock。

中文别名：`浇水 金币 收获 点灯 上香 钟 风铃 摇风铃 木鱼 种植 播种 点击`（`上香`/`木鱼` 仍指向同一内部键，音色已改为风铃）；英文别名：`sell / buy → coin`，`tap → click`，`knock → muyu`，`gong → bell`，`seed → plant`。

## 声音怎么做的

- 古琴：Karplus-Strong 拨弦，每个音高只预计算一次 buffer，播放时用 playbackRate 做「上滑」和「吟」。D 宫五声音阶随机游走，有乐句留白，偶尔加八度和音和泛音。
- 风铃：非谐波正弦叠加的一串高音。庭院钟 / 门铃：非谐波正弦叠加。鸟鸣：高频滑音。水滴：上滑短音。蛙鸣：调幅锯齿波。梆子：高频短促敲击。旧键 `muyu` / `bowl` 已改奏风铃或轻柔泛音。
- 底噪层（风、流水、水面、人声嘈杂、低音持续音）：一段 3 秒循环粉噪，经过不同的滤波，并做缓慢的随机起伏。
- 混响：程序生成的 2.2 秒脉冲响应，经过 ConvolverNode。总线后面接了一个温和的压缩器。

## 性能

- 用前瞻调度：每 120 ms 安排未来 0.45 秒内的音符（不是每帧跑）。
- 同时发声上限 26 个，超过 18 个时跳过环境类的低优先级事件；音效优先。
- 当前场景用不到的底噪层淡出后会被停掉、断开。
- 关闭时，或页面 `document.hidden`、`pagehide` 时，淡出后 `suspend()`；回来再 resume。
- 在 headless Chrome 里离线渲染 20 秒，每个场景大约 0.7 到 1.1 秒（包括 WAV 编码），也就是实时负载的约 5%。

## 挂载方式（以后由 codex / pack 接入，现在没有改任何已有文件）

1. 打包：在 `pack.mjs` 的 `/*__WORLD__*/` 那串里，把 `audio.js` 追加到 `r41.js` 后面（放在哪里都可以，它是自包含的 IIFE）。也可以单独用 `<script src>` 加载。
2. 场景跟随：加载时会包装全局 `worldEnter`（打标记 `__tgAudio`，不会重复包装），在 `DOMContentLoaded` / `load` 时再检查一次。另外每 2 秒轻量读一次 `W3.active` 或 `location.hash` 兜底（只在声音开着时）。所以通常不用手动调 `setScene`。
3. 音效（建议）：让 enhance.js 的 `tgFeedback(kind)` 改成调用 `TG_AUDIO.playSfx(kind)`，避免两套 AudioContext 同时出声。
4. 开关（建议）：让 `#btnMute` 的 onclick 调用 `TG_AUDIO.toggle()`，或者直接调 `TG_AUDIO.bindButton('#btnMute')`，然后去掉原来的 onclick，以免两套静音状态不同步。模块不会自动绑定 `#btnMute`。

## 注意事项

- 浏览器自动播放策略要求：必须先有一次用户手势才会出声，这是正常的。
- 现在和 enhance.js 的 `tgAudio` 会各自用一个 AudioContext；没接入第 3、4 步之前，原来的点击音效和静音按钮照旧工作，但静音按钮不会关掉背景音乐。
- 只做了 headless Chrome 测试，没有在真机 iOS Safari 上试听。iOS 上 `latencyHint: 'playback'` 和 StereoPanner 不支持时，都已经做了降级处理。
- 旋律带随机性，每次听起来都不一样。
- 试听样例在 `qa/audio-samples/`：每个场景一段 20 秒的 `bgm-*.wav`，每个音效一个 `sfx-*.wav`。
