/* 十四、声音、联机与庭院细节：所有资源在本地生成 */
var tgAudio=null,tgMuted=false;
try{tgMuted=localStorage.getItem('templeGarden.mute')==='1';}catch(e){}
function tgResume(){if(window.TG_AUDIO)return;try{if(!tgAudio)tgAudio=new(window.AudioContext||window.webkitAudioContext)();if(tgAudio.state==='suspended')tgAudio.resume().catch(()=>{});}catch(e){}}
document.addEventListener('pointerdown',tgResume,{passive:true});document.addEventListener('keydown',tgResume);
function tgFeedback(kind){
  const w=W3;if(w&&w.body)w.feedback=.45;
  if(tgMuted||!tgAudio||tgAudio.state!=='running')return;
  const notes={plant:[440,660],water:[650,950,750],harvest:[523,659,784],coin:[1100,760,1200],result:[392,523,659],qian:[180,250,330],incense:[330,660],offer:[392,587],muyu:[170],unlock:[523,659,784,1046]}[kind]||[440];
  notes.forEach((f,i)=>{const t=tgAudio.currentTime+i*.075,o=tgAudio.createOscillator(),g=tgAudio.createGain();o.type=kind==='muyu'?'sine':'triangle';o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(f*.65,t+.22);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.065,t+.006);g.gain.exponentialRampToValueAtTime(.0001,t+.3);o.connect(g);g.connect(tgAudio.destination);o.start(t);o.stop(t+.31);});
}
$('#btnMute').textContent=tgMuted?'静':'♫';$('#btnMute').onclick=()=>{tgMuted=!tgMuted;$('#btnMute').textContent=tgMuted?'静':'♫';$('#btnMute').setAttribute('aria-pressed',String(tgMuted));try{localStorage.setItem('templeGarden.mute',tgMuted?'1':'0');}catch(e){}};
$('#btnAuth').onclick=()=>{if(typeof window.TG_AUTH?.open==='function')window.TG_AUTH.open();else toast('未连接');};
window.TG_NET=window.TG_NET||{};
var tgRemoteList=[];
window.applyRemotePlayers=window.TG_NET.applyRemotePlayers=function(list){tgRemoteList=Array.isArray(list)?list.filter(p=>p&&p.id!=null&&p.pos&&[p.pos.x,p.pos.y,p.pos.z].every(Number.isFinite)):[];if(W3?.remotes)tgRemotes(0);};
function tgRemotes(dt){
 const w=W3;if(!w?.player)return;w.remotes=w.remotes||new Map();const ids=new Set(tgRemoteList.map(p=>String(p.id)));
 for(const [id,r]of w.remotes)if(!ids.has(id)){w.scene.remove(r.mesh);r.label.material.map.dispose();r.label.material.dispose();w.remotes.delete(id);}
 for(const p of tgRemoteList){const id=String(p.id);let r=w.remotes.get(id);if(!r){const mesh=w.player.clone(true);mesh.position.set(p.pos.x,p.pos.y,p.pos.z);const c=document.createElement('canvas');c.width=256;c.height=64;const tex=new THREE.CanvasTexture(c),mat=new THREE.SpriteMaterial({map:tex,depthTest:false,transparent:true}),label=new THREE.Sprite(mat);label.position.y=2;label.scale.set(1.8,.45,1);mesh.add(label);w.scene.add(mesh);r={mesh,label,c,name:null};w.remotes.set(id,r);}
 if(r.name!==p.name){r.name=p.name;const c=r.c,ctx=c.getContext('2d');ctx.clearRect(0,0,256,64);ctx.fillStyle='#31261dcc';ctx.fillRect(0,0,256,64);ctx.fillStyle='#ffe6a1';ctx.font='28px sans-serif';ctx.textAlign='center';ctx.fillText(String(p.name||'同行访客').slice(0,16),128,42);r.label.material.map.needsUpdate=true;}
 r.mesh.visible=p.scene===w.active;const a=1-Math.exp(-dt*10);r.mesh.position.lerp(new THREE.Vector3(p.pos.x,p.pos.y,p.pos.z),a);const yaw=typeof p.rot==='number'?p.rot:p.rot?.y||0;r.mesh.rotation.y+=Math.atan2(Math.sin(yaw-r.mesh.rotation.y),Math.cos(yaw-r.mesh.rotation.y))*a;
 const body=r.mesh.children[0];body.position.y=p.anim==='walk'?Math.abs(Math.sin(performance.now()*.011))*.045:0;body.children.filter(c=>c.isGroup).forEach((l,i)=>l.rotation.x=p.anim==='walk'?Math.sin(performance.now()*.011+i*Math.PI)*.4:0);r4Pose(body,body.children.filter(c=>c.isGroup),p.anim,p.anim==='walk',performance.now());
 }
}
/* 栅格 A*：膨胀障碍，八向搜索且不切墙角 */
function worldPath(point){
 const w=W3,step=.5,start={x:Math.round(w.player.position.x/step),z:Math.round(w.player.position.z/step)},end={x:Math.round(point.x/step),z:Math.round(point.z/step)},key=(x,z)=>x+','+z;
 const open=[{...start,g:0,f:0}],seen=new Map(),closed=new Set();seen.set(key(start.x,start.z),open[0]);let found=null,loops=0;
 while(open.length&&loops++<4200){open.sort((a,b)=>b.f-a.f);const n=open.pop(),nk=key(n.x,n.z);if(closed.has(nk))continue;closed.add(nk);if(Math.hypot(n.x-end.x,n.z-end.z)<=1){found=n;break;}
 for(const [dx,dz]of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]]){const x=n.x+dx,z=n.z+dz,k=key(x,z);if(closed.has(k)||!worldCanMove(x*step,z*step))continue;if(dx&&dz&&(!worldCanMove((n.x+dx)*step,n.z*step)||!worldCanMove(n.x*step,(n.z+dz)*step)))continue;const g=n.g+Math.hypot(dx,dz);if(seen.has(k)&&seen.get(k).g<=g)continue;const v={x,z,g,f:g+Math.hypot(x-end.x,z-end.z),parent:n};seen.set(k,v);open.push(v);}}
 w.path=[];if(found){while(found.parent){w.path.unshift(new THREE.Vector3(found.x*step,0,found.z*step));found=found.parent;}w.target=w.path.shift()||point;}else w.target=point;
}
/* 静态几何合并，仅合并同材质且不需单独交互的装饰 */
function mergeGeometries(geos){const attrs={position:[],normal:[],uv:[]};for(const source of geos){const g=source.index?source.toNonIndexed():source;for(const k of Object.keys(attrs))if(g.attributes[k])attrs[k].push(...g.attributes[k].array);if(g!==source)g.dispose();}const out=new THREE.BufferGeometry();for(const k of Object.keys(attrs))if(attrs[k].length)out.setAttribute(k,new THREE.Float32BufferAttribute(attrs[k],k==='uv'?2:3));out.computeBoundingSphere();return out;}
function tgInstances(parent,geo,mat,items){const mesh=new THREE.InstancedMesh(geo,mat,items.length),o=new THREE.Object3D();items.forEach((v,i)=>{o.position.set(v[0],v[1],v[2]);o.scale.set(v[3]||1,v[4]||1,v[5]||1);o.rotation.set(v[6]||0,v[7]||0,v[8]||0);o.updateMatrix();mesh.setMatrixAt(i,o.matrix);});mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;}
function tgTexture(soil){const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.fillStyle=soil?'#725036':'#40575b';x.fillRect(0,0,128,128);let seed=37;const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};for(let i=0;i<700;i++){x.fillStyle=soil?(i%2?'#9b7048':'#4c392a'):(i%2?'#688082':'#293e43');x.fillRect(rnd()*128,rnd()*128,soil?2:12,soil?2:1);}if(!soil){x.strokeStyle='#273b40';for(let i=0;i<128;i+=16){x.beginPath();x.moveTo(i,0);x.lineTo(i,128);x.stroke();}}const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(soil?2:5,soil?2:2);return t;}
function tgDecorate(){
 const w=W3,box=new THREE.BoxGeometry(1,1,1),soil=new THREE.MeshLambertMaterial({map:tgTexture(true)}),tile=new THREE.MeshLambertMaterial({map:tgTexture(false)});
 // 顶点渐变天穹，随场景切换隐藏室内天空。
 const skyGeo=new THREE.SphereGeometry(85,24,16),col=[];for(let i=0;i<skyGeo.attributes.position.count;i++){const t=THREE.MathUtils.clamp((skyGeo.attributes.position.getY(i)+10)/80,0,1),c=new THREE.Color('#eee1bb').lerp(new THREE.Color('#669ec2'),t);col.push(c.r,c.g,c.b);}skyGeo.setAttribute('color',new THREE.Float32BufferAttribute(col,3));w.sky=new THREE.Mesh(skyGeo,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.BackSide,depthWrite:false,fog:false}));w.scene.add(w.sky);w.camera.far=180;w.camera.updateProjectionMatrix();
 for(const name of ['plaza','yard','hall']){const s=w.spaces[name];
  if(name!=='hall'){
   const stones=[];for(let z=-11;z<=12;z+=1.1)for(const x of [-.68,.68])stones.push([x,.045,z,1.25,.08,.95,0,(Math.sin(z)*.025)]);tgInstances(s.group,box,worldMat('#d9cfb5'),stones);
   // 分段上翘屋檐、瓦片纹理、斗拱与石阶。
   for(const side of [-1,1])for(let j=0;j<5;j++){const plate=worldBox(s,0,4.15-j*.07+j*j*.035,-12+side*(.25+j*.36),27,.12,.48,'#43595a');plate.material=tile;plate.rotation.x=side*(.32-j*.16);}
   // 飞檐两端逐层抬高，形成清晰的剪影。
   for(const side of [-1,1])for(let j=0;j<3;j++){const end=worldBox(s,side*(12.5+j*.5),4.35+j*.2,-12,1,.15,3.6-j*.2,'#43595a');end.material=tile;end.rotation.z=side*(.12+j*.13);}
   // 路旁低矮花盆和石子，让近景也有层次。
   const gravel=[];for(const x of [-2,2])for(let z=-7;z<12;z+=1.3)gravel.push([x,.085,z,.16,.1,.2,0,z]);tgInstances(s.group,new THREE.DodecahedronGeometry(1,0),worldMat('#a9a691'),gravel);
   for(const x of [-3,3])for(const z of [6,-7]){worldMesh(s.group,'cylinder','#9e6544',x,.26,z,.36,.5,.36);worldMesh(s.group,'ball','#597e43',x,.65,z,.49,.48,.49);s.blocks.push({x:x-.4,X:x+.4,z:z-.4,Z:z+.4});for(let i=0;i<3;i++)worldMesh(s.group,'ball','#e6bd6f',x+Math.cos(i*2)*.26,.94,z+Math.sin(i*2)*.26,.09,.08,.09);}
   const brackets=[];for(let x=-12;x<=12;x+=2){for(let j=0;j<3;j++)brackets.push([x,3.45+j*.16,-11.7,.4+j*.22,.12,.55+j*.2]);}tgInstances(s.group,box,worldMat('#a66c36'),brackets);
   for(let j=0;j<3;j++)worldBox(s,0,.04+j*.06,-10.8-j*.36,4.2-j*.2,.12,.5,'#a3a69b');
   const stalk=[],leaf=[],lantern=[];for(let i=0;i<22;i++){const x=(name==='plaza'?11:8)+(i%5)*.67,z=(name==='plaza'?-17.5:-10)+Math.floor(i/5)*.64,h=2.7+(i%4)*.35;stalk.push([x,h/2,z,.065,h,.065]);for(let k=0;k<3;k++){leaf.push([x+.15,h-.4-k*.45,z,.48,.045,.17,0,k*.8,.5]);}s.blocks.push({x:x-.13,X:x+.13,z:z-.13,Z:z+.13});}tgInstances(s.group,new THREE.CylinderGeometry(1,1,1,6),worldMat('#63884b'),stalk);tgInstances(s.group,box,worldMat('#3f7849'),leaf);
   for(const x of [-2.9,2.9]){worldBox(s,x,3.2,-11.2,.035,.8,.035,'#674c2b');lantern.push([x,2.65,-11.2,.32,.43,.32]);worldMesh(s.group,'cylinder','#d7ab57',x,2.22,-11.2,.1,.2,.1);}tgInstances(s.group,new THREE.SphereGeometry(1,8,6),worldMat('#cc5035'),lantern);
   const rails=[];for(const x of (name==='yard'?[-21,21]:name==='plaza'?[]:[-14,14]))for(let z=-10;z<14;z+=1.8){rails.push([x,.6,z,.15,1.2,.15],[x,.8,z+.8,.1,.12,1.8]);}tgInstances(s.group,box,worldMat('#8b6542'),rails);
   // 祈愿架与手写愿牌。
   if(name!=='plaza'){worldBox(s,5,1.5,10,4,.16,.18,'#775134');for(const x of [3,7])worldBox(s,x,.85,10,.15,1.7,.15,'#775134',true);
   ['平安喜乐','家和业兴','心田常青','福泽绵长'].forEach((wish,i)=>{const x=3.5+i;worldBox(s,x,1.05,10,.7,.75,.09,'#c79d63');worldLabel(s.group,wish,x,1.1,10.06,.65);worldBox(s,x,1.5,10,.018,.35,.018,'#b44732');});}
   if(name==='yard'){const pond=worldMesh(s.group,'cylinder','#76aeb0',6,.05,-3,2,.08,1.5);pond.material=new THREE.MeshPhongMaterial({color:'#71aeb0',shininess:70,transparent:true,opacity:.85});s.blocks.push({x:4,X:8,z:-4.5,Z:-1.5});const rocks=[];for(let i=0;i<14;i++){const a=i/14*Math.PI*2;rocks.push([6+Math.cos(a)*2,.15,-3+Math.sin(a)*1.5,.4,.3,.32,0,a]);}tgInstances(s.group,new THREE.DodecahedronGeometry(1,0),worldMat('#a4a899'),rocks);}
  }
 }
 for(const m of w.spaces.yard.group.children)if(m.isMesh&&m.geometry===w.geometries.box&&m.scale.x===2.4&&m.scale.z===2.3)m.material=soil;
 // 香鼎：三足、口沿、灰面与双耳。
 const h=w.spaces.hall;for(let i=0;i<3;i++){const a=i/3*Math.PI*2;const leg=worldMesh(h.group,'cylinder','#806c40',Math.cos(a)*.52,.35,-2.3+Math.sin(a)*.52,.09,.7,.09);leg.rotation.z=Math.cos(a)*.15;}
 const rim=new THREE.Mesh(new THREE.TorusGeometry(.69,.085,6,20),worldMat('#c0a45c'));rim.rotation.x=Math.PI/2;rim.position.set(0,1.21,-2.3);h.group.add(rim);worldMesh(h.group,'cylinder','#635c4c',0,1.2,-2.3,.6,.025,.6);
 for(const x of [-.82,.82]){const ear=new THREE.Mesh(new THREE.TorusGeometry(.22,.06,5,10),worldMat('#ac914f'));ear.position.set(x,1.2,-2.3);h.group.add(ear);}
 // 更清楚的僧衣层次、肩膀和眉眼。
 worldMesh(w.body,'ball','#d5812b',0,.98,0,.39,.25,.29);const sash=worldMesh(w.body,'box','#b2672e',-.08,.85,.29,.5,.6,.045);sash.rotation.z=-.3;
 for(const x of [-.105,.105]){const brow=worldMesh(w.body,'box','#80583c',x,1.41,.285,.09,.018,.025);brow.rotation.z=x<0?.12:-.12;}
 for(let i=0;i<7;i++){const a=Math.PI*.18+i/6*Math.PI*.64;worldMesh(w.body,'head','#a6694d',Math.cos(a)*.065,1.225-Math.sin(a)*.035,.301,.012,.012,.012);}
 tgArt2();
 // 将同色固定装饰合批，保留地面、作物和供品的独立更新。
 for(const s of Object.values(w.spaces)){const batches=new Map();for(const m of s.group.children){if(!m.isMesh||m.isInstancedMesh||m===s.floor||m.geometry!==w.geometries.box)continue;const k=m.material.uuid;if(!batches.has(k))batches.set(k,[]);batches.get(k).push(m);}for(const arr of batches.values()){if(arr.length<2)continue;const geos=arr.map(m=>{m.updateMatrix();return m.geometry.clone().applyMatrix4(m.matrix);});const mesh=new THREE.Mesh(mergeGeometries(geos),arr[0].material);mesh.castShadow=mesh.receiveShadow=true;s.group.add(mesh);arr.forEach(m=>s.group.remove(m));geos.forEach(g=>g.dispose());}}
}
