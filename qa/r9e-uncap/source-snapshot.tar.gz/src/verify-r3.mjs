import {chromium} from '../../node_modules/playwright-core/index.mjs';
import http from 'node:http';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const html=fs.readFileSync(new URL('../index.html',import.meta.url));
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:390,height:844},hasTouch:true});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.addInitScript(()=>{window.TG_SHRINE_UPLOAD=async()=> 'data:image/png;base64,bad';window.__upload=window.TG_SHRINE_UPLOAD;});
 await page.goto(`http://127.0.0.1:${server.address().port}`);await page.waitForFunction(()=>window.W3?.active==='plaza');await page.waitForTimeout(600);
 assert.equal(await page.evaluate(()=>TG_SHRINE_UPLOAD===window.__upload),true);
 await page.evaluate(()=>{S.coins=500;S.inventory.carrot=3;renderTop();openShop();});
 await page.click('[data-buy="wood-table"]');assert.equal(await page.evaluate(()=>S.coins),440);assert.equal(await page.evaluate(()=>S.backpack['wood-table']),1);
 await page.evaluate(()=>{S.coins=0;openShop();});await page.click('[data-buy="bench"]');assert.equal(await page.evaluate(()=>S.backpack.bench||0),0);
 const crop=await page.evaluate(()=>{const c=CROPS[0];S.inventory={[c.id]:3};openShop('sell');return {id:c.id,value:c.value};});await page.click(`[data-sell="${crop.id}"]`);assert.equal(await page.evaluate(()=>S.coins),crop.value*8);await page.click(`[data-sell-all="${crop.id}"]`);assert.equal(await page.evaluate(()=>S.coins),crop.value*24);
 await page.evaluate(()=>{S.coins=500;closeModal();S.unlocked=true;worldEnter('hall','yard');current='hall';openShrineStudio();});
 const outside=await page.evaluate(()=>W3.spaces.plaza.floor.material.color.getHex());await page.click('[data-style="palace"]');assert.equal(await page.evaluate(()=>S.coins),380);await page.click('[data-style="zen"]');assert.equal(await page.evaluate(()=>S.coins),300);await page.click('[data-style="palace"]');assert.equal(await page.evaluate(()=>S.coins),300);assert.equal(await page.evaluate(()=>W3.spaces.plaza.floor.material.color.getHex()),outside);
 await page.fill('[data-name="0"]','王明');assert.equal(await page.evaluate(()=>S.shrine.plaques[0].name),'王明');await page.fill('[data-image="0"]','https://invalid.example/portrait.png');await page.locator('[data-image="0"]').blur();await page.waitForTimeout(100);assert.equal(await page.evaluate(()=>W3.spaces.hall.plaqueGroup.children.length),3);
 await page.evaluate(()=>{closeModal();S.backpack.bench=2;enterPlacement('hall');});assert.equal(await page.evaluate(()=>worldBlocked()),true);assert.equal(await page.locator('#joystick').isVisible(),false);
 await page.click('[data-item="wood-table"]');
 async function location(x,z){return page.evaluate(({x,z})=>{const r=document.querySelector('#planCanvas').getBoundingClientRect(),t=TG_PLAN.transform;return {x:r.left+t.ox+x*t.scale,y:r.top+t.oz+z*t.scale};},{x,z});}
 let pt=await location(-2,3);await page.mouse.click(pt.x,pt.y);assert.equal(await page.evaluate(()=>S.decor.hall.length),1);assert.equal(await page.evaluate(()=>S.backpack['wood-table']),0);
 await page.click('#planRotate');assert.equal(await page.evaluate(()=>S.decor.hall[0].rot),Math.PI/2);
 // Drag the selected table and check snap.
 pt=await location(-2,3);let end=await location(-2,1);await page.mouse.move(pt.x,pt.y);await page.mouse.down();await page.mouse.move(end.x,end.y,{steps:5});await page.mouse.up();assert.equal(await page.evaluate(()=>S.decor.hall[0].z),1);
 await page.click('[data-item="bench"]');pt=await location(0,7);await page.mouse.click(pt.x,pt.y);assert.equal(await page.evaluate(()=>S.decor.hall.length),1);assert.equal(await page.evaluate(()=>S.backpack.bench),2);
 pt=await location(-2,1);await page.mouse.click(pt.x,pt.y);await page.click('#planReturn');assert.equal(await page.evaluate(()=>S.backpack['wood-table']),1);assert.equal(await page.evaluate(()=>S.decor.hall.length),0);
 await page.click('[data-item="wood-table"]');pt=await location(-2,3);await page.touchscreen.tap(pt.x,pt.y);assert.equal(await page.evaluate(()=>S.decor.hall.length),1);
 await page.click('#planDone');assert.equal(await page.evaluate(()=>!!TG_PLAN),false);assert.equal(await page.evaluate(()=>W3.spaces.hall.blocks.filter(b=>b.r3Decor).length),1);assert.equal(await page.evaluate(()=>worldCanMove(-2,3)),false);
 assert.equal(await page.evaluate(()=>{const g=W3.spaces.hall.decorGroup.children[0];for(let i=0;i<100;i++)worldSyncDecor();return g===W3.spaces.hall.decorGroup.children[0];}),true);
 assert.match(await page.evaluate(()=>r3PlacementError('hall',{id:'bench',x:0,z:7,rot:0})),/门/);
 assert.match(await page.evaluate(()=>r3PlacementError('hall',{id:'bench',x:6,z:0,rot:0})),/墙/);
 assert.match(await page.evaluate(()=>r3PlacementError('hall',{id:'bench',x:-2,z:3,rot:0})),/重叠/);
 assert.match(await page.evaluate(()=>r3PlacementError('hall',{id:'vase',x:0,z:-2.5,rot:0})),/固定/);
 await page.evaluate(()=>{closeModal();r3OpenBackpack();});assert.equal(await page.locator('#r3Arrange').count(),1);await page.click('#r3Shop');assert.equal(await page.locator('[data-buy]').count(),5);
 await page.evaluate(()=>{closeModal();save();});await page.reload();await page.waitForFunction(()=>W3?.active);assert.equal(await page.evaluate(()=>S.shrine.plaques[0].name),'王明');assert.equal(await page.evaluate(()=>S.decor.hall.length),1);
 const calls={};for(const scene of ['plaza','yard','hall','home','zen','study','gate','market','lotus']){await page.evaluate(scene=>{closeModal();worldEnter(scene);},scene);await page.waitForTimeout(100);calls[scene]=await page.evaluate(()=>W3.renderer.info.render.calls);}
 assert.ok(Object.values(calls).every(v=>v<120),JSON.stringify(calls));
 // Exercise all catalog models, validation and scene-owned collision groups.
 const models=await page.evaluate(()=>{worldEnter('home');const g=new THREE.Group();W3.spaces.home.group.add(g);TG_CATALOG.forEach((v,i)=>r3Furniture(g,{id:v.id,x:i%4*3-5,z:Math.floor(i/4)*3-2,rot:Math.PI/2}));g.updateMatrixWorld(true);r3BatchDecor(g);const n=g.children.length;W3.spaces.home.group.remove(g);return n;});assert.ok(models>0&&models<25);
 await page.evaluate(async()=>{closeModal();await go('hall',true);enterPlacement('hall');});await page.screenshot({path:'/workspace/temple-garden/v4/shots/r3-plan-mobile.png'});await page.click('#planDone');await page.evaluate(()=>openShrineStudio());await page.waitForTimeout(250);await page.screenshot({path:'/workspace/temple-garden/v4/shots/r3-shrine-mobile.png'});
 const defaultPage=await browser.newPage({viewport:{width:390,height:844}});await defaultPage.goto(`http://127.0.0.1:${server.address().port}`);await defaultPage.waitForFunction(()=>W3?.active);
 const upload=await defaultPage.evaluate(async()=>{const c=document.createElement('canvas');c.width=900;c.height=600;const blob=await new Promise(r=>c.toBlob(r));const data=await TG_SHRINE_UPLOAD(new File([blob],'test.png',{type:'image/png'}));const img=new Image();await new Promise((r,j)=>{img.onload=r;img.onerror=j;img.src=data;});return {w:img.width,h:img.height,jpeg:data.startsWith('data:image/jpeg')};});assert.deepEqual(upload,{w:256,h:171,jpeg:true});
 const harvest=await defaultPage.evaluate(()=>{S.coins=17;S.plots[0]={crop:CROPS[0].id,plantedAt:0,boost:1,lastWater:0};const id=CROPS[0].id,before=S.inventory[id]||0;window.harvest(0,null);return {coins:S.coins,gain:S.inventory[id]-before};});assert.deepEqual(harvest,{coins:17,gain:1});
 for(const scene of ['home','zen','study']){await defaultPage.evaluate(async scene=>{await go(scene,true);S.backpack.vase=1;enterPlacement(scene);},scene);await defaultPage.click('[data-item="vase"]');const pt=await defaultPage.evaluate(()=>{const r=document.querySelector('#planCanvas').getBoundingClientRect(),t=TG_PLAN.transform;return {x:r.left+t.ox,y:r.top+t.oz+3*t.scale};});await defaultPage.mouse.click(pt.x,pt.y);assert.equal(await defaultPage.evaluate(scene=>S.decor[scene].length,scene),1);await defaultPage.click('#planDone');assert.equal(await defaultPage.evaluate(()=>W3.spaces[W3.active].blocks.filter(b=>b.r3Decor).length),1);}
 await defaultPage.close();
 assert.deepEqual(errors,[]);console.log(JSON.stringify({pass:true,calls,modelBatches:models,errors},null,2));
}finally{await browser.close();server.close();}
