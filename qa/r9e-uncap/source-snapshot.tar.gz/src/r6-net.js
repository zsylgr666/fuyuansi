/* r6-net.js — offline TG_AVATAR_NET fallback, watering cap, teahouse alias, go() queue, merit hooks.
   Do not inline backend/tg-r6.js; this stub is used only when the spliced NET is absent. */
(()=>{
window.r6TeaId=n=>n==='teahouse'?'tea':n;
window.r6IsTea=n=>n==='tea'||n==='teahouse';

if(Array.isArray(window.TG_SCENES)&&!TG_SCENES.some(s=>s.id==='teahouse'))TG_SCENES.push({id:'teahouse',name:'茶会小院',public:true});

const R6_ACC=[
  {id:'beads',kind:'accessory',name:'珠串',emoji:'📿',price:400,slot:'neck',part:'beads'},
  {id:'hairpin',kind:'accessory',name:'发簪',emoji:'🪮',price:500,slot:'head',part:'hairpin'},
  {id:'jade_pendant',kind:'accessory',name:'玉佩',emoji:'🟢',price:600,slot:'waist',part:'jade'},
  {id:'cape',kind:'accessory',name:'云肩',emoji:'🧣',price:700,slot:'back',part:'cape'}
];
const R6_TITLES=[
  {id:'title_shanxin',kind:'title',name:'善友',emoji:'🌱',price:150},
  {id:'title_jushi',kind:'title',name:'雅士',emoji:'📿',price:300},
  {id:'title_xingzhe',kind:'title',name:'旅人',emoji:'🧘',price:600},
  {id:'title_gongdezhu',kind:'title',name:'福缘主',emoji:'✨',price:1200}
];
const TITLE_NAME=Object.fromEntries(R6_TITLES.map(t=>[t.id,t.name]));

if(!window.TG_AVATAR_NET){
  window.TG_AVATAR_NET={
    __offline:true,
    catalog:()=>R6_ACC.concat(R6_TITLES).map(x=>({...x})),
    owned:()=>[...(S?.avatarInv?.accessories||[]),...(S?.avatarInv?.titles||[])],
    locked(slot,part){
      const item=R6_ACC.find(a=>a.slot===slot&&a.part===part);
      if(!item)return null;
      return (S?.avatarInv?.accessories||[]).includes(item.id)?null:{id:item.id,price:item.price,name:item.name};
    },
    titles:()=>R6_TITLES.map(t=>({...t,owned:(S?.avatarInv?.titles||[]).includes(t.id)})),
    load:async()=>({avatar:S?.avatar||null,title:S?.avatarInv?.equipped?.title||null,title_name:S?.avatar?.title||'',owned:window.TG_AVATAR_NET.owned(),catalog:window.TG_AVATAR_NET.catalog()}),
    mine:()=>S?.avatar||null
  };
}


const R6_ALIAS={jade:"jade_pendant",whitehorse:"white_horse",whitedeer:"white_deer",greenox:"green_ox",bells:"saddle_bell"};
const canonical=id=>R6_ALIAS[id]||id;
function r6MeritPrice(id){
  id=canonical(id);
  if(window.TG_MERIT&&!TG_MERIT.__offline){const price=TG_MERIT.price?.(id);if(price!=null)return price;}
  const cat=(window.TG_CATALOG||[]).find(c=>c.id===id);
  if(cat&&cat.meritPrice!=null)return cat.meritPrice|0;
  const acc=R6_ACC.find(a=>a.id===id); if(acc)return acc.price|0;
  const title=R6_TITLES.find(t=>t.id===id); if(title)return title.price|0;
  const mounts={white_horse:5000,white_deer:9000,green_ox:9000,saddle_bell:2000};
  return mounts[id]!=null?mounts[id]:null;
}
function r6GrantMeritItem(id){
  S.avatarInv??={accessories:[],titles:[],equipped:{}};
  const acc=R6_ACC.find(a=>a.id===id);
  const title=R6_TITLES.find(t=>t.id===id);
  if(acc){const list=S.avatarInv.accessories??=[]; if(!list.includes(id))list.push(id); return;}
  if(title){const list=S.avatarInv.titles??=[]; if(!list.includes(id))list.push(id); return;}
  S.backpack[id]=(S.backpack[id]||0)+1;
}
const R6_REASON={poor:'善缘不足',offline:'需联网才能点灯',unknown:'暂未开放',rate:'今日次数已用完',daily:'今日次数已用完',error:'网络异常，请重试',owned:'已经拥有了',busy:'正在处理，请稍候',free:'免费，无需购买',bad_req:'请求无效，请重试',not_owned:'尚未拥有该装扮',title_not_owned:'尚未获得该称号',bad_name:'名称不可用',bad_title:'称号无效',bad_acc:'配饰无效',bad_avatar:'容貌数据无效',too_big:'数据过大',bad_value:'数据无效',bad_key:'数据无效',no_hooks:'暂不可用',unauthorized:'请先登录',auth:'请先登录'};
if(!window.TG_MERIT){
  const inflight=new Set(),bought={};
  const catalog=()=>({items:[...(window.TG_CATALOG||[]).filter(c=>c.meritPrice!=null).map(c=>({...c,kind:'decor',price:c.meritPrice})),...R6_ACC.filter(a=>a.id!=='beads'),...R6_TITLES,...Object.entries({white_horse:5000,white_deer:9000,green_ox:9000,saddle_bell:2000}).map(([id,price])=>({id,price,kind:id==='saddle_bell'?'mount_decor':'mount'}))],aliases:{...R6_ALIAS},bought:{...bought},owned:TG_AVATAR_NET.owned()});
  window.TG_MERIT={
    __offline:true,id:canonical,price:r6MeritPrice,busy:id=>inflight.has(canonical(id)),bought:id=>bought[canonical(id)]||0,
    catalog,load:async()=>catalog(),reasonText:r=>R6_REASON[typeof r==='string'?r:r?.reason]||'暂时无法购买',
    spend:async function(id){
      id=canonical(id);
      if(inflight.has(id))return {ok:false,reason:'busy',item:id};
      inflight.add(id);
      let charged=false,price;
      try{
        // Yield with the lock held so simultaneous calls observe busy.
        await Promise.resolve();
        const item=catalog().items.find(c=>c.id===id);price=item?.price;
        if(price==null)return {ok:false,reason:'unknown',item:id};
        if((item.kind==='accessory'||item.kind==='title')&&TG_AVATAR_NET.owned().includes(id))return {ok:false,reason:'owned',item:id};
        if(price===0)return {ok:false,reason:'free',item:id};
        if(!await window.TG_MERIT_ADD(-price))return {ok:false,reason:'poor',item:id};
        charged=true;bought[id]=(bought[id]||0)+1;
        return {ok:true,item:id,kind:item.kind,price};
      }catch(e){if(charged)await window.TG_MERIT_ADD(price);return {ok:false,reason:'error',item:id};}
      finally{inflight.delete(id);}
    }
  };
}

window.TG_MERIT_GET=()=>S.merit|0;
window.TG_MERIT_ADD=function(n){
  n=Number(n)||0;
  if(!n)return true;
  if(n<0&&(S.merit|0)+n<0)return false;
  if(typeof addMerit==='function'&&n>0)addMerit(n);
  else{S.merit=(S.merit|0)+n;if(S.merit<0)S.merit=0;save();renderTop?.();}
  return true;
};


/* Force default accessories to all 'none' for unsaved/missing acc (avatar.js DEF already does this). */
(function(){
  const A=window.TG_AVATAR; if(!A||A._r6AccNone)return;
  const NONE={head:'none',neck:'none',waist:'none',back:'none',hand:'none'};
  const def=A.defaultConfig;
  A.defaultConfig=function(){
    const c=def?def.apply(this,arguments):{};
    c.acc={...NONE};
    return c;
  };
  const norm=A.normalize;
  if(norm)A.normalize=function(c,opts){
    if(!c||typeof c!=='object'||!c.acc)c=Object.assign({},c||{},{acc:{...NONE}});
    return norm.call(this,c,opts);
  };
  A._r6AccNone=true;
})();

const _san=sanitizeR4;
sanitizeR4=function(d){
  const title=d.avatar?.title;
  const acc=d.avatar?.acc?{...d.avatar.acc}:null;
  _san(d);
  if(window.TG_AVATAR?.normalize){
    if(d.avatar){
      if(title&&!d.avatar.title)d.avatar.title=title;
      if(acc)d.avatar.acc={...acc,...(d.avatar.acc||{})};
    }
    d.avatar=TG_AVATAR.normalize(d.avatar||TG_AVATAR.defaultConfig?.()||{},{checkOwned:false});
  }
};

window.r6RevalidateAvatar=function(){
  const A=window.TG_AVATAR;if(!A?.normalize||!S?.avatar)return;
  const N=window.TG_AVATAR_NET;if(!N?.catalog?.()?.length)return;
  S.avatar=A.normalize(S.avatar);
  for(const [slot,part]of Object.entries(S.avatar.acc||{}))if(part!=='none'&&N.locked?.(slot,part))S.avatar.acc[slot]='none';
  save();
  r6ApplyAvatar?.();
};
addEventListener('tg-avatar',()=>r6RevalidateAvatar());
setTimeout(()=>{if(window.TG_AVATAR_NET?.catalog?.()?.length)r6RevalidateAvatar();},0);


const _water=typeof waterPlot==='function'?waterPlot:null;
if(_water)window.waterPlot=waterPlot=function(i,el,showMsg){
  const p=S.plots?.[i],before=p?p.boost||0:0;
  const out=_water.apply(this,arguments);
  if(p&&(p.boost||0)>0.25)p.boost=0.25;
  if(p&&before!==p.boost)save();
  return out;
};

const _earn=window.r6EarnCoins;
window.r6EarnCoins=function(n,source,exact){
  if(!r3CanEdit()||!Number.isSafeInteger(n)||n<0)return false;
  if(window.TG_ECON?.earn){
    const actual=Number(TG_ECON.earn(n,source||'task',!!exact))||0;
    if(actual<=0){toast('今日铜钱已达上限');return false;}
    const d=r6Daily();
    d.coinsEarned=(d.coinsEarned||0)+actual;
    S.coins=(S.coins||0)+actual;
    save();renderTop();
    return true;
  }
  return _earn?_earn(n):false;
};

const _grant=window.r6GrantMerit;
window.r6GrantMerit=function(source,amount){
  if(source==='koi'&&window.TG_LOTUS?.koi){
    try{
      const r=TG_LOTUS.koi();
      if(r&&r.ok===false){toast(r.reason==='daily'?'今日锦鲤归水已达上限':'今日善缘已满');return 0;}
    }catch(e){}
  }
  return _grant?_grant(source,amount):0;
};

window.r6OwnedTitleRows=function(){
  const net=window.TG_AVATAR_NET;
  if(net?.titles){
    try{
      const list=net.titles();
      if(Array.isArray(list))return list.filter(t=>t&&(t.owned===true||t.owned===1||t.have)).map(t=>({id:t.id||t.key,name:t.name||TITLE_NAME[t.id]||t.id,emoji:t.emoji||''}));
    }catch(e){}
  }
  return (S.avatarInv?.titles||[]).map(id=>({id,name:TITLE_NAME[id]||id,emoji:''}));
};

window.r6PickTitle=function(idOrName){
  const rows=r6OwnedTitleRows();
  const row=rows.find(t=>t.id===idOrName||t.name===idOrName);
  if(idOrName&&!row)return toast('尚未获得此称号'),false;
  S.avatarInv??={accessories:[],titles:[],equipped:{}};
  S.avatarInv.equipped??={};
  S.avatarInv.equipped.title=row?row.id:null;
  if(S.avatar)S.avatar.title=row?row.name:'';
  save();
  r6ApplyAvatar?.();
  return true;
};

window.r6TitlePickerHtml=function(){
  const owned=r6OwnedTitleRows();
  if(!owned.length)return '<p class="muted">尚未获得称号</p>';
  const cur=S.avatar?.title||S.avatarInv?.equipped?.title||'';
  return '<p>称号</p><select id="r6TitlePick"><option value="">（不佩戴）</option>'+owned.map(t=>`<option value="${r3Esc(t.id)}"${(t.id===cur||t.name===cur)?' selected':''}>${r3Esc((t.emoji?t.emoji+' ':'')+t.name)}</option>`).join('')+'</select>';
};

window.r6CatalogId=id=>window.TG_MERIT?.id?.(id)||canonical(id);
window.r6MeritPrice=r6MeritPrice;
window.r6ToastReason=result=>{
  const r=typeof result==='string'?{reason:result}:result;
  // Save validation reasons are not included in the backend merit map.
  if(['not_owned','title_not_owned','bad_name','bad_title','bad_acc','bad_avatar','too_big','bad_value','bad_key'].includes(r?.reason))return R6_REASON[r.reason];
  return window.TG_MERIT?.reasonText?.(r)||R6_REASON[r?.reason]||'暂不可用，请稍后重试';
};
window.r6Purchases=new Set();
window.r6Purchase=async function(id,fn){id=r6CatalogId(id);if(r6Purchases.has(id))return false;r6Purchases.add(id);try{return await fn();}finally{r6Purchases.delete(id);}};
if(TG_AVATAR_NET.__offline&&!TG_AVATAR_NET.buy)TG_AVATAR_NET.buy=async function(id){
  id=r6CatalogId(id);const c=R6_ACC.concat(R6_TITLES).find(c=>c.id===id);
  if(!c)return {ok:false,reason:'unknown'};
  if(TG_AVATAR_NET.owned().includes(id))return {ok:false,reason:'owned'};
  const r=await TG_MERIT.spend(id);if(r?.ok!==true)return r;
  r6GrantMeritItem(r.item);save();return r;
};
const shop=openShop;
openShop=function(tab){
  const out=shop.apply(this,arguments);
  if(tab==='merit'){
    const host=$('#sheet');
    if(host&&!host.querySelector('#r6TitlePick')){
      host.insertAdjacentHTML('beforeend',r6TitlePickerHtml());
      const sel=host.querySelector('#r6TitlePick');
      if(sel)sel.onchange=()=>r6PickTitle(sel.value||null);
    }
    host?.querySelectorAll('[data-r6-buy],[data-merit-buy]').forEach(b=>{
      const itemId=r6CatalogId(b.dataset.r6Buy||b.dataset.meritBuy);
      b.disabled=!!(b.dataset.busy||TG_MERIT.busy?.(itemId));
      b.style.opacity=b.disabled?'0.5':'';
      const price=TG_MERIT.price?.(itemId);
      if(price!=null){const label=b.closest?.('article')?.querySelector('small');if(label)label.textContent=price+' 善缘';}
      b.onclick=async ev=>{
        ev?.preventDefault?.(); ev?.stopPropagation?.();
        if(b.dataset.busy||r3DenyVisit?.())return;
        const id=r6CatalogId(b.dataset.r6Buy||b.dataset.meritBuy);
        if(!id)return;
        b.dataset.busy='1';b.disabled=true;
        try{await r6Purchase(id,async()=>{
          const avatar=R6_ACC.some(a=>a.id===id)||R6_TITLES.some(t=>t.id===id);
          const r=avatar&&TG_AVATAR_NET.buy?await TG_AVATAR_NET.buy(id):await TG_MERIT.spend(id);
          if(r?.ok!==true){toast(r6ToastReason(r));return false;}
          r6GrantMeritItem(r.item);save();renderTop?.();openShop('merit');
          if(avatar)Promise.resolve(TG_AVATAR_NET.load?.()).catch(()=>{});
          return true;
        });}catch(e){toast(r6ToastReason('error'));}
        finally{delete b.dataset.busy;b.disabled=!!TG_MERIT.busy?.(id);b.style.opacity=b.disabled?"0.5":"";}

      };
    });
  }
  if(tab==='sell'){
    for(const b of $('#sheet').querySelectorAll('[data-sell],[data-sell-all]')){
      b.onclick=()=>{
        if(r3DenyVisit())return;
        const id=b.dataset.sell||b.dataset.sellAll,c=CROP_BY_ID[id]||r3ProduceItem?.(id);
        const n=b.dataset.sellAll?S.inventory[id]:1;
        if(!c||!n||!r6EarnCoins(n*(c.sell??((c.value||1)*8)),'sell',true))return;
        S.inventory[id]-=n;save();openShop('sell');
      };
    }
  }
  return out;
};

const _lead=window.r6LeadOut,_park=window.r6ParkMount;
function netRiding(m){
  const N=window.TG_MOUNT_NET;if(!N)return;
  try{if(m){N.setRiding?.(m);N.save?.(m);}else{N.setRiding?.(null);N.leaveRide?.();}}catch(e){}
}
if(_lead)window.r6LeadOut=function(){const ok=_lead.apply(this,arguments);if(ok)netRiding(window.r6MountNet?.());return ok;};
if(_park)window.r6ParkMount=function(){const ok=_park.apply(this,arguments);netRiding(null);return ok;};

const originalGo=go;
let r6GoQueued=null;
function r6DrainGo(){
  if(typeof switching!=='undefined'&&switching){setTimeout(r6DrainGo,40);return;}
  if(!r6GoQueued)return;
  const q=r6GoQueued;r6GoQueued=null;go(q[0],q[1]);
}
go=async function(name,instant){
  if(name==='teahouse')name='tea';
  if(typeof switching!=='undefined'&&switching){r6GoQueued=[name,instant];setTimeout(r6DrainGo,40);return;}
  const out=await originalGo.call(this,name,instant);
  if(r6GoQueued){const q=r6GoQueued;r6GoQueued=null;return go(q[0],q[1]);}
  return out;
};
window.addEventListener('hashchange',()=>{if(location.hash==='#teahouse')go('teahouse');});

function aliasSpaces(){
  // Same group must not be a second enumerable key: worldEnter does
  //   spaces[n].group.visible = (n===name)
  // so a later 'teahouse' key would hide the courtyard after go('tea').
  if(!W3?.spaces?.tea)return;
  if(Object.prototype.hasOwnProperty.call(W3.spaces,'teahouse')&&W3.spaces.teahouse===W3.spaces.tea && !Object.getOwnPropertyDescriptor(W3.spaces,'teahouse')?.get){
    try{delete W3.spaces.teahouse;}catch(e){}
  }
  if(!Object.getOwnPropertyDescriptor(W3.spaces,'teahouse')){
    Object.defineProperty(W3.spaces,'teahouse',{get(){return W3.spaces.tea;},enumerable:false,configurable:true});
  }
}
const _enter=worldEnter;
worldEnter=function(name,previous){
  aliasSpaces();
  const out=_enter.apply(this,arguments);
  aliasSpaces();
  return out;
};
if(W3)aliasSpaces();
})();
