
/* r8a.2 — fixes from codex2's r8a re-check (qa/r8-audit/r8a-recheck.md, qa/r8a-recheck/buttons.r8a.md).
   Camera: see worldCamera above (trunk never tilted over, collision pull-in rate-limited, 0.7 m/frame hard cap).
   This block: 🎐 on-screen in landscape, gate card, every dead button answers, overlays close on backdrop/Esc,
   overlapping 3D prompts pulled apart, 44 px hit areas. Economy, IDs, save key and RPCs untouched. */
(function(){
 const $q=s=>document.querySelector(s),say=m=>{try{toast(m);}catch(e){}};
 const css=document.createElement('style');css.id='r8a2-css';css.textContent=`
#hall.active #muyu{top:calc(var(--safe-top,0px) + min(445px,100vh - 160px))!important}
@media (orientation:landscape) and (max-height:540px){#hall.active #muyu{top:auto!important;bottom:calc(env(safe-area-inset-bottom,0px) + 18px)!important;right:calc(env(safe-area-inset-right,0px) + 24px)!important;left:auto!important}}
#gateLock{position:fixed!important;inset:0!important;z-index:1000!important;padding:max(20px,env(safe-area-inset-top)) max(20px,env(safe-area-inset-right)) max(20px,env(safe-area-inset-bottom)) max(20px,env(safe-area-inset-left))!important}
#gateLock #lockBack{min-height:var(--tg-hit,44px);min-width:148px;padding:0 24px;font-size:15px}
#r41Waypoints button{min-height:var(--tg-hit,44px)!important;font-size:13px!important}
#r7MenuToggle{min-height:var(--tg-hit,44px)!important;min-width:var(--tg-hit,44px)!important}
#sheet .btn,#sheet .inv-item,#sheet .r3-tabs button,#sheet .dirs button,#r6Placement .btn,#r7Drawer .btn{min-height:var(--tg-hit,44px)}
#sheet textarea,.tgfb-root textarea{min-height:88px}
#sheet>.close[data-close]{min-width:var(--tg-hit,44px);min-height:var(--tg-hit,44px)}
#sheet select,#sheet input:not([type=checkbox]):not([type=radio]){min-height:var(--tg-hit,44px)}
.r6-pond-tabs .btn.r8a2-on{background:#c9a24a!important;color:#3a2410!important;border-color:#a8822e!important;cursor:default}
#toast{max-width:min(92vw,520px)}
`;document.head.append(css);

 // ---- 家庭: offline / not signed in, it used to close the menu and do nothing.
 document.addEventListener('click',e=>{const b=e.target.closest?.('#r7Family');if(!b||typeof window.TG_FAMILY?.open==='function')return;
  e.stopImmediatePropagation();e.preventDefault();try{closeModal();}catch(_){}
  openModal('<h2>家庭</h2><p>家庭要登录并联网后使用：邀请家人、一起照看小院、共乘牛车。</p><p class="muted">现在是本地存档。登录后就能创建或加入家庭。</p><p class="center" style="display:flex;gap:10px;justify-content:center"><button class="btn" id="r8a2Login">去登录</button><button class="btn ghost" id="r8a2Later">知道了</button></p>');
  const L=$q('#r8a2Login');if(L)L.onclick=()=>{closeModal();const a=$q('#btnAuth');if(a&&a.offsetParent)a.click();else say('登录需要联网');};
  const K=$q('#r8a2Later');if(K)K.onclick=()=>closeModal();},true);

 // ---- 🪙 pill: when the shop is already open it re-rendered the same sheet; now it toggles the shop closed.
 document.addEventListener('click',e=>{const b=e.target.closest?.('#pillCoins');if(!b||b.disabled)return;
  if($q('#modal')?.classList.contains('show')&&$q('#sheet .r3-tabs')){e.stopImmediatePropagation();closeModal();}},true);
 // ---- ✨ pill: same message as before, but always readable (landscape toast sat under the HUD).
 // (text is rewritten to 善缘/点灯/摇风铃 by r7-compliance; nothing to change here besides the toast width above)

 // ---- 抽一首诗: the result appeared only after a 2.6 s shake → instant, within one frame.
 const VERSES=[['明月松间照，清泉石上流。','王维'],['采菊东篱下，悠然见南山。','陶渊明'],['绿树村边合，青山郭外斜。','孟浩然'],['海内存知己，天涯若比邻。','王勃'],['行到水穷处，坐看云起时。','王维'],['草长莺飞二月天，拂堤杨柳醉春烟。','高鼎'],['小荷才露尖尖角，早有蜻蜓立上头。','杨万里'],['春眠不觉晓，处处闻啼鸟。','孟浩然'],['等闲识得东风面，万紫千红总是春。','朱熹'],['竹外桃花三两枝，春江水暖鸭先知。','苏轼'],['人闲桂花落，夜静春山空。','王维'],['山重水复疑无路，柳暗花明又一村。','陆游']];
 function poem(){const box=$q('#qianResult');if(!box)return;let i=Math.floor(Math.random()*VERSES.length);if(i===S.r8a2Poem)i=(i+1)%VERSES.length;S.r8a2Poem=i;
  try{tgFeedback('qian');}catch(e){}$q('#tube')?.classList.remove('shaking');document.querySelectorAll('#tubeWrap .outstick').forEach(n=>n.remove());
  const [v,who]=VERSES[i];box.innerHTML=`<div class="qian"><div class="no">今日诗句</div><div class="poem">${v}</div><p style="font-size:13px;color:#9a7a50">—— ${who}</p><p>慢慢来，把眼前的小事做好，也记得照顾自己。</p></div><p class="center"><button class="btn ghost" id="qianAgain">再读一句</button></p>`;
  const b=$q('#qianBtn');if(b)b.disabled=false;requestAnimationFrame(()=>box.scrollIntoView?.({block:'nearest'}));}
 document.addEventListener('click',e=>{const b=e.target.closest?.('#qianBtn,#qianAgain');if(!b)return;e.stopImmediatePropagation();e.preventDefault();poem();},true);

 // ---- 赏景小记: the birth-year picker was a fortune-telling leftover and did nothing visible — removed.
 const om=openModal;openModal=function(){const r=om.apply(this,arguments);try{post();}catch(e){}return r;};
 function post(){const y=$q('#fengYear');if(y){const row=y.closest('.form-row')||y.parentElement;if(row)row.style.display='none';y.tabIndex=-1;
   // r7d keeps rewriting the first <p> after the title, so show our own line and hide that one
   const intro=$q('#sheet h2 + p');if(intro&&!$q('#r8a2FengIntro')){intro.style.display='none';const d=document.createElement('div');d.id='r8a2FengIntro';d.className='center';d.style.cssText='font-size:13px;color:#7a5a3a;margin:6px 0 10px';d.textContent='选一个院子朝向，写下今天的赏景小记。';intro.after(d);}}
  // 莲池 tabs: show which one is open (tapping the open tab looked dead)
  const tab=window.r8a2PondTab||'koi';document.querySelectorAll('#sheet .r6-pond-tabs [data-pond]').forEach(b=>{const on=b.dataset.pond===tab;b.classList.toggle('r8a2-on',on);b.setAttribute('aria-pressed',String(on));b.disabled=on;});}
 if(typeof window.r6PondOpen==='function'){const po=window.r6PondOpen;window.r6PondOpen=function(tab='koi'){window.r8a2PondTab=tab;return po.apply(this,arguments);};}

 document.addEventListener('click',e=>{if(!e.target.closest?.('#fengBtn'))return;const clean=()=>document.querySelectorAll('#fengResult p.center[style*="20px"],#fengResult p.center[style*="7a5a3a"]').forEach(n=>n.remove()); /* birth-year heading + 性格关键词 (derived from the year) */setTimeout(clean,0);setTimeout(clean,120);},true);
 // ---- 摆放心意: tapping a produce you don't have now says so (and where to get it).
 document.addEventListener('click',e=>{const b=e.target.closest?.('#sheet [data-r6-offer]');if(!b)return;const id=b.dataset.r6Offer;
  const bag=(typeof CROP_BY_ID!=='undefined'&&CROP_BY_ID[id])||(typeof R3_PRODUCE!=='undefined'&&R3_PRODUCE.some(c=>c.id===id))?S.inventory:S.backpack;
  if(!(bag&&bag[id]>0)){e.stopImmediatePropagation();const name=b.textContent.replace(/·.*$/,'').trim();say(`还没有${name}：先去心田小院收获，再来摆放`);b.classList.add('r8a2-empty');}},true);

 // ---- 茶会 留笺: empty note did nothing; a posted note had no confirmation.
 document.addEventListener('click',e=>{const b=e.target.closest?.('#r6Send');if(!b)return;const i=$q('#r6Message'),t=(i?.value||'').trim();
  if(!t){e.stopImmediatePropagation();say('先写一句再留笺');i?.focus();return;}
  const n=(S.tea?.messages||[]).length;setTimeout(()=>{if((S.tea?.messages||[]).length>n||!$q('#r6Message')||$q('#r6Message').value==='')say('留笺已贴上墙');},400);},true);

 // ---- 立体布置: 升高/降低/收回 with nothing selected gave no sign; Esc and a second tap on empty ground finish.
 document.addEventListener('click',e=>{const b=e.target.closest?.('#r6PlaceLower,#r6PlaceRaise,#r6PlaceReturn,#r6PlaceRotate');const p=W3?.r6Plan;if(!b||!p)return;
  if(b.id==='r6PlaceReturn'){if(p.selected<0){e.stopImmediatePropagation();say('先点一件已摆好的物品，再收回');}else setTimeout(()=>say('已收回背包'),30);return;}
  setTimeout(()=>{const q=W3.r6Plan;if(!q)return;const list=S.decor[q.scene]||[];
   if(b.id==='r6PlaceRotate'){say(q.selected>=0?'已旋转 90°':'下一件物品将旋转 90° 摆放');return;}
   if(q.selected>=0){const v=list[q.selected];say(`${r3Item(v?.id)?.name||'物品'} 高度 ${(v?.y||0).toFixed(1)} 米`);}else say(`放置高度 ${q.height>=0?'+':''}${q.height.toFixed(1)} 米 · 先在下方选一件物品`);},30);},true);
 const finish=()=>{const d=$q('#r6PlaceDone');if(d)d.click();};
 document.addEventListener('keydown',e=>{if(e.key!=='Escape')return;if(W3?.r6Plan&&$q('#r6Placement')){e.preventDefault();finish();return;}
  const dr=$q('#r7Drawer');if(dr&&!dr.hidden){dr.hidden=true;$q('#r7MenuToggle')?.setAttribute('aria-expanded','false');}});
 let emptyTap=0;
 function hookCanvas(){if(window.r8a2Taps)return;window.r8a2Taps=true;let down=null;
  addEventListener('pointerdown',e=>{down=W3?.r6Plan&&e.target===W3.canvas?{x:e.clientX,y:e.clientY,t:performance.now()}:null;},true);
  addEventListener('pointerup',e=>{const p=W3?.r6Plan,d=down;down=null;if(!p||!d||e.target!==W3.canvas||Math.hypot(e.clientX-d.x,e.clientY-d.y)>10||p.pick||p.selected>=0)return;
   // a tap that selects nothing = a tap on the "backdrop" of placement mode: first one hints, second one finishes
   setTimeout(()=>{const q=W3.r6Plan;if(!q||q.selected>=0||q.pick)return;const now=performance.now();if(now-emptyTap<2500){emptyTap=0;finish();}else{emptyTap=now;say('再点一次空白处结束布置（或点「完成」）');}},30);},true);}
 // ---- tool drawer: closes on a tap outside it (and on Esc, above)
 document.addEventListener('pointerdown',e=>{const dr=$q('#r7Drawer');if(!dr||dr.hidden)return;if(e.target.closest?.('#r7Drawer,#r7MenuToggle,#modal,#gateLock'))return;dr.hidden=true;$q('#r7MenuToggle')?.setAttribute('aria-expanded','false');},true);

 // ---- 3D prompts that stole each other's spot
 function separate(name){const s=W3?.spaces?.[name];if(!s)return;
  if(name==='hall'&&!s.r8a2){s.r8a2=true;// 摇风铃 sat 1.8 m from 前往书房: the auto-exit fires before the exit prompt could ever win
   const g=s.group.getObjectByName('r7-garden-chime');if(g){g.position.z+=-3.5;g.updateMatrixWorld(true);}
   for(const it of s.items)if(it.label==='摇风铃'&&Math.abs(it.x+4)<.2&&Math.abs(it.z-3)<.2){it.z=-.5;it.range=1.6;}
   (window.TG_R8?.changes||[]).push?.({scene:'hall',object:'摇风铃 (chime + prompt) away from 前往书房',from:'(-4,2) / prompt (-4,3)',to:'(-4,-1.5) / prompt (-4,-0.5)'});}
  if(name==='zen'){// legacy r3 seat prompts 「坐下」 duplicated the r7b cushions 「坐下喝茶」 on the same spots
   const tea=s.items.filter(i=>i.label==='坐下喝茶');s.items=s.items.filter(i=>!(i.r4Furniture&&i.label==='坐下'&&tea.some(t=>Math.hypot(t.x-i.x,t.z-i.z)<1.3)));}}
 const sync=worldSyncDecor;worldSyncDecor=function(){const r=sync.apply(this,arguments);try{separate(W3.active);}catch(e){}return r;};
 const en=worldEnter;worldEnter=function(){const r=en.apply(this,arguments);try{hookCanvas();separate(W3.active);}catch(e){}return r;};
 window.TG_R8A2={version:'r8a.2'};
})();
