/* r8d4 (来福): 缘堂 follow-ups to r8d3.
   (1) altar table: its top (5.4 × 0.3 × 1.5 m, y 1.2–1.5, z −6.55…−5.05) was merged into an r8c static batch, so r8d3's occluder fade could not
       touch it and in the facing-south view (camera between altar and back wall) it filled the lower frame. Cheapest fix: keep just that one mesh
       out of the batch (userData.r8cDyn — r8c's own skip flag) so it fades like every other prop, and fade it to 12 % (it sits right under the
       camera). Moving / lowering it would also move the candles, fruit plates and flames that sit on it and their colliders — more change, more risk.
   (2) portrait: standing against the east / west wall puts the 家和业兴 plaque at the top edge where the location-button row is. The row now steps
       down below the plaque while they would touch (eased, never below 40 % of the screen), and goes back when clear. Landscape: same check. */
(()=>{
'use strict';
const T=THREE,R=window.TG_R8D4={version:'r8d5',altar:0,avoid:{n:0,max:0,now:0}};
const near=(a,b,e=.03)=>Math.abs(a-b)<e;
function markAltar(){const h=W3?.spaces?.hall;if(!h)return 0;let n=0;
 for(const o of h.group.children){if(!o.isMesh||o.userData.r8d4Altar)continue;const p=o.position,g=o.geometry;g.computeBoundingBox?.();const b=g.boundingBox;if(!b)continue;const s=b.getSize(new T.Vector3()).multiply(o.scale);
  if(near(p.x,0)&&near(p.y,1.35)&&near(p.z,-5.8)&&s.x>5&&s.y<.5){o.userData.r8cDyn=true;o.userData.r8d4Altar=true;o.userData.r8d4Alpha=.12;n++;}}
 R.altar+=n;return n;}
function unbatchIfNeeded(){const h=W3?.spaces?.hall;if(!h?.r8c?.batches?.length)return;// altar already merged (hall batched before this ran) → re-batch once
 const hidden=[];h.group.traverse(o=>{if(o.userData?.r8d4Altar&&o.userData.r8cIn)hidden.push(o);});if(!hidden.length)return;
 try{for(const b of [...h.r8c.batches]){if(b.recs.some(r=>hidden.includes(r.o))){b.px.parent?.remove(b.px);b.px.geometry.dispose();b.px.material.dispose();h.r8c.batches.splice(h.r8c.batches.indexOf(b),1);
   for(const r of b.recs){r.o.visible=true;r.o.userData.r8cIn=false;}}}window.TG_R8C?.batchNow?.('hall');R.rebatched=true;}catch(e){R.err=String(e);}}
/* (3) layout review (AABB, r8d4/out/halldump-*.json): 10 intersections existed in r8d3 (and earlier):
   - altar legs (y 0–1.3) ran 0.1 m up into the table top (y 1.2–1.5) → legs end at 1.2;
   - the 4 art3 pillars next to the 静室 / 书房 doors (z 0.95 / 5.05) stood 0.4 m from the door posts (z 1.35 / 4.65): plinths and door-post bases
     interpenetrated (0.07–0.16 m) → those pillars (every art3 instance at that spot: shaft, plinth …) move 0.35 m away from the door, colliders with them. */
function layout(){const h=W3?.spaces?.hall;if(!h)return;R.layout=R.layout||{legs:0,pillars:0,blocks:0};
 for(const o of h.group.children){if(!o.isMesh||o.userData.r8d4Leg)continue;const p=o.position;if(near(Math.abs(p.x),2.3)&&near(p.y,.65)&&near(p.z,-5.8)){o.userData.r8d4Leg=true;o.scale.y*=1.2/1.3;o.position.y=.6;R.layout.legs++;}}
 const st=h.art3Styles?.root||h.group.getObjectByName('art3-shrine');
 if(st&&!st.userData.r8d4Pillars){st.userData.r8d4Pillars=true;st.updateMatrixWorld(true);const m4=new T.Matrix4(),pp=new T.Vector3(),q=new T.Quaternion(),sc=new T.Vector3(),wp=new T.Vector3();
  st.traverse(o=>{if(!o.isInstancedMesh)return;let ch=0;for(let i=0;i<o.count;i++){o.getMatrixAt(i,m4);m4.decompose(pp,q,sc);wp.copy(pp).applyMatrix4(o.matrixWorld);
   if(near(Math.abs(wp.x),5.62,.06)&&(near(wp.z,.95,.06)||near(wp.z,5.05,.06))){const dz=wp.z<3?-.35:.35;const lw=new T.Vector3(wp.x,wp.y,wp.z+dz),inv=o.matrixWorld.clone().invert();lw.applyMatrix4(inv);pp.copy(lw);m4.compose(pp,q,sc);o.setMatrixAt(i,m4);ch++;}}
   if(ch){o.instanceMatrix.needsUpdate=true;o.computeBoundingSphere?.();o.computeBoundingBox?.();R.layout.pillars+=ch;}});}
 // r8d5 (codex2 L2 HALL-004/005): the upper art3 wall rails (y 3.32–3.44, x ±5.8) run 0.05/0.15 m into the 静室/书房 door lintels
 // (r3.js:46, y 3.39–3.61, z 0.85–5.15). Trim each rail so it ends 1 cm short of the lintel face (runtime only; art3.js untouched).
 if(st){const lint=[],gb=new T.Box3();h.group.updateMatrixWorld(true);h.group.traverse(o=>{if(!o.isMesh||o.isInstancedMesh)return;for(let q=o;q;q=q.parent)if(q===st)return;const g=o.geometry;if(!g)return;g.computeBoundingBox?.();if(!g.boundingBox)return;gb.copy(g.boundingBox).applyMatrix4(o.matrixWorld);const sz=gb.getSize(new T.Vector3()),c=gb.getCenter(new T.Vector3());
   if(near(sz.y,.22,.03)&&near(gb.min.y,3.39,.04)&&sz.z>3.5&&sz.x<1.5&&near(Math.abs(c.x),5.6,.3))lint.push(gb.clone());});
  R.layout.lintels=lint.length;const m4=new T.Matrix4(),pp=new T.Vector3(),q=new T.Quaternion(),sc=new T.Vector3(),bb=new T.Box3(),wc=new T.Vector3(),ov=(a,b,e)=>Math.min(a.max.x,b.max.x)-Math.max(a.min.x,b.min.x)>e&&Math.min(a.max.y,b.max.y)-Math.max(a.min.y,b.min.y)>e&&Math.min(a.max.z,b.max.z)-Math.max(a.min.z,b.min.z)>e;
  if(lint.length)st.traverse(o=>{if(!o.isInstancedMesh||o.userData.r8d5Rails)return;o.userData.r8d5Rails=true;o.geometry.computeBoundingBox();const gbb=o.geometry.boundingBox;let ch=0;
   for(let i=0;i<o.count;i++){o.getMatrixAt(i,m4);bb.copy(gbb).applyMatrix4(m4).applyMatrix4(o.matrixWorld);const s3=bb.getSize(new T.Vector3());if(s3.z<1||s3.x>.3||s3.y>.3)continue;
    for(const L of lint){if(!ov(bb,L,.002))continue;const z0=bb.min.z,z1=bb.max.z,lc=(L.min.z+L.max.z)/2;let n0=z0,n1=z1;if((z0+z1)/2<lc)n1=Math.min(z1,L.min.z-.01);else n0=Math.max(z0,L.max.z+.01);if(n1-n0<.2)continue;
     m4.decompose(pp,q,sc);const e=o.matrixWorld.elements;if(Math.abs(q.w)<.9999||Math.abs(e[2])>1e-4||Math.abs(e[8])>1e-4)continue; // axis-aligned rails only
     const f=(n1-n0)/(z1-z0);wc.copy(pp).applyMatrix4(o.matrixWorld);wc.z+=((n0+n1)-(z0+z1))/2;pp.copy(wc.applyMatrix4(o.matrixWorld.clone().invert()));sc.z*=f;m4.compose(pp,q,sc);o.setMatrixAt(i,m4);
     bb.copy(gbb).applyMatrix4(m4).applyMatrix4(o.matrixWorld);ch++;}}
   if(ch){o.instanceMatrix.needsUpdate=true;o.computeBoundingSphere?.();o.computeBoundingBox?.();R.layout.rails=(R.layout.rails||0)+ch;}});}
 for(const b of h.blocks||[]){if(b.r8d4)continue;const cx=(b.x+b.X)/2,cz=(b.z+b.Z)/2;if(near(Math.abs(cx),5.62,.06)&&(near(cz,.95,.06)||near(cz,5.05,.06))){const dz=cz<3?-.35:.35;b.z+=dz;b.Z+=dz;b.r8d4=true;R.layout.blocks++;}}}
markAltar();
const enter=worldEnter;worldEnter=function(name){try{markAltar();layout();}catch(e){}const out=enter.apply(this,arguments);if(W3?.active==='hall'){try{markAltar();layout();unbatchIfNeeded();}catch(e){R.err=String(e);}}return out;};
// (2) location buttons avoid the plaque
const v=new T.Vector3();let off=0,k=0,plaque=null;
function plaqueRect(h,cam,W,H){if(!plaque||plaque.parent==null){plaque=null;for(const o of h.group.children)if(o.isMesh&&o.userData.wallSign&&near(o.position.z,-7.78,.05)){plaque=o;break;}}if(!plaque||!plaque.visible)return null;
 const b=new T.Box3().setFromObject(plaque);let l=1e9,r=-1e9,t=1e9,bt=-1e9,front=false;for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y]){v.set(x,y,b.max.z).project(cam);if(v.z>=1)continue;front=true;const sx=(v.x+1)/2*W,sy=(1-v.y)/2*H;l=Math.min(l,sx);r=Math.max(r,sx);t=Math.min(t,sy);bt=Math.max(bt,sy);}
 // r8d5: corners behind the camera are skipped (as in rectOf) and the plaque only counts when its centre is on screen (as the sign test)
 const cx=(l+r)/2,cy=(t+bt)/2;return front&&cx>0&&cx<W&&cy>0&&cy<H?{l,r,t,b:bt}:null;}
// r8d4b: the row must also stay clear of every door-sign / couplet / painting text plane (not only the plaque).
let signs=null,signGroup=null,tgt=0,tsc=1,sc=1,origin='top center';
function textMeshes(h){if(signs&&signGroup===h.group)return signs;signGroup=h.group;signs=[];h.group.traverse(o=>{if(!o.isMesh||!o.material?.map)return;const u=o.userData;if(!(u.r41Label||u.wallSign||o.material.map.image?.__r8c2Text))return;if(h.plaqueGroup&&o.parent===h.plaqueGroup)return;signs.push(o);});return signs;}
const nrm=new T.Vector3(),toC=new T.Vector3();
function rectOf(o,cam,W,H){for(let q=o;q;q=q.parent)if(!q.visible)return null;if(!o.layers.test(cam.layers))return null;
 o.getWorldDirection(nrm);o.getWorldPosition(toC);toC.sub(cam.position).negate().normalize();if(Math.abs(nrm.dot(toC))<.3)return null; // edge-on: text not readable
const b=new T.Box3().setFromObject(o);if(b.isEmpty())return null;let l=1e9,r=-1e9,t=1e9,bt=-1e9,front=false;
 for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z]){v.set(x,y,z).project(cam);if(v.z>=1)continue;front=true;const sx=(v.x+1)/2*W,sy=(1-v.y)/2*H;l=Math.min(l,sx);r=Math.max(r,sx);t=Math.min(t,sy);bt=Math.max(bt,sy);}
 return front&&r>0&&l<W&&bt>0&&t<H?{l,r,t,b:bt}:null;}
const rc=new T.Raycaster(),occ=new Map();
// a sign hidden behind an opaque wall/pillar/door frame is not readable -> no need to dodge it (3 sample points, any clear = visible)
function occluded(o,cam,h){const now=performance.now(),c=occ.get(o);if(c&&now-c.t<300)return c.v;const b=new T.Box3().setFromObject(o),cen=b.getCenter(new T.Vector3()),sz=b.getSize(new T.Vector3());
 const pts=[cen,cen.clone().add(new T.Vector3(sz.x*.35,0,sz.z*.35)),cen.clone().add(new T.Vector3(-sz.x*.35,0,-sz.z*.35))];rc.layers.mask=cam.layers.mask;let vis=false;
 for(const p of pts){const dir=p.clone().sub(cam.position),d=dir.length();rc.set(cam.position,dir.normalize());rc.far=d-.06;const hits=rc.intersectObjects(h.group.children,true);let blocked=false;
  for(const it of hits){const m=it.object;if(m===o||m.userData.r41Label||m.userData.wallSign)continue;let hidden=false;for(let q=m;q;q=q.parent)if(!q.visible){hidden=true;break;}if(hidden)continue;const mat=Array.isArray(m.material)?m.material[0]:m.material;if(!mat||mat.visible===false||(mat.transparent&&mat.opacity<.5))continue;blocked=true;break;}
  if(!blocked){vis=true;break;}}
 occ.set(o,{t:now,v:!vis});return !vis;}
function avoid(){const w=W3,nav=document.getElementById('r41Waypoints');if(!nav)return;const h=w?.spaces?.hall;
 if(w?.active==='hall'&&h&&S.view!=='fp'){if((k++%4)===0){const W=innerWidth,H=innerHeight,cam=w.camera;cam.updateMatrixWorld();h.group.updateMatrixWorld();
  const pr=plaqueRect(h,cam,W,H),boxes=[];if(pr)boxes.push(pr);for(const o of textMeshes(h)){const r=rectOf(o,cam,W,H);if(r&&(r.l+r.r)/2>0&&(r.l+r.r)/2<W&&(r.t+r.b)/2>0&&(r.t+r.b)/2<H){const iw=(r.r-r.l)*.15,ih=(r.b-r.t)*.15;r.l+=iw;r.r-=iw;r.t+=ih;r.b-=ih;r.o=o;boxes.push(r);}}
  for(const e of document.querySelectorAll('#muyu,#joystick,#r7MenuToggle,section.scene.active button,section.scene.active .btn')){if(e.closest('#r41Waypoints'))continue;const r=e.getBoundingClientRect();if(r.width<4||r.height<4)continue;const cs=getComputedStyle(e);if(cs.display==='none'||cs.visibility==='hidden'||+cs.opacity===0)continue;boxes.push({l:r.left,r:r.right,t:r.top,b:r.bottom,hud:1});}
  const pl=w.player;if(pl){const p=pl.position;let l=1e9,r=-1e9,t=1e9,bt=-1e9,front=false;for(const dx of [-.3,.3])for(const dz of [-.3,.3])for(const dy of [1.25,1.85]){v.set(p.x+dx,p.y+dy,p.z+dz).project(cam);if(v.z>=1)continue;front=true;const sx=(v.x+1)/2*W,sy=(1-v.y)/2*H;l=Math.min(l,sx);r=Math.max(r,sx);t=Math.min(t,sy);bt=Math.max(bt,sy);}if(front)boxes.push({l,r,t,b:bt,soft:1});}
  // measure the row untransformed (cheap: 4 buttons), then search translateY d (and, only if no clear d exists, a smaller scale)
  const prevT=nav.style.transform;nav.style.transform='';const bs=[...nav.querySelectorAll('button')].filter(b=>b.getClientRects().length).map(b=>{const r=b.getBoundingClientRect();return {l:r.left,r:r.right,t:r.top,b:r.bottom};});const nr=nav.getBoundingClientRect();nav.style.transform=prevT;
  const wide=nr.width>=nr.height,ox0=wide?(nr.left+nr.right)/2:nr.right,oy0=nr.top;origin=wide?'top center':'top right';
  if(bs.length){let L=1e9,Rr=-1e9,t0=1e9,b0=-1e9;for(const b of bs){L=Math.min(L,b.l);Rr=Math.max(Rr,b.r);t0=Math.min(t0,b.t);b0=Math.max(b0,b.b);}const yMax=b0+Math.max(0,H*.42-t0);
   for(let i=boxes.length-1;i>=0;i--){const x=boxes[i];if(!x.o||x.r<L||x.l>Rr||x.b<t0||x.t>yMax)continue;if(occluded(x.o,cam,h))boxes.splice(i,1);}
   const cost=(d,sc)=>{let c=0;for(const q of bs){const l=ox0+(q.l-ox0)*sc,r=ox0+(q.r-ox0)*sc,t=oy0+(q.t-oy0)*sc+d,bb=oy0+(q.b-oy0)*sc+d;for(const x of boxes){const M=x.hud?-3:4,ox=Math.min(r,x.r+M)-Math.max(l,x.l-M),oy=Math.min(bb,x.b+M)-Math.max(t,x.t-M);if(ox>0&&oy>0)c+=ox*oy*(x.soft?1:100);}}return c;};
   const max=Math.max(0,H*.42-t0);
   R.avoid.why=boxes.filter(x=>bs.some(b=>{const M=x.hud?-3:4;return Math.min(b.r,x.r+M)-Math.max(b.l,x.l-M)>0&&Math.min(b.b,x.b+M)-Math.max(b.t,x.t-M)>0;})).map(x=>(x.o?(x.o.userData.r41Label||x.o.userData.wallSign||x.o.material.map.image?.__r8c2Text||'sign')+'@'+x.o.position.toArray().map(n=>n.toFixed(1)):x.soft?'head':x.hud?'hud':'plaque')+' '+[x.l,x.t,x.r,x.b].map(Math.round));
   if(cost(0,1)===0){tgt=0;tsc=1;}else if(!(cost(tgt,tsc)===0&&tgt<=max)){let best=[0,1],bc=cost(0,1),done=false;
    for(const sc of [1,.85,.72]){for(let d=0;d<=max;d+=2){const c=cost(d,sc)+(sc<1?.5:0);if(c<bc-1e-6){bc=c;best=[d,sc];}if(c<1){done=true;break;}}if(done)break;}
    [tgt,tsc]=best;R.avoid.residual=bc;}}
  else{tgt=0;tsc=1;}}}
 else{tgt=0;tsc=1;}const want=tgt;
 off+=(want-off)*(want>off?.6:.25);if(Math.abs(off-want)<.5)off=want;sc+=(tsc-sc)*.4;if(Math.abs(sc-tsc)<.005)sc=tsc;nav.style.transformOrigin=origin;nav.style.transform=(off>0.5||sc<.999)?`translateY(${off.toFixed(1)}px)`+(sc<.999?` scale(${sc.toFixed(3)})`:''):'';R.avoid.scale=+sc.toFixed(3);R.avoid.now=+off.toFixed(1);R.avoid.max=Math.max(R.avoid.max,off);if(want>0)R.avoid.n++;}
const anim=tgAnimate;tgAnimate=function(ts,dt){const out=anim.apply(this,arguments);try{avoid();}catch(e){R.avoidErr=String(e);}return out;};
R.avoidNow=avoid;R.markAltar=markAltar;
})();
