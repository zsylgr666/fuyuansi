/* r4.1: layout recovery and backend-independent social containment. */
function worldResize(){
 const w=W3,a=document.getElementById('app');if(!w?.renderer||!a)return;
 const x=a.clientWidth,y=a.clientHeight;if(x<100||y<100){clearTimeout(w.resizeRetry);w.resizeRetry=setTimeout(worldResize,50);return;}
 w.renderer.setSize(x,y,false);w.camera.aspect=x/y;w.camera.updateProjectionMatrix();
 if(w.active&&w.player){worldCamera(1);w.renderer.render(w.scene,w.camera);}
}
(()=>{
 const app=$('#app');
 const contain=()=>{document.querySelectorAll('body > .tgg-mask').forEach(el=>{app.append(el);el.classList.add('r41-contained');});};
 new MutationObserver(contain).observe(document.body,{childList:true});contain();
 new MutationObserver(worldResize).observe($('#modal'),{attributes:true,attributeFilter:['class']});
 // Persistent, tappable direction signs supplement the physical doors at phone size.
 const nav=document.createElement('nav');nav.id='r41Waypoints';nav.setAttribute('aria-label','场景出口');app.append(nav);
 const routes={plaza:[['南 · 里门','gate'],['东 · 集市','market'],['北 · 心田小院','yard'],['西 · 心田小院','yard',true]],hall:[['北 · 荷塘','lotus'],['东 · 静室','zen'],['西 · 书房','study']],yard:[['北 · 缘堂','hall'],['南 · 大厅','plaza']],gate:[['北 · 大厅','plaza']],market:[['西 · 大厅','plaza']],lotus:[['南 · 缘堂','hall']],zen:[['西 · 缘堂','hall']],study:[['东 · 缘堂','hall']]};
 const enter=worldEnter;worldEnter=function(name,previous){enter.apply(this,arguments);nav.innerHTML=(routes[W3.active]||[]).map(([text,to,west])=>`<button data-exit="${to}" data-west="${!!west}">${text} ↗</button>`).join('');nav.querySelectorAll('button').forEach(b=>b.onclick=()=>{if(b.dataset.west==='true')window.r4EastArrival=true;go(b.dataset.exit);});worldResize();requestAnimationFrame(worldResize);};
})();
// Billboards that would be cut by the phone edge stay hidden until fully readable.
(()=>{const animate=tgAnimate,point=new THREE.Vector3(),view=new THREE.Vector3();tgAnimate=function(ts,dt){animate(ts,dt);const w=W3;if(!w?.active)return;w.camera.updateMatrixWorld();w.spaces[w.active].group.traverse(m=>{if(!m.userData.r41Label||m.userData.r3OldTablet)return;m.getWorldPosition(point);view.copy(point).applyMatrix4(w.camera.matrixWorldInverse);const depth=-view.z,tan=Math.tan(w.camera.fov*Math.PI/360),hx=m.scale.x/(2*depth*tan*w.camera.aspect),hy=m.scale.y/(2*depth*tan);point.project(w.camera);m.visible=depth>0&&Math.abs(point.x)+hx<.97&&Math.abs(point.y)+hy<.97;});};})();
