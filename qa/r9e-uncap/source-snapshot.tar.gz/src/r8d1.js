/* r8d1 follow-up (on top of r8d; isolated file, last in pack)
   M-1: landscape 缘堂 — the interaction prompt sat on top of 🎐 (#muyu, right column). Prompt box moves left of the 🎐 column
        (right: 80px + safe area). Portrait / desktop unchanged. */
(()=>{const st=document.createElement('style');st.id='r8d1-style';
st.textContent=`@media (orientation:landscape){body[data-scene="hall"] #promptBtn{right:calc(80px + env(safe-area-inset-right,0px))!important;max-width:calc(100% - 260px)!important}}`;
document.head.appendChild(st);const R=window.TG_R8D1={version:'r8d1',hallBatch:[]};
/* M-4: 缘堂 draw calls. Unbatched, the restored hall (pillars, lattice, lanterns, shelves, paintings…) is ~150–156 calls per render
   in landscape; r8c merges static meshes only after a 1.5 s stability window (codex2's 156 is that window). Merge the hall's static
   geometry as part of the entry itself (≈50 ms, inside the scene-switch fade); r8c's own check() still un-merges anything that moves. */
/* M-3 (+ audit HALL-009): the hanging garden chime at (-3.13,-1.25) had no collider — the player could stand inside it (head in the chime). */
function chimeBlock(){const h=W3?.spaces?.hall;if(!h||h.blocks.some(b=>b.r8d1==='chime'))return;let c=null;h.group.traverse(o=>{if(!c&&o.name==='r7-garden-chime')c=o;});if(!c)return;const v=new THREE.Box3().setFromObject(c).getCenter(new THREE.Vector3());h.blocks.push({x:v.x-.3,X:v.x+.3,z:v.z-.3,Z:v.z+.3,r8d1:'chime'});R.chime=[+v.x.toFixed(2),+v.z.toFixed(2)];}
const en=worldEnter;worldEnter=function(){const r=en.apply(this,arguments);try{const w=W3;if(w?.active==='hall')chimeBlock();if(w?.active==='hall'&&window.TG_R8C?.batchNow){const s=w.spaces.hall;if(!(s.r8c?.batches?.length)){const t0=performance.now();const n=TG_R8C.batchNow('hall');R.hallBatch.push({n,ms:Math.round(performance.now()-t0)});}}}catch(e){R.err=String(e);}return r;};
})();
