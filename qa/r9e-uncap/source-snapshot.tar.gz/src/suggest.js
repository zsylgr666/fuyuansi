/* suggest.js — 福缘里 · 心田小院 意见箱界面  window.TG_FEEDBACK
 * 网络层由 backend/tg-suggest.js 在打包时注入为 window.TG_SUGGEST。本文件不定义、不覆盖 TG_SUGGEST，
 * 只在调用时读取 window.TG_SUGGEST（submit/list/followup/unread/count/markSeen/onUnread/reasonText/statusText/categories/limits）。
 * 菜单入口：window.TG_FEEDBACK.open() / close()；红点：hasUnread()、onBadge(cb)。
 * 前端另做一层屏蔽词过滤。无 THREE 依赖。可重复加载（幂等）。
 * r8：外观改用 ui-kit.js（TG_UI，需先于本文件打包）；提示走 TG_UI.toast 队列，面板层级走 TG_UI.openLayer。 */
(function(){
'use strict';
if(window.TG_FEEDBACK && window.TG_FEEDBACK.__v) return;
var VER=2;

var FALLBACK_CATS=[
  {id:'decor',name:'装饰'},
  {id:'gameplay',name:'玩法'},
  {id:'ui',name:'界面'},
  {id:'bug',name:'问题反馈'},
  {id:'other',name:'其他'}
];
var FALLBACK_LIMITS={perDay:3,min:10,max:500,followMin:5};
var TONE={pending:'wait',need_info:'more',accepted_live:'ok',rejected:'no',escalated:'go'};
var BANNED=[
  '加微信','加微信号','加VX','加vx','加V信','加QQ','加qq','加扣扣',
  '微信号','免费领取','代充','刷单','赚钱链接','私聊我',
  'http://','https://','www.',
  '傻逼','傻B','煞笔','草泥马','操你妈','妈的','妈逼','鸡巴','操你',
  '去死','自杀','毒品','冰毒','海洛因'
];

var extraBanned=[];
var badgeUnsub=null;
var panel=null;
var toastT=0;

function net(){return window.TG_SUGGEST||null;}
function limits(){var n=net();return (n&&n.limits)||FALLBACK_LIMITS;}
function cats(){var n=net();var c=n&&n.categories;return (c&&c.length)?c:FALLBACK_CATS;}
function statusText(s){var n=net();if(n&&typeof n.statusText==='function') return n.statusText(s)||s||'';return ({pending:'待审阅',need_info:'需要补充',accepted_live:'已上线',rejected:'未采纳',escalated:'已转交'}[s]||s||'');}
function reasonText(r){var n=net();if(n&&typeof n.reasonText==='function') return n.reasonText(r);var k=typeof r==='string'?r:(r&&r.reason);var min=(r&&r.min)||limits().min||10;return ({bad_category:'先选一个类别',too_short:'至少写 '+min+' 个字',too_long:'最多 '+(limits().max||500)+' 字',empty:'还没写内容',link:'不能带链接',number:'请不要留联系方式',blocked:'有不能发的词，换个说法试试',daily:'今天已提交 '+(limits().perDay||3)+' 条，明天再来',not_found:'这条意见不存在了',not_need_info:'这条不需要补充',offline:'联网后才能提交',error:'网络出错了，稍后再试',banned:'有不能发的词，换个说法试试'}[k]||'暂时无法提交');}
function catName(id){var list=cats();for(var i=0;i<list.length;i++) if(list[i].id===id) return list[i].name;return id||'';}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function el(tag,cls,attrs,text){var e=document.createElement(tag);if(cls)e.className=cls;if(attrs)for(var k in attrs) if(attrs[k]!=null) e.setAttribute(k,attrs[k]);if(text!=null)e.textContent=text;return e;}
function allBanned(){return BANNED.concat(extraBanned||[]);}
function norm(s){return String(s||'').replace(/[\s\u3000]+/g,'').toLowerCase();}
function when(p,ok,fail){
  return Promise.resolve(p).then(function(r){return ok?ok(r):r;},function(e){
    var r={ok:false,reason:'error',message:e&&e.message};
    return fail?fail(r):r;
  });
}

/* 前端屏蔽词；长度与类别交给 TG_SUGGEST，但本地先拦一层更即时。kind: 'submit' | 'followup' */
function checkText(text,kind){
  var raw=String(text==null?'':text);
  var t=raw.replace(/[\u0000-\u001f\u007f\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/g,' ').replace(/\s+/g,' ').trim();
  var L=limits();
  var min=kind==='followup'?(L.followMin||5):(L.min||10);
  var max=L.max||500;
  if(!t) return {ok:false,reason:'empty'};
  if(t.length<min) return {ok:false,reason:'too_short',min:min};
  if(t.length>max) return {ok:false,reason:'too_long',max:max};
  var n=norm(t), hits=[], list=allBanned();
  for(var i=0;i<list.length;i++){
    var w=String(list[i]||'').trim();
    if(w && n.indexOf(norm(w))>=0 && hits.indexOf(w)<0) hits.push(w);
  }
  if(/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i.test(t) || /(?:^|[^\d])(1[3-9]\d{9})(?:[^\d]|$)/.test(t.replace(/[\s\-]/g,''))){
    return {ok:false,reason:'number',hits:hits.concat(['联系方式'])};
  }
  if(hits.length) return {ok:false,reason:'blocked',hits:hits};
  return {ok:true,text:t};
}

function unreadCount(){var n=net();return n&&typeof n.count==='function'?(n.count()|0):0;}
function hasUnread(){return unreadCount()>0;}
function onBadge(cb){
  if(typeof cb!=='function') return function(){};
  var n=net();
  var wrap=function(c){try{cb((c|0)>0,c|0);}catch(e){}};
  if(n&&typeof n.onUnread==='function'){
    n.onUnread(wrap);
    return function(){};
  }
  try{cb(false,0);}catch(e){}
  return function(){};
}

/* 样式：通用外观来自 ui-kit.js（.tg-*）；这里只放意见箱自己的排版。旧类名 .tgfb-* 保留，供 r7b-ux 等外部脚本定位。 */
var CSS=[
'.tgfb-root{z-index:9990}',
'.tgfb-wrap{max-width:520px}',
'.tgfb-tab .tgfb-dot{display:none}.tgfb-tab.has-unread .tgfb-dot{display:block}',
'.tgfb-meta{display:flex;justify-content:space-between;gap:8px}',
'.tgfb-meta.warn .tgfb-count{color:var(--tg-err,#a3261c)}',
'.tgfb-card.unread{border-color:var(--tg-accent,#9b3a2a);box-shadow:inset 3px 0 0 var(--tg-accent,#9b3a2a)}',
'.tgfb-card-h{display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:8px}',
'.tgfb-time{margin-left:auto}',
'.tgfb-txt{font-size:var(--tg-fs-2,16px);line-height:1.65;white-space:pre-wrap;word-break:break-word}',
'.tgfb-off,.tgfb-sup{margin-top:12px;padding:8px 12px;border-radius:var(--tg-r-2,12px);font-size:var(--tg-fs-1,14px);line-height:1.65;white-space:pre-wrap;word-break:break-word}',
'.tgfb-off{background:var(--tg-paper-2,#f3e9d5)}',
'.tgfb-sup{border:1px dashed var(--tg-line-2,#c9ab72);color:var(--tg-ink-2,#634a37)}',
'.tgfb-off b,.tgfb-sup b{display:block;margin-bottom:2px;font-weight:600;color:var(--tg-ink,#3b2a1e)}',
'.tgfb-in{margin-top:12px;min-height:88px}',
'.tgfb-card .tgfb-row{display:flex;gap:8px;margin-top:8px}',
'.tgfb-card .tg-btn{margin-top:12px}',
'.tgfb-card .tgfb-row .tg-btn{margin-top:0}',
'.tgfb-fallback-toast{position:absolute;left:50%;top:64px;transform:translateX(-50%);max-width:90%;padding:10px 16px;border-radius:12px;background:rgba(45,30,20,.92);color:#fff8ec;font-size:14px;opacity:0;transition:opacity .2s;pointer-events:none;z-index:5}',
'.tgfb-fallback-toast.on{opacity:1}'
].join('');
/* ui-kit 缺席时的最低可用样式（正常打包不会用到）。 */
var FALLBACK_CSS='.tg-scrim{position:fixed;inset:0;display:flex;align-items:flex-end;justify-content:center;background:rgba(28,18,10,.48);font-family:sans-serif;color:#3b2a1e}.tg-sheet{position:relative;display:flex;flex-direction:column;width:100%;max-width:560px;height:88%;background:#fbf6ec;border-radius:16px 16px 0 0}.tg-sheet__head{display:grid;grid-template-columns:44px 1fr 44px;align-items:center;min-height:56px;padding:0 8px}.tg-sheet__title{text-align:center;font-size:18px;margin:0}.tg-sheet__body{flex:1;min-height:0;overflow:auto;padding:16px}.tg-sheet__foot{display:flex;gap:12px;padding:12px 16px}.tg-btn,.tg-chip,.tg-tab,.tg-iconbtn{min-height:44px;min-width:44px;font-size:16px}.tg-tabs{display:flex;margin:12px 16px 0}.tg-tab{flex:1}.tg-chips{display:flex;flex-wrap:wrap;gap:8px}.tg-textarea,.tg-input{width:100%;font-size:16px;min-height:44px}.tg-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#d8392b}';

function UI(){return window.TG_UI||null;}
function ensureCss(){
  var u=UI();
  if(u) u.ensure();
  else if(!document.getElementById('tgfb-fallback-css')){var f=el('style',null,{id:'tgfb-fallback-css'});f.textContent=FALLBACK_CSS;document.head.appendChild(f);}
  if(document.getElementById('tgfb-css')) return;
  var st=el('style',null,{id:'tgfb-css'});st.textContent=CSS;document.head.appendChild(st);
}
function iconHtml(name){var u=UI();return u?u.icon(name,22):'';}
function fmtTime(ts){
  if(!ts) return '';
  var loc=new Date(ts);
  if(isNaN(loc.getTime())){
    loc=new Date(String(ts).replace(' ','T'));
    if(isNaN(loc.getTime())) return String(ts);
  }
  var y=loc.getFullYear(), m=loc.getMonth()+1, day=loc.getDate();
  var hh=String(loc.getHours()).padStart(2,'0'), mm=String(loc.getMinutes()).padStart(2,'0');
  var now=new Date();
  if(now.getFullYear()===y&&now.getMonth()+1===m&&now.getDate()===day) return '今天 '+hh+':'+mm;
  if(now.getFullYear()===y) return m+'月'+day+'日 '+hh+':'+mm;
  return y+'-'+String(m).padStart(2,'0')+'-'+String(day).padStart(2,'0');
}
/* 提示：优先走 TG_UI 的统一队列；没有 ui-kit 时退回面板内的单条提示。 */
function showToast(p,msg,tone){
  if(!msg) return;
  var u=UI();
  if(u){u.toast(msg,{tone:tone||'info'});return;}
  if(!p||!p.toast) return;
  p.toast.textContent=msg;p.toast.classList.add('on');
  clearTimeout(toastT);toastT=setTimeout(function(){p.toast.classList.remove('on');},2200);
}

function init(o){
  o=o||{};
  if(Array.isArray(o.bannedWords)) extraBanned=o.bannedWords.slice();
  if(typeof o.onBadge==='function') onBadge(o.onBadge);
  var n=net();
  if(n&&typeof n.unread==='function') when(n.unread());
  return window.TG_FEEDBACK;
}

function close(){
  if(!panel) return;
  var p=panel;panel=null;
  clearTimeout(toastT);
  if(p.layer) p.layer.remove();
  if(p.root&&p.root.parentNode)p.root.parentNode.removeChild(p.root);
}

var BADGE={pending:'',need_info:' tg-badge--warn',accepted_live:' tg-badge--ok',rejected:'',escalated:' tg-badge--info'};

function open(o){
  o=o||{};
  close();
  ensureCss();
  var tab = o.tab==='list'||o.tab==='mine' ? 'list' : 'write';
  var host=o.container||document.body;
  var root=el('div','tgfb-root tg-ui tg-scrim',{role:'dialog','aria-modal':'true','aria-labelledby':'tgfb-title'});
  if(o.container&&o.container!==document.body) root.style.position='absolute';
  var wrap=el('div','tgfb-wrap tg-sheet');
  var head=el('div','tgfb-head tg-sheet__head');
  head.appendChild(el('span'));
  head.appendChild(el('h2','tg-sheet__title',{id:'tgfb-title'},'意见箱'));
  var x=el('button','tgfb-x tg-iconbtn',{type:'button','aria-label':'关闭'});
  x.innerHTML=iconHtml('close')||'×';
  x.onclick=function(){close();};
  head.appendChild(x);
  wrap.appendChild(head);
  var tabs=el('div','tgfb-tabs tg-tabs',{role:'tablist'});
  var tWrite=el('button','tgfb-tab tg-tab',{type:'button',role:'tab','aria-selected':'false'},'写意见');
  var tList=el('button','tgfb-tab tg-tab',{type:'button',role:'tab','aria-selected':'false'},'我的意见');
  tList.appendChild(el('span','tgfb-dot tg-dot',{'aria-hidden':'true'}));
  tWrite.onclick=function(){tab='write';render();};
  tList.onclick=function(){tab='list';render();};
  tabs.appendChild(tWrite);tabs.appendChild(tList);
  wrap.appendChild(tabs);
  var body=el('div','tgfb-body tg-sheet__body');
  wrap.appendChild(body);
  var foot=el('div','tgfb-foot tg-sheet__foot');
  wrap.appendChild(foot);
  var toast=el('div','tgfb-toast tgfb-fallback-toast',{'aria-live':'polite'});
  wrap.appendChild(toast);
  root.appendChild(wrap);
  root.addEventListener('click',function(e){if(e.target===root) close();});
  host.appendChild(root);
  var layer=UI()?UI().openLayer(root,{onClose:close}):null;

  var state={cat:(cats()[0]&&cats()[0].id)||'gameplay',text:'',expand:o.expand||null,listRes:null,busy:false};
  if(o.category) state.cat=o.category;

  function leftLabel(){
    var L=limits();
    var n=state.listRes && typeof state.listRes.left==='number' ? state.listRes.left : null;
    if(n==null) return '每天最多 '+L.perDay+' 条';
    return n>0?'今天还能提交 '+n+' 条':'今天的 '+L.perDay+' 条已用完';
  }

  function renderWrite(){
    var L=limits();
    body.textContent='';
    foot.textContent='';
    foot.hidden=false;
    body.appendChild(el('p','tgfb-hint tg-intro',null,'说说你的想法或遇到的问题，我们会在「我的意见」里回复。请不要留微信、电话或链接。'));
    body.appendChild(el('div','tgfb-lab tg-label',{id:'tgfb-cat-l'},'类别'));
    var row=el('div','tgfb-row tg-chips',{role:'group','aria-labelledby':'tgfb-cat-l'});
    cats().forEach(function(c){
      var b=el('button','tgfb-chip tg-chip',{type:'button','aria-pressed':String(state.cat===c.id)},c.name);
      b.onclick=function(){state.cat=c.id;row.querySelectorAll('.tgfb-chip').forEach(function(x){x.setAttribute('aria-pressed',String(x===b));});};
      row.appendChild(b);
    });
    body.appendChild(row);
    body.appendChild(el('label','tgfb-lab tg-label',{'for':'tgfb-ta'},'内容（'+L.min+'–'+L.max+' 字）'));
    var ta=el('textarea','tgfb-ta tg-textarea',{id:'tgfb-ta',maxlength:String(L.max),placeholder:'比如：留言墙能不能按日期翻看？','aria-describedby':'tgfb-meta'});
    ta.value=state.text||'';
    var meta=el('div','tgfb-meta tg-help',{id:'tgfb-meta'});
    var err=el('span','tgfb-err',{role:'alert'});
    var count=el('span','tgfb-count tg-meta');
    meta.appendChild(err);meta.appendChild(count);
    function syncMeta(){
      state.text=ta.value;
      var n=ta.value.trim().length;
      count.textContent=n+'/'+L.max+' · '+leftLabel();
      meta.className='tgfb-meta tg-help'+(n>0&&n<L.min?' warn':'');
      if(err.textContent&&n>=L.min){err.textContent='';err.className='tgfb-err';}
    }
    ta.addEventListener('input',syncMeta);
    body.appendChild(ta);
    body.appendChild(meta);
    syncMeta();
    var send=el('button','tgfb-btn ok tg-btn tg-btn--primary tg-btn--block',{type:'button'},'提交');
    send.onclick=function(){doSubmit(ta,send,err);};
    foot.appendChild(send);
    if(!o.noFocus&&!(window.matchMedia&&matchMedia('(pointer:coarse)').matches)) setTimeout(function(){try{ta.focus({preventScroll:true});}catch(e){}},200);
  }

  function inlineError(err,msg){
    if(!err) return false;
    err.textContent=msg;err.className='tgfb-err tg-help--err';
    return true;
  }

  function doSubmit(ta,btn,err){
    if(state.busy) return;
    var ck=checkText(ta.value,'submit');
    if(!ck.ok){if(!inlineError(err,reasonText(ck))) showToast(panel,reasonText(ck),'warn');try{ta.focus({preventScroll:true});}catch(e){}return;}
    var n=net();
    if(!n||typeof n.submit!=='function'){showToast(panel,reasonText('offline'),'warn');return;}
    state.busy=true;btn.disabled=true;btn.textContent='提交中…';
    when(n.submit(state.cat,ck.text),function(r){
      state.busy=false;btn.disabled=false;btn.textContent='提交';
      if(!r||!r.ok){showToast(panel,reasonText(r||'error'),'warn');return;}
      state.text='';
      if(typeof r.left==='number') state.listRes=Object.assign({},state.listRes||{},{left:r.left});
      showToast(panel,'已提交，回复会显示在「我的意见」里','ok');
      tab='list';
      render();
    },function(r){state.busy=false;btn.disabled=false;btn.textContent='提交';showToast(panel,reasonText(r||'error'),'warn');});
  }

  function empty(msg,action){
    body.textContent='';
    var box=el('div','tgfb-empty tg-empty',null,msg);
    if(action){var b=el('button','tg-btn',{type:'button'},action[0]);b.style.marginTop='12px';b.onclick=action[1];box.appendChild(el('br'));box.appendChild(b);}
    body.appendChild(box);
  }

  function renderList(){
    body.textContent='';
    foot.textContent='';
    foot.hidden=true;
    body.appendChild(el('div','tgfb-empty tg-empty',null,'加载中…'));
    var n=net();
    if(!n||typeof n.list!=='function'){empty(reasonText('offline'));return;}
    when(n.list(),function(r){
      if(!panel) return;
      if(!r||!r.ok){empty(reasonText(r||'error'),['重试',renderList]);return;}
      state.listRes=r;
      var items=r.items||[];
      body.textContent='';
      if(!items.length){
        empty('还没有提交过意见。',['写一条',function(){tab='write';render();}]);
        return;
      }
      items.forEach(function(it){body.appendChild(card(it));});
    },function(r){empty(reasonText(r||'error'),['重试',renderList]);});
  }

  function itemBody(it){return it.body||it.text||'';}
  function itemUnread(it){return !!(it&&it.unread);}

  function card(it){
    var st=it.status||'pending';
    var unread=itemUnread(it);
    var box=el('article','tgfb-card tg-card'+(unread?' unread':''),{'data-id':String(it.id)});
    var h=el('div','tgfb-card-h');
    h.appendChild(el('span','tgfb-st '+(TONE[st]||'wait')+' tg-badge'+(BADGE[st]||''),null,statusText(st)));
    h.appendChild(el('span','tgfb-cat tg-meta',null,catName(it.category)));
    if(unread) h.appendChild(el('span','tgfb-st more tg-badge tg-badge--accent',null,'有新回复'));
    h.appendChild(el('span','tgfb-time tg-meta',null,fmtTime(it.created_at||it.createdAt)));
    box.appendChild(h);
    box.appendChild(el('div','tgfb-txt',null,itemBody(it)));
    if(it.follow_up){
      var fu=el('div','tgfb-sup');
      fu.appendChild(el('b',null,null,'我的补充'+(it.updated_at?(' · '+fmtTime(it.updated_at)):'')));
      fu.appendChild(document.createTextNode(it.follow_up));
      box.appendChild(fu);
    }
    if(it.reply){
      var p=el('div','tgfb-off');
      p.appendChild(el('b',null,null,'回复'+(it.reply_at?(' · '+fmtTime(it.reply_at)):'')));
      p.appendChild(document.createTextNode(it.reply));
      box.appendChild(p);
    }
    if(st==='need_info'){
      var openIt=String(state.expand)===String(it.id);
      if(openIt){
        var L=limits();
        var ta=el('textarea','tgfb-in tg-textarea',{maxlength:String(L.max),placeholder:'补充哪些信息？至少 '+(L.followMin||5)+' 个字','aria-label':'补充说明'});
        var err=el('div','tgfb-err tg-help',{role:'alert'});
        var row=el('div','tgfb-row');
        var cancel=el('button','tgfb-btn tg-btn tg-btn--block',{type:'button'},'取消');
        var ok=el('button','tgfb-btn ok tg-btn tg-btn--primary tg-btn--block',{type:'button'},'提交补充');
        cancel.onclick=function(){state.expand=null;render();};
        ok.onclick=function(){doFollowup(it.id,ta,ok,err);};
        box.appendChild(ta);box.appendChild(err);box.appendChild(row);row.appendChild(cancel);row.appendChild(ok);
        markSeen(it);
        setTimeout(function(){try{ta.focus({preventScroll:true});}catch(e){}},100);
      }else{
        var more=el('button','tgfb-btn tg-btn',{type:'button'},'补充说明');
        more.onclick=function(){state.expand=it.id;markSeen(it);render();};
        box.appendChild(more);
      }
    }else if(unread){
      box.addEventListener('click',function(){markSeen(it);box.classList.remove('unread');var tag=box.querySelector('.tgfb-st.more');if(tag) tag.remove();});
    }
    return box;
  }

  function markSeen(it){
    if(!it) return;
    it.unread=false;
    var n=net();
    if(n&&typeof n.markSeen==='function') when(n.markSeen(it.id));
    syncDot();
  }

  function doFollowup(id,ta,btn,err){
    if(state.busy) return;
    var ck=checkText(ta.value,'followup');
    if(!ck.ok){if(!inlineError(err,reasonText(ck))) showToast(panel,reasonText(ck),'warn');return;}
    var n=net();
    if(!n||typeof n.followup!=='function'){showToast(panel,reasonText('offline'),'warn');return;}
    state.busy=true;btn.disabled=true;
    when(n.followup(id,ck.text),function(r){
      state.busy=false;btn.disabled=false;
      if(!r||!r.ok){showToast(panel,reasonText(r||'error'),'warn');return;}
      state.expand=null;
      showToast(panel,'补充已提交','ok');
      render();
    },function(r){state.busy=false;btn.disabled=false;showToast(panel,reasonText(r||'error'),'warn');});
  }

  function syncDot(){tList.classList.toggle('has-unread', hasUnread());}

  function render(){
    tWrite.setAttribute('aria-selected',String(tab==='write'));
    tList.setAttribute('aria-selected',String(tab==='list'));
    syncDot();
    if(tab==='write') renderWrite(); else renderList();
  }

  panel={root:root,toast:toast,layer:layer,render:render,setTab:function(t){tab=t;render();},state:state};
  if(!badgeUnsub){
    badgeUnsub=onBadge(function(){if(panel) syncDot();});
  }
  var n=net();
  if(n&&typeof n.list==='function'&&tab==='write'){
    when(n.list(),function(r){
      if(r&&r.ok&&panel&&panel.state===state){state.listRes=r;if(tab==='write'){var c=body.querySelector('.tgfb-count'),ta=body.querySelector('.tgfb-ta');if(c&&ta) c.textContent=ta.value.trim().length+'/'+limits().max+' · '+leftLabel();}}
    });
  }
  render();
  return panel;
}

window.TG_FEEDBACK={
  __v:VER,
  open:open,close:close,init:init,
  hasUnread:hasUnread,onBadge:onBadge,unreadCount:unreadCount,
  checkText:checkText,
  get categories(){return cats().slice();},
  get limits(){return Object.assign({},limits());},
  get panel(){return panel;}
};
})();
