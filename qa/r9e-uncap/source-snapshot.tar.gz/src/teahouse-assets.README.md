# teahouse-assets.js — `window.TG_TEA`（r6）

这是西侧新社交区「茶会小院」的资产，风格是暖金色的风格化写实。如果已加载 `TG_REAL`，就用它的写实材质；没有时退回纯色 `MeshStandardMaterial`（已测试，见 `tea-fallback-*.png`）。也可以用 `TG_TEA.forceFallback=true` 强制退回。
文件独立，只依赖 `THREE`（r170）。

## API
所有 build 函数都返回 `THREE.Group`。坐标是局部坐标，地面 y=0。`userData` 里有以下字段：
- `kind`；
- `blocks:[{x,X,z,Z}]`：局部碰撞框，格式与 `space.blocks` 相同；
- `interact:{x,z,label}`；
- 部分资产还有 `seats:[{x,z,ry}]`。

| 函数 | 说明 |
|---|---|
| `teaTable({style:'low'\|'high', seats:4, cushion:'#3e5f7a', teaset:true, steam:true})` | 茶席：草席、木面加朱漆桌裙、坐垫或青瓷鼓凳；配整套茶具（紫砂壶、公道杯、4 只青瓷杯、茶盘）、花瓶插花，以及热气 sprite |
| `messageWall({width:4.2, height:2.6, cols:4, rows:2, messages})` | 留言墙：砖基座、白灰墙心、朱漆柱和青瓦顶。所有祈愿木牌画在**同一张 canvas 图集**上，只占 1 个 draw call。API 在 `userData.api` 里 |
| `chessTable({stools:4})` | 石棋桌：青石墩和桌面，象棋盘贴图（楚河漢界加 32 子）。棋子是有厚度的圆柱，顶面 UV 直接映射到棋盘贴图，与棋盘共享同一个 draw call。配 4 个石鼓凳，石凳周围有青苔 |
| `riverLanterns({length:10, width:1.8, count:9, lotusLeaves:10, banks:true})` | 小河，沿 X 轴：TG_REAL 水面、河床、带青苔的卵石岸、荷叶（instanced）、莲花河灯（instanced）。河灯自发光，有火苗和水面光晕（加色混合），会漂流、起伏、摇摆。`userData.release()` 对应玩家「放河灯」：把最靠下游的一盏灯移回起点 |
| `bambooFence({from:[x,z], to:[x,z], depth:1.2, density:7, height:[3.2,5.2], fence:true})` | 竹林：竹竿和竹叶各用 1 个 InstancedMesh，靠顶点着色器摇曳（只改一个 uniform）。前面配一道竹篱笆，绑绳合并成一个 mesh |
| `plants({spots:[[x,z,r]], shrubs, flowers, tufts, moss, rocks})` | 繁茂植物：灌木、花朵（instanceColor：粉、黄、白、红、紫、橙）、草丛面片（会摇曳）、青苔斑和长苔石头，每类 1 个 InstancedMesh |
| `pottedPlant({kind:'bonsai'\|'flower'\|'bamboo', pot})` | 盆栽 |
| `osmanthusTree({height, foliage, blossom})` | 主景桂花树：团簇树冠、叶片 alpha 卡、桂花小点和树下落花 |
| `stoneLantern()` | 石灯笼，暖光窗，用 emissive 实现，没有实时光源 |
| `buildCourtyard({width:24, depth:20, tables:3, lanterns:9, messages, lite, ground:true})` | 整个样板院子，返回 `{group, parts, blocks, interact, wall, river, update(dt), dispose()}` |
| `TG_TEA.update(dt)` | 推进所有活动资产：竹子和草的摇曳、河灯、热气。水面流动由 `TG_REAL.update` 负责 |
| `TG_TEA.stats(root)` | 返回 `{meshes, instanced, instances, triangles, materials}` |
| `TG_TEA.instance(protoGroup, [[x,y,z,ry,scale],...], parent)` | 把任意原型批量转成 InstancedMesh |
| `TG_TEA.disposeObject(group)` / `TG_TEA.dispose()` | 释放资源 |

### 留言墙 API：`court.wall`，或 `messageWall().userData.api`
```js
wall.addMessage({text, author, style:'wood'|'red'|'jade'|'paper'})  // 只显示最新的 cols*rows 条，长文本自动换行，超出部分用 … 截断
wall.setMessages([{text,author}]) ; wall.clear() ; wall.messages()
wall.pick(raycastHit.uv) → message   // 射线命中 wall.board 时，用 uv 找出点到的是哪一条留言
```

### buildCourtyard 布局（院子中心为原点，+X 朝东，-Z 朝北）
- 竹林围住北、西、南三面，东侧留入口小径（z≈1.2），对应游戏从广场进入后的出生点 `[11,0]`。
- 留言墙在北侧居中，位置 `(0, -D/2+2.6)`，面朝南。
- 中央是青石板广场，四周用青砖包边。茶席位于 `(-3.2,-1.4)`、`(1.6,-2.2)`、`(-0.8,1.9)`（第三席是高桌）。
- 石棋桌在 `(W*.2, -D*.06)`。
- 桂花树在西北角，旁边配花圃。
- 4 盏石灯笼，用 instancing。4 个盆栽。
- 南侧是小河，带河灯和小石桥。
- 地面层高：草地 .012，花圃泥土 .022，石板 .024，砖边 .06。这些层高高于游戏 floor 顶面（y=0），**避免 z-fight**。河道位置的草地已挖空。

## codex 接入步骤（r6.js 已大致接好，以下是补充）
1. 在 `pack.mjs` 的 `__WORLD__` 拼接里加入本文件，放在 realism.js 之后：
   `+"\n"+fs.readFileSync(path.join(dir,"teahouse-assets.js"),"utf8")`
2. r6.js 目前**写死了**两个交互点：`worldInteract(t,0,-9,…留言墙)` 和 `(7.5,-3.5,…石桌对弈)`。在 27×27 的院子里，留言墙实际位于 z=-10.9，棋桌位于 (5.4,-1.6)。建议改成遍历 `court.interact`：
   ```js
   for(const i of court.interact){ if(i.kind==='messageWall')worldInteract(t,i.x,i.z,'茶会留言墙',r6TeaWall,3);
     else if(i.kind==='chessTable')worldInteract(t,i.x,i.z,'石桌对弈',…); else if(i.kind==='river')worldInteract(t,i.x,i.z,'放河灯',()=>court.river.release()); }
   ```
3. 每帧调用 `TG_TEA.update(dt)`（r6.js 已在 tgAnimate 里调用）。水面流动需要 `TG_REAL.install()`，或手动调用 `TG_REAL.update(dt)`。
4. 进入 tea 场景时要套用预设。用 `TG_REAL.install()` 会自动处理（预设 `tea` 等同于 `teahouse`）。
5. 留言墙数据同步：每次 `S.tea.messages` 变化时调用 `court.wall.setMessages(...)`（r6.js 已这样做）。

## 性能（swiftshader 实测；calls 含阴影 pass）
| 配置 | draw calls（含阴影） | 三角面 | 说明 |
|---|---|---|---|
| 完整样板院 24×20，全景 | 98 | 114k | 89 个 mesh，其中 23 个 InstancedMesh（共 2743 个实例），48 个材质 |
| 近景（茶席、留言墙、河、竹林） | 30–80 | 58k–105k | 视锥剔除生效 |
| 游戏内 tea 场景（27×27，lite，旧版打包） | 91 | 130k | 新版竹子去掉了节环，三角面会更少 |

- 竹子占三角面的大头，约 47k。手机上建议加大 `density` 的反向调节：`bambooFence({density:5})`，或者 `buildCourtyard({lite:true})`（植物数量约减半）。
- 小件（陶瓷、布、绳、花）合并进 2–3 个**顶点色共享材质**（gloss/satin/matte），所以每张茶桌只需 6–7 个 draw call。
- 所有动画都只改 uniform 或预分配的矩阵，**每帧没有对象分配**。整个院子构建约 1s（swiftshader）。

## 已知限制
- 茶桌之间没有做 instancing，因为每席颜色和样式不同。
- 竹林碰撞是每段一个 AABB（整条带状区域）。
- 河灯的光只来自 emissive 和光晕贴片，没有实时点光源，所以不会照亮周围物体。
- 树冠仍带一定的低模感，有叶片卡缓解。
- 文字依赖系统里的 CJK 字体，按 Noto Serif CJK → Songti → serif 的顺序回退。

截图见 `qa/r6-shots/`：
- `tea-*.png`：overview、aerial、tables、teaset、wall、wall-api、chess、river、river-t2、bamboo、tree；
- `tea-contact-sheet.png`；
- `tea-fallback-*.png`；
- `game-tea-before/after*.png`。

测试脚本：`qa/r6-tools/courtyard.mjs [fallback]`。
