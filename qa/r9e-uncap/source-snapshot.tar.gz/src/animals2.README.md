# animals2.js：新动物低多边形模型

这是独立的新文件，**还没有**加进 `pack.mjs`，也没有接进游戏逻辑。现有文件一个都没改。

## API

```js
window.TG_ANIMALS2 = {
  __v: 1,                     // 幂等标记，重复加载时直接 return
  kinds: ['duck','goose','rabbit','horse','alpaca','beehive','fishpond'],
  info:  { kind: {name, emoji, size:[宽,高,长], speed, static?} },
  build(kind) -> THREE.Group | null,   // 未知 kind 时 console.warn 并返回 null
  anim(group, t, state),               // t = 毫秒（同 tgAnimate / r3UpdateAnimalMatrices 的 ts）
  palette                              // 用到的色板
}
```

- **坐标约定**：和 r3 的 `r3AnimalModel` 一致，地面在 y=0，头朝 +Z，比例尺相同（鸡约 1.0 高，牛约 1.4 高）。
- **层级**：`group`（调用方负责 position / rotation.y / scale）→ `group.userData.rig`（anim 负责：起伏、摇摆、趴下）→ 各部件。
  anim 每帧会重置 rig 的变换，**不会**动 group 本身，所以寻路和朝向可以照旧写在 group 上。
- **state**：`'idle'`（待机），`'walk'`（走动），`'rest'`（可选，趴下或卧倒）。其他值都按 idle 处理。
- **动画是纯函数**：只由 t 和 `userData.phase` 决定，不累积状态，可以跳帧，也可以暂停。每只动物的 phase 不同，所以不会同步动作。
- **材质和几何**：页面里有 `W3` 和 `worldMat` 时，直接复用游戏的 `W3.materials` 和 `W3.geometries`。材质是 MeshLambert 加 flatShading，几何共 4 种，与 worldMesh 完全相同（ball=Sphere(1,10,7)，cone=Cone(1,1,8)，cylinder=Cylinder(1,1,1,12)，box）。没有 W3 时用模块自己的缓存。没有贴图。
  例外：鱼池水面用一个共享的半透明材质；3 圈涟漪各有一份独立材质（因为要分别改 opacity）。
- **阴影**：所有 Mesh 都设了 `castShadow` 和 `receiveShadow`，和 worldMesh 一样。

## userData 里的部件引用

| kind | 可用引用 |
|---|---|
| 所有 | `kind, rig, legs[], phase, info, tgAnimals2:true` |
| duck | `body, head, wings[2]` |
| goose | `body, neck, head, wings[2]` |
| rabbit | `body, head, ears[2], nose, tail`，legs 依次为前左、前右、后左、后右 |
| horse | `body, neck, head, tail`，legs 4 条，带蹄 |
| alpaca | `body, neck, head, jaw, tail`，legs 4 条 |
| beehive | `hive, bees[7]`（每只的 `userData`：轨道半径、高度、速度、翅膀） |
| fishpond | `water, pads[3], fish[3]`（每条的 `userData.tail`），`ripples[3]` |

## 各种类

实测包围盒（宽 × 高 × 长，单位与场景相同）：

| kind | 名称 | 尺寸 | idle | walk | rest |
|---|---|---|---|---|---|
| duck | 小鸭（绿头鸭） | 0.78 × 0.74 × 0.91 | 点头啄食、左右张望，偶尔扑翅 | 左右摇摆的鸭步，双脚交替 | 身体压低 |
| goose | 大白鹅 | 0.98 × 1.11 × 1.20 | 长脖子缓慢环顾，偶尔扑翅 | 脖子前探、一伸一缩，摇摆 | 身体压低 |
| rabbit | 小兔 | 0.71 × 0.96 × 0.83 | 鼻子抽动、耳朵抖动，偶尔原地小跳 | 连续跳跃：前后腿交替，身体俯仰，耳朵后贴 | 压扁，耳朵后倒 |
| horse | 小马 | 1.34 × 1.93 × 1.89 | 甩尾，周期性低头吃草 | 对角步（左前和右后同相），点头 | 跪卧 |
| alpaca | 羊驼 | 1.06 × 1.86 × 1.18 | 脖子摇晃、转头，嘴巴反刍 | 四腿交替，脖子小幅摆动 | 跪卧 |
| beehive | 蜂箱（含木架、小屋顶、一朵花） | 1.24 × 1.23 × 1.27 | 3 只蜜蜂慢慢绕飞 | 7 只全部出动，飞得更快、更远，箱体轻微嗡嗡抖动 | 同 idle |
| fishpond | 鱼池（石砌池沿、荷叶、莲花） | 2.75 × 0.23 × 2.75 | 3 条锦鲤慢游摆尾，荷叶轻浮，涟漪慢慢扩散 | 鱼游得更快，第一条鱼会跃出水面，涟漪更密 | 同 idle |

`info.speed` 是建议的移动速度，和 r3 的鸡 0.6、牛 0.65、宠物 1.15 处在同一量级。`beehive` 和 `fishpond` 的 `static:true` 表示不应该移动，是摆件。

## 以后怎么挂进游戏（建议）

1. 在 `pack.mjs` 里把 `animals2.js` 放在 `three.inline.js` 和 `world3d.js` 之后。它只要求全局能拿到 `THREE`，`W3` 可有可无。
2. 商店：往 `R3_ANIMAL_SHOP` 追加条目，例如 `{id:'duck',name:'小鸭',emoji:'🦆',price:50,cap:4,pen:0,nickname:'嘎嘎',...}`。`r3SanitizeAnimals` 的白名单就取自 `R3_ANIMAL_SHOP`，加进去就会放行。但它内部的 `names` 和 `pens` 默认表只有旧的 6 种：条目里一定要写 `nickname` 和 `pen`，否则存档里的名字会是 undefined。
   另外，`r3AnimalModel(kind)` 不认识新 kind（`bodyColor` 会是 undefined），建模分支要在调用它之前判断 kind 属于 `TG_ANIMALS2.kinds`。
3. 建模：r3 现在是用 `r3AnimalModel(kind)` 把部件烘成 InstancedMesh 批次（`r.parts` 加 `setMatrixAt`）。两种接法：
   - **简单**：kind 属于 `TG_ANIMALS2.kinds` 时，把 `TG_ANIMALS2.build(kind)` 直接加进 `animalGroup`，作为普通 Mesh 渲染，不走批次。每帧设好 `group.position` 和 `rotation.y`，再调用 `TG_ANIMALS2.anim(group, ts, walking ? 'walk' : r.rest ? 'rest' : 'idle')`。
   - **批次**：如果坚持用实例化，可以在 anim 之后调用 `group.updateMatrixWorld(true)`，再像 r3 那样把每个子 Mesh 的 `matrixWorld` 写进对应批次。
4. 注意：r3UpdateAnimalMatrices 会直接写 `root.position.y`、`root.scale.y` 和 `head.rotation.x`。新动物不要再走这套逻辑，否则会和 rig 的动画叠加。只让它们设 x、z、yaw 就行。
5. 蜂箱和鱼池建议当作摆件或产出建筑（蜂蜜、鱼）：放在固定位置，每帧调用 anim 即可，state 可以按"有产物待收"之类的条件切成 'walk'，让画面更热闹。

## 验证

- `node --check animals2.js` 通过。
- 无头 Chrome（playwright-core + swiftshader）测试页：同时加载 three.inline.js、从 r3.js 原样抽出的 `r3AnimalModel`（用于比例对照）和 animals2.js（**加载两次**，验证幂等）。逐个 build 所有 kind，各跑 idle、walk、rest、undefined 共 300 帧。结果是 console 没有错误，没有 NaN，anim 也不会改动 group 的位置或旋转。walk 的运动量明显大于 idle。
- 场景开销：7 个模型共 164 个 Mesh，不同几何只有 6 个，材质按颜色共享。
- 截图在 `qa/animals2-shots/`：`lineup-idle.png` / `lineup-walk.png` 是与 r3 的鸡、狗、牛并排的比例对照；`<kind>-idle-2000.png`、`<kind>-walk-2160.png`、`<kind>-walk-2330.png` 是各物种的特写；`closeups-contact-sheet.png` 是总览。测试脚本是 `animals2-test.mjs`。
