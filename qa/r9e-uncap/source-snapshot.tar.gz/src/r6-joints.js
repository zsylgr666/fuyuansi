/* r6-joints.js — disabled: splitting wide sleeves tears their triangles.
   Proper two-segment limbs belong in avatar.js. Keep this pack slot/API inert. */
(function(){
  'use strict';
  function attach(g){return g;}
  function apply(){}
  function wrap(){}
  window.TG_R6_JOINTS={attach,apply,wrap,version:'r6-joints-disabled'};
})();
