/* =========================================================
   十三、三维世界：场景、和尚、碰撞与第三人称输入
   使用函数声明及启动时初始化：玩法脚本在本段执行前调用 initWorld。
   ========================================================= */
var W3;
function initWorld(canvas){
  if(W3) return;
  const w=W3={canvas, spaces:{}, keys:new Set(), joy:{x:0,y:0}, pointers:new Map(), target:null, active:null, yaw:0, pitch:.62, radius:8, phase:0, action:null, materials:{}, geometries:{}};
  try{
    w.renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,preserveDrawingBuffer:true,powerPreference:'high-performance'});
    w.renderer.setPixelRatio(Math.min(1.5,window.devicePixelRatio||1));
    w.renderer.shadowMap.enabled=true; w.renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  }catch(e){ $('#webglFail').classList.add('show'); return; }
  w.scene=new THREE.Scene(); w.camera=new THREE.PerspectiveCamera(55,1,.1,100);
  w.follow=new THREE.Vector3(); w.ray=new THREE.Raycaster(); w.ndc=new THREE.Vector2();
  w.hemi=new THREE.HemisphereLight(0xfff4d9,0x667054,2); w.scene.add(w.hemi);
  w.sun=new THREE.DirectionalLight(0xffe4b4,2.4); w.sun.position.set(-8,16,9); w.sun.castShadow=true;
  w.sun.shadow.mapSize.set(1024,1024); Object.assign(w.sun.shadow.camera,{left:-26,right:26,top:26,bottom:-26,near:.5,far:55});
  w.sun.shadow.normalBias=.035; w.scene.add(w.sun);
  worldBuild(); worldMonk(); tgDecorate(); worldInput();
  worldResize();requestAnimationFrame(()=>{worldResize();requestAnimationFrame(worldResize);});
  [0,50,200].forEach(ms=>setTimeout(worldResize,ms));document.fonts?.ready.then(worldResize);
  window.addEventListener('resize',worldResize);window.addEventListener('orientationchange',worldResize);window.visualViewport?.addEventListener('resize',worldResize);
  new ResizeObserver(worldResize).observe($('#app'));
  canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();worldStop();$('#webglFail').classList.add('show');});
  canvas.addEventListener('webglcontextrestored',()=>location.reload());
  document.addEventListener('visibilitychange',()=>{worldStop();w.last=0;});
  window.addEventListener('blur',worldStop);
  $('#promptBtn').addEventListener('click',()=>{if(!worldBlocked()&&w.action){const a=w.action;worldStop();a();worldSyncYard();worldSyncHall();}});
  // DOM 玩法仍负责状态变更；同一事件结束后同步三维外观。
  $('#app').addEventListener('click',()=>queueMicrotask(()=>{worldSyncYard();worldSyncHall();}));
  requestAnimationFrame(worldFrame);
}
function worldMat(color,smooth){const w=W3;const key=smooth?color+':s':color;return w.materials[key]||(w.materials[key]=new THREE.MeshLambertMaterial({color,flatShading:!smooth}));}
function worldMesh(parent,type,color,x,y,z,sx,sy,sz){
  const w=W3;const geo=w.geometries[type]||(w.geometries[type]=type==='head'?new THREE.SphereGeometry(1,32,24):type==='ball'?new THREE.SphereGeometry(1,10,7):type==='cone'?new THREE.ConeGeometry(1,1,8):type==='cylinder'?new THREE.CylinderGeometry(1,1,1,12):new THREE.BoxGeometry(1,1,1));
  const m=new THREE.Mesh(geo,worldMat(color,type==='head'));m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;
}
function worldBox(s,x,y,z,a,b,c,color,solid){const m=worldMesh(s.group,'box',color,x,y,z,a,b,c);if(solid)s.blocks.push({x:x-a/2,X:x+a/2,z:z-c/2,Z:z+c/2});return m;}
function worldLabel(parent,text,x,y,z,width){
  const c=document.createElement('canvas');c.width=512;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#402820';ctx.fillRect(0,0,512,128);ctx.strokeStyle='#dfb65a';ctx.lineWidth=8;ctx.strokeRect(8,8,496,112);ctx.fillStyle='#ffe6a1';ctx.font='bold 66px serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,256,66);
  const t=new THREE.CanvasTexture(c);const m=new THREE.Mesh(new THREE.PlaneGeometry(1,1),new THREE.MeshBasicMaterial({map:t,side:THREE.DoubleSide}));m.scale.set(width,width/4,1);m.userData.wallSign=true;m.position.set(x,y,z);parent.add(m);
}
function worldInteract(s,x,z,label,run,range){s.items.push({x,z,label,run,range:range||2.3});}
function worldBuild(){
  const w=W3;
  for(const name of ['plaza','yard','hall']){
    const s=w.spaces[name]={group:new THREE.Group(),blocks:[],items:[],exits:[],limit:name==='hall'?{x:6,z:8}:{x:14.6,z:14.6}};w.scene.add(s.group);s.group.visible=false;
    s.floor=worldBox(s,0,-.15,0,name==='hall'?12:52,.3,name==='hall'?16:52,name==='plaza'?'#cbb98e':name==='yard'?'#85a963':'#674332',false);
  }
  const p=w.spaces.plaza,y=w.spaces.yard,h=w.spaces.hall;
  worldBox(p,0,.015,0,3,.04,28,'#e4d7b4');
  function roof(s,x,z,width,ypos){for(const side of [-1,1]){const m=worldBox(s,x,ypos,z+side*.7,width,.22,1.8,'#46585a');m.rotation.x=side*.3;}worldBox(s,x,ypos+.27,z,width+.3,.18,.22,'#647779');}
  function doorway(s,title,z){
    for(const x of [-8,8])worldBox(s,x,1.8,z,10,3.6,.65,'#a94436',true);
    for(const x of [-2.3,2.3])worldBox(s,x,1.8,z,.55,3.6,.9,'#8d2f29',true);
    for(const x of [-1.9,1.9])worldBox(s,x,1.35,z,.35,2.7,.24,'#67372a',true);
    worldBox(s,0,3.4,z,5, .6,1,'#a94436');roof(s,0,z,27,4.1);
    for(const side of [1,-1]){worldLabel(s.group,title,0,3.45,z+side*.53,3.2);const label=s.group.children[s.group.children.length-1];label.material.side=THREE.FrontSide;label.rotation.y=side===1?0:Math.PI;}
  }
  doorway(p,'福缘里',-12);doorway(y,'福缘堂',-12);
  p.exits.push({x:0,z:-12,to:'yard'}); y.exits.push({x:0,z:-12,to:'hall'},{x:0,z:14,to:'plaza'});h.exits.push({x:0,z:7.5,to:'yard'});
  for(const [s,labels] of [[p,['进入院子']],[y,['进入缘堂','回大厅']],[h,['回院子']]])s.exits.forEach((e,i)=>worldInteract(s,e.x,e.z,labels[i],()=>go(e.to),2.2));
  const stallData=[[-4.8,1,'读心笺',openGua], [4.8,1,'抽每日诗笺',openQian],[7,7,'赏园景',openFeng]];
  stallData.forEach(([x,z,label,run],i)=>{
    if(window.TG_R8?.replaceStalls){worldInteract(p,x,z+1.65,label,run);return;}
    worldBox(p,x,.65,z,3,1.3,1.6,'#855333',true);
    for(const dx of [-1.4,1.4])for(const dz of [-.65,.65])worldBox(p,x+dx,1.6,z+dz,.12,3.2,.12,'#5c3d2a');
    for(let j=0;j<8;j++){const m=worldBox(p,x-1.575+j*.45,2.9,z, .45,.16,2.3,j%2?'#fff1d1':'#b94234');m.rotation.x=.12;}
    worldLabel(p.group,label,x,2.1,z+.76,2.4);worldInteract(p,x,z+1.65,label,run);
    if(i===0){worldMesh(p.group,'cylinder','#ede4cd',x,1.37,z,.65,.12,.65);for(const dx of [-.25,.25])worldMesh(p.group,'ball',dx<0?'#252e30':'#fff9e5',x+dx,1.46,z,.23,.06,.4);}
    if(i===1){worldMesh(p.group,'cylinder','#ac382b',x,1.65,z,.35,.6,.35);for(let j=0;j<7;j++)worldBox(p,x+(j-3)*.075,2,z,.04,.6,.04,'#e6c276');}
    if(i===2){worldMesh(p.group,'cylinder','#dbba65',x,1.4,z,.6,.18,.6);const needle=worldBox(p,x,1.53,z,.12,.06,.9,'#a3382c');needle.rotation.y=.6;}
  });
  function tree(s,x,z){worldMesh(s.group,'cylinder','#72513b',x,1,z,.25,2,.25);worldMesh(s.group,'ball','#537c48',x,2.8,z,1.3,1.6,1.2);s.blocks.push({x:x-.35,X:x+.35,z:z-.35,Z:z+.35});}
  for(const [x,z] of [[-12,-7],[12,-7],[-12,8],[12,10]])tree(p,x,z);
  if(!window.TG_R8?.replaceStalls)for(const x of [-4,4]){worldBox(p,x,.3,-10,1.1,.6,1.3,'#929992',true);worldMesh(p.group,'ball','#afb4a7',x,1,-10,.43,.6,.55);worldMesh(p.group,'ball','#afb4a7',x,1.65,-9.7,.4,.4,.4);}
  for(let i=0;i<9;i++){const m=worldMesh(p.group,'cone',i%2?'#809d9b':'#a1b2a6',-32+i*8,3,-29,8,8+(i%3)*3,6);m.castShadow=false;}
  // 小猫与静坐僧人。
  worldMesh(p.group,'ball','#d5af7c',10,.35,6,.5,.3,.3);worldMesh(p.group,'ball','#d5af7c',10.4,.6,6,.24,.25,.25);
  for(const dx of [.26,.52])worldMesh(p.group,'cone','#d5af7c',10+dx,.89,6,.12,.2,.12);
  worldMesh(p.group,'cone','#cf7d28',-10,.5,5,.6,1,.6);worldMesh(p.group,'ball','#f3c994',-10,1.2,5,.32,.35,.32);


  worldBox(y,0,.01,0,2.4,.04,27,'#c6c5a1');
  for(const x of [-13,13])for(const z of [-9,0,9]){worldBox(y,x,1.4,z,.12,2.8,.12,'#654637');worldMesh(y.group,'ball','#d84932',x,2.6,z,.4,.5,.4);}
  w.crops=[];
  for(let i=0;i<12;i++){
    const x=3.5+(i%3)*3.3-13.5,z=-6+Math.floor(i/3)*3.5;
    worldBox(y,x,.1,z,2.4,.2,2.3,'#765139',false);
    for(const dx of [-1.25,1.25])worldBox(y,x+dx,.16,z,.12,.3,2.55,'#aa8660');
    const group=new THREE.Group();group.position.set(x,.24,z);y.group.add(group);w.crops.push({group,key:null,ripe:false});
    worldInteract(y,x,z,()=>!S.plots[i]?'播种':plotProgress(S.plots[i],Date.now())>=1?'收获':'浇水',()=>$('#plots .plot[data-i="'+i+'"]').click(),2.05);
  }
  // 留出中央主路，另一侧花木、石凳。
  for(const z of [-7,5,10])tree(y,z===5?13:11,z);
  worldBox(y,12,.5,8,2.8,1,1,'#b5b6a3',true);
  for(const x of [-6,6])worldBox(h,x,2.7,0,.3,5.4,16,'#442b25',true);
  worldBox(h,0,2.7,-8,12,5.4,.3,'#442b25',true);
  for(const x of [-4,4])worldBox(h,x,2.7,8,4,5.4,.3,'#442b25',true);
  // 实体天花板从室内可见，从上方不会遮挡俯视镜头。
  const ceiling=worldBox(h,0,5.5,0,12,.2,16,'#3b2722');ceiling.material=new THREE.MeshLambertMaterial({color:'#3b2722',side:THREE.BackSide});
  for(let z=-7;z<8;z+=1)worldBox(h,0,.015,z,11.8,.025,.035,'#936448');
  for(const x of [-4,4]){worldMesh(h.group,'cylinder','#a53b2c',x,2.5,-2,.35,5,.35);h.blocks.push({x:x-.4,X:x+.4,z:-2.4,Z:-1.6});}
  worldLabel(h.group,'慎终追远',0,4.1,-7.78,4.5);
  for(const [x,text] of [[-1.8,'福泽绵长'],[0,'家和业兴'],[1.8,'家和业兴']]){const big=x===0;worldBox(h,x,2.8,-7.2,big?1.5:1.25,big?2:1.55,.25,'#39271d');worldLabel(h.group,text,x,2.8,-7.05,big?1.45:1.2);worldBox(h,x,1.8,-7.2,big?1.7:1.4,.16,.6,'#c6a34c');}
  worldBox(h,0,1.35,-5.8,5.4,.3,1.5,'#993c2d',true);for(const x of [-2.3,2.3])worldBox(h,x,.65,-5.8,.3,1.3,1,'#693d2b');
  worldInteract(h,0,-4.4,'上供',()=>$('#btnOffer').click());
  worldMesh(h.group,'cylinder','#a1864a',0,.85,-2.3,.7,.7,.7);h.blocks.push({x:-.8,X:.8,z:-3.1,Z:-1.5});
  for(const x of [-.45,.45])worldBox(h,x,.3,-2.3,.15,.6,.2,'#a1864a');
  worldInteract(h,0,-.9,'上香',()=>$('#btnIncense').click());
  worldBox(h,2.1,.6,-3.8,1.7,1.2,1.2,'#825032',true);worldMesh(h.group,'ball','#b88445',2.1,1.4,-3.8,.6,.4,.45);worldBox(h,2.1,1.65,-3.55,.65,.04,.04,'#533b26');worldInteract(h,2.1,-2.4,'敲木鱼',()=>$('#muyu').click());
  for(const x of [-2.2,2.2]){worldMesh(h.group,'cylinder','#f0d4a3',x,1.85,-5.8,.12,.7,.12);worldMesh(h.group,'ball','#ffd472',x,2.28,-5.8,.09,.18,.09);const light=new THREE.PointLight(0xffae49,5,7,2);light.position.set(x,2.4,-5.5);h.group.add(light);}
  // 暖色顶光照亮人物与供桌，烛光保留局部层次。
  const fill=new THREE.PointLight(0xffddaf,28,18,2);fill.position.set(0,4.6,-2);h.group.add(fill);
  w.sticks=new THREE.Group();h.group.add(w.sticks);w.fruits=new THREE.Group();h.group.add(w.fruits);
  w.smoke=new THREE.Group();h.group.add(w.smoke);const sm=new THREE.MeshBasicMaterial({color:0xddd5c2,transparent:true,opacity:.14,depthWrite:false});
  for(let i=0;i<18;i++){const m=new THREE.Mesh(w.geometries.ball,sm);m.castShadow=false;w.smoke.add(m);}
  r3Build();
  worldSyncYard();worldSyncHall();
}
function worldMonk(){
  const w=W3;w.player=new THREE.Group();w.body=new THREE.Group();w.player.add(w.body);w.scene.add(w.player);
  worldMesh(w.body,'cone','#e39432',0,.68,0,.43,.95,.36);
  const sash=worldMesh(w.body,'box','#a95725',.08,.84,.27,.18,.68,.12);sash.rotation.z=-.4;
  worldMesh(w.body,'head','#f2ca9d',0,1.3,0,.32,.35,.31);
  for(const x of [-.32,.32])worldMesh(w.body,'head','#e8b98e',x,1.28,0,.075,.12,.07);
  for(const x of [-.105,.105])worldMesh(w.body,'head','#372f2a',x,1.34,.282,.028,.035,.02);
  worldMesh(w.body,'head','#ba7354',0,1.19,.297,.055,.018,.015);
  w.limbs=[];
  for(let i=0;i<4;i++){const limb=new THREE.Group();const arm=i<2;limb.position.set((i%2?1:-1)*(arm?.4:.19),arm?1:.42,0);w.body.add(limb);worldMesh(limb,'cylinder',arm?'#d77728':'#7b4b30',0,arm?-.23:-.17,0,arm?.1:.115,arm?.46:.34,arm?.1:.12);worldMesh(limb,arm?'head':'ball',arm?'#edbf92':'#4a352b',0,arm?-.46:-.33,.04,.12,.09,.16);w.limbs.push(limb);}
}
function worldClear(group){while(group.children.length)group.remove(group.children[0]);}
function worldSyncYard(){
  const w=W3;if(!w||!w.crops)return;
  w.crops.forEach((c,i)=>{const p=S.plots[i],st=p?stageOf(plotProgress(p,Date.now())):-1,key=p?p.crop+':'+st:'empty';if(key===c.key)return;c.key=key;c.ripe=st===3;worldClear(c.group);if(!p)return;
    tgCropModel(c.group,p.crop,st);
  });
}
function worldSyncHall(){
  const w=W3;if(!w||!w.sticks)return;
  const active=S.incense.sticks.filter(t=>Date.now()-t<INCENSE_BURN_MS),key=active.join(',')+'|'+S.offerings.map(o=>o.crop+o.at).join(',');
  if(key===w.hallKey)return;w.hallKey=key;worldClear(w.sticks);worldClear(w.fruits);
  active.forEach((t,i)=>{worldMesh(w.sticks,'cylinder','#a0492e',(i-(active.length-1)/2)*.22,1.58,-2.3,.025,.95,.025);worldMesh(w.sticks,'ball','#ffb452',(i-(active.length-1)/2)*.22,2.07,-2.3,.04,.045,.04);});
  S.offerings.slice(-7).forEach((o,i)=>{if(typeof r3HallProduce==='function'&&r3HallProduce(w.fruits,o,i))return;worldMesh(w.fruits,'ball',o.crop==='tomato'?'#d75339':o.crop==='peach'?'#f0aaa0':'#9fbd54',(i-3)*.52,1.72,-5.7,.23,.22,.23);});w.smoke.visible=active.length>0;
}
function worldBlocked(){return !!window.TG_PLAN||switching||$('#modal').classList.contains('show')||$('#gateLock').classList.contains('show')||/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement.tagName);}
function worldStop(){const w=W3;if(!w)return;w.keys.clear();w.target=null;w.path=[];w.vx=w.vz=0;w.joy.x=w.joy.y=0;w.joyId=null;if(w.pointers)w.pointers.clear();w.action=null;$('#joyKnob').style.transform='';$('#promptBtn').classList.remove('show');}
function worldEnter(name,previous){
  worldResize();
  if(name==='home'){window.r4EastArrival=true;name='yard';}
  const w=W3;if(!w||!w.renderer)return;worldStop();w.active=name;Object.entries(w.spaces).forEach(([n,s])=>s.group.visible=n===name);
  const spawn=r3Spawn(name,previous),[x,z,yaw]=spawn;
  w.player.position.set(x,0,z);w.player.rotation.y=yaw+Math.PI;w.yaw=yaw;w.pitch=r3Indoor(name)?.55:.42;w.radius=r3Indoor(name)?9.8:8.8;
  w.follow.copy(w.player.position).y=1.1;w.scene.background=new THREE.Color(r3Indoor(name)?'#32251f':'#87b8d6');w.scene.fog=new THREE.Fog(r3Indoor(name)?'#32251f':'#9ec9e8',r3Indoor(name)?14:24,r3Indoor(name)?35:65);w.hemi.intensity=r3Indoor(name)?1.35:2;w.sun.intensity=r3Indoor(name)?1.1:2.4;w.elapsed=0;w.exitCooldownUntil=performance.now()+1300;w.exitLatch=w.spaces[name].exits.find(e=>Math.abs(x-e.x)<1.35&&Math.abs(z-e.z)<.9)||null;w.exitInside=w.exitLatch;worldCamera(1);worldSyncYard();worldSyncHall();if(typeof worldSyncDecor==='function')worldSyncDecor();worldSyncShrine();if(typeof worldSyncAnimals==='function')worldSyncAnimals();worldResize();
}
function worldCamera(a){
  const w=W3,goal=w.player.position.clone();goal.y+=1.1;w.follow.lerp(goal,a);
  const r=w.radius,cp=Math.cos(w.pitch);
  const offset=new THREE.Vector3(Math.sin(w.yaw)*r*cp,Math.sin(w.pitch)*r,Math.cos(w.yaw)*r*cp);
  const desired=w.follow.clone().add(offset),origin=w.player.position.clone();origin.y=1.25;
  if(r3Indoor(w.active)){
    desired.x=THREE.MathUtils.clamp(desired.x,-w.spaces[w.active].limit.x+.35,w.spaces[w.active].limit.x-.35);
    desired.z=THREE.MathUtils.clamp(desired.z,-w.spaces[w.active].limit.z+.35,w.spaces[w.active].limit.z-.35);
    // Preserve the viewing slope when a room boundary shortens the boom.
    desired.y=Math.min(desired.y,5.05,origin.y+Math.hypot(desired.x-origin.x,desired.z-origin.z)*Math.tan(w.pitch));
  }
  // Keep the plaza follow camera on the courtyard side of both gate beams.
  if(w.active==='plaza')desired.z=THREE.MathUtils.clamp(desired.z,-10.8,11.5);
  const minDist=7.2,indoor=r3Indoor(w.active),space=w.spaces[w.active];
  w.cameraRay=w.cameraRay||new THREE.Raycaster();
  const obstacles=space.group.children.filter(m=>m!==space.floor&&m!==w.player&&m!==space.plaqueGroup);
  const solid=h=>{
    if(h.distance<=.05||h.point.y<=.3)return false;
    for(let m=h.object;m&&m!==space.group;m=m.parent)
      if(!m.visible||m===w.player||m.userData.wallSign||m.userData.r41Label)return false;
    return true;
  };
  const firstHit=(from,to)=>{
    const direction=to.clone().sub(from),distance=direction.length();
    w.cameraRay.set(from,direction.normalize());w.cameraRay.far=distance;
    w.cameraRay.camera=W3.camera;
    return w.cameraRay.intersectObjects(obstacles,true).find(solid);
  };
  // Shorten onto the player's side first. Recover eye distance with Y only,
  // checking the vertical lift as well so a roof cannot be crossed.
  for(let i=0;i<6;i++){
    const hit=firstHit(origin,desired);
    if(hit){const direction=desired.clone().sub(origin).normalize();desired.copy(origin).addScaledVector(direction,Math.max(.6,hit.distance-.22));}
    if(desired.distanceTo(origin)>=minDist-.001)break;
    const horizontal=(desired.x-origin.x)**2+(desired.z-origin.z)**2;
    const raised=desired.clone();raised.y=Math.max(desired.y,origin.y+Math.sqrt(Math.max(0,minDist*minDist-horizontal)));
    if(indoor&&raised.y>5.05)break;
    const ceiling=firstHit(desired,raised);
    if(ceiling)raised.y=Math.min(raised.y,Math.max(desired.y,ceiling.point.y-.22));
    const moved=raised.y-desired.y;desired.copy(raised);
    if(moved<.001)break;
  }
  // The final lift must also have a clear sightline; ceilings take precedence
  // over minimum distance in a confined room.
  const lastHit=firstHit(origin,desired);
  if(lastHit){const boom=desired.clone().sub(origin).normalize();desired.copy(origin).addScaledVector(boom,Math.max(.6,lastHit.distance-.22));}
  if(indoor)desired.y=Math.min(desired.y,5.05);
  w.camera.position.copy(desired);
  // 视线略向前延伸，让门楼与室内陈设进入竖屏上半部。
  const look=w.follow.clone();const ahead=r3Indoor(w.active)?1.2:2;
  look.x-=Math.sin(w.yaw)*ahead;look.z-=Math.cos(w.yaw)*ahead;
  w.camera.lookAt(look);
}

function worldInput(){
  const w=W3,c=w.canvas,joy=$('#joystick');if('ontouchstart' in window||navigator.maxTouchPoints>0)document.body.classList.add('is-touch');
  const movement=['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'];
  window.addEventListener('keydown',e=>{if(movement.includes(e.code)&&!/^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName)){e.preventDefault();if(!worldBlocked()){w.keys.add(e.code);w.target=null;w.path=[];}}});window.addEventListener('keyup',e=>w.keys.delete(e.code));
  function joyMove(e){if(e.pointerId!==w.joyId)return;e.preventDefault();const r=joy.getBoundingClientRect();let x=e.clientX-r.left-r.width/2,y=e.clientY-r.top-r.height/2;const max=r.width*.34,len=Math.hypot(x,y);if(len>max){x*=max/len;y*=max/len;}w.joy.x=x/max;w.joy.y=y/max;$('#joyKnob').style.transform=`translate(${x}px,${y}px)`;}
  joy.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();if(worldBlocked())return;w.joyId=e.pointerId;w.target=null;w.path=[];joy.setPointerCapture(e.pointerId);joyMove(e);});joy.addEventListener('pointermove',joyMove);
  const joyEnd=e=>{if(e.pointerId===w.joyId){w.joyId=null;w.joy.x=w.joy.y=0;$('#joyKnob').style.transform='';}};for(const event of ['pointerup','pointercancel','lostpointercapture'])joy.addEventListener(event,joyEnd);
  c.addEventListener('touchmove',e=>e.preventDefault(),{passive:false});
  c.addEventListener('pointerdown',e=>{if(worldBlocked()||e.button>0)return;e.preventDefault();c.setPointerCapture(e.pointerId);w.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,moved:false});if(w.pointers.size>1){w.pointers.forEach(p=>p.moved=true);w.pinch=0;}});
  c.addEventListener('pointermove',e=>{const p=w.pointers.get(e.pointerId);if(!p)return;if(worldBlocked()){worldStop();return;}const dx=e.clientX-p.x,dy=e.clientY-p.y;p.x=e.clientX;p.y=e.clientY;if(Math.hypot(p.x-p.startX,p.y-p.startY)>7)p.moved=true;
    if(w.pointers.size===2){const a=[...w.pointers.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);if(w.pinch)w.radius=THREE.MathUtils.clamp(w.radius*w.pinch/d,7,24);w.pinch=d;}else if(p.moved){w.yaw-=dx*.008;w.pitch=THREE.MathUtils.clamp(w.pitch+dy*.006,.25,1.2);}});
  c.addEventListener('pointerup',e=>{const p=w.pointers.get(e.pointerId);if(p&&!p.moved&&w.pointers.size===1&&!worldBlocked()){
    const r=c.getBoundingClientRect();w.ndc.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);w.ray.setFromCamera(w.ndc,w.camera);w.ray.camera=W3.camera;const hits=w.ray.intersectObject(w.spaces[w.active].floor);if(hits.length){const point=hits[0].point.clone(),item=w.spaces[w.active].items.filter(i=>Math.hypot(i.x-point.x,i.z-point.z)<1.3&&(!i.r3Edit||r3CanEdit())).sort((a,b)=>Math.hypot(a.x-point.x,a.z-point.z)-Math.hypot(b.x-point.x,b.z-point.z))[0];if(item&&Math.hypot(item.x-w.player.position.x,item.z-w.player.position.z)<item.range){worldStop();item.run();}else{w.pose='idle';worldPath(point);}}
  }w.pointers.delete(e.pointerId);w.pinch=0;});
  for(const event of ['pointercancel','lostpointercapture'])c.addEventListener(event,e=>{w.pointers.delete(e.pointerId);w.pinch=0;});
  c.addEventListener('wheel',e=>{e.preventDefault();if(!worldBlocked())w.radius=THREE.MathUtils.clamp(w.radius+e.deltaY*.01,7,24);},{passive:false});
}
function worldCanMove(x,z){const s=W3.spaces[W3.active],r=.28;if(Math.abs(x)>s.limit.x-r||Math.abs(z)>s.limit.z-r)return false;return !s.blocks.some(b=>x>b.x-r&&x<b.X+r&&z>b.z-r&&z<b.Z+r);}
function worldFrame(ts){
  const w=W3;requestAnimationFrame(worldFrame);if(document.hidden){w.last=0;return;}const dt=Math.min(.04,w.last?(ts-w.last)/1000:0);w.last=ts;if(!w.active)return;
  let moving=false;
  if(worldBlocked())worldStop();else{
    let x=w.joy.x+(w.keys.has('KeyD')||w.keys.has('ArrowRight')?1:0)-(w.keys.has('KeyA')||w.keys.has('ArrowLeft')?1:0),z=w.joy.y+(w.keys.has('KeyS')||w.keys.has('ArrowDown')?1:0)-(w.keys.has('KeyW')||w.keys.has('ArrowUp')?1:0);
    let dx=x*Math.cos(w.yaw)+z*Math.sin(w.yaw),dz=-x*Math.sin(w.yaw)+z*Math.cos(w.yaw);let len=Math.hypot(dx,dz);
    if(len>.08){w.target=null;w.path=[];}else if(w.target){dx=w.target.x-w.player.position.x;dz=w.target.z-w.player.position.z;len=Math.hypot(dx,dz);if(len<.2){w.target=w.path?.shift()||null;len=0;}}
    const acceleration=1-Math.exp(-dt*(len>.08?5.5:8));
    w.vx=(w.vx||0)+((len>.08?dx/len*Math.min(1,len)*4:0)-(w.vx||0))*acceleration;
    w.vz=(w.vz||0)+((len>.08?dz/len*Math.min(1,len)*4:0)-(w.vz||0))*acceleration;
    if(len>.08)w.pose='idle';
    const pos=w.player.position,oldX=pos.x,oldZ=pos.z;
    if(worldCanMove(pos.x+w.vx*dt,pos.z))pos.x+=w.vx*dt;else w.vx=0;
    if(worldCanMove(pos.x,pos.z+w.vz*dt))pos.z+=w.vz*dt;else w.vz=0;
    moving=Math.hypot(pos.x-oldX,pos.z-oldZ)>.0001;
    if(moving){const angle=Math.atan2(w.vx,w.vz);w.player.rotation.y+=Math.atan2(Math.sin(angle-w.player.rotation.y),Math.cos(angle-w.player.rotation.y))*(1-Math.exp(-dt*7));}

    w.elapsed+=dt;
    const exit=w.spaces[w.active].exits.find(e=>Math.abs(w.player.position.x-e.x)<1.35&&Math.abs(w.player.position.z-e.z)<.9);
    const entered=exit&&exit!==w.exitInside;w.exitInside=exit;
    if(!exit)w.exitLatch=null;
    if(entered&&moving&&performance.now()>w.exitCooldownUntil&&w.exitLatch!==exit){w.exitLatch=exit;worldStop();if(exit.r4East)window.r4EastArrival=true;go(exit.to);}
  }
  w.r8Motion=(w.r8Motion||0)+((moving?1:0)-(w.r8Motion||0))*(1-Math.exp(-dt*9));
  w.phase+=dt*(2+9*w.r8Motion);w.body.position.y=Math.abs(Math.sin(w.phase))*.045*w.r8Motion+Math.sin(w.phase)*.018*(1-w.r8Motion);
  w.limbs.forEach((l,i)=>l.rotation.x=Math.sin(w.phase+(i===0||i===3?0:Math.PI))*.5*w.r8Motion);
  r4Pose(w.body,w.limbs,w.pose,moving,ts);if(w.r4SipUntil>ts&&!moving)w.limbs[1].rotation.x=-1.7+Math.sin(ts*.006)*.08;if(w.r4Rock>ts&&!moving)w.body.rotation.z=Math.sin(ts*.004)*.14;
  worldCamera(1-Math.exp(-dt*6));
  if(w.feedback>0){w.feedback-=dt;w.body.position.y+=Math.sin(w.feedback*22)*.055;w.body.rotation.z=Math.sin(w.feedback*18)*.035;}else w.body.rotation.z=0;
  if(w.sky)w.sky.visible=!r3Indoor(w.active);
  tgRemotes(dt);window.__tgFps=window.__tgFps?window.__tgFps*.95+(1/Math.max(.001,dt))*.05:60;
  if(ts-(w.netTime||0)>=100){const pos=w.player.position,rot=w.player.rotation.y,anim=moving?'walk':['sit','sleep'].includes(w.pose)?w.pose:'idle',last=w.netLast;
    if(!last||last.scene!==w.active||Math.hypot(pos.x-last.x,pos.z-last.z)>.001||Math.abs(rot-last.rot)>.001||anim!==last.anim){w.netTime=ts;w.netLast={x:pos.x,z:pos.z,rot,anim,scene:w.active};try{window.TG_NET.onLocalPlayerMove?.({x:pos.x,y:pos.y,z:pos.z},rot,anim);}catch(e){}}
  }
  for(const c of w.crops)c.group.position.y=.24+(c.ripe?Math.sin(ts*.002+c.group.position.x)*.035:0);
  if(w.active==='hall'&&w.smoke.visible)w.smoke.children.forEach((m,i)=>{const t=(ts*.00022+i/18)%1;m.position.set(Math.sin(t*8+i)*.13,2.1+t*1.9,-2.3+Math.cos(i+t*5)*.1);m.scale.setScalar(.035+t*.14);});
  if(typeof r3AnimateAnimals==='function')r3AnimateAnimals(ts,dt);
  let nearest=null,best=Infinity;if(!worldBlocked())for(const item of w.spaces[w.active].items){if(item.r3Edit&&!r3CanEdit())continue;if(w.active==='hall'&&['上香','上供','敲木鱼'].includes(item.label))continue;const d=Math.hypot(w.player.position.x-item.x,w.player.position.z-item.z);if(d<item.range&&d<best){best=d;nearest=item;}}
  const btn=$('#promptBtn');w.action=nearest?nearest.run:null;btn.classList.toggle('show',!!nearest);if(nearest)btn.textContent=typeof nearest.label==='function'?nearest.label():nearest.label;
  if(typeof tgAnimate==='function')tgAnimate(ts,dt);
  if(typeof worldSyncDecor==='function')worldSyncDecor();
  w.renderer.render(w.scene,w.camera);
}
