# r8a.2 — isolated hotfix release on top of r8a.1

- Build: `v4/index.r8a2.html` — **1,660,193 bytes**, sha256 `2a02a2d8df7394eb92b45beb1fe0a69110199ef4ff42f6c68b782b3301ceb675`
- Base: `v4/index.r8a1.html` (sha e962056e…, unchanged). Patch: `v4/r8a2.patch` (diff -u vs r8a1, 140 lines).
- Source: qa/r8b-base-src + the r8a1 sidecar (r8.js) + the r8a2 camera edits in r8.js + the r8a2 block appended to r8.js (copy at `_src/r8a2-block.js`). No r8b yard/tea/market work is included.
- Not touched: codex2 files, backend, economy, IDs, save key, RPCs. Fixes in codex2 files are runtime overrides from r8.js (list below).

## 1. Old-tree camera
- firstHit(…, noTrunk): the virtual trunk box ('r8-trunk', 9.2 m) no longer drives the boost/tilt search. The trunk is handled only by pull-in. Before, the tilt search lifted the camera over the trunk until it was almost top-down on the 18 m boom.
- Hard cap after the h-branch: the camera moves at most 0.7 m per frame, on top of the existing 18·dt lerp.
- codex2 tree-trace (qa/r8-audit/tree-trace.mjs, re-run with OUT=/tmp/r8w/a2/tt): **r8a1 had 6 jumps, r8a2 has 0.**
- Standing still on the tree's north side at (0.19,-3.35): r8a1 camera y drifted 5.94→6.34 (desired point y 18.9). r8a2 holds a steady y 2.11–2.13. At (3.37,-3.33) y stays between 2.98 and 3.21, with no creep.
- Traces and shots: qa/r8a2-shots/tree/

## 2. #muyu 🎐
- Portrait 390×844: top min(445px, 100vh-160px), on-screen.
- Landscape 844×390: bottom 18px / right 24px gives rect [776,328,44,44]. elementFromPoint hits it and a tap works. (At bottom 96px it sat under the waypoint stack, so it was moved.)

## 3. Gate card
- #lockBack 「回小院」: 56×31 → **148×44**.
- #gateLock: fixed, inset 0, z 1000 (above the landscape top bar), with safe-area padding.
- In all three viewports, elementFromPoint(8,8) returns #gateLock and a corner tap returns to the yard (desktop included).

## 4. Dead buttons (qa/r8a-recheck/buttons.r8a.md)
| Button | r8a1 | r8a2 |
|---|---|---|
| 家庭 | no response when TG_FAMILY.open is missing | opens a modal explaining 家庭, with 去登录 (opens login, or toasts 登录需要联网 offline) and 知道了 |
| 🪙 | did nothing while the shop was open | toggles the shop closed |
| ✨ (landscape) | flagged dead | the toast works: opacity 0 at 50 ms, 0.95 at 300 ms, 1 at 700 ms, text 「当前善缘…」. The crawler screenshot was taken during the 0.25 s fade-in (qa/r8a2-shots/toast-land.png) |
| 抽一首诗 / #qianAgain | about 2.3 s with no feedback | instant poem in about 23 ms (12 verses with author) plus 再读一句 |
| 留笺 #r6Send | silent | empty → 「先写一句再留笺」 plus focus; sent → 「留笺已贴上墙」 |
| 锦鲤归水 / 萝卜 / 番茄 ([data-r6-offer]) with no stock | silent | toast 「还没有X：先去心田小院收获，再来摆放」 |
| Backpack 升高 / 降低 | silent without a selection | toast with the height and 「先在下方选一件物品」; with a selection, the item height |
| 收回 | silent without a selection | 「先点一件已摆好的物品，再收回」, otherwise 已收回背包 |
| 旋转 | silent | toast |
| Pond tabs | no active state | active tab marked (highlight, aria-pressed, disabled) |
| 赏景 form | year field / year heading / 性格关键词 | year row hidden, own intro 「选一个院子朝向，写下今天的赏景小记。」, year heading and 性格关键词 line removed from the result |

## 5. Overlays, 3D prompts, hit areas
- #r6Placement: Esc finishes placement. The first tap on empty canvas hints 「再点一次空白处结束布置（或点「完成」）」 and a second tap within 2.5 s saves (「立体布置已保存」). Verified in portrait, landscape and desktop.
- #r7Drawer: closes on Esc and on a tap outside. Verified in portrait, landscape and desktop.
- 前往书房 vs 摇风铃 (hall): the chime group moved z −3.5 and its prompt moved (-4,3)→(-4,-0.5) with range 1.6. At (-4.6,3) and (-4.5,2.6) the prompt is 前往书房; at (-4,-0.4) it is 摇风铃.
- 坐下 vs 坐下喝茶 (zen): duplicate r4Furniture 「坐下」 prompts within 1.3 m of a 坐下喝茶 are removed. Zen prompts are now 前往缘堂, 静室听风铃 and 4× 坐下喝茶.
- Hit areas raised to ≥44 px:
  - #r41Waypoints, #r7MenuToggle
  - #sheet .btn, .inv-item, .r3-tabs, .dirs buttons
  - #r6Placement .btn, #r7Drawer .btn
  - select/input 44 px, textareas 88 px
  - #sheet close 44×44, #lockBack
  - tools 57×44
- Not raised: canvas-drawn and 3D items, which have no DOM box.

## Tests
- Portrait 390×844, landscape 844×390 and desktop: **0 page errors** in every probe (button probe, shots, placement/drawer, calls).
- Draw calls (portrait, r8a1 → r8a2): plaza 167→167, gate 87→87, hall 41→41, yard 124→124, zen 31→31, study 28→28. Lotus 94→94; in landscape 102→102. **Unchanged.**
- The full button-audit crawler was not re-run: it takes 15+ minutes and writes into codex2's output folder. Targeted probes per button were used instead (/tmp/r8w/a2/probe.mjs, place.mjs, toast.mjs, shots.mjs).
- Screenshots: qa/r8a2-shots/{a1,a2}-{mobile,land[,desktop]}-{hall,gate,feng,poem,toast,pond,lotus}.png, plus toast-land.png and tree/.

## Runtime overrides of codex2 files (all in r8.js; codex2 files not edited)
- gameplay.js: toast left as is; #toast max-width set by CSS.
- r5 / family (TG_FAMILY missing): capture listener on 家庭.
- r6.js:
  - openModal post-pass for the pond tab and 赏景 form
  - r6PondOpen wrapper
  - [data-r6-offer] and #r6Send capture listeners
  - placement buttons, Esc and empty-tap
  - hall chime item relocation
- r7.js / r7b-ux.js / r7d:
  - drawer outside-tap and Esc
  - 赏景 intro as a separate div (r7d rewrites `#sheet h2 + p`)
  - shop 🪙 toggle
  - qian instant poem
- r4 furniture: duplicate 坐下 removed in zen (worldSyncDecor and worldEnter wrappers).

## Open flags
- **Compliance risk:** the 赏景小记 result still lists 「可以试试 / 今天不妨少做」, which reads like 宜/忌. Recommend rewording in r8c, or now if 来福 wants it.
- ZEN-005/006 and STUDY-004/005 are left for r8c as instructed.

## Carried into the r8b line
- v4/_src/r8.js (r8b) now has the same camera edits (noTrunk, boost true, 0.7 m cap) plus the r8a2 block appended.
- v4/index.html re-packed (1,697,667 bytes): 0 errors in portrait; placement/drawer checks pass in landscape.
