/* r7b — secular furnishings, wind, and explicit overview camera poses. */
(()=>{
'use strict';
const T=typeof THREE!=='undefined'&&THREE||window.THREE;
// Merge small furniture into one vertex-coloured draw, without touching shared geometry.
function merge(g){g.updateMatrixWorld(true);const inv=g.matrixWorld.clone().invert(),geos=[],colors=[];g.traverse(m=>{if(!m.isMesh)return;const geo=(m.geometry.index?m.geometry.toNonIndexed():m.geometry.clone()).applyMatrix4(new T.Matrix4().multiplyMatrices(inv,m.matrixWorld));geos.push(geo);const c=m.material.color;for(let i=0;i<geo.attributes.position.count;i++)colors.push(c.r,c.g,c.b);});if(!geos.length)return;const geo=mergeGeometries(geos);geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.clear();const mesh=new T.Mesh(geo,new T.MeshLambertMaterial({vertexColors:true}));mesh.userData.tgRealSkip=true;g.add(mesh);geos.forEach(o=>o.dispose());}
const box=(g,c,x,y,z,w,h,d)=>worldMesh(g,'box',c,x,y,z,w,h,d);
const furniture=r3Furniture;
r3Furniture=function(parent,item){if(item.id!=='golden_buddha')return furniture.apply(this,arguments);const g=new T.Group();g.name='r7b-stone-lantern';g.position.set(item.x,item.y||0,item.z);g.rotation.y=item.rot||0;parent.add(g);
box(g,'#858a82',0,.1,0,.92,.2,.92);box(g,'#a0a59a',0,.28,0,.65,.16,.65);box(g,'#8b9187',0,.58,0,.32,.5,.32);box(g,'#b0b4a7',0,.88,0,.78,.14,.78);
box(g,'#353e37',0,1.12,0,.49,.36,.49);for(const x of [-.29,.29])for(const z of [-.29,.29])box(g,'#a0a89b',x,1.13,z,.12,.42,.12);
for(const [x,z,w,d] of [[0,.251,.2,.012],[0,-.251,.2,.012],[.251,0,.012,.2],[-.251,0,.012,.2]])box(g,'#e9ce8d',x,1.1,z,w,.17,d);
box(g,'#9da597',0,1.38,0,.86,.15,.86);worldMesh(g,'cone','#788375',0,1.58,0,.71,.32,.71);worldMesh(g,'ball','#929c8d',0,1.79,0,.1,.1,.1);merge(g);};
for(const c of TG_CATALOG)if(c.id==='golden_buddha')c.name='石灯';
function rack(h){for(const o of h.group.children)if(o.name==='r7-copper-lamp')o.visible=false;if(h.group.getObjectByName('r7b-wish-rack'))return;const g=new T.Group();g.name='r7b-wish-rack';g.position.set(2.8,0,2);h.group.add(g);for(const x of [-.85,.85]){box(g,'#79503a',x,1.15,0,.12,2.3,.16);box(g,'#79503a',x,.09,0,.4,.18,.72);}for(const y of [1.25,2.1])box(g,'#95694b',0,y,0,1.95,.12,.14);for(let i=0;i<8;i++){const x=-.65+(i%4)*.43,y=i<4?1.89:1.04;box(g,'#bd4341',x,y,0,.05,.32,.025);box(g,'#d5af74',x,y-.26,.02,.25,.25,.045);}merge(g);
// Keep the lamp transaction at its existing location; the separate rack offers wishes.
worldInteract(h,2.8,2.5,'挂心愿牌',()=>$('#btnOffer').click(),1.5);
}
// r6 merged these furnishings; filter only their local triangles, preserving the rug/books.
function zen(){const s=W3?.spaces?.zen,g=s?.group.getObjectByName('r6-zen-furnishing');if(!g||s.r7bStudy)return;s.r7bStudy=true;
for(const m of [...s.group.children]){if(m.isMesh&&!m.isInstancedMesh&&Math.abs(m.position.x)===1.5&&m.position.z===-2&&m.position.y===.35)m.visible=false;if((m.userData.r41Label||m.userData.wallSign)&&m.position.z< -7&&m.position.y>3.3)m.visible=false;}
g.traverse(m=>{if(!m.isMesh)return;const geo=m.geometry.index?m.geometry.toNonIndexed():m.geometry.clone(),p=geo.attributes.position,keep=[];for(let i=0;i<p.count;i+=3){const x=(p.getX(i)+p.getX(i+1)+p.getX(i+2))/3,y=(p.getY(i)+p.getY(i+1)+p.getY(i+2))/3,z=(p.getZ(i)+p.getZ(i+1)+p.getZ(i+2))/3;const scroll=Math.abs(x)<1.3&&z< -7.5&&y>1.5,altar=Math.abs(x)<1.65&&z< -4.8&&z> -6.6&&y<2,seat=y<.8&&[-2,0,2].some(cx=>Math.abs(x-cx)<.53)&&[-3,-.8].some(cz=>Math.abs(z-cz)<.53)&&Math.max(p.getY(i),p.getY(i+1),p.getY(i+2))>.115;if(!scroll&&!altar&&!seat)keep.push(i,i+1,i+2);}geo.setIndex(keep);m.geometry=geo;});
const n=new T.Group();n.name='r7b-tea-study';s.group.add(n);
box(n,'#805b43',0,.59,-1.9,1.7,.16,2.5);for(const x of [-.64,.64])for(const z of [-2.85,-.95])box(n,'#6e503d',x,.29,z,.13,.58,.13);
for(const x of [-1.5,1.5])for(const z of [-2.8,-1]){box(n,'#728f87',x,.26,z,.93,.27,.86);box(n,'#b7c7ae',x,.405,z,.79,.04,.72);worldInteract(s,x,z,'坐下喝茶',()=>r4Use({id:'cushion',x,z,rot:x<0?-Math.PI/2:Math.PI/2},'zen'),1.3);}
box(n,'#a3ac99',0,.71,-1.9,1.24,.05,.65);for(const z of [-2.1,-1.65])worldMesh(n,'cylinder','#e4dfc3',.33,.8,z,.12,.14,.12);worldMesh(n,'ball','#617d71',-.24,.84,-1.9,.23,.2,.23);worldMesh(n,'ball','#617d71',-.24,1.02,-1.9,.1,.035,.1);
box(n,'#8a674d',0,.78,-5.7,1.7,.13,.7);for(const x of [-.65,.65])box(n,'#795b45',x,.38,-5.7,.13,.76,.5);worldMesh(n,'ball','#8da9a1',0,1.03,-5.7,.22,.3,.22);worldMesh(n,'cylinder','#95b0a3',0,1.3,-5.7,.08,.15,.08);for(const x of [-.15,0,.14]){worldMesh(n,'cylinder','#64836a',x,1.59,-5.7,.018,.55,.018);worldMesh(n,'ball','#d5c5c0',x,1.9,-5.7,.12,.07,.1);}
// A wide misty mountain painting, painted locally with no external assets.
const canvas=document.createElement('canvas');canvas.width=768;canvas.height=384;const ctx=canvas.getContext('2d');ctx.fillStyle='#e2dfcb';ctx.fillRect(0,0,768,384);for(let layer=0;layer<3;layer++){ctx.fillStyle=['#b7c4ba','#93a99e','#6c8a80'][layer];ctx.beginPath();ctx.moveTo(0,384);for(let x=0;x<=768;x+=12)ctx.lineTo(x,185+layer*56-65*Math.sin(x*.009+layer*1.6)-24*Math.sin(x*.024+layer));ctx.lineTo(768,384);ctx.fill();}const mist=ctx.createLinearGradient(0,180,0,375);mist.addColorStop(0,'#e5e2d000');mist.addColorStop(.65,'#e5e2d0b0');mist.addColorStop(1,'#d7decd55');ctx.fillStyle=mist;ctx.fillRect(0,150,768,234);
box(n,'#674f3e',0,2.96,-7.68,3.6,1.95,.13);merge(n);const tex=new T.CanvasTexture(canvas),painting=new T.Mesh(new T.PlaneGeometry(3.36,1.71),new T.MeshBasicMaterial({map:tex}));painting.position.set(0,2.96,-7.599);painting.userData.tgRealSkip=true;n.add(painting);
s.blocks.push({x:-.85,X:.85,z:-3.15,Z:-.65});
}
function dress(){if(!W3?.spaces)return;const h=W3.spaces.hall;if(h?.r7Built)rack(h);zen();}
const decorate=tgDecorate;tgDecorate=function(){const out=decorate.apply(this,arguments);dress();return out;};
// r8d: the hall wish-tree wind animation (instances()) was dead code — the tree lives in the plaza (r7c animates it there).
const animate=tgAnimate;tgAnimate=function(ts,dt){const out=animate.apply(this,arguments);if(W3?.active==='hall'){if(W3.scene.fog){W3.scene.fog.near=40;W3.scene.fog.far=90;}}return out;};
// Hall is a tall open interior. Bypass only the legacy 5.05m low-ceiling clamp
// while the existing r7 distance-damped camera evaluates this explicit pose.
let tallCamera=false,entry=null,opening=false,overview=null;
function restoreOverview(){if(!overview)return;const w=W3;w.camera.far=overview.far;w.camera.updateProjectionMatrix();if(w.scene.fog===overview.fog){w.scene.fog.near=overview.near;w.scene.fog.far=overview.fogFar;}overview=null;}
const indoor=r3Indoor;r3Indoor=function(id){return tallCamera&&id==='hall'?false:indoor.apply(this,arguments);};
const enter=worldEnter;worldEnter=function(name){restoreOverview();entry=null;opening=name==='hall';try{const out=enter.apply(this,arguments);dress();if(W3.active==='hall'){if(W3.scene.fog){W3.scene.fog.near=35;W3.scene.fog.far=75;}worldCamera(1);}return out;}finally{opening=false;}};
const place=enterPlacement;enterPlacement=function(scene){const out=place.apply(this,arguments);if(W3?.r6Plan?.scene==='yard'){W3.pitch=1.22;W3.radius=24;W3.yaw=0;worldCamera(1);W3.renderer.render(W3.scene,W3.camera);}return out;};
const exit=r6ExitPlacement;r6ExitPlacement=function(){const yard=W3?.r6Plan?.scene==='yard';restoreOverview();const out=exit.apply(this,arguments);if(yard){W3.pitch=.42;W3.radius=8.8;W3.follow.copy(W3.player.position).add(new T.Vector3(0,1.1,0));}return out;};
const camera=worldCamera;worldCamera=function(){const w=W3;if(!w?.active)return camera.apply(this,arguments);
if(opening&&w.active==='hall'&&!entry){w.pitch=.7;w.radius=w.camera.aspect>1?18:24;entry={spawn:w.player.position.clone(),anchor:new T.Vector3(0,0,w.camera.aspect>1?4:11.5)};}
if(w.r6Plan?.scene==='yard'){
// Fit the entire yard at FOV 55 even in narrow portrait. A virtual look-at
// above the centre extends the view without changing the 7–24 zoom contract.
if(!overview)overview={far:w.camera.far,fog:w.scene.fog,near:w.scene.fog?.near,fogFar:w.scene.fog?.far};
const ui=document.getElementById('r6Placement'),top=ui?.querySelector('header')?.getBoundingClientRect().height||0,bottom=ui?.querySelector('footer')?.getBoundingClientRect().height||0,usable=Math.max(.3,1-(top+bottom+20)/w.canvas.clientHeight);
const L=w.spaces.yard.limit,aspect=w.camera.aspect,vfov=55*Math.PI/180,hfov=2*Math.atan(Math.tan(vfov/2)*aspect),height=1.12*Math.max((L.x+1)/Math.tan(hfov/2),(L.z+1)/(Math.tan(vfov/2)*usable));const target=new T.Vector3(0,Math.max(0,height-24*Math.sin(w.pitch)),0),cp=Math.cos(w.pitch);w.camera.position.copy(target).add(new T.Vector3(Math.sin(w.yaw)*w.radius*cp,Math.sin(w.pitch)*w.radius,Math.cos(w.yaw)*w.radius*cp));w.camera.lookAt(0,0,(bottom-top)/w.canvas.clientHeight*height*Math.tan(vfov/2));w.camera.far=Math.max(100,height+70);w.camera.updateProjectionMatrix();if(w.scene.fog){w.scene.fog.near=height+20;w.scene.fog.far=height+100;}return;
}
if(w.active!=='hall'||S.view==='fp')return camera.apply(this,arguments);
const saved=w.player.position.clone(),follow=w.follow.clone();
// Entry opening shot releases as soon as the player walks. Subsequent motion
// follows the real player with the new user-adjustable pitch/radius.
if(entry&&saved.distanceTo(entry.spawn)>.18)entry=null;
const openingShot=!!entry;if(entry){w.player.position.copy(entry.anchor);w.follow.copy(entry.anchor).add(new T.Vector3(0,1.1,0));}else{w.player.position.y+=2.3;w.follow.y+=2.3;}
tallCamera=true;try{const out=camera.apply(this,arguments);if(entry)w.camera.lookAt(0,5,0);return out;}finally{tallCamera=false;w.player.position.copy(saved);if(openingShot)w.follow.copy(follow);else w.follow.y-=2.3;}
};
const css=document.createElement('style');css.textContent=`@media(orientation:landscape) and (max-height:500px){
#topbar{padding-left:max(9px,env(safe-area-inset-left));padding-right:max(9px,env(safe-area-inset-right));gap:5px}#r7MenuToggle{top:calc(env(safe-area-inset-top) + 49px)}#r7Drawer{top:calc(env(safe-area-inset-top) + 89px);max-height:calc(100% - 110px)}#r41Waypoints{top:calc(env(safe-area-inset-top) + 91px);right:max(9px,env(safe-area-inset-right));gap:3px}#joystick{width:78px!important;height:78px!important;bottom:calc(env(safe-area-inset-bottom) + 12px)!important}#promptBtn,body[data-scene="yard"] #promptBtn{bottom:calc(env(safe-area-inset-bottom) + 15px)!important;max-width:calc(100% - 240px);white-space:normal}#r6Placement footer{padding:4px max(10px,env(safe-area-inset-right)) max(4px,env(safe-area-inset-bottom)) max(10px,env(safe-area-inset-left))}#r6Placement .r6-controls{gap:5px;margin:3px 0}#r6Placement .r6-controls button{min-height:32px;padding:5px 2px}#r6Placement header{padding-top:max(4px,env(safe-area-inset-top))}#r6Placement .r7-place-inventory summary{font-size:12px}#r7Drawer #seedBar{max-height:70px;flex-wrap:nowrap!important}#r7Drawer #seedBar .seed{flex-shrink:0}
}`;document.head.append(css);dress();
})();
