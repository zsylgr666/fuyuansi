/* art3 — 公共地图美化（里门/大厅广场/集市/荷塘）+ 缘堂「古朴木作」与「竹石素雅」两种风格的明显区分。
 * 独立文件：只通过已有全局钩子挂载（THREE、W3、TG_SCENES、TG_RERENDER、initWorld、worldEnter、
 * worldSyncShrine、tgAnimate、worldMat），不修改任何既有函数体；所有包装都幂等、带守卫。
 * 新增模型全部放在各场景 group 下的独立子 Group（art3Group）里：
 *   - 不是 group 的直接 Mesh 子节点 → 不参与相机避障射线、不被 art2 tgArtBatch 合并；
 *   - 点击拾取只命中 space.floor → 不影响点击走路/交互；
 *   - 只往 space.blocks 追加小块碰撞，不动出口、交互点、地板。
 */
(function(){
'use strict';
var G=typeof window!=='undefined'?window:globalThis;
if(G.__TG_ART3)return;
var A=G.__TG_ART3={version:'art3-1',applied:{},styleBuilt:{},errors:[]};
var PUBLIC_BUILDERS={};           // sceneId -> builder(space)
var LIVE={};                      // per-scene animated objects
var GEO={},MAT={},TEX={};

function hooksReady(){
 return typeof THREE!=='undefined'&&typeof W3!=='undefined'&&!!W3&&!!W3.spaces&&!!W3.scene&&!!W3.renderer&&
  Array.isArray(G.TG_SCENES)&&typeof G.worldMat==='function';
}
function warn(where,e){A.errors.push(where+': '+(e&&e.message||e));try{console.warn('[art3] '+where,e);}catch(_){}}
/* 可复现的伪随机，保证每次进入布局一致。 */
function rng(seed){var s=seed>>>0||1;return function(){s=(s*16807)%2147483647;return s/2147483647;};}

/* ---------- 几何/材质缓存（挂在 W3.geometries / W3.materials 的 art3: 前缀下） ---------- */
function geo(name){
 if(GEO[name])return GEO[name];
 var g;
 switch(name){
  case 'box':g=new THREE.BoxGeometry(1,1,1);break;
  case 'ball':g=new THREE.SphereGeometry(1,10,7);break;
  case 'ball6':g=new THREE.SphereGeometry(1,7,5);break;
  case 'cyl':g=new THREE.CylinderGeometry(1,1,1,12);break;
  case 'cyl6':g=new THREE.CylinderGeometry(1,1,1,6);break;
  case 'cyl8':g=new THREE.CylinderGeometry(1,1,1,8);break;
  case 'cone':g=new THREE.ConeGeometry(1,1,8);break;
  case 'cone6':g=new THREE.ConeGeometry(1,1,6);break;
  case 'rock':g=new THREE.DodecahedronGeometry(1,0);break;
  case 'plane':g=new THREE.PlaneGeometry(1,1);break;
  case 'flat':g=new THREE.PlaneGeometry(1,1).rotateX(-Math.PI/2);break;
  case 'disc':g=new THREE.CircleGeometry(1,40).rotateX(-Math.PI/2);break;
  case 'leaf':g=new THREE.CircleGeometry(1,16,.28,Math.PI*2-.56).rotateX(-Math.PI/2);break;
  case 'torus':g=new THREE.TorusGeometry(1,.16,6,18);break;
  case 'petal':g=new THREE.SphereGeometry(1,7,5).translate(0,1,0);break;
  case 'bowl':g=new THREE.SphereGeometry(1,12,4,0,Math.PI*2,0,1.05).rotateX(Math.PI).translate(0,1,0);break;
  case 'tri':{g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute([-.5,0,0,.5,0,0,0,-1,0],3));g.computeVertexNormals();break;}
  default:g=new THREE.BoxGeometry(1,1,1);
 }
 W3.geometries['art3:'+name]=g;return GEO[name]=g;
}
function mat(c){return G.worldMat(c);}                 // 共享平面着色 Lambert（与原场景一致）
function smat(c){return G.worldMat(c,true);}
function cached(key,make){return MAT[key]||(MAT[key]=W3.materials['art3:'+key]=make());}
function dmat(c){return cached('d:'+c,function(){return new THREE.MeshLambertMaterial({color:c,side:THREE.DoubleSide});});}
function emat(c,e,i){return cached('e:'+c+':'+(e||c)+':'+(i||.6),function(){return new THREE.MeshLambertMaterial({color:c,emissive:e||c,emissiveIntensity:i||.6});});}
function canvasTex(key,w,h,draw,repeat){
 if(TEX[key])return TEX[key];
 var c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);
 var t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;if(repeat)t.repeat.set(repeat[0],repeat[1]);
 if('colorSpace' in t&&THREE.SRGBColorSpace)t.colorSpace=THREE.SRGBColorSpace;
 return TEX[key]=t;
}
function texMat(key,w,h,draw,opts){
 return cached('t:'+key,function(){var o=Object.assign({map:canvasTex(key,w,h,draw)},opts||{});return o.basic?(delete o.basic,new THREE.MeshBasicMaterial(o)):new THREE.MeshLambertMaterial(o);});
}

/* ---------- 构件 ---------- */
/* P(group, 几何名|几何, 颜色|材质, 位置, 缩放, 旋转, 是否投影) */
function P(g,gn,m,x,y,z,sx,sy,sz,rx,ry,rz,cast){
 var mesh=new THREE.Mesh(typeof gn==='string'?geo(gn):gn,typeof m==='string'?mat(m):m);
 mesh.position.set(x,y,z);mesh.scale.set(sx,sy==null?sx:sy,sz==null?sx:sz);
 if(rx||ry||rz)mesh.rotation.set(rx||0,ry||0,rz||0);
 mesh.userData.a3cast=!!cast;g.add(mesh);return mesh;
}
function sub(g,x,y,z,ry,s){var o=new THREE.Group();o.position.set(x,y,z);if(ry)o.rotation.y=ry;if(s)o.scale.setScalar(s);g.add(o);return o;}
function block(s,x,z,a,b){s.blocks.push({x:x-a/2,X:x+a/2,z:z-b/2,Z:z+b/2,art3:true});}
/* 把静态构件按 几何+材质 合并成 InstancedMesh：大幅减少 draw call。userData.a3live 的直接子节点保留不动（动画用）。 */
function bake(g){
 g.updateMatrixWorld(true);
 var inv=new THREE.Matrix4().copy(g.matrixWorld).invert(),buckets=new Map(),keep=[];
 g.traverse(function(o){
  if(o===g)return;
  var p=o.parent,live=false;while(p&&p!==g){if(p.userData.a3live)live=true;p=p.parent;}
  if(live)return;
  if(o.userData.a3live){if(o.parent===g)keep.push(o);return;}
  if(o.isMesh&&!o.isInstancedMesh){var k=o.geometry.uuid+'|'+o.material.uuid;if(!buckets.has(k))buckets.set(k,[]);buckets.get(k).push(o);}
  else if((o.isInstancedMesh||o.isPoints)&&o.parent===g)keep.push(o);
 });
 var built=[];
 buckets.forEach(function(list){
  var f=list[0],mtx=new THREE.Matrix4(),out;
  if(list.length===1){out=new THREE.Mesh(f.geometry,f.material);mtx.multiplyMatrices(inv,f.matrixWorld);mtx.decompose(out.position,out.quaternion,out.scale);}
  else{out=new THREE.InstancedMesh(f.geometry,f.material,list.length);for(var i=0;i<list.length;i++){mtx.multiplyMatrices(inv,list[i].matrixWorld);out.setMatrixAt(i,mtx);}out.instanceMatrix.needsUpdate=true;out.computeBoundingSphere();}
  out.castShadow=false;out.receiveShadow=false;built.push(out);
 });
 while(g.children.length)g.remove(g.children[0]);
 keep.forEach(function(o){g.add(o);});built.forEach(function(o){g.add(o);});
 return g;
}
function glowTexture(){return canvasTex('glow',64,64,function(a){var gr=a.createRadialGradient(32,32,0,32,32,32);gr.addColorStop(0,'rgba(255,255,255,1)');gr.addColorStop(.35,'rgba(255,255,255,.45)');gr.addColorStop(1,'rgba(255,255,255,0)');a.fillStyle=gr;a.fillRect(0,0,64,64);});}
/* 一次 draw call 的发光点（灯笼光晕/萤火）：不用真实点光源，手机上更省。 */
function glow(g,pts,color,size,opacity){
 if(!pts.length)return null;var flat=[];pts.forEach(function(p){flat.push(p[0],p[1],p[2]);});
 var bg=new THREE.BufferGeometry();bg.setAttribute('position',new THREE.Float32BufferAttribute(flat,3));
 var m=new THREE.PointsMaterial({map:glowTexture(),color:color,size:size,sizeAttenuation:true,transparent:true,opacity:opacity||.8,depthWrite:false,blending:THREE.AdditiveBlending});
 var p=new THREE.Points(bg,m);p.userData.a3live=true;p.userData.baseOpacity=opacity||.8;p.frustumCulled=false;g.add(p);return p;
}

/* 曲面屋顶：中脊陡、檐口缓、四角起翘（中式反宇飞檐）。顶面用瓦垄贴图，底面用 BackSide 彩色材质。 */
function roofGeo(len,depth,rise,lift){
 var key='roof:'+[len,depth,rise,lift].map(function(v){return (+v).toFixed(2);}).join(',');
 if(GEO[key])return GEO[key];
 var nu=12,nv=20,pos=[],uv=[],idx=[],i,j;
 for(i=0;i<=nu;i++){var u=-1+2*i/nu,au=Math.abs(u);
  for(j=0;j<=nv;j++){var v=j/nv,e=Math.pow(Math.abs(2*v-1),5);
   pos.push((v-.5)*len*(1+.07*au),rise*Math.pow(1-au,1.8)+lift*e*Math.pow(au,1.6),u*depth/2*(1+.1*e));
   uv.push(v*len/1.1,(u+1)*depth/2.2);}}
 for(i=0;i<nu;i++)for(j=0;j<nv;j++){var a=i*(nv+1)+j,b=a+1,c=a+nv+1,d=c+1;idx.push(a,c,b,b,c,d);}
 var g=new THREE.BufferGeometry();g.setIndex(idx);g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.computeVertexNormals();
 W3.geometries['art3:'+key]=g;return GEO[key]=g;
}
function tileMat(color,double){
 return cached('tile:'+color+(double?':2':''),function(){
  var t=canvasTex('tiles',128,128,function(a){a.fillStyle='#ffffff';a.fillRect(0,0,128,128);for(var x=0;x<128;x+=16){var gr=a.createLinearGradient(x,0,x+16,0);gr.addColorStop(0,'#8c8c8c');gr.addColorStop(.45,'#ffffff');gr.addColorStop(1,'#7a7a7a');a.fillStyle=gr;a.fillRect(x,0,16,128);}a.fillStyle='rgba(0,0,0,.22)';for(var y=0;y<128;y+=21)a.fillRect(0,y,128,2);});
  return new THREE.MeshLambertMaterial({map:t,color:color,side:double?THREE.DoubleSide:THREE.FrontSide});
 });
}
function underMat(color){return cached('under:'+color,function(){return new THREE.MeshLambertMaterial({color:color,side:THREE.BackSide});});}
function roof(g,x,y,z,len,depth,rise,lift,o){
 o=o||{};var r=sub(g,x,y,z,o.ry||0),gm=roofGeo(len,depth,rise,lift);
 var top=new THREE.Mesh(gm,tileMat(o.tile||'#4a5d5c'));top.userData.a3cast=true;r.add(top);
 var under=new THREE.Mesh(gm,underMat(o.under||'#8e3b2b'));under.position.y=-.09;r.add(under);
 var rc=o.ridge||'#2f3b3b';P(r,'box',rc,0,rise+.07,0,len*.9,.26,.28,0,0,0,true);
 for(var s=-1;s<=1;s+=2){P(r,'cone',rc,s*len*.45,rise+.36,0,.17,.6,.22,0,0,-s*.38);P(r,'ball6',rc,s*len*.45,rise+.18,0,.2,.2,.2);}
 if(o.pearl)P(r,'ball',emat('#e8c45a','#a8761c',.35),0,rise+.42,0,.22);
 return r;
}
/* 攒尖顶（亭子宝顶）：Lathe 凹曲面。 */
function latheRoofGeo(radius,height,segs,exp){
 var key='lathe:'+[radius,height,segs,exp].join(',');if(GEO[key])return GEO[key];
 var pts=[];for(var i=0;i<=12;i++){var t=i/12;pts.push(new THREE.Vector2(Math.max(.001,radius*t),height*Math.pow(1-t,exp||1.6)));}
 var g=new THREE.LatheGeometry(pts,segs||8,0,Math.PI*2);W3.geometries['art3:'+key]=g;return GEO[key]=g;
}
function latheRoof(g,x,y,z,radius,height,segs,color,exp,tips,noFinial){
 var r=sub(g,x,y,z,0);var m=new THREE.Mesh(latheRoofGeo(radius,height,segs,exp),tileMat(color||'#4a5d5c',true));m.userData.a3cast=true;r.add(m);
 if(tips)for(var i=0;i<segs;i++){var a=i/segs*Math.PI*2;P(r,'cone',color||'#4a5d5c',Math.sin(a)*radius*1.02,.12,Math.cos(a)*radius*1.02,.09,.38,.09,Math.cos(a)*-.9,0,Math.sin(a)*.9);}
 if(!noFinial){P(r,'ball',emat('#d9b356','#8a5d16',.25),0,height+.1,0,.16,.2,.16);P(r,'cyl8','#3a4747',0,height-.05,0,.12,.3,.12);}
 return r;
}
function textTex(key,text,bg,fg,border,w,h,font){
 return canvasTex(key,w||64,h||256,function(a,W,H){a.fillStyle=bg;a.fillRect(0,0,W,H);if(border){a.strokeStyle=border;a.lineWidth=5;a.strokeRect(5,5,W-10,H-10);}a.fillStyle=fg;a.textAlign='center';a.textBaseline='middle';var ch=[...text],step=(H-30)/ch.length;a.font=(font||'bold ')+Math.min(W*.68,step*.8)+'px serif';ch.forEach(function(c,i){a.fillText(c,W/2,15+step*(i+.5));});});
}
function signPlane(g,key,text,bg,fg,border,x,y,z,w,h,ry){
 var m=new THREE.Mesh(geo('plane'),cached('sign:'+key,function(){return new THREE.MeshLambertMaterial({map:textTex(key,text,bg,fg,border),side:THREE.DoubleSide});}));
 m.position.set(x,y,z);m.scale.set(w,h,1);if(ry)m.rotation.y=ry;g.add(m);return m;
}
function flagRect(g,key,text,bg,fg,border,x,y,z,w,h,ry){
 var m=new THREE.Mesh(geo('plane'),cached('flag:'+key,function(){return new THREE.MeshLambertMaterial({map:canvasTex('flag:'+key,256,96,function(a,W,H){a.fillStyle=bg;a.fillRect(0,0,W,H);if(border){a.strokeStyle=border;a.lineWidth=6;a.strokeRect(6,6,W-12,H-12);}a.fillStyle=fg;a.textAlign='center';a.textBaseline='middle';a.font='bold 36px serif';a.fillText(text,W/2,H/2);}),side:THREE.DoubleSide});}));
 m.position.set(x,y,z);m.scale.set(w,h,1);if(ry)m.rotation.y=ry;g.add(m);return m;
}
/* 红灯笼：返回光晕位置。 */
function lantern(g,x,y,z,s,color){
 s=s||1;var red=emat(color||'#d2402c','#b3261a',.55),gold=mat('#d8ae55');
 P(g,'ball',red,x,y,z,.26*s,.31*s,.26*s);
 P(g,'cyl8',gold,x,y+.3*s,z,.13*s,.07*s,.13*s);P(g,'cyl8',gold,x,y-.3*s,z,.13*s,.07*s,.13*s);
 P(g,'box','#c9372a',x,y-.48*s,z,.03*s,.26*s,.03*s);
 return [x,y,z];
}
function pine(g,s,x,z,h,seed){
 var r=rng(seed||7);h=h||4.5;P(g,'cyl','#6e4e37',x,h*.4,z,.2,h*.8,.2,0,0,.05,true);
 for(var i=0;i<5;i++){var t=i/4,y=h*(.45+t*.5),rad=1.7*(1-t*.55),a=r()*6.28;P(g,'ball6',i%2?'#4d774b':'#5b8653',x+Math.cos(a)*.35*(1-t),y,z+Math.sin(a)*.35*(1-t),rad,.42,rad*.9,0,a,0,true);}
 block(s,x,z,.6,.6);
}
function roundTree(g,s,x,z,h,col,seed){
 var r=rng(seed||3);h=h||3;P(g,'cyl','#7a573c',x,h*.45,z,.2,h*.9,.2,0,0,0,true);
 for(var i=0;i<5;i++){var a=r()*6.28,d=.6*r();P(g,'ball',col||'#79a05c',x+Math.cos(a)*d,h+r()*.8,z+Math.sin(a)*d,.9+r()*.4,.8+r()*.3,.9+r()*.4,0,0,0,true);}
 block(s,x,z,.6,.6);
}
function willow(g,s,x,z,seed){
 var r=rng(seed||11);P(g,'cyl','#6f5440',x,1.4,z,.22,2.8,.22,0,0,.08,true);
 for(var i=0;i<4;i++)P(g,'ball','#8db35f',x+(r()-.5)*1.2,3+r()*.5,z+(r()-.5)*1.2,1.1,.6,1.1,0,0,0,true);
 for(i=0;i<34;i++){var a=i/34*6.28+r()*.2,d=.9+r()*.7,len=1.2+r()*1.1;P(g,'box',i%3?'#9cc26a':'#b5d17c',x+Math.cos(a)*d,3.1-len/2,z+Math.sin(a)*d,.05,len,.05,Math.sin(a)*.12,0,-Math.cos(a)*.12);}
 block(s,x,z,.6,.6);
}
function stoneLantern(g,x,z,s,light){
 s=s||1;var st='#a7a79c',dk='#8d8d82';
 P(g,'cyl6',st,x,.12*s,z,.45*s,.24*s,.45*s,0,0,0,true);P(g,'cyl6',st,x,.62*s,z,.14*s,.8*s,.14*s,0,0,0,true);
 P(g,'cyl6',dk,x,1.06*s,z,.36*s,.1*s,.36*s);P(g,'box',light||emat('#f3e6c2','#e0b25a',.5),x,1.3*s,z,.36*s,.38*s,.36*s);
 P(g,'cone6',dk,x,1.66*s,z,.56*s,.36*s,.56*s,0,0,0,true);P(g,'ball6',st,x,1.9*s,z,.1*s,.13*s,.1*s);
 return [x,1.3*s,z];
}
/* 石狮：朝 +z。male 踩绣球，female 抚幼狮。 */
function lion(g,x,y,z,ry,s,male){
 var L=sub(g,x,y,z,ry,s),st='#b4b1a4',dk='#94907f';
 P(L,'ball',st,0,.5,-.25,.42,.42,.5,0,0,0,true);P(L,'ball',st,0,.86,.1,.4,.55,.38,0,0,0,true);
 for(var sx=-1;sx<=1;sx+=2){P(L,'box',st,sx*.2,.38,.32,.15,.76,.17);P(L,'ball6',st,sx*.24,.2,-.18,.17,.22,.3);P(L,'ball6',dk,sx*.2,.04,.42,.11,.06,.14);}
 P(L,'ball',st,0,1.34,.3,.34,.33,.32,0,0,0,true);
 for(var i=0;i<12;i++){var a=i/12*Math.PI*2;P(L,'ball6',dk,Math.cos(a)*.31,1.34+Math.sin(a)*.31,.14,.12);}
 P(L,'box',dk,0,1.25,.6,.22,.15,.14);P(L,'box','#7e7a6c',0,1.12,.55,.2,.05,.1);
 for(sx=-1;sx<=1;sx+=2){P(L,'ball6','#3d3b35',sx*.12,1.41,.6,.04,.04,.03);P(L,'ball6',dk,sx*.24,1.62,.22,.08,.1,.08);}
 P(L,'ball6',dk,0,.72,-.68,.15,.28,.15,.6,0,0);
 if(male)P(L,'ball',dk,.26,.15,.58,.16);else{P(L,'ball6',st,-.28,.18,.55,.14,.13,.18);P(L,'ball6',st,-.28,.33,.62,.09);}
 return L;
}
function ground(g,size,color,y){P(g,'flat',smat(color),0,y==null?-.33:y,0,size,1,size);}

/* ================= 场景：里门 gate ================= */
PUBLIC_BUILDERS.gate=function(s,g){
 var red='#9b3a2c',gold='#d9b052',stone='#c3bca8';
 ground(g,170,'#9fae86');
 // 低矮石台基 + 两级浅阶（高度 ≤ .08，不挡走路）
 P(g,'box',stone,0,.04,-5,15,.08,4.4);for(var j=0;j<2;j++)P(g,'box','#b5ae99',0,.02,-2.55+j*.3,10-j*1.4,.04,.35);
 P(g,'box','#aaa38e',0,.02,-7.45,15.4,.04,.4);
 // 主楼曲檐顶、斗拱、彩画梁
 roof(g,0,5.42,-5,13.4,3.2,1,.6,{tile:'#3f5453',under:'#a34a33',pearl:true});
 var dou=[];for(var x=-6;x<=6.01;x+=.6)for(var sd=-1;sd<=1;sd+=2){P(g,'box',(Math.round(x/.6)%2)?'#2f6f68':gold,x,5.16,-5+sd*.72,.3,.16,.36);P(g,'box','#7b3424',x,5.0,-5+sd*.66,.2,.14,.24);}
 var band=texMat('gateband',256,32,function(a){a.fillStyle='#2f6f68';a.fillRect(0,0,256,32);a.fillStyle='#d9b052';a.fillRect(0,0,256,3);a.fillRect(0,29,256,3);for(var i=0;i<8;i++){a.fillStyle=i%2?'#1f4f6a':'#3f8a7a';a.beginPath();a.ellipse(16+i*32,16,13,9,0,0,Math.PI*2);a.fill();a.strokeStyle='#e8cf7a';a.lineWidth=2;a.stroke();}});
 [[-3.65,3.1],[3.65,3.1]].forEach(function(b){P(g,'plane',band,b[0],4.6,-4.385,b[1],.6,1);});
 P(g,'plane',band,0,4.6,-5.615,10.8,.6,1,0,Math.PI,0);
 // 抱鼓石夹柱
 for(var sx=-1;sx<=1;sx+=2){for(var sz=-1;sz<=1;sz+=2){P(g,'cyl',stone,sx*5,.55,-5+sz*.72,.42,.16,.42,Math.PI/2,0,0,true);P(g,'box',stone,sx*5,.2,-5+sz*.72,.36,.4,.5);}block(s,sx*5,-5,.8,2.3);}
 // 次间：两侧矮柱 + 小屋顶 + 额枋
 for(sx=-1;sx<=1;sx+=2){var px=sx*7.5;P(g,'box',red,px,1.7,-5,.5,3.4,.6,0,0,0,true);P(g,'box',stone,px,.2,-5,.9,.4,1.1);P(g,'box',red,sx*6.25,3.05,-5,2.5,.45,.7);P(g,'box',gold,sx*6.25,3.05,-4.64,2.2,.12,.02);
  roof(g,sx*6.3,3.4,-5,3.6,2.4,.6,.35,{tile:'#3f5453',under:'#a34a33'});block(s,px,-5,.6,.7);P(g,'box',gold,px,3.42,-5,.6,.12,.7);}
 // 石狮一对（台基上）
 for(sx=-1;sx<=1;sx+=2){P(g,'box',stone,sx*2.65,.32,-3.15,1.05,.5,1.35,0,0,0,true);P(g,'box','#d0c9b4',sx*2.65,.6,-3.15,1.15,.08,1.45);lion(g,sx*2.65,.64,-3.15,0,.95,sx>0);block(s,sx*2.65,-3.15,1.1,1.4);}
 // 石碑（龟趺）
 P(g,'ball','#8f8d80',-9.4,.35,-.6,.9,.42,1.2,0,0,0,true);P(g,'ball6','#8f8d80',-9.4,.42,.55,.3,.26,.32);
 P(g,'box','#a9a698',-9.4,1.55,-.6,1.1,2.1,.32,0,0,0,true);P(g,'box','#9a978a',-9.4,2.72,-.6,1.25,.3,.4);
 signPlane(g,'stele','福缘胜境','#a9a698','#4a4638',null,-9.4,1.55,-.43,.75,1.8);block(s,-9.4,-.3,1.6,2.2);
 // 松柏夹道
 [[-12.5,-3],[12.5,-3],[-12.5,10.5],[12.5,10.5],[-6.8,11.6],[6.8,11.6],[12.3,3.8]].forEach(function(p,i){pine(g,s,p[0],p[1],4+i%3*.6,i+3);});
 // 远景：山坡、上山石阶、坡顶楼阁、阙楼、远山
 P(g,'ball',smat('#86a070'),0,-1,-35,24,7,14);P(g,'ball',smat('#7e9a6c'),-20,-2,-40,16,9,12);P(g,'ball',smat('#7e9a6c'),20,-2,-41,17,8,12);
 for(j=0;j<18;j++){var zz=-20.2-j*.5,yy=Math.max(0,-1+7*Math.sqrt(Math.max(0,1-Math.pow((zz+35)/14,2))));P(g,'box','#cfc6ad',0,yy-.15,zz,3.2,.32,.55);}
 P(g,'box','#cfc6ad',0,5.85,-31.5,7,.3,4);P(g,'box','#a54436',0,7.3,-33.4,7,2.8,2.6);for(sx=-3;sx<=3;sx+=2)P(g,'box','#7d2f24',sx,7.2,-32.05,.25,2.8,.25);
 roof(g,0,8.7,-33.4,9.2,4.6,1.5,.7,{tile:'#3b4b4b',under:'#a34a33'});
 var pg=sub(g,-10,3.2,-34,0);P(pg,'box','#a54436',0,1.1,0,2.2,2.2,1.6);P(pg,'box','#d8cfb8',0,2.25,0,2.6,.22,2.0);P(pg,'box','#a54436',0,3.15,0,1.8,1.5,1.3);roof(pg,0,3.95,0,2.8,2.2,.7,.35,{tile:'#3b4b4b',under:'#a34a33'});
 for(var i=0;i<7;i++){var m=P(g,'cone',smat(i%2?'#9fb0a6':'#8ea398'),-42+i*14,6,-52-(i%3)*3,12,14+(i%3)*4,9);}
 var tp=[];var r=rng(5);for(i=0;i<16;i++){var tx=(r()-.5)*36,tz=-24-r()*14;if(Math.abs(tx)<3)tx+=6;P(g,'cone','#557e52',tx,2+r()*2,tz,1,3,1);}
 bake(g);
 // 雾气感由 worldEnter 包装里的 fog 设置提供
};

/* ================= 场景：集市 market ================= */
PUBLIC_BUILDERS.market=function(s,g){
 var wood='#7c5236',gold='#d8ae55',glows=[];
 ground(g,170,'#c2b392');
 // 路沿石
 for(var sd=-1;sd<=1;sd+=2)P(g,'box','#8f8a7a',0,.05,sd*1.55,26,.1,.16);
 var names=[['花木','#3f7a5a'],['家具','#8a4a2e'],['灯彩','#a8322a']];
 [-7,0,7].forEach(function(x,i){
  // 瓦顶 + 花边垂幔
  roof(g,x,3.18,-5,5.4,3.5,.75,.38,{tile:'#4b5f5d',under:'#7d4a30'});
  for(var j=0;j<16;j++){var col=j%2?'#f3e6c6':(i===1?'#a8553b':'#c0473a');P(g,'disc',dmat(col),x-2.25+j*.3,2.88,-3.52,.15,1,.15,Math.PI/2,0,0);}
  // 货架 + 货物
  P(g,'box',wood,x,1.25,-6.25,3.6,2.5,.4,0,0,0,true);for(var k=0;k<3;k++)P(g,'box','#9a6b48',x,.5+k*.8,-6.05,3.5,.06,.5);
  var r=rng(20+i);
  for(k=0;k<15;k++){var row=k%3,cx=x-1.5+Math.floor(k/3)*.75;
   if(i===0){P(g,'cyl','#9c7448',cx,.62+row*.8,-6,.17,.18,.17);P(g,'ball6',row===1?'#e48aa0':row?'#f0c25a':'#6f9a52',cx,.82+row*.8,-6,.2,.18,.2);}
   else if(i===1){P(g,'box',r()>.5?'#8a5a3c':'#6e4630',cx,.72+row*.8,-6,.36,.38,.32);}
   else{P(g,'cyl','#d8ae55',cx,.62+row*.8,-6,.08,.08,.08);P(g,'ball',row===1?'#d2402c':'#e8d6a8',cx,.78+row*.8,-6,.16,.18,.16);}}
  block(s,x,-6.25,3.7,.5);
  // 柜台上的篮/罐
  for(k=0;k<3;k++){var bx=x-1.2+k*1.2;P(g,'cyl','#a77b4c',bx,1.5,-5.35,.3,.18,.3);P(g,'ball6',i===2?'#c6a46a':['#ef8a5a','#e7c65a','#86b35c'][k],bx,1.62,-5.35,.26,.12,.26);}
  // 幌子
  var px=x+2.6;P(g,'cyl','#5f412c',px,2.1,-3.6,.06,4.2,.06,0,0,0,true);P(g,'box','#5f412c',px-.35,4.1,-3.6,.8,.06,.06);
  signPlane(g,'mk'+i,names[i][0],names[i][1],'#fff0c8','#e2c06a',px-.55,3.15,-3.6,.46,1.5);block(s,px,-3.6,.22,.22);
  // 地上的箱筐/麻袋
  P(g,'box','#9a7048',x-2.45,.3,-5.6,.6,.6,.6,0,.3,0,true);P(g,'box','#8a6040',x-2.45,.8,-5.6,.45,.4,.45,0,.9,0);P(g,'ball6','#d8c49a',x+2.35,.32,-5.9,.32,.34,.3);
  block(s,x-2.45,-5.6,.8,.8);
 });
 // 横跨街道的灯笼串（4 组）+ 彩旗
 var poles=[-10.5,-3.5,3.5,10.5];
 poles.forEach(function(x){for(var sd=-1;sd<=1;sd+=2){P(g,'cyl','#5f412c',x,2,sd*2.7,.07,4,.07,0,0,0,true);P(g,'ball6',gold,x,4.05,sd*2.7,.1);block(s,x,sd*2.7,.24,.24);}
  for(var t=0;t<=8;t++){var u=t/8,zz=-2.7+u*5.4,yy=3.85-.45*(1-Math.pow(2*u-1,2));if(t<8){var u2=(t+.5)/8;P(g,'box','#3b2a20',x,3.85-.45*(1-Math.pow(2*u2-1,2)),-2.7+u2*5.4,.02,.02,.7);}
   if(t%2===1)glows.push(lantern(g,x,yy-.45,zz,.85));}});
 var flagC=['#c0473a','#e2b24a','#3f7a5a','#3f6a8a'];
 for(sd=-1;sd<=1;sd+=2)for(var p=0;p<3;p++){var x0=poles[p],x1=poles[p+1];for(var f=0;f<12;f++){var u=(f+.5)/12,fx=x0+(x1-x0)*u,fy=3.55-.4*(1-Math.pow(2*u-1,2));P(g,'tri',dmat(flagC[f%4]),fx,fy,sd*2.7,.42,.5,1);}}
 // 南侧：茶摊 + 水果车 + 水缸
 var tea=sub(g,-6,0,6.5,0);P(tea,'cyl','#7c5236',0,.36,0,.12,.72,.12);P(tea,'cyl','#9a6b48',0,.74,0,.75,.06,.75,0,0,0,true);
 for(var a=0;a<3;a++){var aa=a/3*6.28+.5;P(tea,'cyl','#8a5d3e',Math.cos(aa)*1.15,.24,Math.sin(aa)*1.15,.25,.48,.25,0,0,0,true);}
 P(tea,'ball','#5d7f86',0,.9,0,.16,.13,.16);P(tea,'cyl','#5d7f86',.17,.92,0,.03,.14,.03,0,0,-.9);for(a=0;a<3;a++)P(tea,'cyl','#efe6d2',Math.cos(a*2)*.42,.8,Math.sin(a*2)*.42,.06,.07,.06);
 P(tea,'cyl','#5f412c',.05,1.6,.05,.04,3,.04);P(tea,'cone',dmat('#d8a24a'),.05,3.05,.05,1.9,.55,1.9,0,0,0,true);P(tea,'ball6','#a8322a',.05,3.35,.05,.08);
 block(s,-6,6.5,2.6,2.6);
 var cart=sub(g,5.2,0,6.6,-.15);P(cart,'box','#8a5a3c',0,.85,0,2.2,.5,1.1,0,0,0,true);for(sd=-1;sd<=1;sd+=2){P(cart,'cyl','#5f412c',-.4,.45,sd*.62,.45,.08,.45,Math.PI/2,0,0);P(cart,'box','#5f412c',1.6,.85,sd*.4,1.2,.06,.06);}
 var fr=rng(9);for(a=0;a<22;a++)P(cart,'ball6',['#f08a3c','#e8c64a','#d9483a','#8fbf5a'][a%4],-.9+fr()*1.8,1.18+fr()*.18,-.4+fr()*.8,.15);
 for(var cx=-1;cx<=1;cx+=2)for(var cz=-1;cz<=1;cz+=2)P(cart,'cyl','#5f412c',cx*1,1.6,cz*.5,.03,1.5,.03);P(cart,'box',dmat('#3f7a5a'),0,2.36,0,2.4,.05,1.3,0,0,0,true);
 block(s,5.2,6.6,3.4,1.8);
 for(sd=-1;sd<=1;sd+=2){P(g,'cyl','#6a5f50',sd*12.3,.45,-5.6,.55,.9,.55,0,0,0,true);P(g,'cyl','#5f9aa0',sd*12.3,.88,-5.6,.48,.02,.48);block(s,sd*12.3,-5.6,1.2,1.2);}
 // 远景：墙外民居屋顶
 [-10,-3.5,3.5,10].forEach(function(x,i){P(g,'box','#e8e0cc',x,2.4,-18,5,4.8,4,0,0,0,false);roof(g,x,4.8,-18,5.8,4.6,1.1,.45,{tile:'#4b5a5a',under:'#6a5040'});});
 [-9,0,9].forEach(function(x){P(g,'box','#e8e0cc',x,2.4,18.5,6,4.8,4);roof(g,x,4.8,18.5,6.8,4.6,1.1,.45,{tile:'#4b5a5a',under:'#6a5040'});});
 var pag=sub(g,-14,0,-30,0);P(pag,'box','#a54436',0,1.4,0,2.8,2.8,2.2);P(pag,'box','#d8cfb8',0,2.9,0,3.2,.28,2.6);P(pag,'box','#a54436',0,4.0,0,2.2,1.8,1.8);roof(pag,0,4.95,0,3.4,2.8,.85,.4,{tile:'#3b4b4b',under:'#a34a33'});
 bake(g);
 LIVE.market={glow:glow(g,glows,'#ffb35a',1.5,.75)};
};

/* ================= 场景：荷塘 lotus ================= */
PUBLIC_BUILDERS.lotus=function(s,g){
 var r=rng(42),cx=0,cz=-2;
 ground(g,170,'#93ab7c');
 // 水面：深浅渐变底 + 加色闪光层（动画）
 var base=texMat('pondbase',256,256,function(a){var gr=a.createRadialGradient(128,128,10,128,128,128);gr.addColorStop(0,'#2f7f86');gr.addColorStop(.7,'#4c9f9c');gr.addColorStop(1,'#86c3b0');a.fillStyle=gr;a.fillRect(0,0,256,256);});
 var basem=P(g,'disc',base,cx,.072,cz,6.95,1,5.95);basem.userData.a3live=true;basem.receiveShadow=true;
 var shimmer=cached('shimmer',function(){var t=canvasTex('shimmer',256,256,function(a){a.clearRect(0,0,256,256);var q=rng(3);for(var i=0;i<70;i++){a.strokeStyle='rgba(255,255,255,'+(.18+q()*.35)+')';a.lineWidth=1+q()*1.5;var x=q()*256,y=q()*256,l=8+q()*26;a.beginPath();a.moveTo(x,y);a.quadraticCurveTo(x+l/2,y-2-q()*3,x+l,y);a.stroke();}},[3,3]);return new THREE.MeshBasicMaterial({map:t,transparent:true,opacity:.55,depthWrite:false,blending:THREE.AdditiveBlending});});
 var sh=P(g,'disc',shimmer,cx,.09,cz,6.9,1,5.9);sh.userData.a3live=true;
 // 锦鲤（实例化，逐帧更新）
 var koiBody=new THREE.InstancedMesh(geo('ball6'),smat('#f0763a'),8),koiTail=new THREE.InstancedMesh(geo('cone'),smat('#f3a06a'),8),koiSpot=new THREE.InstancedMesh(geo('ball6'),smat('#fff4e6'),8);
 [koiBody,koiTail,koiSpot].forEach(function(m){m.userData.a3live=true;m.frustumCulled=false;g.add(m);});
 var fish=[];for(var i=0;i<8;i++)fish.push({r:2.6+(i%4)*.75,speed:(.18+r()*.12)*(i%2?1:-1),phase:r()*6.28});
 // 石砌驳岸（规则条石，压在原有卵石下）
 for(i=0;i<56;i++){var a=i/56*Math.PI*2;P(g,'box',i%2?'#b9b3a1':'#c8c1ae',cx+Math.cos(a)*7.05,.07,cz+Math.sin(a)*6.05,.62,.14,.95,0,-a,0);}
 // 北侧汉白玉栏杆
 for(i=0;i<=14;i++){var a2=Math.PI+.9+(Math.PI-1.8)*i/14,px=cx+Math.cos(a2)*7.9,pz=cz+Math.sin(a2)*6.9;P(g,'box','#ece8dc',px,.38,pz,.16,.76,.16,0,0,0,true);P(g,'ball6','#f4f1e8',px,.82,pz,.12,.12,.12);block(s,px,pz,.24,.24);
  if(i<14){var a3=Math.PI+.9+(Math.PI-1.8)*(i+.5)/14,qx=cx+Math.cos(a3)*7.9,qz=cz+Math.sin(a3)*6.9,seg=2*Math.PI*7.4*(Math.PI-1.8)/(2*Math.PI)/14;P(g,'box','#e4dfd1',qx,.6,qz,seg,.08,.08,0,-a3-Math.PI/2,0);P(g,'box','#e4dfd1',qx,.22,qz,seg,.08,.08,0,-a3-Math.PI/2,0);P(g,'box','#efebe0',qx,.41,qz,seg*.8,.3,.04,0,-a3-Math.PI/2,0);}}
 // 荷叶（带缺口）、高荷叶、荷花与花苞
 function inPond(x,z,k){return Math.pow((x-cx)/(7*k),2)+Math.pow((z-cz)/(6*k),2)<1;}
 var island={x:2.8,z:-4.3,r:1.25};
 function free(x,z){return inPond(x,z,.88)&&Math.hypot(x-island.x,z-island.z)>island.r+.5;}
 var placed=0,tries=0;while(placed<34&&tries++<400){var lx=cx+(r()-.5)*13,lz=cz+(r()-.5)*11;if(!free(lx,lz))continue;placed++;var sc=.32+r()*.42;P(g,'leaf',dmat(placed%3?'#5f9a55':'#78ad5e'),lx,.1+r()*.01,lz,sc,1,sc*.92,0,r()*6.28,0);}
 var flowers=[],tf=0;tries=0;while(flowers.length<9&&tries++<400){var fx=cx+(r()-.5)*12,fz=cz+(r()-.5)*10;if(!free(fx,fz)||flowers.some(function(f){return Math.hypot(f[0]-fx,f[1]-fz)<1.2;}))continue;flowers.push([fx,fz]);}
 flowers.forEach(function(f,k){var h=.25+(k%3)*.18,fx=f[0],fz=f[1];P(g,'cyl','#5b8a4c',fx,h/2+.08,fz,.025,h,.025);
  var y=h+.1;if(k%4===3){P(g,'petal',smat('#f08fac'),fx,y,fz,.09,.16,.09);return;}
  for(var p=0;p<8;p++){var pa=p/8*6.28;P(g,'petal',smat('#f3a9bf'),fx+Math.cos(pa)*.04,y,fz+Math.sin(pa)*.04,.07,.15,.04,Math.sin(pa)*.95,0,-Math.cos(pa)*.95);}
  for(p=0;p<6;p++){var pb=p/6*6.28+.3;P(g,'petal',smat('#fbd6e1'),fx+Math.cos(pb)*.02,y,fz+Math.sin(pb)*.02,.055,.13,.035,Math.sin(pb)*.45,0,-Math.cos(pb)*.45);}
  P(g,'cyl','#e5c95a',fx,y+.06,fz,.05,.05,.05);P(g,'leaf',dmat('#5f9a55'),fx+.25,.13+k*.012,fz+.1,.45,1,.42,0,k,0);});
 for(i=0;i<6;i++){var ux,uz;tries=0;do{ux=cx+(r()-.5)*11;uz=cz+(r()-.5)*9;}while(!free(ux,uz)&&tries++<60);var hh=.55+r()*.5;P(g,'cyl','#5b8a4c',ux,hh/2,uz,.025,hh,.025);P(g,'bowl',dmat('#6aa35a'),ux,hh,uz,.42,.16,.42);}
 // 芦苇/香蒲
 [[-5.8,-4.5],[5.5,.5],[-4.5,1.8],[5.4,-5.2]].forEach(function(c,k){for(var j=0;j<9;j++){var a=j*2.4,d=.15+j%3*.14,x=c[0]+Math.cos(a)*d,z=c[1]+Math.sin(a)*d,h=.9+(j%4)*.25;P(g,'cyl','#7c9a4e',x,h/2,z,.022,h,.022,Math.cos(a)*.08,0,Math.sin(a)*.08);if(j%3===0)P(g,'cyl','#7a4f2e',x,h-.05,z,.045,.22,.045);else P(g,'box','#8fae5a',x,h*.7,z,.03,h*.6,.07,0,a,.25);}});
 // 湖心石岛 + 石亭
 for(i=0;i<9;i++){var ia=i*2.1;P(g,'rock','#9d9b8c',island.x+Math.cos(ia)*.65*(i%3?1:.4),.12+(i%3)*.08,island.z+Math.sin(ia)*.55*(i%3?1:.4),.45+(i%2)*.15,.3,.4,0,ia,0,true);}
 var tower=sub(g,island.x,.25,island.z,0);P(tower,'cyl8','#b8b4a5',0,.2,0,.7,.4,.7);for(var t=0;t<4;t++){var ta=t/4*Math.PI*2+Math.PI/4;P(tower,'cyl','#cfc6b3',Math.cos(ta)*.38,.7,Math.sin(ta)*.38,.05,1.0,.05);}
 latheRoof(tower,0,1.25,0,.85,.5,8,'#8e8b7f',1.4,true);
 // 柳树
 willow(g,s,-9.6,1.4,5);willow(g,s,9.2,-6.6,8);
 // 亭子：八角攒尖顶覆盖原圆锥顶 + 挂灯
 var glows=[];latheRoof(g,10,3.5,6,3.7,2,8,'#44595a',1.6,true);
 for(var gx=8.5;gx<=11.51;gx+=3)for(var gz=4.5;gz<=7.51;gz+=3){glows.push(lantern(g,gx+(gx<10?.25:-.25),2.85,gz+(gz<6?.25:-.25),.8));P(g,'box','#d2402c',gx,3.2,gz,.16,.3,.16);}
 P(g,'box','#a34a33',10,3.18,4.45,3.3,.18,.08);P(g,'box','#a34a33',10,3.18,7.55,3.3,.18,.08);
 // 远景树林
 for(i=0;i<20;i++){var ra=i/20*Math.PI*2,rr=19+r()*5;P(g,'ball',smat(i%2?'#6f9560':'#7fa66b'),Math.cos(ra)*(rr+5),1.6+r()*1.5,Math.sin(ra)*(rr+5),2.4+r(),2.2+r()*1.4,2.4+r());}
 var glow2=null;
 bake(g);
 // 萤火 / 水面微光
 var ff=[];for(i=0;i<14;i++)ff.push([cx+(r()-.5)*12,.4+r()*1.2,cz+(r()-.5)*10]);
 LIVE.lotus={water:shimmer,base:basem,koi:{body:koiBody,tail:koiTail,spot:koiSpot,fish:fish,cx:cx,cz:cz},glow:glow(g,glows,'#ffb35a',1.4,.75),ff:glow(g,ff,'#fff2b0',.35,.85)};
};

/* ================= 场景：大厅广场 plaza ================= */
PUBLIC_BUILDERS.plaza=function(s,g){
 var bronze='#7d6a3e',bz2='#9a8550',stone='#c9c1aa',glows=[];
 // 中轴路沿 + 圆形莲纹铺装
 for(var sd=-1;sd<=1;sd+=2)P(g,'box','#8f8a7a',sd*1.58,.05,1,.14,.1,24);
 var inlay=texMat('inlay',256,256,function(a){a.fillStyle='#d9cfb4';a.fillRect(0,0,256,256);a.translate(128,128);for(var ring=0;ring<3;ring++){a.strokeStyle=ring?'#a99a76':'#8d7d58';a.lineWidth=5-ring;a.beginPath();a.arc(0,0,122-ring*30,0,Math.PI*2);a.stroke();}for(var i=0;i<12;i++){a.save();a.rotate(i/12*Math.PI*2);a.fillStyle=i%2?'#c9b48a':'#bba479';a.beginPath();a.ellipse(0,-64,13,30,0,0,Math.PI*2);a.fill();a.restore();}a.fillStyle='#b19e74';a.beginPath();a.arc(0,0,26,0,Math.PI*2);a.fill();});
 var ig=sub(g,5,0,0,0);
 P(ig,'disc',inlay,0,.092,-6.5,2.4,1,2.4).receiveShadow=true;
 // 铜灯：八角石台、铜柱、灯室，台边盆花；无香无烟
 P(ig,'cyl8',stone,0,.16,-6.5,1.25,.32,1.25,0,0,0,true);P(ig,'cyl8','#b8af96',0,.36,-6.5,1.05,.1,1.05);
 P(ig,'cyl',bronze,0,.7,-6.5,.16,.7,.16,0,0,0,true);P(ig,'cyl8',bz2,0,1.05,-6.5,.32,.08,.32);
 P(ig,'cyl',smat(bronze),0,1.22,-6.5,.42,.16,.42);P(ig,'cyl',smat('#3d3428'),0,1.32,-6.5,.32,.04,.32);
 P(ig,'ball',emat('#ffd27a','#ff9a3a',.8),0,1.5,-6.5,.12,.16,.12);
 for(var i=0;i<4;i++){var b=i/4*Math.PI*2+Math.PI/4;P(ig,'cyl',bronze,Math.cos(b)*.28,1.55,-6.5+Math.sin(b)*.28,.025,.4,.025);}
 latheRoof(ig,0,1.85,-6.5,.55,.32,4,'#5e5236',1.4,true);
 for(i=0;i<6;i++){var fa=i/6*Math.PI*2;P(ig,'cyl','#8a5a3c',Math.cos(fa)*.7,.48,-6.5+Math.sin(fa)*.7,.08,.16,.08);P(ig,'ball6','#6f9a52',Math.cos(fa)*.7,.62,-6.5+Math.sin(fa)*.7,.12,.1,.12);}
 block(s,5,-6.5,2.4,2.4);
 // 檐下红灯笼（与原有一对呼应）
 [-6,-9.5,6,9.5].forEach(function(x){P(g,'box','#674c2b',x,3.25,-11.1,.03,.7,.03);glows.push(lantern(g,x,2.62,-11.1,1));});
 // 彩旗旗杆（横幅吉语）
 for(sd=-1;sd<=1;sd+=2){var fx=sd*5.8;P(g,'cyl6',stone,fx,.2,-3.2,.35,.4,.35);P(g,'cyl','#6a4a30',fx,3,-3.2,.07,6,.07,0,0,0,true);P(g,'box','#6a4a30',fx+sd*-.85,5.55,-3.2,1.7,.05,.05);
  flagRect(g,'fan'+sd,sd<0?'风调雨顺':'国泰民安',sd<0?'#d9b24a':'#b33a2c','#5a1f14','#7a2a1a',fx-sd*.9,5.15,-3.2,1.7,.7);P(g,'ball',emat('#e0bd5c','#8a6018',.3),fx,6.08,-3.2,.12);block(s,fx,-3.2,.5,.5);}
 // 古松与银杏
 pine(g,s,-7.6,-8.4,5.4,21);pine(g,s,8.9,-3.9,4.8,22);
 roundTree(g,s,-7.2,10.6,3.2,'#e3c25a',31);P(g,'cyl','#b9b29c',-7.2,.2,10.6,.75,.4,.75);
 for(var pt of [[-7.6,-8.4],[8.9,-3.9]])P(g,'cyl','#b9b29c',pt[0],.18,pt[1],.75,.36,.75);
 // 两侧石灯笼（广场入口）
 for(sd=-1;sd<=1;sd+=2){glows.push(stoneLantern(g,sd*4.2,12.2,1.2));block(s,sd*4.2,12.2,.7,.7);}
 // 原有门前石兽外加完整石狮造型（位置不变）
 for(sd=-1;sd<=1;sd+=2)lion(g,sd*4,.6,-10,0,1.12,sd>0);
 bake(g);
 LIVE.plaza={glow:glow(g,glows,'#ffb35a',1.5,.7)};
};

/* ================= 缘堂风格：wood / zen ================= */
function buildShrineStyles(h){
 if(h.art3Styles)return h.art3Styles;
 var root=new THREE.Group();root.name='art3-shrine';h.group.add(root);
 var wood=new THREE.Group(),zen=new THREE.Group();wood.name='art3-wood';zen.name='art3-zen';root.add(wood,zen);
 /* --- 古朴木作：暖木、朱漆柱、雕花窗棂、彩画额枋、宫灯、红毯 --- */
 var lattice=texMat('lattice',128,128,function(a){a.fillStyle='#3a2116';a.fillRect(0,0,128,128);a.strokeStyle='#8a5634';a.lineWidth=7;a.strokeRect(4,4,120,120);a.lineWidth=4;for(var i=0;i<4;i++){a.beginPath();a.moveTo(16+i*32,4);a.lineTo(16+i*32,124);a.moveTo(4,16+i*32);a.lineTo(124,16+i*32);a.stroke();}a.strokeStyle='#b07a44';a.lineWidth=3;a.beginPath();a.arc(64,64,24,0,Math.PI*2);a.stroke();a.fillStyle='#c79a52';for(var j=0;j<4;j++){a.beginPath();a.arc(j%2?96:32,j<2?32:96,5,0,Math.PI*2);a.fill();}});
 var frieze=texMat('frieze',256,32,function(a){a.fillStyle='#7a2a20';a.fillRect(0,0,256,32);a.fillStyle='#d6ad55';a.fillRect(0,0,256,4);a.fillRect(0,28,256,4);for(var i=0;i<16;i++){a.strokeStyle='#e0bf6a';a.lineWidth=2;a.beginPath();a.moveTo(i*16,22);a.lineTo(i*16,10);a.lineTo(i*16+10,10);a.lineTo(i*16+10,18);a.lineTo(i*16+5,18);a.stroke();}});
 var carpet=texMat('carpet',64,256,function(a){a.fillStyle='#a2382b';a.fillRect(0,0,64,256);a.fillStyle='#d8ae55';a.fillRect(4,0,4,256);a.fillRect(56,0,4,256);a.fillStyle='#b8473a';for(var y=16;y<256;y+=40){a.beginPath();a.arc(32,y,9,0,Math.PI*2);a.fill();}});
 var carved=texMat('carved',256,32,function(a){a.fillStyle='#8a5a2a';a.fillRect(0,0,256,32);a.strokeStyle='#e6c46a';a.lineWidth=2;for(var i=0;i<8;i++){a.beginPath();a.arc(16+i*32,16,10,0,Math.PI*2);a.stroke();a.beginPath();a.arc(16+i*32,16,4,0,Math.PI*2);a.stroke();}a.strokeRect(2,2,252,28);});
 [[-3.25,8.3],[6.25,2.5]].forEach(function(seg){for(var sx=-1;sx<=1;sx+=2){P(wood,'plane',lattice,sx*5.835,2.25,seg[0],seg[1],2.2,1,0,-sx*Math.PI/2,0);P(wood,'box','#5a3322',sx*5.8,1.1,seg[0],.08,.12,seg[1]);P(wood,'box','#5a3322',sx*5.8,3.38,seg[0],.08,.12,seg[1]);}});
 for(var sx=-1;sx<=1;sx+=2){P(wood,'plane',frieze,sx*5.835,3.98,0,15.6,.38,1,0,-sx*Math.PI/2,0);}
 P(wood,'plane',frieze,0,3.98,-7.84,11.6,.38,1);
 [[-5.62,-7.6],[5.9,-7.6],[-5.62,.95],[5.62,.95],[-5.62,5.05],[5.62,5.05],[-2.35,7.62],[2.35,7.62]].forEach(function(c){P(wood,'cyl','#9e2f25',c[0],2.1,c[1],.17,4.2,.17,0,0,0,true);P(wood,'cyl8','#d6ad55',c[0],4.05,c[1],.22,.18,.22);P(wood,'cyl8','#8d8476',c[0],.08,c[1],.26,.16,.26);});
 for(var z of [-6,0,6])for(sx=-1;sx<=1;sx+=2){P(wood,'box','#a8452f',sx*5.55,4.75,z,.5,.16,.34);P(wood,'box','#d6ad55',sx*5.5,4.93,z,.7,.14,.3);P(wood,'box','#7a2a20',sx*5.45,5.08,z,.9,.12,.28);}
 var carpetMesh=P(wood,'flat',carpet,0,.052,2.95,2.2,1,8.7);carpet.map.repeat.set(1,4);
 P(wood,'plane',carved,0,1.35,-5.045,5.2,.26,1);
 var wg=[];[[-2.7,-4.2],[2.7,-4.2],[-2.7,2.6],[2.7,2.6]].forEach(function(c){P(wood,'box','#3b2a20',c[0],4.6,c[1],.025,1.1,.025);wg.push(lantern(wood,c[0],3.72,c[1],1.25,'#c7362a'));P(wood,'box','#d6ad55',c[0],3.32,c[1],.02,.3,.02);});
 bake(wood);glow(wood,wg,'#ffa64a',1.6,.7);
 /* --- 竹石素雅：灰白枯山水、石灯笼、竹、障子纸门、榻榻米、素木条案、闲字山水轴 --- */
 var tatami=texMat('tatami',256,256,function(a){a.fillStyle='#cfc8a8';a.fillRect(0,0,256,256);a.strokeStyle='rgba(120,112,80,.14)';a.lineWidth=1;for(var y=0;y<256;y+=4){a.beginPath();a.moveTo(0,y);a.lineTo(256,y);a.stroke();}a.fillStyle='#77786a';a.fillRect(0,0,256,4);a.fillRect(0,126,256,4);a.fillRect(0,252,256,4);a.fillRect(126,0,4,128);a.fillRect(0,0,4,256);a.fillRect(252,0,4,256);});
 var gravel=texMat('raked',128,256,function(a){a.fillStyle='#dcd9d0';a.fillRect(0,0,128,256);a.strokeStyle='#b9b5aa';a.lineWidth=2;for(var x=6;x<128;x+=10){a.beginPath();a.moveTo(x,0);for(var y=0;y<=256;y+=16)a.lineTo(x+Math.sin(y/40)*2,y);a.stroke();}var q=rng(4);a.fillStyle='rgba(150,146,135,.5)';for(var i=0;i<260;i++)a.fillRect(q()*128,q()*256,1.5,1.5);});
 var shoji=texMat('shoji',128,128,function(a){a.fillStyle='#f3efe4';a.fillRect(0,0,128,128);a.strokeStyle='#8a8478';a.lineWidth=3;for(var i=0;i<=4;i++){a.beginPath();a.moveTo(i*32,0);a.lineTo(i*32,128);a.stroke();}for(var j=0;j<=6;j++){a.beginPath();a.moveTo(0,j*21.3);a.lineTo(128,j*21.3);a.stroke();}},{emissive:'#d9d3c2',emissiveIntensity:.25});
 var scroll=texMat('scrollXian',96,256,function(a){a.fillStyle='#efe9da';a.fillRect(0,0,96,256);a.fillStyle='#6b6a62';a.fillRect(0,0,96,10);a.fillRect(0,246,96,10);a.fillStyle='#d4cbb0';a.beginPath();a.arc(28,78,16,0,Math.PI*2);a.fill();a.fillStyle='#6a7a5a';a.beginPath();a.moveTo(0,130);a.quadraticCurveTo(30,90,60,125);a.lineTo(96,140);a.lineTo(96,175);a.lineTo(0,175);a.fill();a.fillStyle='#556348';a.beginPath();a.moveTo(0,150);a.quadraticCurveTo(50,120,96,155);a.lineTo(96,200);a.lineTo(0,200);a.fill();a.fillStyle='#3a5a6a';a.fillRect(0,196,96,8);a.fillStyle='#2c2b28';a.font='bold 42px serif';a.textAlign='center';a.fillText('闲',48,232);a.fillStyle='#b8473a';a.fillRect(70,238,10,10);});
 P(zen,'flat',tatami,0,.064,0,8.8,1,15.2);tatami.map.repeat.set(2,4);
 [[-3.4,8.4],[6.3,2.6]].forEach(function(seg){for(var sx=-1;sx<=1;sx+=2){P(zen,'flat',gravel,sx*5.15,.058,seg[0],1.3,1,seg[1]);P(zen,'box','#8d8b82',sx*4.47,.06,seg[0],.1,.12,seg[1]);
  P(zen,'plane',shoji,sx*5.835,2.25,seg[0],seg[1]-.2,2.4,1,0,-sx*Math.PI/2,0);P(zen,'box','#c9c2b2',sx*5.8,1.03,seg[0],.07,.08,seg[1]);P(zen,'box','#c9c2b2',sx*5.8,3.47,seg[0],.07,.08,seg[1]);}});
 for(sx=-1;sx<=1;sx+=2){P(zen,'rock','#8f8f88',sx*5.1,.2,-1.6,.42,.3,.36,0,sx,0,true);P(zen,'rock','#a2a29a',sx*5.25,.14,-2.4,.24,.18,.22);P(zen,'ball6','#6f8a5a',sx*5.05,.07,-1.0,.3,.08,.26);}
 var zg=[];for(sx=-1;sx<=1;sx+=2){zg.push(stoneLantern(zen,sx*5.1,-7.1,1,emat('#f2ede0','#d9cfae',.45)));zg.push(stoneLantern(zen,sx*5.15,7.2,.9,emat('#f2ede0','#d9cfae',.45)));}
 for(sx=-1;sx<=1;sx+=2)for(var k=0;k<7;k++){var bx=sx*5.2+Math.cos(k*2.3)*.35,bz=5.9+Math.sin(k*2.3)*.4,bh=3.2+(k%3)*.4;P(zen,'cyl6','#87a26a',bx,bh/2,bz,.04,bh,.04);for(var n=1;n<5;n++)P(zen,'cyl6','#6d8a55',bx,n*bh/5,bz,.05,.03,.05);for(var l=0;l<3;l++)P(zen,'box','#7f9e5c',bx+.15,bh-.2-l*.35,bz,.35,.02,.07,0,k+l,.4);}
 P(zen,'box','#cfc6b3',0,1.35,-5.8,5.46,.33,1.54,0,0,0,true);for(sx=-1;sx<=1;sx+=2)P(zen,'box','#b8ad97',sx*2.3,.65,-5.8,.33,1.32,1.03);
 P(zen,'plane',scroll,-3.6,2.7,-7.83,.8,2.2,1);P(zen,'box','#5b5a54',-3.6,3.83,-7.82,.95,.05,.05);
 for(sx=-1;sx<=1;sx+=2)signPlane(zen,'zenc'+sx,sx<0?'花开四季':'月明中庭','#eee8d9','#2f2e2a','#9c968a',sx*4.7,2.8,-7.69,.46,2.32);
 P(zen,'cyl','#ddd6c6',0,.12,-2.3,1.05,.08,1.05);
 bake(zen);glow(zen,zg,'#fff0cc',.9,.55);
 h.art3Styles={root:root,wood:wood,zen:zen};
 return h.art3Styles;
}
function syncShrineStyle(){
 try{
  var h=W3&&W3.spaces&&W3.spaces.hall;if(!h||!h.group)return;
  var st=buildShrineStyles(h),style=window.r41PreviewStyle||(typeof S!=='undefined'&&S&&S.shrine&&S.shrine.style)||'wood';
  h.blocks=h.blocks.filter(b=>!b.art3Style);
  if(style==='zen')for(var side of [-1,1])for(var c of [[5.2,5.9,.65,.65],[5.1,-7.1,.4,.4],[5.15,7.2,.4,.4],[5.1,-1.6,.6,.55],[5.25,-2.4,.3,.3]])h.blocks.push({x:side*c[0]-c[2],X:side*c[0]+c[2],z:c[1]-c[3],Z:c[1]+c[3],art3Style:'zen'});
  st.wood.visible=style==='wood';st.zen.visible=style==='zen';
  // 竹石风格：主灯偏冷白；其他风格恢复原色（不改强度/位置）
  h.group.children.forEach(function(o){if(o.isPointLight){if(!o.userData.a3base)o.userData.a3base=o.color.getHex();o.color.setHex(style==='zen'?(o.intensity>10?0xf1efe8:0xffd9a0):o.userData.a3base);}});
  A.style=style;
 }catch(e){warn('shrine style',e);}
}

/* ---------- 灯光/雾：每次 worldEnter 后按场景调整 ---------- */
var TUNE={
 plaza:{fog:'#ecdcb9',near:28,far:78,hemi:'#fff1d6',ground:'#6f6a4e',hi:2,sun:'#ffd59a',si:2.55},
 market:{fog:'#efd6ae',near:24,far:70,hemi:'#fff0d2',ground:'#6e6048',hi:2.05,sun:'#ffcf94',si:2.45},
 gate:{fog:'#dbe3dc',near:18,far:62,hemi:'#f3f3ea',ground:'#5f7058',hi:2,sun:'#ffe7c2',si:2.3},
 lotus:{fog:'#d4e7de',near:22,far:64,hemi:'#effaf2',ground:'#5b7a5c',hi:2.05,sun:'#fff1cf',si:2.35}
};
var BASE=null;
function tune(name){
 var w=W3;if(!w||!w.hemi||!w.sun)return;
 if(!BASE)BASE={hemi:w.hemi.color.getHex(),ground:w.hemi.groundColor.getHex(),sun:w.sun.color.getHex()};
 var t=TUNE[name];
 if(t&&A.applied[name]){if(w.scene.fog){w.scene.fog.color.set(t.fog);w.scene.fog.near=t.near;w.scene.fog.far=t.far;}w.hemi.color.set(t.hemi);w.hemi.groundColor.set(t.ground);w.hemi.intensity=t.hi;w.sun.color.set(t.sun);w.sun.intensity=t.si;}
 else{w.hemi.color.setHex(BASE.hemi);w.hemi.groundColor.setHex(BASE.ground);w.sun.color.setHex(BASE.sun);}
 if(name==='hall')syncShrineStyle();
}

/* ---------- 动画（挂在 tgAnimate 之后，仅当前场景运行） ---------- */
var tmpO=null;
function animate(ts,dt){
 var w=W3;if(!w)return;var act=w.active,L=LIVE[act];if(!L)return;
 if(L.glow){L.glow.material.opacity=L.glow.userData.baseOpacity*(.9+Math.sin(ts*.004)*.06+Math.sin(ts*.011)*.04);}
 if(act==='lotus'){
  var m=L.water.map;m.offset.x=(m.offset.x+dt*.018)%1;m.offset.y=(m.offset.y-dt*.011)%1;L.water.opacity=.45+Math.sin(ts*.0012)*.12;
  tmpO=tmpO||new THREE.Object3D();var k=L.koi;
  k.fish.forEach(function(f,i){var a=f.phase+ts*.001*f.speed,x=k.cx+Math.cos(a)*f.r,z=k.cz+Math.sin(a)*f.r*.82,dir=f.speed>0?1:-1,wig=Math.sin(ts*.012+i)*.25;
   var yaw=Math.atan2(Math.cos(a)*f.r*.82*dir,-Math.sin(a)*f.r*dir);
   tmpO.position.set(x,.08,z);tmpO.rotation.set(0,-yaw,0);tmpO.scale.set(.26,.06,.1);tmpO.updateMatrix();k.body.setMatrixAt(i,tmpO.matrix);
   tmpO.scale.set(.06,.03,.05);tmpO.position.set(x+Math.cos(yaw)*.06,.1,z+Math.sin(yaw)*.06);tmpO.updateMatrix();k.spot.setMatrixAt(i,tmpO.matrix);
   tmpO.position.set(x-Math.cos(yaw)*.3,.08,z-Math.sin(yaw)*.3);tmpO.rotation.set(0,-yaw+wig,-Math.PI/2);tmpO.scale.set(.08,.16,.03);tmpO.updateMatrix();k.tail.setMatrixAt(i,tmpO.matrix);
  });
  k.body.instanceMatrix.needsUpdate=k.tail.instanceMatrix.needsUpdate=k.spot.instanceMatrix.needsUpdate=true;
  if(L.ff){L.ff.position.y=Math.sin(ts*.0009)*.15;L.ff.material.opacity=.55+Math.sin(ts*.003)*.3;}
 }
 if(act==='plaza'&&L.smoke){var pos=L.smoke.geometry.attributes.position;for(var i=0;i<pos.count;i++){var t=(ts*.00018+i/pos.count)%1;pos.setXYZ(i,5+Math.sin(t*7+i)*.25*t,2.1+t*3.2,-6.5+Math.cos(t*5+i)*.2*t);}pos.needsUpdate=true;L.smoke.material.opacity=.32;}
}

/* ---------- 挂载 ---------- */
function applyScene(id){
 if(A.applied[id])return;var s=W3.spaces[id],b=PUBLIC_BUILDERS[id];if(!s||!s.group||!b)return;
 var g=new THREE.Group();g.name='art3-'+id;g.userData.art3=true;s.group.add(g);s.art3Group=g;
 try{b(s,g);A.applied[id]=true;}catch(e){warn('build '+id,e);try{s.group.remove(g);}catch(_){}}
}
function wrapOnce(name,make){
 var f=G[name];if(typeof f!=='function'||f.__art3)return false;var nf=make(f);nf.__art3=true;nf.__art3Orig=f;G[name]=nf;return true;
}
function apply(){
 if(A.ready)return true;if(!hooksReady())return false;A.ready=true;
 try{
  var ids=G.TG_SCENES.filter(function(v){return v&&v.public;}).map(function(v){return v.id;});
  ids.forEach(function(id){if(PUBLIC_BUILDERS[id])applyScene(id);});
  wrapOnce('worldEnter',function(orig){return function(name){var r=orig.apply(this,arguments);try{tune(W3&&W3.active);}catch(e){warn('tune',e);}return r;};});
  wrapOnce('worldSyncShrine',function(orig){return function(){var r=orig.apply(this,arguments);syncShrineStyle();return r;};});
  wrapOnce('tgAnimate',function(orig){return function(ts,dt){var r=orig.apply(this,arguments);try{animate(ts,dt);}catch(e){if(!A.animErr){A.animErr=1;warn('animate',e);}}return r;};});
  if(typeof G.tgAnimate!=='function'){G.tgAnimate=function(ts,dt){try{animate(ts,dt);}catch(e){}};G.tgAnimate.__art3=true;}
  wrapOnce('TG_RERENDER',function(orig){return function(){var r=orig.apply(this,arguments);syncShrineStyle();try{tune(W3&&W3.active);}catch(e){}return r;};});
  syncShrineStyle();tune(W3.active);
 }catch(e){warn('apply',e);}
 return true;
}
A.apply=apply;
// 情况 1：与其他模块打包在同一 <script> 里（pack.mjs 追加在 r4.js 之后）——此时 initWorld 尚未执行，包装它。
// 情况 2：作为独立 <script> 晚于主脚本加载——世界可能已建好，直接挂载。
if(!apply()){
 wrapOnce('initWorld',function(orig){return function(){var r=orig.apply(this,arguments);try{apply();}catch(e){warn('initWorld',e);}return r;};});
 if(typeof G.initWorld!=='function'){var tries=0,iv=setInterval(function(){if(apply()||++tries>40)clearInterval(iv);},250);}
}
})();
