/* ui-kit.js — 福缘里 · 心田小院 共享界面样式与提示层  window.TG_UI
 * 打包顺序：放在 suggest.js / manual.js / avatar.js 之前。无 THREE 依赖，可重复加载（幂等）。
 * 作用范围：只影响带 .tg-ui 的节点（本文件创建的提示/对话框，以及意见箱、手册、捏脸面板），不改游戏其他界面。
 *
 * API
 *   TG_UI.ensure()                       注入一次 <style id="tg-ui-kit">
 *   TG_UI.toast(msg, {tone, duration})   统一提示队列：最多同时 3 条，自上而下排列，不互相重叠；相同文字只刷新计时。
 *                                        tone: 'info' | 'ok' | 'warn' | 'error'；返回 {close}
 *   TG_UI.openLayer(el, {onClose, esc})  把面板根节点登记为一层：自动分配 z-index（越晚打开越靠上），Esc 关闭最上层。
 *                                        返回 {z, close, remove}；面板自己移除节点时调用 handle.remove()。
 *   TG_UI.modal({title, body, actions, dismissible})  居中对话框；actions: [{label, primary, danger, onClick}]，onClick 返回 false 则不关闭。
 *   TG_UI.confirm({title, text, ok, cancel, danger}) -> Promise<boolean>
 *   TG_UI.icon(name, size)               线性 SVG 图标字符串（currentColor）。名称见 TG_UI.icons。
 *   TG_UI.Z                              层级常量 {panel, modal, toast}
 *   TG_UI.tokens                         设计变量（颜色/圆角/阴影/字号/间距），与 CSS 变量 --tg-* 一一对应。
 */
(function(){
'use strict';
if(window.TG_UI && window.TG_UI.__v) return;
var VER=1;
var Z={panel:9990,step:10,modal:10040,toast:10100};

var TOKENS={
  paper:'#fbf6ec', paper2:'#f3e9d5', card:'#fffdf8',
  ink:'#3b2a1e', ink2:'#634a37', ink3:'#7d624d',
  line:'#e5d6ba', line2:'#c9ab72',
  accent:'#9b3a2a', accent2:'#7c2d20', onAccent:'#fff8ec', accentSoft:'#f7e6dc',
  ok:'#2e6a45', okSoft:'#e3efe4', warn:'#8a5410', warnSoft:'#f8ead2', err:'#a3261c', errSoft:'#f8e1dd', info:'#35566e', infoSoft:'#e3edf3',
  scrim:'rgba(28,18,10,.48)',
  r1:'8px', r2:'12px', r3:'16px', pill:'999px',
  sh1:'0 1px 2px rgba(60,35,15,.12)', sh2:'0 4px 12px rgba(60,35,15,.16)', sh3:'0 12px 32px rgba(40,24,10,.28)',
  fs1:'14px', fs2:'16px', fs3:'18px', fs4:'22px',
  s1:'4px', s2:'8px', s3:'12px', s4:'16px', s5:'24px',
  hit:'44px'
};
function tokenVars(){
  var map={paper:'paper',paper2:'paper-2',card:'card',ink:'ink',ink2:'ink-2',ink3:'ink-3',line:'line',line2:'line-2',accent:'accent',accent2:'accent-2',onAccent:'on-accent',accentSoft:'accent-soft',
    ok:'ok',okSoft:'ok-soft',warn:'warn',warnSoft:'warn-soft',err:'err',errSoft:'err-soft',info:'info',infoSoft:'info-soft',scrim:'scrim',
    r1:'r-1',r2:'r-2',r3:'r-3',pill:'r-pill',sh1:'sh-1',sh2:'sh-2',sh3:'sh-3',fs1:'fs-1',fs2:'fs-2',fs3:'fs-3',fs4:'fs-4',s1:'s-1',s2:'s-2',s3:'s-3',s4:'s-4',s5:'s-5',hit:'hit'};
  var out=[];for(var k in map) out.push('--tg-'+map[k]+':'+TOKENS[k]);
  out.push('--tg-font:"PingFang SC","Hiragino Sans GB","Noto Sans CJK SC","Noto Sans SC","Source Han Sans SC","Microsoft YaHei",system-ui,sans-serif');
  out.push('--tg-font-title:"Noto Serif CJK SC","Noto Serif SC","Source Han Serif SC","Songti SC",serif');
  out.push('--tg-focus:0 0 0 3px rgba(155,58,42,.32)');
  return out.join(';');
}

/* 图标：24 栅格，1.75 线宽，圆角端点；统一风格，不用表情符号。 */
var P={
  close:'<path d="M6 6l12 12M18 6L6 18"/>',
  back:'<path d="M15 5l-7 7 7 7"/>',
  next:'<path d="M9 5l7 7-7 7"/>',
  search:'<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
  lock:'<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8.5 10.5V8a3.5 3.5 0 017 0v2.5"/>',
  shuffle:'<path d="M4 7h3.5c2 0 3 1 4.2 3l1.6 3c1.2 2 2.2 3 4.2 3H20M17 4l3 3-3 3M4 17h3.5c1 0 1.8-.3 2.5-1M14 8c.7-.7 1.5-1 2.5-1"/><path d="M17 13.5l3 2.5-3 2.5"/>',
  home:'<path d="M4 11l8-6.5 8 6.5"/><path d="M6 9.5V20h12V9.5"/><path d="M10 20v-5h4v5"/>',
  hand:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 4v2M12 18v2M4 12h2M18 12h2"/>',
  layout:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 10h16M10 10v10"/>',
  sprout:'<path d="M12 20v-8"/><path d="M12 12c0-4-3-6-7-6 0 4 3 6 7 6z"/><path d="M12 14c0-3.5 2.5-5.5 7-5.5 0 3.5-2.5 5.5-7 5.5z"/>',
  paw:'<circle cx="7" cy="10" r="1.8"/><circle cx="10.5" cy="6.5" r="1.8"/><circle cx="14.5" cy="6.5" r="1.8"/><circle cx="18" cy="10" r="1.8"/><path d="M8.5 17c0-2.8 1.6-5 3.5-5s3.5 2.2 3.5 5c0 1.6-1.2 2.5-3.5 2.5S8.5 18.6 8.5 17z"/>',
  tree:'<path d="M12 21v-6"/><path d="M12 15c-4.5 0-7-2.3-7-5.3C5 6.5 8 4 12 4s7 2.5 7 5.7c0 3-2.5 5.3-7 5.3z"/><path d="M9 21h6"/>',
  cup:'<path d="M5 9h11v4a5 5 0 01-5 5h-1a5 5 0 01-5-5V9z"/><path d="M16 10.5h1.5a2.5 2.5 0 010 5H15.5"/><path d="M4 21h14"/>',
  shop:'<path d="M4 9l1.5-4.5h13L20 9"/><path d="M4 9c0 1.5 1.2 2.5 2.7 2.5S9.3 10.5 9.3 9c0 1.5 1.2 2.5 2.7 2.5s2.7-1 2.7-2.5c0 1.5 1.1 2.5 2.6 2.5S20 10.5 20 9"/><path d="M5.5 11.5V20h13v-8.5"/>',
  user:'<circle cx="12" cy="8" r="3.8"/><path d="M4.5 20c.8-3.8 3.8-6 7.5-6s6.7 2.2 7.5 6"/>',
  route:'<circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M8 18h6.5a3.5 3.5 0 000-7h-5a3.5 3.5 0 010-7H16"/>',
  family:'<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9.5" r="2.4"/><path d="M3.5 19.5c.6-3.3 2.8-5.5 5.5-5.5s4.9 2.2 5.5 5.5"/><path d="M15 14.2c2.6-.3 4.8 1.5 5.5 4.8"/>',
  coin:'<circle cx="12" cy="12" r="8"/><rect x="9.5" y="9.5" width="5" height="5"/>',
  mail:'<rect x="3.5" y="5.5" width="17" height="13" rx="2"/><path d="M4 7l8 6 8-6"/>',
  check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  info:'<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.8v.4"/>',
  warn:'<path d="M12 4l9 16H3z"/><path d="M12 10v4.5M12 17.3v.3"/>'
};
function icon(name,size){
  var d=P[name]; if(!d) return '';
  size=size||20;
  return '<svg class="tg-icon" width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'+d+'</svg>';
}

var CSS=[
'.tg-ui{'+tokenVars()+';font-family:var(--tg-font);color:var(--tg-ink);-webkit-tap-highlight-color:transparent;-webkit-text-size-adjust:100%}',
'.tg-ui *,.tg-ui *:before,.tg-ui *:after{box-sizing:border-box}',
'.tg-ui button,.tg-ui input,.tg-ui textarea{font-family:inherit}',
'.tg-ui :focus{outline:none}.tg-ui :focus-visible{box-shadow:var(--tg-focus)}',
'.tg-icon{display:inline-block;vertical-align:middle;flex-shrink:0}',
/* 遮罩 + 面板（手机竖屏：底部抽屉；横屏矮屏：居中满高；宽屏：居中卡片） */
'.tg-scrim{position:fixed;inset:0;display:flex;justify-content:center;align-items:flex-end;background:var(--tg-scrim);padding:0 env(safe-area-inset-right,0px) 0 env(safe-area-inset-left,0px);font-size:var(--tg-fs-2);line-height:1.6}',
'.tg-sheet{position:relative;width:100%;max-width:560px;height:88%;max-height:calc(100% - env(safe-area-inset-top,0px) - 8px);display:flex;flex-direction:column;background:var(--tg-paper);border-radius:var(--tg-r-3) var(--tg-r-3) 0 0;box-shadow:var(--tg-sh-3);overflow:hidden;padding-bottom:env(safe-area-inset-bottom,0px)}',
'.tg-sheet__head{flex:0 0 auto;display:grid;grid-template-columns:var(--tg-hit) 1fr var(--tg-hit);align-items:center;gap:var(--tg-s-2);min-height:56px;padding:var(--tg-s-1) var(--tg-s-2);border-bottom:1px solid var(--tg-line)}',
'.tg-sheet__title{margin:0;text-align:center;font-family:var(--tg-font-title);font-size:var(--tg-fs-3);font-weight:600;letter-spacing:.04em;color:var(--tg-ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
'.tg-sheet__body{flex:1 1 auto;min-height:0;overflow-y:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;padding:var(--tg-s-4)}',
'.tg-sheet__foot{flex:0 0 auto;display:flex;gap:var(--tg-s-3);padding:var(--tg-s-3) var(--tg-s-4);border-top:1px solid var(--tg-line);background:var(--tg-paper)}',
'@media (min-width:700px) and (min-height:600px){.tg-scrim{align-items:center}.tg-sheet{height:min(760px,86vh);border-radius:var(--tg-r-3)}}',
'@media (orientation:landscape) and (max-height:560px){.tg-scrim{align-items:center;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}.tg-sheet{height:calc(100% - 16px);max-height:none;max-width:640px;border-radius:var(--tg-r-3);padding-bottom:0}.tg-sheet__head{min-height:48px}.tg-sheet__body{padding:var(--tg-s-3) var(--tg-s-4)}.tg-sheet__foot{padding:var(--tg-s-2) var(--tg-s-4)}}',
/* 按钮 */
'.tg-btn{display:inline-flex;align-items:center;justify-content:center;gap:var(--tg-s-2);min-height:var(--tg-hit);min-width:var(--tg-hit);padding:0 var(--tg-s-4);border-radius:var(--tg-r-2);border:1px solid var(--tg-line-2);background:var(--tg-card);color:var(--tg-ink);font-size:var(--tg-fs-2);font-weight:600;line-height:1.2;cursor:pointer;touch-action:manipulation;transition:background-color .12s,transform .06s}',
'.tg-btn:active{transform:translateY(1px)}',
'.tg-btn--primary{background:var(--tg-accent);border-color:var(--tg-accent);color:var(--tg-on-accent)}',
'.tg-btn--primary:active{background:var(--tg-accent-2)}',
'.tg-btn--danger{background:var(--tg-err);border-color:var(--tg-err);color:#fff}',
'.tg-btn--ghost{background:transparent;border-color:transparent;color:var(--tg-ink-2)}',
'.tg-btn--block{flex:1 1 0;width:100%}',
'.tg-btn[disabled],.tg-btn[aria-disabled=true]{opacity:.5;cursor:not-allowed;transform:none}',
'.tg-iconbtn{display:inline-flex;align-items:center;justify-content:center;width:var(--tg-hit);height:var(--tg-hit);padding:0;border:0;border-radius:var(--tg-r-pill);background:transparent;color:var(--tg-ink-2);cursor:pointer;touch-action:manipulation}',
'.tg-iconbtn:active{background:var(--tg-paper-2)}',
/* 分段标签 */
'.tg-tabs{display:flex;gap:var(--tg-s-1);padding:var(--tg-s-1);margin:var(--tg-s-3) var(--tg-s-4) 0;background:var(--tg-paper-2);border-radius:var(--tg-r-2)}',
'.tg-tab{position:relative;flex:1 1 0;min-height:var(--tg-hit);padding:0 var(--tg-s-3);border:0;border-radius:var(--tg-r-1);background:transparent;color:var(--tg-ink-2);font-size:var(--tg-fs-2);cursor:pointer;white-space:nowrap}',
'.tg-tab[aria-selected=true]{background:var(--tg-card);color:var(--tg-ink);font-weight:600;box-shadow:var(--tg-sh-1)}',
'.tg-tabs--scroll{overflow-x:auto;scrollbar-width:none}.tg-tabs--scroll::-webkit-scrollbar{display:none}.tg-tabs--scroll .tg-tab{flex:0 0 auto;min-width:56px}',
/* 选择片 */
'.tg-chips{display:flex;flex-wrap:wrap;gap:var(--tg-s-2)}',
'.tg-chip{position:relative;display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:var(--tg-hit);min-width:64px;padding:0 var(--tg-s-3);border-radius:var(--tg-r-2);border:1px solid var(--tg-line-2);background:var(--tg-card);color:var(--tg-ink);font-size:var(--tg-fs-2);cursor:pointer;touch-action:manipulation}',
'.tg-chip[aria-pressed=true]{border-color:var(--tg-accent);background:var(--tg-accent-soft);color:var(--tg-accent-2);font-weight:600;box-shadow:inset 0 0 0 1px var(--tg-accent)}',
/* 表单 */
'.tg-label{display:block;margin:var(--tg-s-4) 0 var(--tg-s-2);font-size:var(--tg-fs-1);font-weight:600;color:var(--tg-ink-2)}',
'.tg-label:first-child{margin-top:0}',
'.tg-input,.tg-textarea{display:block;width:100%;min-height:var(--tg-hit);padding:var(--tg-s-2) var(--tg-s-3);border:1px solid var(--tg-line-2);border-radius:var(--tg-r-2);background:var(--tg-card);color:var(--tg-ink);font-size:var(--tg-fs-2);line-height:1.6}',
'.tg-textarea{min-height:132px;resize:vertical}',
'.tg-input:focus,.tg-textarea:focus{border-color:var(--tg-accent);box-shadow:var(--tg-focus)}',
'.tg-input::placeholder,.tg-textarea::placeholder{color:#806a57}',
'.tg-help{margin:var(--tg-s-2) 0 0;font-size:var(--tg-fs-1);line-height:1.6;color:var(--tg-ink-2)}',
'.tg-help--err{color:var(--tg-err)}',
'.tg-intro{margin:0 0 var(--tg-s-2);font-size:var(--tg-fs-1);line-height:1.7;color:var(--tg-ink-2)}',
/* 卡片 / 徽标 / 空状态 */
'.tg-card{background:var(--tg-card);border:1px solid var(--tg-line);border-radius:var(--tg-r-3);padding:var(--tg-s-3) var(--tg-s-4);box-shadow:var(--tg-sh-1)}',
'.tg-card+.tg-card{margin-top:var(--tg-s-3)}',
'.tg-badge{display:inline-flex;align-items:center;min-height:24px;padding:0 var(--tg-s-2);border-radius:var(--tg-r-pill);font-size:var(--tg-fs-1);font-weight:600;line-height:1;white-space:nowrap;background:var(--tg-paper-2);color:var(--tg-ink-2)}',
'.tg-badge--ok{background:var(--tg-ok-soft);color:var(--tg-ok)}.tg-badge--warn{background:var(--tg-warn-soft);color:var(--tg-warn)}.tg-badge--err{background:var(--tg-err-soft);color:var(--tg-err)}.tg-badge--info{background:var(--tg-info-soft);color:var(--tg-info)}.tg-badge--accent{background:var(--tg-accent);color:var(--tg-on-accent)}',
'.tg-dot{position:absolute;top:8px;right:10px;width:8px;height:8px;border-radius:50%;background:#d8392b;box-shadow:0 0 0 2px var(--tg-paper-2)}',
'.tg-empty{padding:var(--tg-s-5) var(--tg-s-4);text-align:center;font-size:var(--tg-fs-1);color:var(--tg-ink-2);line-height:1.7}',
'.tg-meta{font-size:var(--tg-fs-1);color:var(--tg-ink-3)}',
/* 提示队列 */
'.tg-toasts{position:fixed;left:0;right:0;top:calc(env(safe-area-inset-top,0px) + 60px);display:flex;flex-direction:column;align-items:center;gap:var(--tg-s-2);padding:0 var(--tg-s-4);pointer-events:none;z-index:'+Z.toast+'}',
'@media (orientation:landscape) and (max-height:560px){.tg-toasts{top:calc(env(safe-area-inset-top,0px) + 12px)}}',
'.tg-toast{display:flex;align-items:center;gap:var(--tg-s-2);max-width:min(420px,100%);padding:10px var(--tg-s-4);border-radius:var(--tg-r-2);background:rgba(45,30,20,.92);color:#fff8ec;font-size:var(--tg-fs-1);line-height:1.5;box-shadow:var(--tg-sh-2);opacity:0;transform:translateY(-6px);transition:opacity .18s,transform .18s}',
'.tg-toast.is-on{opacity:1;transform:none}',
'.tg-toast--ok .tg-icon{color:#9fd8ae}.tg-toast--warn .tg-icon{color:#f2c879}.tg-toast--error{background:rgba(120,28,20,.94)}',
/* 对话框 */
'.tg-dialog-scrim{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:var(--tg-s-4);background:var(--tg-scrim)}',
'.tg-dialog{width:100%;max-width:360px;max-height:100%;overflow:auto;background:var(--tg-paper);border-radius:var(--tg-r-3);box-shadow:var(--tg-sh-3);padding:var(--tg-s-5) var(--tg-s-4) var(--tg-s-4)}',
'.tg-dialog__title{margin:0 0 var(--tg-s-2);font-family:var(--tg-font-title);font-size:var(--tg-fs-3);font-weight:600;color:var(--tg-ink)}',
'.tg-dialog__body{font-size:var(--tg-fs-2);line-height:1.7;color:var(--tg-ink-2)}',
'.tg-dialog__actions{display:flex;gap:var(--tg-s-3);margin-top:var(--tg-s-5)}',
'@media (prefers-reduced-motion:reduce){.tg-toast,.tg-btn{transition:none}}'
].join('\n');

function ensure(){
  if(document.getElementById('tg-ui-kit')) return;
  var st=document.createElement('style');st.id='tg-ui-kit';st.textContent=CSS;
  (document.head||document.documentElement).appendChild(st);
}

/* ---------- 层级 ---------- */
var layers=[];
function restack(){for(var i=0;i<layers.length;i++){var L=layers[i];L.z=(L.kind==='modal'?Z.modal:Z.panel)+i*Z.step;L.el.style.zIndex=String(L.z);}}
function openLayer(el,o){
  o=o||{};ensure();
  var L={el:el,kind:o.kind||'panel',onClose:o.onClose||null,esc:o.esc!==false,z:0};
  layers.push(L);restack();
  var h={get z(){return L.z;},
    close:function(){if(layers.indexOf(L)<0) return;h.remove();if(L.onClose) try{L.onClose();}catch(e){console.warn(e);}},
    remove:function(){var i=layers.indexOf(L);if(i>=0){layers.splice(i,1);restack();}}};
  L.h=h;return h;
}
function topLayer(){return layers.length?layers[layers.length-1]:null;}
document.addEventListener('keydown',function(e){
  if(e.key!=='Escape') return;
  var L=topLayer();if(!L||!L.esc) return;
  if(!L.el.isConnected){L.h.remove();return;}
  e.preventDefault();L.h.close();
});

/* ---------- 提示队列 ---------- */
var MAX_TOASTS=3, stack=null, live=[];
function host(){
  if(stack&&stack.isConnected) return stack;
  ensure();
  stack=document.createElement('div');stack.className='tg-ui tg-toasts';stack.setAttribute('role','status');stack.setAttribute('aria-live','polite');
  document.body.appendChild(stack);return stack;
}
function toast(msg,o){
  if(msg==null||msg==='') return {close:function(){}};
  if(window.__tgToastCapture){window.__tgToastCapture(String(msg));return {close:function(){}};} /* r8d1: lets the r8d toast queue run the full filter chain (r7 / r7-compliance / r7b-ux / r8) without displaying */
  if(typeof o==='number') o={duration:o};
  o=o||{};
  var text=String(msg), tone=o.tone||'info', dur=o.duration||Math.min(4200,1800+text.length*60);
  var root=host();
  for(var i=0;i<live.length;i++){
    if(live[i].text===text){var same=live[i];clearTimeout(same.t);same.t=setTimeout(same.close,dur);return {close:same.close};}
  }
  var el=document.createElement('div');el.className='tg-toast tg-toast--'+tone;
  var ic=tone==='ok'?'check':tone==='warn'||tone==='error'?'warn':'';
  el.innerHTML=ic?icon(ic,18):'';
  var span=document.createElement('span');span.textContent=text;el.appendChild(span);
  var item={text:text,el:el,t:0,close:null};
  item.close=function(){
    clearTimeout(item.t);var k=live.indexOf(item);if(k>=0) live.splice(k,1);
    el.classList.remove('is-on');setTimeout(function(){if(el.parentNode) el.parentNode.removeChild(el);},200);
  };
  live.push(item);root.appendChild(el);
  while(live.length>MAX_TOASTS) live[0].close();
  requestAnimationFrame(function(){el.classList.add('is-on');});
  item.t=setTimeout(item.close,dur);
  return {close:item.close};
}

/* ---------- 对话框 ---------- */
function modal(o){
  o=o||{};ensure();
  var scrim=document.createElement('div');scrim.className='tg-ui tg-dialog-scrim tg-ui-modal';
  var box=document.createElement('div');box.className='tg-dialog';box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');
  if(o.title){var t=document.createElement('h2');t.className='tg-dialog__title';t.textContent=o.title;box.appendChild(t);box.setAttribute('aria-label',o.title);}
  var b=document.createElement('div');b.className='tg-dialog__body';
  if(o.body&&o.body.nodeType) b.appendChild(o.body); else if(o.body!=null) b.textContent=String(o.body);
  box.appendChild(b);
  var acts=document.createElement('div');acts.className='tg-dialog__actions';
  var h, done=false;
  function close(){if(done) return;done=true;if(h) h.remove();if(scrim.parentNode) scrim.parentNode.removeChild(scrim);if(o.onClose) try{o.onClose();}catch(e){}}
  (o.actions||[{label:'知道了',primary:true}]).forEach(function(a){
    var btn=document.createElement('button');btn.type='button';
    btn.className='tg-btn tg-btn--block'+(a.danger?' tg-btn--danger':a.primary?' tg-btn--primary':'');
    btn.textContent=a.label;
    btn.onclick=function(){var r=a.onClick?a.onClick():undefined;if(r!==false) close();};
    acts.appendChild(btn);
  });
  box.appendChild(acts);scrim.appendChild(box);
  if(o.dismissible!==false) scrim.addEventListener('click',function(e){if(e.target===scrim) close();});
  document.body.appendChild(scrim);
  h=openLayer(scrim,{kind:'modal',esc:o.dismissible!==false,onClose:close});
  var first=acts.querySelector('.tg-btn--primary,.tg-btn--danger')||acts.firstChild;
  setTimeout(function(){try{first.focus({preventScroll:true});}catch(e){}},30);
  return {el:scrim,close:close};
}
function confirm(o){
  o=o||{};
  return new Promise(function(res){
    var v=false;
    modal({title:o.title,body:o.text,dismissible:true,onClose:function(){res(v);},
      actions:[{label:o.cancel||'取消'},{label:o.ok||'确定',primary:!o.danger,danger:!!o.danger,onClick:function(){v=true;}}]});
  });
}

window.TG_UI={__v:VER,version:'ui-kit-1',
  ensure:ensure,toast:toast,openLayer:openLayer,modal:modal,confirm:confirm,icon:icon,
  get icons(){return Object.keys(P);},
  get layers(){return layers.length;},
  Z:Z,tokens:TOKENS};
})();
