/* teahouse-assets.js — window.TG_TEA：西侧新社交区「茶会小院」资产。
 * 茶席（矮桌/坐垫/鼓凳/茶具）、留言墙（祈愿木牌，文字画到一张图集贴图）、石棋桌（象棋盘）、河灯（漂浮/起伏/发光）、
 * 竹林围墙（InstancedMesh 竹竿+竹叶，着色器摇曳）、繁茂植物（灌木/花丛/草丛/青苔/盆栽/石头/桂花树）。
 * 美术：王者荣耀家园式「风格化写实」，暖金色调。有 TG_REAL 时用其写实材质，否则退回纯色 MeshStandardMaterial。
 * 性能：每个资产内部按材质合并几何（一材质一 draw call）；重复物件用 InstancedMesh；所有动画只改 uniform/预分配矩阵。
 * 独立文件，不改任何既有代码；只依赖全局 THREE(r170)，可选 TG_REAL。
 */
(function(){
'use strict';
var G=typeof window!=='undefined'?window:globalThis;
if(G.TG_TEA)return;
function T(){return typeof THREE!=='undefined'?THREE:G.THREE;}
function R(){return G.TG_REAL||null;}
var MAT={},TEX={},GEO={},LIVE=new Set(),TIME={value:0};
function rng(seed){var s=(seed>>>0)||1;return function(){s=(s*16807)%2147483647;return s/2147483647;};}

/* ---------------- 材质 ---------------- */
var FALLBACK={roofTile:'#4f5a5e',lacquer:'#a8261a',wood:'#8a5a32',bluestone:'#7f8b8a',brick:'#6d7574',soil:'#7a5434',grass:'#5f9634',water:'#2a8f8a',plaster:'#e8dcc4',moss:'#4f7a2a'};
function real(name,opts){
 opts=opts||{};var r=R();
 if(r&&!API.forceFallback){try{return r.material(name,Object.assign({worldUV:opts.worldUV==null?true:opts.worldUV},opts));}catch(e){}}
 var TH=T(),k='fb:'+name+':'+(opts.tint||'');if(MAT[k])return MAT[k];
 var m=new TH.MeshStandardMaterial({color:opts.tint||FALLBACK[name]||'#888',roughness:name==='water'?.08:name==='lacquer'?.35:.85});
 if(name==='water'){m.transparent=true;m.opacity=.88;m.depthWrite=false;}return MAT[k]=m;
}
function std(color,rough,extra){var k='s:'+color+':'+rough+':'+JSON.stringify(extra||{});if(MAT[k])return MAT[k];var p=Object.assign({color:color,roughness:rough==null?.8:rough,metalness:0},extra||{});return MAT[k]=new (T().MeshStandardMaterial)(p);}
function canvasTex(key,w,h,draw,srgb){if(TEX[key])return TEX[key];var TH=T(),c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);var t=new TH.CanvasTexture(c);t.colorSpace=srgb===false?TH.NoColorSpace:TH.SRGBColorSpace;t.anisotropy=4;return TEX[key]=t;}
/* 摇曳：顶点按本地高度² 水平偏移；InstancedMesh 用实例位置做相位。只改 uniform，无每帧分配。 */
function sway(m,amp,freq){
 m.onBeforeCompile=function(sh){sh.uniforms.tgT=TIME;sh.vertexShader='uniform float tgT;\n'+sh.vertexShader.replace('#include <begin_vertex>',
  '#include <begin_vertex>\nfloat tgPh=0.0;\n#ifdef USE_INSTANCING\ntgPh=instanceMatrix[3].x*0.7+instanceMatrix[3].z*0.9;\n#endif\nfloat tgH=max(position.y,0.0);transformed.x+=sin(tgT*'+freq.toFixed(2)+'+tgPh)*'+amp.toFixed(3)+'*tgH*tgH;transformed.z+=cos(tgT*'+(freq*.8).toFixed(2)+'+tgPh*1.3)*'+(amp*.6).toFixed(3)+'*tgH*tgH;');};
 m.customProgramCacheKey=function(){return 'tgSway'+amp+':'+freq;};return m;
}

/* ---------------- 几何合并（按材质） ---------------- */
var _m4,_q,_e,_s,_p;
function tmp(){var TH=T();if(!_m4){_m4=new TH.Matrix4();_q=new TH.Quaternion();_e=new TH.Euler();_s=new TH.Vector3();_p=new TH.Vector3();}}
function Builder(){this.parts=new Map();}
Builder.prototype.add=function(geo,mat,x,y,z,rx,ry,rz,sx,sy,sz){
 tmp();_p.set(x||0,y||0,z||0);_e.set(rx||0,ry||0,rz||0);_q.setFromEuler(_e);_s.set(sx==null?1:sx,sy==null?(sx==null?1:sx):sy,sz==null?(sx==null?1:sx):sz);
 _m4.compose(_p,_q,_s);var g=geo.index?geo.toNonIndexed():geo.clone();g.applyMatrix4(_m4);
 if(mat&&mat.__vc){var cc=new (T().Color)(mat.color),n=g.attributes.position.count,ca=new Float32Array(n*3),src=g.attributes.color;for(var i=0;i<n;i++){var f=src?src.getX(i)*0+1:1;ca[i*3]=cc.r*f;ca[i*3+1]=cc.g*f;ca[i*3+2]=cc.b*f;}g.setAttribute('color',new (T().BufferAttribute)(ca,3));mat=vcMat(mat.cls);}
 var e=this.parts.get(mat);if(!e)this.parts.set(mat,e=[]);e.push(g);return g;};
Builder.prototype.addGeo=function(g,mat){if(mat&&mat.__vc)mat=vcMat(mat.cls);var e=this.parts.get(mat);if(!e)this.parts.set(mat,e=[]);e.push(g.index?g.toNonIndexed():g);};
Builder.prototype.finish=function(group,opts){
 opts=opts||{};var TH=T(),out=[];
 this.parts.forEach(function(list,mat){var g=merge(list);var m=new TH.Mesh(g,mat);m.castShadow=opts.cast!==false&&!mat.transparent;m.receiveShadow=true;m.name='tea:'+(mat.name||'mat');group.add(m);out.push(m);});return out;};
function merge(list){
 var TH=T(),n=0,i,hasUV=true,hasCol=false;for(i=0;i<list.length;i++){n+=list[i].attributes.position.count;if(!list[i].attributes.uv)hasUV=false;if(list[i].attributes.color)hasCol=true;}
 var P=new Float32Array(n*3),N=new Float32Array(n*3),U=hasUV?new Float32Array(n*2):null,C=hasCol?new Float32Array(n*3):null,o=0;
 for(i=0;i<list.length;i++){var g=list[i],c=g.attributes.position.count;if(!g.attributes.normal)g.computeVertexNormals();P.set(g.attributes.position.array,o*3);N.set(g.attributes.normal.array,o*3);if(U)U.set(g.attributes.uv.array,o*2);if(C){if(g.attributes.color)C.set(g.attributes.color.array,o*3);else C.fill(1,o*3,(o+c)*3);}o+=c;g.dispose();}
 var out=new TH.BufferGeometry();out.setAttribute('position',new TH.BufferAttribute(P,3));out.setAttribute('normal',new TH.BufferAttribute(N,3));if(U)out.setAttribute('uv',new TH.BufferAttribute(U,2));if(C)out.setAttribute('color',new TH.BufferAttribute(C,3));out.computeBoundingSphere();out.computeBoundingBox();return out;
}
function geo(k){if(GEO[k])return GEO[k];var TH=T(),g;switch(k){
 case 'box':g=new TH.BoxGeometry(1,1,1);break;case 'cyl':g=new TH.CylinderGeometry(1,1,1,16);break;case 'cyl8':g=new TH.CylinderGeometry(1,1,1,8);break;
 case 'cyl24':g=new TH.CylinderGeometry(1,1,1,24);break;case 'sph':g=new TH.SphereGeometry(1,12,8);break;case 'cone':g=new TH.ConeGeometry(1,1,10);break;
 case 'disc':g=new TH.CircleGeometry(1,24).rotateX(-Math.PI/2);break;case 'plane':g=new TH.PlaneGeometry(1,1);break;case 'flat':g=new TH.PlaneGeometry(1,1).rotateX(-Math.PI/2);break;
 case 'torus':g=new TH.TorusGeometry(1,.12,6,20);break;case 'rock':g=jitter(new TH.IcosahedronGeometry(1,1),.18,5);break;
 case 'bush':g=jitter(new TH.IcosahedronGeometry(1,1),.22,9);shade(g,'#2f5a1e','#86b440');break;
 default:g=new TH.BoxGeometry(1,1,1);}return GEO[k]=g;}
function jitter(g,a,seed){var r=rng(seed),p=g.attributes.position,map={};for(var i=0;i<p.count;i++){var key=p.getX(i).toFixed(3)+','+p.getY(i).toFixed(3)+','+p.getZ(i).toFixed(3);var f=map[key]||(map[key]=1+(r()-.5)*2*a);p.setXYZ(i,p.getX(i)*f,p.getY(i)*f*(p.getY(i)<0?.6:1),p.getZ(i)*f);}g.computeVertexNormals();return g;}
function shade(g,lo,hi){var TH=T(),p=g.attributes.position,a=new TH.Color(lo),b=new TH.Color(hi),c=new TH.Color(),col=[];for(var i=0;i<p.count;i++){var t=Math.min(1,Math.max(0,(p.getY(i)+1)/2));c.copy(a).lerp(b,t*t);col.push(c.r,c.g,c.b);}g.setAttribute('color',new TH.Float32BufferAttribute(col,3));return g;}
function lathe(pts,seg){var TH=T();return new TH.LatheGeometry(pts.map(function(p){return new TH.Vector2(p[0],p[1]);}),seg||16);}

/* InstancedMesh：把一个“原型 Group”（其 Mesh 子节点）复制到多组变换上 → 每材质 1 draw call */
function instance(proto,list,parent){
 var TH=T(),out=new TH.Group(),o=new TH.Object3D();out.name='tea:inst';
 proto.updateMatrixWorld(true);
 proto.traverse(function(m){if(!m.isMesh)return;var im=new TH.InstancedMesh(m.geometry,m.material,list.length);im.castShadow=m.castShadow;im.receiveShadow=true;
  for(var i=0;i<list.length;i++){var t=list[i];o.position.set(t[0],t[1]||0,t[2]);o.rotation.set(0,t[3]||0,0);o.scale.setScalar(t[4]||1);o.updateMatrix();o.matrix.multiply(m.matrixWorld);im.setMatrixAt(i,o.matrix);}
  im.computeBoundingSphere();out.add(im);});
 if(parent)parent.add(out);return out;
}

/* ---------------- 布料/草席/竹/叶 贴图 ---------------- */
function matTex(){return canvasTex('mat',128,128,function(g,w,h){g.fillStyle='#c9ab6e';g.fillRect(0,0,w,h);for(var y=0;y<h;y+=4){g.fillStyle=y%8?'#b8995c':'#d6bb80';g.fillRect(0,y,w,2);}g.fillStyle='rgba(90,60,20,.5)';for(var x=0;x<w;x+=32)g.fillRect(x,0,2,h);g.strokeStyle='#5d3f1d';g.lineWidth=6;g.strokeRect(0,0,w,h);});}
function bambooTex(){var t=canvasTex('bamboo',64,256,function(g,w,h){var gr=g.createLinearGradient(0,0,w,0);gr.addColorStop(0,'#46702a');gr.addColorStop(.45,'#8fb85a');gr.addColorStop(1,'#3c6424');g.fillStyle=gr;g.fillRect(0,0,w,h);
  for(var i=0;i<60;i++){g.fillStyle='rgba(30,60,20,.25)';g.fillRect(Math.random()*w,Math.random()*h,1,6+Math.random()*20);}
  for(var y=0;y<h;y+=64){g.fillStyle='#c9cf8a';g.fillRect(0,y,w,3);g.fillStyle='#2d4a1b';g.fillRect(0,y+3,w,2);}});t.wrapS=t.wrapT=T().RepeatWrapping;return t;}
function leafTex(){return canvasTex('leaf',256,256,function(g,w,h){var r=rng(17);g.clearRect(0,0,w,h);for(var i=0;i<46;i++){var x=r()*w*.8+w*.1,y=r()*h*.8+h*.1,a=r()*Math.PI*2,L=34+r()*36,W=5+r()*4;g.save();g.translate(x,y);g.rotate(a);var c=['#5e8f2e','#75a83a','#4a7a26','#9cc552','#3f6b22'][i%5];g.fillStyle=c;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(L*.45,-W,L,0);g.quadraticCurveTo(L*.45,W,0,0);g.fill();g.strokeStyle='rgba(30,50,15,.5)';g.lineWidth=1;g.beginPath();g.moveTo(0,0);g.lineTo(L,0);g.stroke();g.restore();}});}
function tuftTex(){return canvasTex('tuft',128,128,function(g,w,h){var r=rng(23);g.clearRect(0,0,w,h);for(var i=0;i<70;i++){var x=w*.15+r()*w*.7,lean=(r()-.5)*40,hh=h*(.45+r()*.5);var c=['#6fa337','#8dbb47','#4c7f2a','#b0c45a'][i%4];g.strokeStyle=c;g.lineWidth=2+r()*2;g.beginPath();g.moveTo(x,h);g.quadraticCurveTo(x+lean*.3,h-hh*.6,x+lean,h-hh);g.stroke();}});}
function glowTex(){return canvasTex('glow',64,64,function(g,w,h){var gr=g.createRadialGradient(32,32,0,32,32,32);gr.addColorStop(0,'rgba(255,200,120,1)');gr.addColorStop(.35,'rgba(255,150,70,.45)');gr.addColorStop(1,'rgba(255,120,40,0)');g.fillStyle=gr;g.fillRect(0,0,w,h);});}
function steamTex(){return canvasTex('steam',64,64,function(g,w,h){var gr=g.createRadialGradient(32,32,0,32,32,30);gr.addColorStop(0,'rgba(255,255,255,.55)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.fillRect(0,0,w,h);});}
/* 顶点色共享材质：小件（陶瓷/布料/绳/花）只按光泽分 2 个材质，合并后 draw call 很少 */
function V(color,cls){return {__vc:1,color:color,cls:cls||'matte'};}
function vcMat(cls){var k='vc:'+cls;return MAT[k]||(MAT[k]=new (T().MeshStandardMaterial)({vertexColors:true,roughness:cls==='gloss'?.28:cls==='satin'?.55:.92,metalness:0,name:'tea:vc-'+cls}));}
function fabric(c){return V(c,'matte');}
function ceramic(c){return V(c,'gloss');}

/* ======================= 1. 茶席 ======================= */
/* teaTable({style:'low'|'high', seats:4, cushion:'#3d5a80', teaset:true, steam:true}) → Group（userData: blocks, seats, kind） */
function teaTable(opts){
 opts=opts||{};var TH=T(),g=new TH.Group(),b=new Builder(),wood=real('wood'),lac=real('lacquer'),low=opts.style!=='high';g.name='tea:table';
 var W=low?1.5:1.1,D=low?.85:1.1,H=low?.36:.74;
 if(low){b.add(geo('flat'),std('#ffffff',.95,{map:matTex()}),0,.034,0,0,0,0,2.9,1,2.3);}
 b.add(geo('box'),wood,0,H-.03,0,0,0,0,W,.06,D);b.add(geo('box'),lac,0,H-.085,0,0,0,0,W-.08,.05,D-.08);
 [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(function(s){b.add(geo('box'),lac,s[0]*(W/2-.1),(H-.1)/2,s[1]*(D/2-.1),0,0,0,.07,H-.1,.07);b.add(geo('box'),wood,s[0]*(W/2-.1),.015,s[1]*(D/2-.1),0,0,0,.12,.03,.12);});
 var seats=[],cc=opts.cushion||'#3e5f7a',cush=fabric(cc),trim=fabric('#c99a3c');
 var n=opts.seats==null?4:opts.seats,pos=low?[[0,D/2+.42,0],[0,-(D/2+.42),Math.PI],[W/2+.42,0,Math.PI/2],[-(W/2+.42),0,-Math.PI/2]]:[[0,D/2+.5,0],[0,-(D/2+.5),Math.PI],[W/2+.5,0,Math.PI/2],[-(W/2+.5),0,-Math.PI/2]];
 for(var i=0;i<Math.min(n,4);i++){var p=pos[i],sx,sz;
  if(i<2){sx=0;sz=p[1];}else{sx=p[0];sz=0;}
  if(low){b.add(geo('cyl24'),cush,sx,.085,sz,0,0,0,.3,.12,.3);b.add(geo('torus'),trim,sx,.145,sz,Math.PI/2,0,0,.27,.27,.25);b.add(geo('sph'),cush,sx,.145,sz,0,0,0,.27,.07,.27);}
  else{var drum=lathe([[0,0],[.17,0],[.21,.08],[.23,.22],[.21,.36],[.17,.44],[0,.44]],18);b.add(drum,ceramic('#6f9a8a'),sx,0,sz);b.add(geo('torus'),ceramic('#c9a24a'),sx,.22,sz,Math.PI/2,0,0,.225,.225,.3);}
  seats.push({x:sx,z:sz,ry:p[2]});}
 if(opts.teaset!==false)teaSet(b,0,H,0,opts);
 b.finish(g);
 if(opts.steam!==false)g.add(steam(0.12,H+.24,0.0));
 g.userData={kind:'teaTable',seats:seats,blocks:[{x:-W/2-.1,X:W/2+.1,z:-D/2-.1,Z:D/2+.1}],interact:{x:0,z:0,label:'品茶'}};return g;
}
function teaSet(b,x,y,z,opts){
 var TH=T(),tray=real('wood',{tint:'#5a3320',tintMix:.7}),zisha=V('#7a3a22','gloss'),cel=ceramic('#cfe0d2'),white=ceramic('#f3eee2'),lid=V('#6a3020','gloss');
 b.add(geo('box'),tray,x,y+.02,z,0,0,0,.62,.04,.38);
 var pot=lathe([[0,0],[.06,0],[.09,.02],[.1,.06],[.085,.1],[.05,.115],[0,.115]],16);b.add(pot,zisha,x+.12,y+.04,z);
 b.add(geo('cyl'),lid,x+.12,y+.16,z,0,0,0,.05,.012,.05);b.add(geo('sph'),lid,x+.12,y+.175,z,0,0,0,.016);
 b.add(geo('cyl8'),zisha,x+.235,y+.11,z,0,0,-1.0,.014,.09,.014);b.add(geo('torus'),zisha,x+.02,y+.1,z,0,0,0,.045,.045,.4);
 var cup=lathe([[0,0],[.022,0],[.03,.012],[.034,.045],[.031,.045],[.026,.014],[0,.01]],12);
 [[-.16,-.1],[-.06,-.11],[-.16,.1],[-.06,.11]].forEach(function(c){b.add(cup,cel,x+c[0],y+.04,z+c[1]);});
 var pitcher=lathe([[0,0],[.035,0],[.045,.03],[.042,.08],[.05,.095],[.0,.095]],14);b.add(pitcher,white,x-.24,y+.04,z);
 // 小花瓶+一枝花（细节）
 var vase=lathe([[0,0],[.03,0],[.045,.05],[.02,.11],[.025,.14],[0,.14]],12);b.add(vase,ceramic('#2f5a7a'),x-.55,y,z+.25);
 b.add(geo('cyl8'),V('#5a3a20'),x-.55,y+.2,z+.25,0,0,.25,.006,.16,.006);
 [[-.57,.3,.24],[-.53,.27,.27],[-.585,.25,.23]].forEach(function(f){b.add(geo('sph'),V('#f2a0b4','satin'),x+f[0],y+f[1],z+f[2],0,0,0,.022);});
}
function steam(x,y,z){var TH=T(),m=new TH.SpriteMaterial({map:steamTex(),transparent:true,depthWrite:false,opacity:.5}),g=new TH.Group();g.name='tea:steam';
 for(var i=0;i<3;i++){var s=new TH.Sprite(m);s.position.set(x,y+i*.1,z);s.scale.setScalar(.08);s.userData.k=i;g.add(s);}
 g.userData.update=function(t){for(var i=0;i<g.children.length;i++){var s=g.children[i],ph=(t*.35+i/3)%1;s.position.y=y+ph*.35;s.position.x=x+Math.sin(t*1.3+i)*.03*ph;s.scale.setScalar(.05+ph*.14);}m.opacity=.45;};
 LIVE.add(g);return g;}

/* ======================= 2. 留言墙 ======================= */
/* messageWall({width:4.2,height:2.6,cols:4,rows:2,messages:[{text,author,style:'wood'|'red'|'jade'}]}) → Group，userData.api */
function messageWall(opts){
 opts=opts||{};var TH=T(),g=new TH.Group(),b=new Builder(),W=opts.width||4.2,H=opts.height||2.6,cols=opts.cols||4,rows=opts.rows||2;g.name='tea:messageWall';
 var lac=real('lacquer'),roof=real('roofTile'),wall=real('plaster'),brick=real('brick'),wood=real('wood');
 b.add(geo('box'),brick,0,.25,0,0,0,0,W+.3,.5,.36);// 砖基座
 b.add(geo('box'),wall,0,.5+H/2,-.05,0,0,0,W,H,.22);// 抹灰墙心
 [-1,1].forEach(function(s){b.add(geo('box'),lac,s*(W/2+.06),.5+H/2+.1,0,0,0,0,.16,H+.2,.3);});
 b.add(geo('box'),lac,0,.5+H+.04,.02,0,0,0,W+.3,.1,.3);
 [-1,1].forEach(function(s){b.add(geo('box'),roof,0,.5+H+.24,s*.24,s*-.38,0,0,W+.7,.07,.6);});
 b.add(geo('box'),real('roofTile',{tint:'#3d4548'}),0,.5+H+.36,0,0,0,0,W+.8,.1,.12);
 [-1,1].forEach(function(s){b.add(geo('box'),real('roofTile',{tint:'#3d4548'}),s*(W/2+.38),.5+H+.44,0,0,0,s*.5,.3,.08,.1);});
 // 横杆（挂木牌的绳子落点）
 for(var r=0;r<rows;r++)b.add(geo('cyl8'),wood,0,.5+H-.18-r*(H-.25)/rows,.1,0,0,Math.PI/2,.018,W-.2,.018);
 b.finish(g);
 // 木牌图集：一张 canvas，全部卡片 1 draw call
 var CW=1024,CH=Math.round(1024*(H-.2)/(W-.2)),cv=document.createElement('canvas');cv.width=CW;cv.height=CH;var ctx=cv.getContext('2d'),tex=new TH.CanvasTexture(cv);tex.colorSpace=TH.SRGBColorSpace;tex.anisotropy=4;
 var board=new TH.Mesh(new TH.PlaneGeometry(W-.2,H-.2),new TH.MeshStandardMaterial({map:tex,transparent:true,alphaTest:.05,roughness:.75}));board.position.set(0,.5+H/2-.02,.075);board.name='tea:messageCards';g.add(board);
 var list=[],cap=cols*rows,STY={wood:['#c99560','#9c6a3a','#3a2412'],red:['#c8402c','#9a2a1c','#fff0d0'],jade:['#bcd8c4','#86ae98','#20402e'],paper:['#f1e6c8','#cdbb8e','#3a2a18']};
 function wrap(text,max,lines){var out=[],cur='';for(var i=0;i<text.length;i++){var ch=text[i];if(ch==='\n'){out.push(cur);cur='';continue;}if(ctx.measureText(cur+ch).width>max){out.push(cur);cur=ch;}else cur+=ch;if(out.length>=lines)break;}if(cur&&out.length<lines)out.push(cur);if(out.length===lines&&text.length>out.join('').length)out[lines-1]=out[lines-1].slice(0,-1)+'…';return out;}
 function draw(){
  ctx.clearRect(0,0,CW,CH);var cw=CW/cols,ch=CH/rows,show=list.slice(-cap);
  for(var i=0;i<show.length;i++){var m=show[i],c=i%cols,r=(i/cols)|0,st=STY[m.style]||STY[['wood','red','jade','paper'][i%4]],x=c*cw+cw*.12,y=r*ch+ch*.16,w=cw*.76,h=ch*.76,tilt=((i*37)%7-3)*.012;
   ctx.save();ctx.translate(x+w/2,r*ch+ch*.06);ctx.rotate(tilt);ctx.translate(-(x+w/2),-(r*ch+ch*.06));
   ctx.strokeStyle='#b8241a';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x+w/2,r*ch+ch*.02);ctx.lineTo(x+w/2,y+6);ctx.stroke();// 红绳
   ctx.fillStyle='rgba(0,0,0,.28)';rr(x+6,y+8,w,h,14);ctx.fill();
   var gr=ctx.createLinearGradient(x,y,x,y+h);gr.addColorStop(0,st[0]);gr.addColorStop(1,st[1]);ctx.fillStyle=gr;rr(x,y,w,h,14);ctx.fill();
   ctx.strokeStyle='rgba(60,30,10,.55)';ctx.lineWidth=3;rr(x+7,y+7,w-14,h-14,10);ctx.stroke();
   if(m.style!=='jade'&&m.style!=='paper'){ctx.globalAlpha=.12;ctx.strokeStyle='#2a160a';for(var k=0;k<8;k++){ctx.beginPath();ctx.moveTo(x+10,y+12+k*h/8);ctx.bezierCurveTo(x+w*.3,y+18+k*h/8,x+w*.7,y+6+k*h/8,x+w-10,y+12+k*h/8);ctx.stroke();}ctx.globalAlpha=1;}
   ctx.fillStyle='#b8241a';ctx.beginPath();ctx.arc(x+w/2,y+16,7,0,Math.PI*2);ctx.fill();
   var fs=Math.round(h*.12);ctx.font='bold '+fs+'px "Noto Serif CJK SC","Songti SC",serif';ctx.fillStyle=st[2];ctx.textAlign='center';ctx.textBaseline='top';
   var lines=wrap(String(m.text||''),w-30,4);for(var L=0;L<lines.length;L++)ctx.fillText(lines[L],x+w/2,y+34+L*fs*1.22);
   if(m.author){ctx.font=Math.round(fs*.72)+'px "Noto Serif CJK SC",serif';ctx.textAlign='right';ctx.fillText('— '+m.author,x+w-16,y+h-fs*.95);}
   ctx.restore();}
  tex.needsUpdate=true;}
 function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
 var api={capacity:cap,
  addMessage:function(m){if(typeof m==='string')m={text:m};list.push({text:m.text,author:m.author,style:m.style,id:m.id,ts:m.ts||Date.now()});if(list.length>cap*4)list.splice(0,list.length-cap*4);draw();return list.length;},
  setMessages:function(arr){list=(arr||[]).map(function(m){return typeof m==='string'?{text:m}:Object.assign({},m);});draw();},
  clear:function(){list=[];draw();},messages:function(){return list.slice();},
  /* 点击命中：传 Raycaster 的 uv 返回槽位里的那条留言 */
  pick:function(uv){if(!uv)return null;var c=Math.floor(uv.x*cols),r=Math.floor((1-uv.y)*rows),show=list.slice(-cap);return show[r*cols+c]||null;},
  board:board,texture:tex};
 g.userData={kind:'messageWall',api:api,blocks:[{x:-W/2-.2,X:W/2+.2,z:-.25,Z:.25}],interact:{x:0,z:.9,label:'留言'}};
 api.setMessages(opts.messages||[]);return g;
}

/* ======================= 3. 石棋桌 ======================= */
var XQ=[['車',0,0],['馬',1,0],['相',2,0],['仕',3,0],['帥',4,0],['仕',5,0],['相',6,0],['馬',7,0],['車',8,0],['炮',1,2],['炮',7,2],['兵',0,3],['兵',2,3],['兵',4,4],['兵',6,3],['兵',8,3]];
var XQB=[['車',0,9],['馬',2,7],['象',2,9],['士',3,9],['將',4,9],['士',5,9],['象',6,9],['馬',7,9],['車',8,8],['砲',4,7],['砲',7,7],['卒',0,6],['卒',2,6],['卒',4,6],['卒',6,6],['卒',8,6]];
function boardTex(){return canvasTex('xiangqi',512,512,function(g,w,h){
 g.fillStyle='#8c9590';g.fillRect(0,0,w,h);for(var i=0;i<900;i++){g.fillStyle='rgba('+(i%2?'60,70,68':'170,175,160')+',.18)';g.fillRect(Math.random()*w,Math.random()*h,2,2);}
 var m=56,cw=(w-2*m)/8,ch=(h-2*m)/9;g.strokeStyle='#3c2a1e';g.lineWidth=3;g.strokeRect(m-8,m-8,w-2*m+16,h-2*m+16);g.lineWidth=2;
 for(var r=0;r<10;r++){g.beginPath();g.moveTo(m,m+r*ch);g.lineTo(w-m,m+r*ch);g.stroke();}
 for(var c=0;c<9;c++){g.beginPath();g.moveTo(m+c*cw,m);g.lineTo(m+c*cw,m+4*ch);g.moveTo(m+c*cw,m+5*ch);g.lineTo(m+c*cw,m+9*ch);g.stroke();if(c===0||c===8){g.beginPath();g.moveTo(m+c*cw,m+4*ch);g.lineTo(m+c*cw,m+5*ch);g.stroke();}}
 [[0,2],[7,9]].forEach(function(p){g.beginPath();g.moveTo(m+3*cw,m+p[0]*ch);g.lineTo(m+5*cw,m+p[1]*ch);g.moveTo(m+5*cw,m+p[0]*ch);g.lineTo(m+3*cw,m+p[1]*ch);g.stroke();});
 g.fillStyle='#3c2a1e';g.font='bold 34px "Noto Serif CJK SC",serif';g.textAlign='center';g.textBaseline='middle';g.fillText('楚 河',m+2*cw,m+4.5*ch);g.fillText('漢 界',m+6*cw,m+4.5*ch);
 function piece(t,c,r,red){var x=m+c*cw,y=m+r*ch;g.fillStyle='#e6c690';g.beginPath();g.arc(x,y,cw*.42,0,Math.PI*2);g.fill();g.strokeStyle=red?'#a8261a':'#1e1e1e';g.lineWidth=2;g.beginPath();g.arc(x,y,cw*.34,0,Math.PI*2);g.stroke();g.fillStyle=red?'#a8261a':'#1e1e1e';g.font='bold '+Math.round(cw*.42)+'px "Noto Serif CJK SC",serif';g.fillText(t,x,y+1);}
 XQ.forEach(function(p){piece(p[0],p[1],p[2],true);});XQB.forEach(function(p){piece(p[0],p[1],p[2],false);});
});}
/* chessTable({stools:4}) —— 棋子是带厚度的小圆柱：顶面 UV 映射到棋盘贴图上对应位置，与棋盘共享一张贴图、一个 draw call */
function chessTable(opts){
 opts=opts||{};var TH=T(),g=new TH.Group(),b=new Builder(),stone=real('bluestone',{tint:'#8d9692'}),moss=real('moss');g.name='tea:chessTable';
 var ped=lathe([[0,0],[.38,0],[.36,.08],[.2,.16],[.16,.4],[.2,.62],[.34,.68],[0,.68]],20);b.add(ped,stone,0,0,0);
 b.add(geo('cyl24'),stone,0,.72,0,0,0,0,.62,.08,.62);
 b.add(geo('disc'),moss,0,.005,0,0,0,0,.7,1,.6);
 var S=opts.stools==null?4:opts.stools;var stool=lathe([[0,0],[.2,0],[.22,.06],[.18,.2],[.2,.38],[.22,.42],[0,.42]],16),seats=[];
 for(var i=0;i<S;i++){var a=i*Math.PI*2/S+Math.PI/4,x=Math.cos(a)*1.0,z=Math.sin(a)*1.0;b.add(stool,stone,x,0,z);b.add(geo('disc'),moss,x+.05,.003,z+.04,0,0,0,.32,1,.28);seats.push({x:x,z:z,ry:-a-Math.PI/2});}
 // 棋盘面 + 棋子：共享 boardTex
 var bm=new TH.MeshStandardMaterial({map:boardTex(),roughness:.7});var B=new Builder(),side=.82,top=.762;
 var pl=new TH.PlaneGeometry(side,side).rotateX(-Math.PI/2);pl.translate(0,top,0);B.addGeo(pl,bm);
 var m=56/512,cw=(1-2*m)/8,ch=(1-2*m)/9,wood=std('#c8a46c',.55);
 XQ.concat(XQB).forEach(function(p){var u=m+p[1]*cw,v=m+p[2]*ch,x=(u-.5)*side,z=(v-.5)*side,rad=cw*.42*side;
  var cap=new TH.CircleGeometry(rad,16).rotateX(-Math.PI/2);var uv=cap.attributes.uv,pos=cap.attributes.position;for(var k=0;k<uv.count;k++){uv.setXY(k,u+pos.getX(k)/side,1-(v+pos.getZ(k)/side));}
  cap.translate(x,top+.022,z);B.addGeo(cap,bm);var sd=new TH.CylinderGeometry(rad,rad,.02,16,1,true);sd.translate(x,top+.012,z);B.addGeo(sd,wood);});
 b.finish(g);B.finish(g,{cast:false});
 g.userData={kind:'chessTable',seats:seats,blocks:[{x:-.7,X:.7,z:-.7,Z:.7}],interact:{x:0,z:0,label:'对弈'}};return g;
}

/* ======================= 4. 河灯 ======================= */
/* riverLanterns({length:10,width:1.8,count:9,banks:true,lotusLeaves:12,seed}) —— 沿 X 轴的小河；灯在 update 中漂流/起伏/摇摆 */
function lanternGeo(){if(GEO.lantern)return GEO.lantern;var TH=T(),list=[];
 for(var i=0;i<8;i++){var p=new TH.SphereGeometry(.09,8,6,0,Math.PI*2,0,Math.PI/2);p.scale(.55,1.25,.32);p.rotateX(-.55);p.translate(0,.02,.075);p.rotateY(i*Math.PI/4);list.push(p.toNonIndexed());}
 for(var j=0;j<8;j++){var q=new TH.SphereGeometry(.07,8,6,0,Math.PI*2,0,Math.PI/2);q.scale(.6,1.3,.32);q.rotateX(-.25);q.translate(0,.03,.045);q.rotateY(j*Math.PI/4+Math.PI/8);list.push(q.toNonIndexed());}
 var base=new TH.CylinderGeometry(.13,.1,.03,12);list.push(base.toNonIndexed());
 return GEO.lantern=merge(list);}
function riverLanterns(opts){
 opts=opts||{};var TH=T(),g=new TH.Group(),b=new Builder(),L=opts.length||10,W=opts.width||1.8,N=opts.count||9,r=rng(opts.seed||7);g.name='tea:river';
 var water=new TH.Mesh(new TH.PlaneGeometry(L,W).rotateX(-Math.PI/2),real('water'));water.position.y=-.08;water.receiveShadow=true;water.name='tea:water';g.add(water);
 b.add(geo('box'),real('soil',{tint:'#4a3a28'}),0,-.25,0,0,0,0,L,.1,W);// 河床
 if(opts.banks!==false){var stone=real('bluestone'),moss=real('moss');
  for(var s=-1;s<=1;s+=2)for(var x=-L/2+.3;x<L/2;x+=.55+r()*.2){var sc=.22+r()*.16;b.add(geo('rock'),stone,x,-.04,s*(W/2+.05)+(r()-.5)*.12,r()*3,r()*3,0,sc*1.3,sc*.7,sc);if(r()<.55)b.add(geo('rock'),moss,x+.03,.05+sc*.25,s*(W/2+.05),0,r()*3,0,sc*.9,sc*.25,sc*.75);}}
 b.finish(g);
 // 荷叶（instanced）
 var nl=opts.lotusLeaves==null?10:opts.lotusLeaves,leafG=new TH.CircleGeometry(.22,14,.25,Math.PI*2-.5).rotateX(-Math.PI/2),leaves=new TH.InstancedMesh(leafG,std('#4f8a35',.6,{side:TH.DoubleSide}),nl),o=new TH.Object3D();
 for(var i=0;i<nl;i++){o.position.set((r()-.5)*L*.9,-.07,(r()<.5?-1:1)*(W*.25+r()*W*.2));o.rotation.set(0,r()*6.28,0);o.scale.setScalar(.7+r()*.7);o.updateMatrix();leaves.setMatrixAt(i,o.matrix);}leaves.receiveShadow=true;g.add(leaves);
 // 河灯
 var paper=new TH.MeshStandardMaterial({color:'#ffd2c0',emissive:'#ff8a5a',emissiveIntensity:.9,roughness:.8,side:TH.DoubleSide}),flameM=new TH.MeshBasicMaterial({color:'#ffd27a',toneMapped:false});
 var lan=new TH.InstancedMesh(lanternGeo(),paper,N),fl=new TH.InstancedMesh(new TH.SphereGeometry(.03,8,6).scale(1,1.6,1),flameM,N),gl=new TH.InstancedMesh(new TH.PlaneGeometry(.9,.9).rotateX(-Math.PI/2),new TH.MeshBasicMaterial({map:glowTex(),transparent:true,depthWrite:false,blending:TH.AdditiveBlending,toneMapped:false,opacity:.75}),N);
 lan.castShadow=false;[lan,fl,gl].forEach(function(m){m.frustumCulled=false;g.add(m);});lan.name='tea:lanterns';
 var st=[];for(var k=0;k<N;k++)st.push({x:-L/2+(k+r())*L/N,z:(r()-.5)*W*.5,ph:r()*6.28,sp:.12+r()*.1,ry:r()*6.28,hue:k%3});
 var cols=[new TH.Color('#ffd2c0'),new TH.Color('#ffe6b0'),new TH.Color('#ffc0c8')];for(k=0;k<N;k++)lan.setColorAt(k,cols[st[k].hue]);
 var dummy=new TH.Object3D(),t=0;
 g.userData={kind:'river',blocks:[{x:-L/2,X:L/2,z:-W/2,Z:W/2}],interact:{x:0,z:W/2+.6,label:'放河灯'},lanterns:st,
  update:function(dt){t+=dt;for(var i=0;i<N;i++){var s=st[i];s.x+=s.sp*dt;if(s.x>L/2-.2)s.x=-L/2+.2;var y=-.06+Math.sin(t*1.6+s.ph)*.012,zz=s.z+Math.sin(t*.4+s.ph)*.08;
   dummy.position.set(s.x,y,zz);dummy.rotation.set(Math.sin(t*1.3+s.ph)*.05,s.ry+t*.15,Math.cos(t*1.1+s.ph)*.05);dummy.scale.setScalar(1);dummy.updateMatrix();lan.setMatrixAt(i,dummy.matrix);
   dummy.position.y=y+.07;dummy.scale.set(1,1+Math.sin(t*9+s.ph)*.15,1);dummy.updateMatrix();fl.setMatrixAt(i,dummy.matrix);
   dummy.position.set(s.x,-.075,zz);dummy.rotation.set(0,0,0);dummy.scale.setScalar(1+Math.sin(t*7+s.ph)*.06);dummy.updateMatrix();gl.setMatrixAt(i,dummy.matrix);}
   lan.instanceMatrix.needsUpdate=fl.instanceMatrix.needsUpdate=gl.instanceMatrix.needsUpdate=true;paper.emissiveIntensity=.85+Math.sin(t*5.3)*.06+Math.sin(t*11.7)*.04;},
  /* addLantern(x?) —— 玩家「放河灯」：复用最靠后的一盏移到起点 */
  release:function(){var j=0;for(var i=1;i<N;i++)if(st[i].x>st[j].x)j=i;st[j].x=-L/2+.2;st[j].z=(Math.random()-.5)*W*.4;return j;}};
 g.userData.update(0);LIVE.add(g);return g;
}

/* ======================= 5. 竹林围墙 ======================= */
/* bambooFence({from:[x,z],to:[x,z],depth:1.2,density:9,height:[3.2,5],fence:true,seed}) —— 竹竿/竹叶各一个 InstancedMesh，着色器摇曳 */
function culmGeo(){if(GEO.culm)return GEO.culm;var TH=T(),list=[],c=new TH.CylinderGeometry(.045,.055,1,7,1,true);c.translate(0,.5,0);
 var uv=c.attributes.uv;for(var i=0;i<uv.count;i++)uv.setY(i,uv.getY(i)*4);list.push(c.toNonIndexed());
 var gg=merge(list);return GEO.culm=gg;}
function leafClusterGeo(){if(GEO.leafc)return GEO.leafc;var TH=T(),list=[];for(var i=0;i<3;i++){var p=new TH.PlaneGeometry(1,1);p.rotateY(i*Math.PI/3);p.rotateZ((i-1)*.25);list.push(p.toNonIndexed());}var h=new TH.PlaneGeometry(1,1).rotateX(-Math.PI/2);list.push(h.toNonIndexed());return GEO.leafc=merge(list);}
function bambooFence(opts){
 opts=opts||{};var TH=T(),g=new TH.Group(),r=rng(opts.seed||11),A=opts.from||[-6,0],B=opts.to||[6,0],dx=B[0]-A[0],dz=B[1]-A[1],len=Math.hypot(dx,dz),ux=dx/len,uz=dz/len,nx=-uz,nz=ux,dep=opts.depth||1.2,dens=opts.density||7,hr=opts.height||[3.2,5.2];g.name='tea:bamboo';
 var n=Math.max(4,Math.round(len*dens*dep/1.2)),cm=sway(new TH.MeshStandardMaterial({map:bambooTex(),roughness:.55}),.006,1.1),lm=sway(new TH.MeshStandardMaterial({map:leafTex(),alphaTest:.45,side:TH.DoubleSide,roughness:.7,color:'#e8f0c0'}),.012,1.4);
 var cul=new TH.InstancedMesh(culmGeo(),cm,n),leafPer=4,lv=new TH.InstancedMesh(leafClusterGeo(),lm,n*leafPer),o=new TH.Object3D(),q=new TH.Object3D();cul.castShadow=true;lv.castShadow=true;lv.receiveShadow=true;
 var li=0;for(var i=0;i<n;i++){var t=r()*len,d=(r()-.5)*dep,x=A[0]+ux*t+nx*d,z=A[1]+uz*t+nz*d,H=hr[0]+r()*(hr[1]-hr[0]),lean=(r()-.5)*.12;
  o.position.set(x,0,z);o.rotation.set(lean,r()*6.28,(r()-.5)*.12);o.scale.set(1+r()*.3,H,1+r()*.3);o.updateMatrix();cul.setMatrixAt(i,o.matrix);
  for(var k=0;k<leafPer;k++){var hh=H*(.45+k*.16+r()*.08);q.position.set(x+Math.sin(lean)*hh*0+(r()-.5)*.3,hh,z+(r()-.5)*.3);q.rotation.set((r()-.5)*.5,r()*6.28,(r()-.5)*.5);q.scale.setScalar(.9+r()*.8+k*.15);q.updateMatrix();lv.setMatrixAt(li++,q.matrix);}}
 g.add(cul);g.add(lv);
 if(opts.fence!==false){var b=new Builder(),pole=V('#a8935a','satin'),rail=V('#8fa058','satin'),off=dep/2+.35,cx=(A[0]+B[0])/2+nx*off,cz=(A[1]+B[1])/2+nz*off,ang=Math.atan2(-uz,ux);
  for(var s=0;s<=len;s+=.18){var px=A[0]+ux*s+nx*off,pz=A[1]+uz*s+nz*off;b.add(geo('cyl8'),pole,px,.45,pz,0,0,0,.03,.9+(Math.round(s/.18)%2)*.08,.03);}
  [.25,.6,.82].forEach(function(y){b.add(geo('cyl8'),rail,cx,y,cz,0,ang,Math.PI/2,.025,len,.025);});
  // 绑绳
  for(var s2=0;s2<=len;s2+=.9){var px2=A[0]+ux*s2+nx*off,pz2=A[1]+uz*s2+nz*off;b.add(geo('torus'),V('#5a3a1e'),px2,.6,pz2,Math.PI/2,0,0,.05,.05,.3);}
  b.finish(g);}
 var bl=[{x:Math.min(A[0],B[0])-Math.abs(nx)*dep/2-.1,X:Math.max(A[0],B[0])+Math.abs(nx)*dep/2+.1,z:Math.min(A[1],B[1])-Math.abs(nz)*dep/2-.1,Z:Math.max(A[1],B[1])+Math.abs(nz)*dep/2+.1}];
 g.userData={kind:'bambooFence',count:n,blocks:bl};return g;
}

/* ======================= 6. 繁茂植物 / 小细节 ======================= */
/* plants({area:[x0,z0,x1,z1] 或 spots:[[x,z,r]], shrubs,flowers,tufts,moss,rocks,seed}) —— 每类一个 InstancedMesh */
function flowerGeo(){if(GEO.flower)return GEO.flower;var TH=T(),list=[];for(var i=0;i<5;i++){var p=new TH.SphereGeometry(.05,5,3);p.scale(1,.35,.6);p.translate(.05,0,0);p.rotateY(i*Math.PI*2/5);list.push(p.toNonIndexed());}var c=new TH.SphereGeometry(.025,5,3);c.translate(0,.012,0);list.push(c.toNonIndexed());var gg=merge(list);
 var col=new Float32Array(gg.attributes.position.count*3);var petalVerts=gg.attributes.position.count-new TH.SphereGeometry(.025,5,3).toNonIndexed().attributes.position.count;for(var j=0;j<gg.attributes.position.count;j++){var cc=j<petalVerts?[1,1,1]:[1,.78,.25];col[j*3]=cc[0];col[j*3+1]=cc[1];col[j*3+2]=cc[2];}gg.setAttribute('color',new TH.BufferAttribute(col,3));return GEO.flower=gg;}
function plants(opts){
 opts=opts||{};var TH=T(),g=new TH.Group(),r=rng(opts.seed||31),o=new TH.Object3D(),c=new TH.Color();g.name='tea:plants';
 var spots=opts.spots||[[0,0,2]];function pick(){var s=spots[(r()*spots.length)|0],a=r()*6.28,d=Math.sqrt(r())*s[2];return [s[0]+Math.cos(a)*d,s[1]+Math.sin(a)*d];}
 function im(gg,m,n,fn,cast){if(!n)return null;var mesh=new TH.InstancedMesh(gg,m,n);for(var i=0;i<n;i++){fn(i);o.updateMatrix();mesh.setMatrixAt(i,o.matrix);}mesh.castShadow=!!cast;mesh.receiveShadow=true;g.add(mesh);return mesh;}
 var nS=opts.shrubs==null?14:opts.shrubs,nF=opts.flowers==null?60:opts.flowers,nT=opts.tufts==null?40:opts.tufts,nM=opts.moss==null?8:opts.moss,nR=opts.rocks==null?5:opts.rocks;
 var bm=sway(new TH.MeshStandardMaterial({vertexColors:true,roughness:.8}),.03,1.2),sh=im(geo('bush'),bm,nS,function(){var p=pick(),s=.25+r()*.35;o.position.set(p[0],s*.55,p[1]);o.rotation.set(0,r()*6,0);o.scale.set(s*(1+r()*.3),s*(.8+r()*.4),s*(1+r()*.3));},true);
 if(sh){for(var i=0;i<nS;i++){c.setHSL(.24+r()*.08,.45+r()*.2,.42+r()*.12);sh.setColorAt(i,c);}}
 var FC=['#f6a6bf','#ffd34d','#ffffff','#e85a5a','#c79ef0','#ff9f5a'];
 var fm=new TH.MeshStandardMaterial({vertexColors:true,roughness:.6}),fl=im(flowerGeo(),fm,nF,function(){var p=pick(),s=.8+r()*.8;o.position.set(p[0],.12+r()*.22,p[1]);o.rotation.set((r()-.5)*.6,r()*6,(r()-.5)*.6);o.scale.setScalar(s);});
 if(fl){for(i=0;i<nF;i++){c.set(FC[(r()*FC.length)|0]);fl.setColorAt(i,c);}}
 // 花茎+草丛：交叉面片 alpha
 var tm=sway(new TH.MeshStandardMaterial({map:tuftTex(),alphaTest:.4,side:TH.DoubleSide,roughness:.8}),.08,1.6),tg=(function(){if(GEO.tuft)return GEO.tuft;var a=new TH.PlaneGeometry(1,1).translate(0,.5,0),b=a.clone().rotateY(Math.PI/2),d=a.clone().rotateY(Math.PI/4);return GEO.tuft=merge([a.toNonIndexed(),b.toNonIndexed(),d.toNonIndexed()]);})();
 im(tg,tm,nT,function(){var p=pick(),s=.3+r()*.35;o.position.set(p[0],0,p[1]);o.rotation.set(0,r()*6,0);o.scale.set(s,s*(.8+r()*.5),s);});
 var mm=real('moss',{worldUV:true});im(geo('disc'),mm,nM,function(){var p=pick();o.position.set(p[0],.008,p[1]);o.rotation.set(0,r()*6,0);o.scale.set(.3+r()*.5,1,.25+r()*.4);});
 var rk=real('bluestone',{tint:'#8a8f86'});im(geo('rock'),rk,nR,function(){var p=pick(),s=.18+r()*.3;o.position.set(p[0],s*.3,p[1]);o.rotation.set(r(),r()*6,r()*.3);o.scale.set(s*1.3,s*.75,s);},true);
 im(geo('rock'),mm,nR,function(){var p=pick(),s=.16+r()*.2;o.position.set(p[0],s*.42,p[1]);o.rotation.set(0,r()*6,0);o.scale.set(s*1.2,s*.25,s);});
 return g;
}
/* pottedPlant({kind:'bonsai'|'flower'|'bamboo',pot:'#2f5a7a'}) */
function pottedPlant(opts){
 opts=opts||{};var TH=T(),g=new TH.Group(),b=new Builder(),k=opts.kind||'flower';g.name='tea:pot';
 var pot=lathe([[0,0],[.16,0],[.2,.05],[.24,.32],[.27,.34],[.0,.34]],16);b.add(pot,ceramic(opts.pot||'#2f5a7a'),0,0,0);b.add(geo('disc'),real('soil'),0,.33,0,0,0,0,.23,1,.23);
 var bm=new TH.MeshStandardMaterial({vertexColors:true,roughness:.8});
 if(k==='bonsai'){b.add(geo('cyl8'),V('#5a3a22'),0,.55,0,0,0,.35,.04,.5,.04);b.add(geo('cyl8'),V('#5a3a22'),.12,.78,0,0,0,-.9,.025,.3,.025);[[-.12,.82,0,.22],[.26,.9,.02,.18],[.05,1.0,-.05,.2]].forEach(function(p){b.add(geo('bush'),bm,p[0],p[1],p[2],0,0,0,p[3],p[3]*.55,p[3]);});}
 else if(k==='bamboo'){for(var i=0;i<5;i++){b.add(geo('cyl8'),V('#7aa046','satin'),(i-2)*.05,.34+.45,((i%2)-.5)*.06,0,0,(i-2)*.06,.012,.9+i*.05,.012);b.add(geo('bush'),bm,(i-2)*.07,1.2+i*.04,0,0,0,0,.12,.08,.1);}}
 else{b.add(geo('bush'),bm,0,.5,0,0,0,0,.28,.22,.28);var FC=['#f6a6bf','#ffd34d','#e85a5a'];for(var j=0;j<9;j++){var a=j*2.4;b.add(geo('sph'),V(FC[j%3],'satin'),Math.cos(a)*.2,.58+(j%3)*.04,Math.sin(a)*.2,0,0,0,.05);}}
 b.finish(g);g.userData={kind:'pot',blocks:[{x:-.3,X:.3,z:-.3,Z:.3}]};return g;
}
/* osmanthusTree({height:4.2,foliage:'#d98b2b'}) —— 院中主景树：枝干 + 团簇树冠（顶点色），金桂/红枫暖色 */
function osmanthusTree(opts){
 opts=opts||{};var TH=T(),g=new TH.Group(),b=new Builder(),H=opts.height||4.2,r=rng(opts.seed||5),bark=V('#5b3b26');g.name='tea:tree';
 var trunk=lathe([[0,0],[.32,0],[.24,.2],[.2,.6],[.17,1.4],[.14,H*.55],[0,H*.55]],10);b.add(trunk,bark,0,0,0);
 for(var i=0;i<5;i++){var a=i*1.26+r(),L=1+r()*.8;b.add(geo('cyl8'),bark,Math.cos(a)*L*.35,H*.5+L*.3,Math.sin(a)*L*.35,Math.sin(a)*.9,0,-Math.cos(a)*.9,.07,L,.07);}
 var fg=shade(jitter(new TH.IcosahedronGeometry(1,2),.16,13),'#2f5a1e','#9cc04a'),fc=new TH.Color(opts.foliage||'#5f8f2a'),fh=new TH.Color(opts.blossom||'#f2c14e'),col=fg.attributes.color;
 for(var k=0;k<col.count;k++){var t=col.getY(k);var cc=new TH.Color(col.getX(k),col.getY(k),col.getZ(k)).lerp(fc,.5);col.setXYZ(k,cc.r,cc.g,cc.b);}
 var fm=sway(new TH.MeshStandardMaterial({vertexColors:true,roughness:.85}),.01,.9);
 for(i=0;i<9;i++){var a2=r()*6.28,d=r()*1.3,s=.75+r()*.6;b.add(fg,fm,Math.cos(a2)*d,H*.62+r()*H*.3,Math.sin(a2)*d,0,r()*6,0,s,s*.75,s);}
 b.finish(g);
 // 树冠外层叶片卡（alpha），打破低模轮廓
 var lc=new TH.InstancedMesh(leafClusterGeo(),sway(new TH.MeshStandardMaterial({map:leafTex(),alphaTest:.45,side:TH.DoubleSide,roughness:.7,color:opts.foliage||'#cfe09a'}),.01,1.1),70),o0=new TH.Object3D();
 for(var q=0;q<70;q++){var aa=r()*6.28,dd=.9+r()*1.2,yy=H*.6+r()*H*.42;o0.position.set(Math.cos(aa)*dd,yy,Math.sin(aa)*dd);o0.rotation.set(r()*.6,r()*6.28,r()*.6);o0.scale.setScalar(.7+r()*.6);o0.updateMatrix();lc.setMatrixAt(q,o0.matrix);}lc.castShadow=true;g.add(lc);
 // 桂花小点（instanced）
 var bn=60,bl=new TH.InstancedMesh(new TH.IcosahedronGeometry(.04,0),new TH.MeshStandardMaterial({color:fh,emissive:fh,emissiveIntensity:.25,roughness:.6}),bn),o=new TH.Object3D();
 for(i=0;i<bn;i++){var a3=r()*6.28,d2=.6+r()*1.4;o.position.set(Math.cos(a3)*d2,H*.6+r()*H*.38,Math.sin(a3)*d2);o.scale.setScalar(.7+r());o.updateMatrix();bl.setMatrixAt(i,o.matrix);}g.add(bl);
 // 树下落花（instanced flat）
 var pn=40,pm=new TH.InstancedMesh(new TH.CircleGeometry(.03,5).rotateX(-Math.PI/2),new TH.MeshStandardMaterial({color:fh,roughness:.8}),pn);for(i=0;i<pn;i++){var a4=r()*6.28,d3=r()*2;o.position.set(Math.cos(a4)*d3,.012,Math.sin(a4)*d3);o.scale.setScalar(.7+r());o.updateMatrix();pm.setMatrixAt(i,o.matrix);}pm.receiveShadow=true;g.add(pm);
 g.userData={kind:'tree',blocks:[{x:-.4,X:.4,z:-.4,Z:.4}]};return g;
}
/* stoneLantern() —— 石灯笼，暖光窗（emissive，无实时光源） */
function stoneLantern(opts){
 opts=opts||{};var TH=T(),g=new TH.Group(),b=new Builder(),st=real('bluestone',{tint:'#8e928a'});g.name='tea:stoneLantern';
 b.add(geo('box'),st,0,.08,0,0,0,0,.5,.16,.5);b.add(geo('cyl8'),st,0,.5,0,0,0,0,.09,.7,.09);b.add(geo('box'),st,0,.9,0,0,0,0,.42,.1,.42);
 b.add(geo('box'),st,0,1.1,0,0,0,0,.34,.3,.34);b.add(geo('cone'),real('roofTile',{tint:'#62686a'}),0,1.38,0,0,Math.PI/4,0,.42,.26,.42);b.add(geo('sph'),st,0,1.53,0,0,0,0,.06);
 b.add(geo('rock'),real('moss'),.05,.17,.05,0,0,0,.26,.05,.22);
 b.finish(g);
 var win=new TH.Mesh(new TH.BoxGeometry(.36,.18,.36),new TH.MeshBasicMaterial({color:'#ffcf7a',toneMapped:false}));win.position.y=1.1;g.add(win);
 g.userData={kind:'stoneLantern',blocks:[{x:-.28,X:.28,z:-.28,Z:.28}]};return g;
}

/* 地面层高（避免与游戏 floor 顶面 y=0 z-fight）：草地 .012，花圃泥土 .022，石板 .024，砖边 .06，草席 .034 */
/* ======================= 7. 整个样板院子 ======================= */
/* buildCourtyard({width:24,depth:20,messages:[...],tables:3,seed,ground:true}) → {group,update,dispose,blocks,interact,wall,river,parts}
 * 坐标：院子中心为原点，+X 东，-Z 北。竹林围北/西/南三面，东侧留出入口；小河在南侧；留言墙靠北；茶席居中；棋桌在东北；主景桂花树在西北。 */
function buildCourtyard(opts){
 opts=opts||{};var TH=T(),g=new TH.Group(),W=opts.width||24,D=opts.depth||20,parts={},blocks=[],interact=[];g.name='tea:courtyard';
 function add(o,x,z,ry){o.position.set(x,0,z);o.rotation.y=ry||0;g.add(o);var u=o.userData||{};(u.blocks||[]).forEach(function(b){blocks.push(rot(b,x,z,ry||0));});if(u.interact)interact.push({x:x+u.interact.x,z:z+u.interact.z,label:u.interact.label,kind:u.kind});return o;}
 function rot(b,x,z,ry){var q=Math.round((ry||0)/(Math.PI/2))&3,c=[[b.x,b.z],[b.X,b.Z]].map(function(p){var px=p[0],pz=p[1];for(var i=0;i<q;i++){var t=px;px=pz;pz=-t;}return [px+x,pz+z];});return {x:Math.min(c[0][0],c[1][0]),X:Math.max(c[0][0],c[1][0]),z:Math.min(c[0][1],c[1][1]),Z:Math.max(c[0][1],c[1][1])};}
 if(opts.ground!==false){var gb=new Builder();
  // 草地挖出河道：河 x∈[rx0,rx1], z∈[rz0,rz1]
  var rL=W*.62,rcx=-W*.05,rcz=D/2-2.6,rx0=rcx-rL/2,rx1=rcx+rL/2,rz0=rcz-.9,rz1=rcz+.9;
  gb.add(geo('box'),real('grass'),0,-.088,(-D/2+rz0)/2,0,0,0,W,.2,rz0+D/2);gb.add(geo('box'),real('grass'),0,-.088,(rz1+D/2)/2,0,0,0,W,.2,D/2-rz1);
  gb.add(geo('box'),real('grass'),(-W/2+rx0)/2,-.088,rcz,0,0,0,rx0+W/2,.2,1.8);gb.add(geo('box'),real('grass'),(rx1+W/2)/2,-.088,rcz,0,0,0,W/2-rx1,.2,1.8);
  gb.add(geo('box'),real('bluestone'),0,-.076,-1,0,0,0,W*.55,.2,D*.48);// 中央石板院（顶面 y=.01）
  gb.add(geo('box'),real('bluestone',{tint:'#9a9888'}),W*.32,-.08,1.2,0,0,0,W*.36,.2,1.4);// 东入口小径
  [[-W*.36,-D*.05,2.2,3.2],[W*.25,D*.12,2.6,1.6]].forEach(function(f){gb.add(geo('box'),real('soil'),f[0],-.078,f[1],0,0,0,f[2],.2,f[3]);});// 花圃泥土
  // 石板边缘：青砖镶边
  [[0,-1-D*.24,W*.55+.2,.25],[0,-1+D*.24,W*.55+.2,.25]].forEach(function(e){gb.add(geo('box'),real('brick'),e[0],-.02,e[1],0,0,0,e[2],.16,e[3]);});
  [[-W*.275,-1,.25,D*.48],[W*.275,-1,.25,D*.48]].forEach(function(e){gb.add(geo('box'),real('brick'),e[0],-.02,e[1],0,0,0,e[2],.16,e[3]);});
  var gm=new TH.Group();gm.name='tea:ground';gb.finish(gm,{cast:false});g.add(gm);parts.ground=gm;}
 // 竹林三面
 parts.bamboo=[bambooFence({from:[-W/2+.8,-D/2+.8],to:[W/2-.8,-D/2+.8],seed:11,depth:1.4}),bambooFence({from:[-W/2+.8,D/2-.8],to:[-W/2+.8,-D/2+.8],seed:12,depth:1.4}),bambooFence({from:[W/2-4.5,D/2-.6],to:[-W/2+.8,D/2-.6],seed:13,depth:1.0,height:[2.6,4.2]})];
 parts.bamboo.forEach(function(b){add(b,0,0,0);});
 // 河灯：南侧
 parts.river=add(riverLanterns({length:W*.62,width:1.8,count:opts.lanterns||9,seed:7}),-W*.05,D/2-2.6,0);
 // 小石桥
 var br=new Builder(),bs=real('bluestone',{tint:'#9a9a90'});br.add(geo('box'),bs,0,.12,0,0,0,0,1.2,.14,2.6);[-1,1].forEach(function(s){br.add(geo('box'),bs,s*.56,.32,0,0,0,0,.08,.3,2.4);});br.add(geo('box'),real('moss'),.3,.2,.8,0,0,0,.4,.02,.5);
 var bridge=new TH.Group();bridge.name='tea:bridge';br.finish(bridge);add(bridge,W*.18,D/2-2.6,0);parts.bridge=bridge;
 // 留言墙：北侧居中，面向南（+Z）
 parts.wall=add(messageWall({messages:opts.messages||[{text:'愿家人平安喜乐',author:'来福',style:'red'},{text:'今天采了三斤茶，手上还是香的',author:'小禾',style:'wood'},{text:'荷塘的锦鲤又胖了一圈',author:'阿竹',style:'jade'},{text:'明天下午再来坐坐',author:'过路人',style:'paper'},{text:'明晚七点，石棋桌下一局？',author:'松奕',style:'wood'},{text:'茶会小院开张啦',author:'福缘里',style:'red'}]}),0,-D/2+2.6,0);
 // 茶席：中央 3 席（一席高桌）
 var tables=[[-3.2,-1.4,0,'low','#3e5f7a'],[1.6,-2.2,.35,'low','#8a4a3a'],[-0.8,1.9,-.2,'high','#5d7a4a']].slice(0,opts.tables||3);
 parts.tables=tables.map(function(t){return add(teaTable({style:t[3],cushion:t[4]}),t[0],t[1],t[2]);});
 // 石棋桌：东北
 parts.chess=add(chessTable(),W*.2,-D*.06,0);
 // 主景树 + 石灯笼 + 盆栽
 parts.tree=add(osmanthusTree({seed:5}),-W*.34,-D*.18,0);
 var lp=[[-W*.26,-D*.24+.3],[W*.26,-D*.24+.3],[W*.27,D*.21],[-W*.14,D*.21]];// 石灯笼用 instancing：4 盏只占 4 个 draw call
 parts.lanterns=instance(stoneLantern(),lp.map(function(p){return [p[0],0,p[1],0,1];}),g);lp.forEach(function(p){blocks.push({x:p[0]-.28,X:p[0]+.28,z:p[1]-.28,Z:p[1]+.28});});
 parts.pots=[[-2.6,-D/2+2.8,'bonsai','#6b3a2a'],[2.6,-D/2+2.8,'bamboo','#2f5a7a'],[4.1,.6,'flower','#c9a24a'],[-5.6,1.4,'flower','#2f5a7a']].map(function(p){return add(pottedPlant({kind:p[2],pot:p[3]}),p[0],p[1],0);});
 // 植物：沿竹林根部、花圃、河岸、树下
 parts.plants=add(plants({seed:31,spots:[[-W*.36,-D*.05,1.6],[W*.25,D*.12,1.4],[-W/2+2.2,0,2.4],[0,-D/2+2.2,3],[W*.35,-D*.35,1.6],[-W*.3,D/2-1.2,2],[W*.38,D/2-1.4,1.4],[-W*.34,-D*.18,1.8]],shrubs:opts.lite?14:26,flowers:opts.lite?60:140,tufts:opts.lite?40:110,moss:16,rocks:9}),0,0,0);
 var live=[];g.traverse(function(o){if(o.userData&&typeof o.userData.update==='function')live.push(o);});
 var api={group:g,parts:parts,blocks:blocks,interact:interact,wall:parts.wall.userData.api,river:parts.river.userData,
  update:function(dt){for(var i=0;i<live.length;i++)live[i].userData.update(dt,TIME.value);},
  dispose:function(){disposeObject(g);LIVE.delete(g);}};
 g.userData.tea=api;return api;
}
function disposeObject(root){if(!root)return;root.parent&&root.parent.remove(root);root.traverse(function(o){if(o.isMesh||o.isSprite){LIVE.delete(o);if(o.geometry&&!isShared(o.geometry))o.geometry.dispose();if(o.isInstancedMesh)o.dispose&&o.dispose();}LIVE.delete(o);});}
function isShared(gg){for(var k in GEO)if(GEO[k]===gg)return true;return false;}

/* 全局 update：推进摇曳/蒸汽/河灯；如需水面流动请同时调用 TG_REAL.update(dt)（或用 TG_REAL.install 自动挂 tgAnimate） */
function update(dt){dt=Math.min(dt||0,.1);TIME.value+=dt;LIVE.forEach(function(o){if(o.userData&&o.userData.update)o.userData.update(dt,TIME.value);});}
function stats(root){var s={meshes:0,instanced:0,instances:0,triangles:0,materials:new Set()};root.traverse(function(o){if(!o.isMesh)return;s.meshes++;var g2=o.geometry,tri=(g2.index?g2.index.count:g2.attributes.position.count)/3,cnt=o.isInstancedMesh?o.count:1;if(o.isInstancedMesh){s.instanced++;s.instances+=cnt;}s.triangles+=tri*cnt;s.materials.add(o.material.uuid);});s.materials=s.materials.size;return s;}
function dispose(){LIVE.clear();for(var k in GEO){GEO[k].dispose();delete GEO[k];}for(k in MAT){MAT[k].dispose();delete MAT[k];}for(k in TEX){TEX[k].dispose();delete TEX[k];}}

var API=G.TG_TEA={version:'r6-tea-1',forceFallback:false,
 teaTable:teaTable,messageWall:messageWall,chessTable:chessTable,riverLanterns:riverLanterns,bambooFence:bambooFence,
 plants:plants,pottedPlant:pottedPlant,osmanthusTree:osmanthusTree,stoneLantern:stoneLantern,
 buildCourtyard:buildCourtyard,update:update,stats:stats,disposeObject:disposeObject,dispose:dispose,instance:instance,time:TIME};
})();
