/* r8 shared scene safety. r8a owns plaza + gate; later batches extend this file. */
(()=>{'use strict';
const T=THREE;
const changes=[];
const indoor=n=>['hall','zen','study'].includes(n);
function visible(m,root){for(let p=m;p&&p!==root;p=p.parent)if(!p.visible)return false;return true;}
function cameraMeshes(s){const out=[];s.group.traverseVisible(m=>{
 if(!m.isMesh||m.isSprite||m.name==='r7b-solid-bark'||m.material?.visible===false||m.material?.opacity===0)return;
 for(let p=m;p&&p!==s.group;p=p.parent){const u=p.userData||{};if(u.wallSign||u.r41Label||u.r7Particle||u.r7TreeSoft||u.r6Mount||u.r6Ride||u.r6Passenger||p.name==='r7f-wish-tags'||p.name==='r8a-distance')return;}
 if(m.material?.transparent&&m.material.opacity<.8)return;
 out.push(m);
 });return out;}
const ray=new T.Raycaster();
function firstHit(s,from,to,noTrunk){
 const d=to.clone().sub(from),len=d.length();if(len<.001)return null;
 ray.set(from,d.multiplyScalar(1/len));ray.near=.06;ray.far=len;ray.camera=W3.camera;
 const meshes=cameraMeshes(s);
 const far=(h,d)=>!h.object.userData.r8cNoCam||d>=1.6; // r8c: indoor furniture only pushes the eye in when it is well away from the player (never crowds the head)
 let hit=ray.intersectObjects(meshes,false).find(h=>h.point.y>.28&&h.distance>.06&&far(h,h.distance));
 // Thin roof undersides may use BackSide materials. Test both directions so
 // collision never depends on which side of a slab the camera approaches.
 ray.set(to,d.clone().negate());ray.near=.01;ray.far=len;
 const back=ray.intersectObjects(meshes,false).filter(h=>h.point.y>.28&&len-h.distance>.06&&far(h,len-h.distance)).sort((a,b)=>b.distance-a.distance)[0];
 if(back&&(!hit||len-back.distance<hit.distance))hit={...back,distance:len-back.distance};
 ray.set(from,d);ray.near=.06;ray.far=len;
 for(const row of s.r8CameraBoxes||[]){if(!visible(row.mesh,s.group))continue;const v=ray.ray.intersectBox(row.box,new T.Vector3());if(v){const distance=v.distanceTo(from);if(distance>.06&&distance<len&&(!hit||distance<hit.distance))hit={distance,point:v,object:row.mesh};}}
 if(W3.active==='plaza'&&!noTrunk){
 const b=new T.Box3(new T.Vector3(-1.15,0,-1.15),new T.Vector3(1.15,9.2,1.15)),v=ray.ray.intersectBox(b,new T.Vector3());
 if(v){const distance=v.distanceTo(from);if(distance< len&&(!hit||distance<hit.distance))hit={distance,point:v,object:{name:'r8-trunk'}};}
 }return hit;
}
let state=null,entry=null;
const camera=worldCamera;
worldCamera=function(a){
 const w=W3;if(!w?.active)return camera.apply(this,arguments);
 if(w.active==='plaza'&&!w.r6Plan&&!r6IsRiding()){
 const p=w.player.position,dx=Math.abs(p.x-18),dz=Math.abs(p.z-3);
 const edge=T.MathUtils.clamp((1.55-dx)/.35,0,1)*T.MathUtils.clamp((1.2-dz)/.3,0,1),height=(.19+.14*Math.cos(Math.min(1,dx/1.08)*Math.PI/2))*edge;
 p.y+=(height-p.y)*(a===1?1:1-Math.exp(-(w.r8CameraDt||.016)*14));
 }
 const old=w.camera.position.clone();camera.apply(this,arguments);
 if(S.view==='fp'||w.r6Plan){state=null;return;}
 const s=w.spaces[w.active],origin=w.player.position.clone().add(new T.Vector3(0,1.4,0));
 let goal=w.camera.position.clone(),quat=w.camera.quaternion.clone();
 if(entry&&w.player.position.distanceTo(entry.position)>.12)entry=null;
 if(w.active==='plaza'||w.active==='gate'){const r=w.radius,cp=Math.cos(w.pitch);goal.copy(origin).add(new T.Vector3(Math.sin(w.yaw)*r*cp,Math.sin(w.pitch)*r,Math.cos(w.yaw)*r*cp));w.camera.position.copy(goal);w.camera.lookAt(origin);quat.copy(w.camera.quaternion);}

 if(indoor(w.active)){
 goal.x=T.MathUtils.clamp(goal.x,-s.limit.x+.55,s.limit.x-.55);
 goal.z=T.MathUtils.clamp(goal.z,-s.limit.z+.55,s.limit.z-.55);
 goal.y=T.MathUtils.clamp(goal.y,1.55,w.active==='hall'?4.85:3.85);
 }
 // r8a: near walls/hedges, tilt the boom up (over the obstacle) before pulling it in, so the camera
 // never collapses into the player's back. Re-evaluated at ~8 Hz, eased so it never pops.
 if(!indoor(w.active)){
  const dt0=w.r8CameraDt||.016,dir=goal.clone().sub(origin),r=dir.length(),hz=Math.hypot(dir.x,dir.z);
  if(r>.5&&hz>.05){const p0=Math.atan2(dir.y,hz),ux=dir.x/hz,uz=dir.z/hz,at=p=>origin.clone().add(new T.Vector3(ux*Math.cos(p)*r,Math.sin(p)*r,uz*Math.cos(p)*r));
   const PMAX=1.5,want=Math.min(r*.8,6);w.r8BoostT=(w.r8BoostT||0)-dt0;
   if(a===1||w.r8BoostT<=0||w.r8BoostScene!==w.active){w.r8BoostT=.12;w.r8BoostScene=w.active;let need=0;
    const h0=firstHit(s,origin,goal,true); /* r8a.2: the old tree's trunk is handled by pulling in, never by tilting over it (that crept to top-down on an 18 m boom) */
    if(h0&&h0.distance<want){let best=0,bestD=h0.distance,clear=false,dTop=0;for(let k=1;k<=8;k++){const p=Math.min(PMAX,p0+k*.16),h=firstHit(s,origin,at(p),true),d=h?h.distance:r;if(!h||d>=want){need=p-p0;clear=true;break;}if(d>bestD+.25){bestD=d;best=p-p0;}if(p>=PMAX){dTop=d;break;}}
     if(!clear)need=dTop>=1.6?PMAX-p0:best; /* nothing clears (canopy overhead, tight corner): take the tilt with the longest free boom */}
    w.r8BoostNeed=need;}
   const need=w.r8BoostNeed||0;w.r8Boost=a===1?need:(w.r8Boost||0)+(need-(w.r8Boost||0))*(1-Math.exp(-dt0*(need>(w.r8Boost||0)?6:2.5)));
   if(w.r8Boost>.005){goal.copy(at(Math.min(1.5,p0+w.r8Boost)));w.camera.position.copy(goal);w.camera.lookAt(origin);quat.copy(w.camera.quaternion);}
  }
 }
 // keep the eye inside the scene's enclosure (it could drift over the wall into the distant tree belts)
 if(!indoor(w.active)){const L=w.active==='plaza'?24.4:w.active==='gate'?16.2:null;if(L){const gx=goal.x,gz=goal.z;goal.x=T.MathUtils.clamp(goal.x,-L,L);goal.z=T.MathUtils.clamp(goal.z,-L,L);if(gx!==goal.x||gz!==goal.z)w.r8Clamped=true;else w.r8Clamped=false;}}
 const hit=firstHit(s,origin,goal);
 if(hit){const boom=goal.clone().sub(origin).normalize();goal.copy(origin).addScaledVector(boom,Math.max(.12,hit.distance-.32));}
 const now=performance.now(),reset=!state||state.scene!==w.active||a===1;
 if(reset){state={scene:w.active,time:now,position:goal.clone(),goal:goal.clone(),quaternion:quat.clone()};}
 else{
 const dt=w.r8CameraDt||Math.min(.05,Math.max(.001,(now-state.time)/1000));state.time=now;
 // Hold sub-centimetre changes; retract faster than extension. Resolve the
 // interpolated boom too, so damping cannot carry the eye through a wall.
 if(goal.distanceTo(state.goal)>.035)state.goal.copy(goal);
 let retract=goal.distanceTo(origin)<state.position.distanceTo(origin);
 // r8d: after a retract, hold extension for 0.35 s (kills in/out pumping on flickering hits, e.g. tea)
 if(retract)state.holdUntil=now+350;else if(now<(state.holdUntil||0)){const dg=goal.distanceTo(origin),dp=state.position.distanceTo(origin);if(dg>dp)state.goal.copy(origin).addScaledVector(goal.clone().sub(origin).normalize(),dp);}
 const previous=state.position.clone(),next=previous.clone().lerp(state.goal,1-Math.exp(-dt*(retract?14:7)));
 const travel=next.clone().sub(previous),cap=18*dt;if(travel.length()>cap)next.copy(previous).addScaledVector(travel.normalize(),cap);
 const h=firstHit(s,origin,next);
 if(h){
 const oldHit=firstHit(s,origin,previous);
 if(!oldHit){const boom=previous.clone().sub(origin),len=boom.length();next.copy(origin).addScaledVector(boom.normalize(),Math.max(.12,len-cap));}
 else {const boom=next.clone().sub(origin).normalize();next.copy(origin).addScaledVector(boom,Math.max(.12,h.distance-.32));}
 }
 // r8a.2: collision pull-in is rate-limited too — hard cap on the eye's travel per frame (no snapping to a hit point)
 {const mv=next.clone().sub(previous),HC=Math.max(.16,13*dt);if(mv.length()>HC)next.copy(previous).addScaledVector(mv.normalize(),HC);} // r8d: ≤13 m/s (was 0.7 m/frame)
 state.position.copy(next);
 }
 // Keep the near plane out of walls: if anything is within 0.3 m sideways/up/down, nudge away.
 if(hit||state.pushed||indoor(w.active)){let push=new T.Vector3();const ms=cameraMeshes(s);state.pushed=false;
  for(const d of [[1,0,0],[-1,0,0],[0,0,1],[0,0,-1],[0,1,0],[0,-1,0]]){const dir=new T.Vector3(...d);ray.set(state.position,dir);ray.near=0;ray.far=.3;const h=ray.intersectObjects(ms,false)[0];if(h){push.addScaledVector(dir,-(.3-h.distance));state.pushed=true;}}
  if(push.lengthSq()>1e-6){const cand=state.position.clone().add(push);if(!firstHit(s,origin,cand))state.position.copy(cand);}}
 w.camera.position.copy(state.position);
 if(hit||indoor(w.active)||!entry||w.r8Clamped||w.r8Boost>.005){w.camera.lookAt(origin);quat.copy(w.camera.quaternion);}
 if(reset)state.quaternion.copy(quat);else{const dq=w.r8CameraDt||.016,tq=state.quaternion.clone().slerp(quat,1-Math.exp(-dq*10));state.quaternion.rotateTowards(tq,(230*Math.PI/180)*dq);} // r8d: ≤230°/s
 w.camera.quaternion.copy(state.quaternion);
 w.camera.updateMatrixWorld();fadeCanopy(w.r8CameraDt||.016,reset);fadeSigns(s,origin,w.r8CameraDt||.016,reset);
 w.r8Camera={desired:goal.toArray(),hit:hit?.object.name||null,delta:w.camera.position.distanceTo(old)};
};
// Hanging signboards never collide with the camera; when one sits between the eye and the player it fades.
const signRay=new T.Raycaster();
function fadeSigns(s,head,dt,snap){const c=W3.camera.position,d=head.clone().sub(c),len=d.length();if(len<.01)return;
 if(snap||!s.r8Signs||performance.now()-(s.r8SignsAt||0)>2000){s.r8Signs=null;s.r8SignsAt=performance.now();} // labels can be added after entry (stall signs, wish tags)
 const signs=s.r8Signs||(s.r8Signs=(()=>{const o=[];s.group.traverse(m=>{if(m.isMesh&&(m.userData.wallSign||m.userData.r8cFade)&&m.material)o.push(m);});return o;})());if(!signs.length)return;
 const hits=new Set();for(const dy of [0,-.6,-1.3]){const t=head.clone();t.y+=dy;const dd=t.sub(c),l=dd.length();signRay.set(c,dd.multiplyScalar(1/l));signRay.far=l;for(const h of signRay.intersectObjects(signs,false))hits.add(h.object);}
 const now=performance.now(),rdt=Math.min(.1,Math.max(dt,(now-(s.r8SignT||now))/1000));s.r8SignT=now;const k=snap?1:1-Math.exp(-rdt*14);
 for(const m of signs){const target=hits.has(m)?.2:1,cur=m.userData.r8SignFade??1,next=cur+(target-cur)*k;m.userData.r8SignFade=next;
  if(next<.995){m.material.transparent=true;m.material.depthWrite=false;m.material.opacity=next;}else if(m.material.transparent&&m.userData.r8SignFade!==undefined){m.material.opacity=1;m.material.transparent=false;m.material.depthWrite=true;}}
}
let soft=[],fade=1;
function prepareCanopy(){
 const tree=W3.spaces.plaza.group.getObjectByName('r7-wish-tree');if(!tree)return;
 const bark=tree.getObjectByName('r7b-solid-bark');
 if(bark&&!tree.getObjectByName('r8a-soft-branches')){
 const g=bark.geometry,p=g.attributes.position,branch=new Set();
 for(const ids of components(g)){let low=Infinity;for(const i of ids)low=Math.min(low,p.getY(i));if(low>3)ids.forEach(i=>branch.add(i));}
 const ix=g.index,solid=[],softIx=[];for(let i=0;i<(ix?ix.count:p.count);i+=3){const a=ix?ix.getX(i):i,dst=branch.has(a)?softIx:solid;dst.push(a,ix?ix.getX(i+1):i+1,ix?ix.getX(i+2):i+2);}
 bark.geometry=g.clone();bark.geometry.setIndex(solid);const upper=new T.Mesh(g.clone(),bark.material.clone());upper.geometry.setIndex(softIx);upper.name='r8a-soft-branches';upper.userData.r7TreeSoft=true;tree.add(upper);
 }

 tree.traverse(m=>{if(!m.isMesh||m.name==='r7b-solid-bark')return;
 m.material=m.material.clone();m.material.transparent=true;m.material.depthWrite=false;
 m.userData.r8Opacity=m.material.opacity;soft.push(m);
 });
 const tags=W3.spaces.plaza.group.getObjectByName('r7f-wish-tags');tags?.traverse(m=>{if(m.isMesh){m.material=m.material.clone();m.material.transparent=true;m.material.depthWrite=false;m.userData.r8Opacity=m.material.opacity;soft.push(m)}});
}
function fadeCanopy(dt,snap){
 if(W3.active!=='plaza'||!soft.length)return;
 const c=W3.camera.position,p=W3.player.position;
 // Canopy envelope is only an occlusion/fade volume, never a camera collider.
 const b=new T.Box3(new T.Vector3(-7.5,6,-7.5),new T.Vector3(7.5,11.3,7.5));
 const head=p.clone().add(new T.Vector3(0,1.4,0)),d=c.clone().sub(head),len=d.length();
 const rr=new T.Ray(head,d.normalize()),v=rr.intersectBox(b,new T.Vector3());
 const covered=v&&v.distanceTo(head)<len+.2;
 const inside=b.clone().expandByScalar(.6).containsPoint(c); // eye inside the crown: near-invisible, so branches never fill the frame
 {const tgt=inside?.05:covered?.16:1;fade=snap?tgt:fade+(tgt-fade)*(1-Math.exp(-Math.min(dt,.05)*7));} // snap on a camera reset (scene entry) so a spawn view is never blocked for the first frames
 for(const m of soft){if(m.material!==m.userData.r8Mat){/* realism.js may swap materials after init */m.material=m.material.clone();m.material.transparent=true;m.material.depthWrite=false;m.userData.r8Mat=m.material;}m.material.opacity=m.userData.r8Opacity*fade;}
 W3.r8CanopyOpacity=fade;
}
// Connected triangle components retain merged draw calls while allowing a
// complete source prop to move. Welding also handles non-indexed baked boxes.
const pieces=new WeakMap();
function components(g){
 if(pieces.has(g))return pieces.get(g);
 const p=g.attributes.position,ix=g.index,uf=Array.from({length:p.count},(_,i)=>i),weld=new Map();
 function find(i){while(uf[i]!==i){uf[i]=uf[uf[i]];i=uf[i]}return i;}
 function join(a,b){a=find(a);b=find(b);if(a!==b)uf[b]=a;}
 for(let i=0;i<p.count;i++){const k=[p.getX(i),p.getY(i),p.getZ(i)].map(n=>Math.round(n*10000)).join(',');if(weld.has(k))join(i,weld.get(k));else weld.set(k,i);}
 for(let i=0;i<(ix?ix.count:p.count);i+=3){const a=ix?ix.getX(i):i;join(a,ix?ix.getX(i+1):i+1);join(a,ix?ix.getX(i+2):i+2);}
 const groups=new Map();for(let i=0;i<p.count;i++){const k=find(i);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(i);}
 const out=[...groups.values()];pieces.set(g,out);return out;
}
function relocate(root,ox,oz,nx,nz,rad){
 root.updateMatrixWorld(true);const delta=new T.Vector3(nx-ox,0,nz-oz),v=new T.Vector3(),box=new T.Box3(),mat=new T.Matrix4();
 root.traverse(m=>{
 if(!m.isMesh&&!m.isSprite)return;
 for(let p=m;p&&p!==root;p=p.parent)if(['r7-wish-tree','r7f-wish-tags','r7f-flower-bed','r7b-wish-rack','r8a-stalls','r7d-tree-ring','r7e-gardener','r8a-distance'].includes(p.name))return;
 if(m.isInstancedMesh){let changed=false;
 for(let i=0;i<m.count;i++){m.getMatrixAt(i,mat);v.setFromMatrixPosition(mat).applyMatrix4(m.matrixWorld);if(Math.hypot(v.x-ox,v.z-oz)>rad)continue;
 const local=delta.clone().transformDirection(m.matrixWorld.clone().invert()).multiplyScalar(delta.length());mat.elements[12]+=local.x;mat.elements[13]+=local.y;mat.elements[14]+=local.z;m.setMatrixAt(i,mat);changed=true;}
 if(changed){m.instanceMatrix.needsUpdate=true;m.computeBoundingSphere?.();m.computeBoundingBox?.();}return;}
 if(m.isSprite){m.getWorldPosition(v);if(Math.hypot(v.x-ox,v.z-oz)<rad)m.position.add(delta);return;}
 const g=m.geometry,p=g.attributes.position;let dirty=false;
 for(const ids of components(g)){box.makeEmpty();for(const i of ids)box.expandByPoint(v.fromBufferAttribute(p,i).applyMatrix4(m.matrixWorld));box.getCenter(v);
 if(Math.hypot(v.x-ox,v.z-oz)>rad)continue;
 // Long floors, walls and axial paths are never cluster furnishings.
 const size=box.getSize(new T.Vector3());if(Math.max(size.x,size.z)>rad*3+1)continue;
 const inv=m.matrixWorld.clone().invert(),a=delta.clone().applyMatrix4(inv).sub(new T.Vector3().applyMatrix4(inv));
 if(!dirty){m.geometry=g.clone();}const dst=m.geometry.attributes.position;
 for(const i of ids)dst.setXYZ(i,p.getX(i)+a.x,p.getY(i)+a.y,p.getZ(i)+a.z);dirty=true;
 }
 if(dirty){m.geometry.attributes.position.needsUpdate=true;m.geometry.computeBoundingBox();m.geometry.computeBoundingSphere();pieces.set(m.geometry,components(g));}
 });
}

// r8a: quiet, inhabited horizons. One coloured surface, one mist layer and
// one sky draw per outdoor scene; distant pieces never enter walk bounds.
function baked(group,name,parts,opacity){
 const geos=[],colors=[];for(const p of parts){let g=p.geo.index?p.geo.toNonIndexed():p.geo.clone();const o=new T.Object3D();o.position.set(...p.at);o.scale.set(...(p.scale||[1,1,1]));o.rotation.set(...(p.rot||[0,0,0]),p.order||'XYZ');o.updateMatrix();g.applyMatrix4(p.mat?p.mat.clone().multiply(o.matrix):o.matrix);const c=new T.Color(p.color);for(let i=0;i<g.attributes.position.count;i++)colors.push(c.r,c.g,c.b);geos.push(g);}
 const g=mergeGeometries(geos);g.setAttribute('color',new T.Float32BufferAttribute(colors,3));
 const m=new T.Mesh(g,new T.MeshLambertMaterial({vertexColors:true,transparent:opacity!=null,opacity:opacity??1,depthWrite:opacity==null}));m.name=name;m.receiveShadow=true;group.add(m);geos.forEach(g=>g.dispose());return m;
}
// r8a distant landscape: layered ridgelines with aerial perspective, mist bands, tree belts, village roof
// clusters with a few warm lights, field ground and a sky gradient. Five draw calls per scene, all merged.
function rng(seed){let a=seed>>>0;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function ridge(R,base,amp,c0,c1,seed,valley){const N=180,pos=[],col=[],idx=[],r=rng(seed),ph=[r()*6.3,r()*6.3,r()*6.3,r()*6.3],a=new T.Color(c0),b=new T.Color(c1);
 for(let i=0;i<=N;i++){const t=i/N*Math.PI*2;let h=base+amp*(.5*Math.sin(t*2+ph[0])+.28*Math.sin(t*5+ph[1])+.16*Math.sin(t*11+ph[2])+.08*Math.sin(t*23+ph[3]));
  if(valley!=null){let d=t-valley;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;h*=1-.55*Math.exp(-d*d*7);}
  h=Math.max(2.5,h);const x=Math.cos(t)*R,z=Math.sin(t)*R;pos.push(x,-2,z,x,h,z);col.push(a.r,a.g,a.b,b.r,b.g,b.b);
  if(i<N){const k=i*2;idx.push(k,k+1,k+2,k+1,k+3,k+2);}}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('color',new T.Float32BufferAttribute(col,3));g.setIndex(idx);return g;}
function band(R,h,color,alpha,seed){const N=120,pos=[],col=[],idx=[],c=new T.Color(color),r=rng(seed);
 for(let i=0;i<=N;i++){const t=i/N*Math.PI*2,hh=h*(.75+.5*r()),x=Math.cos(t)*R,z=Math.sin(t)*R;pos.push(x,-1,z,x,hh,z);col.push(c.r,c.g,c.b,alpha,c.r,c.g,c.b,0);if(i<N){const k=i*2;idx.push(k,k+1,k+2,k+1,k+3,k+2);}}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('color',new T.Float32BufferAttribute(col,4));g.setIndex(idx);return g;}
// The game's global mergeGeometries keeps only position/normal/uv; this one keeps vertex colours (rgb or rgba).
function mergeColored(geos,n=3){const pos=[],col=[];for(const src of geos){const g=src.index?src.toNonIndexed():src,c=g.attributes.color;pos.push(...g.attributes.position.array);
  for(let i=0;i<g.attributes.position.count;i++){for(let k=0;k<n;k++)col.push(c?(k<c.itemSize?c.array[i*c.itemSize+k]:1):1);}}
 const out=new T.BufferGeometry();out.setAttribute('position',new T.Float32BufferAttribute(pos,3));out.setAttribute('color',new T.Float32BufferAttribute(col,n));out.computeBoundingSphere();return out;}
function colored(g,color){g=g.index?g.toNonIndexed():g.clone();for(const k of Object.keys(g.attributes))if(k!=='position')g.deleteAttribute(k);const c=new T.Color(color),a=[];for(let i=0;i<g.attributes.position.count;i++)a.push(c.r,c.g,c.b);g.setAttribute('color',new T.Float32BufferAttribute(a,3));return g;}
function horizon(s,name,o={}){
 const root=new T.Group();root.name='r8a-distance';s.group.add(root);
 const plaza=name==='plaza',r=rng(o.seed||(plaza?71:29)),inner=o.inner||(plaza?30:21); // inner: just outside the scene's wall line
 const sphere=new T.SphereGeometry(1,9,6),cone=new T.ConeGeometry(1,1,6),box=new T.BoxGeometry(1,1,1),far=[],near=[];
 const add=(list,geo,color,at,scale,rot)=>list.push({geo,color,at,scale,rot});
 // Exit valleys: the mountains dip behind the main approach so the eye is led out along the route.
 const valley=o.valley??Math.PI/2,sq=o.square||0,outside=(x,z)=>!sq||Math.max(Math.abs(x),Math.abs(z))>sq;
 const ridges=[ridge(96,20,11,'#e9dcc3','#c3cbc2',7,valley),ridge(84,15,8,'#e3d6bd','#a6b5aa',11,valley),ridge(72,9,5,'#ddd0b4','#8c9f8f',19,valley+.6)];
 // Tree belts: irregular clumps (not a ring), denser in the back quadrants.
 for(let k=0;k<30;k++){const a=r()*Math.PI*2,rad=inner+3+r()*24,cx=Math.cos(a)*rad,cz=Math.sin(a)*rad,n=3+Math.floor(r()*5);
  for(let q=0;q<n;q++){const x=cx+(r()-.5)*7,z=cz+(r()-.5)*7,d=Math.hypot(x,z);if(d<inner+1.5||!outside(x,z))continue;const tone=['#6f8a64','#7d9466','#5f7c5c','#86986a'][Math.floor(r()*4)];
   if(r()<.32){const h=4+r()*4;add(far,cone,'#5e7a5f',[x,h/2,z],[1.1+r()*.8,h,1.1+r()*.8]);}
   else{const w=1.8+r()*1.6,h=1.5+r()*1.4;add(far,sphere,tone,[x,1.2+h*.9,z],[w,h,w*(.8+r()*.4)]);add(far,box,'#6b5444',[x,.9,z],[.3,1.8,.3]);}}}
 // Village roof clusters (粉墙黛瓦) — a few groups at differing distances, with warm windows / lanterns.
 const villages=o.villages||(plaza?[[-.62,46,6],[2.2,52,7],[3.6,44,5],[5.2,40,6],[1.25,58,5]]:[[-.9,34,5],[2.0,38,6],[4.1,30,5],[5.4,42,4]]);
 for(const [a0,rad,n] of villages)for(let q=0;q<n;q++){const a=a0+(r()-.5)*.38,d=rad+(r()-.5)*9,x=Math.cos(a)*d,z=Math.sin(a)*d,w=3+r()*3,dep=2.4+r()*1.4,h=2+r()*1.6,rot=a+Math.PI/2+(r()-.5)*.5;
  const sn=Math.sin(rot),cs=Math.cos(rot);add(far,box,r()<.5?'#e8e0d0':'#ddd3c0',[x,h/2,z],[w,h,dep],[0,-rot,0]);
  for(const side of [-1,1]){const ox=-sn*side*dep*.27,oz=-cs*side*dep*.27;add(far,box,'#4a5556',[x+ox*1.0,h+.32,z+oz*1.0],[w+.5,.14,dep*.62],[0,-rot,0]);}
  add(far,box,'#3d4748',[x,h+.62,z],[w+.6,.16,.22],[0,-rot,0]);
  if(r()<.55)add(far,box,'#ffcf7a',[x-sn*dep*.51,h*.45,z-cs*dep*.51],[.5,.55,.06],[0,-rot,0]);}
 // Distant lantern lights along an outer lane.
 for(let k=0;k<9;k++){const a=valley+(k-4)*.13+(r()-.5)*.04,d=inner+9+k*1.6;add(far,sphere,'#ffb85c',[Math.cos(a)*d,1.9,Math.sin(a)*d],[.22,.28,.22]);add(far,box,'#5a4535',[Math.cos(a)*d,.95,Math.sin(a)*d],[.08,1.9,.08]);}
 const geos=ridges.slice();for(const p of far){let g=colored(p.geo,p.color);const o=new T.Object3D();o.position.set(...p.at);o.scale.set(...p.scale);o.rotation.set(...(p.rot||[0,0,0]));o.updateMatrix();g.applyMatrix4(o.matrix);geos.push(g);}
 const fg=mergeColored(geos);
 const farMesh=new T.Mesh(fg,new T.MeshBasicMaterial({vertexColors:true,side:T.DoubleSide,fog:false}));farMesh.name='r8a-horizon';root.add(farMesh);
 // Field ground under everything (hidden under the paving inside the scene).
 const gg=new T.PlaneGeometry(240,240,48,48);gg.rotateX(-Math.PI/2);const gp=gg.attributes.position,gc=[],c1=new T.Color('#b9b48a'),c2=new T.Color('#a4ab7c'),c3=new T.Color('#c8bb93'),tmp=new T.Color();
 for(let i=0;i<gp.count;i++){const x=gp.getX(i),z=gp.getZ(i),u=Math.sin(x*.11+Math.sin(z*.07)*1.7)*Math.cos(z*.09-x*.03);tmp.copy(u>.25?c2:u<-.3?c3:c1);gc.push(tmp.r,tmp.g,tmp.b);gp.setY(i,-.06-(Math.hypot(x,z)>70?(Math.hypot(x,z)-70)*.04:0));}
 gg.setAttribute('color',new T.Float32BufferAttribute(gc,3));const ground=new T.Mesh(gg,new T.MeshLambertMaterial({vertexColors:true}));ground.name='r8a-ground';ground.receiveShadow=true;root.add(ground);
 // Mist bands between the ridge layers.
 const mg=mergeColored([band(66,7,'#f1e7d4',.62,3),band(80,9,'#f3eadb',.5,5),band(inner+18,3.2,'#efe6d2',.35,9)],4);
 const mist=new T.Mesh(mg,new T.MeshBasicMaterial({vertexColors:true,transparent:true,depthWrite:false,side:T.DoubleSide,fog:false}));mist.name='r8a-mist';mist.renderOrder=-1;root.add(mist);
 // Clouds: soft lumpy groups, high and few.
 const cl=[];for(let k=0;k<7;k++){const a=r()*Math.PI*2,d=55+r()*22,x=Math.cos(a)*d,z=Math.sin(a)*d,y=24+r()*10;for(let q=0;q<4;q++)cl.push({geo:sphere,color:'#fbf6ec',at:[x+(q-1.5)*4.2+(r()-.5)*2,y+(r()-.5)*1.2,z+(r()-.5)*3],scale:[4+r()*3,1.3+r()*.8,3+r()*1.5]});}
 const cloud=baked(root,'r8a-clouds',cl,.7);cloud.material=new T.MeshBasicMaterial({vertexColors:true,transparent:true,opacity:.7,depthWrite:false,fog:false});
 const sky=new T.Mesh(new T.SphereGeometry(140,24,12),new T.ShaderMaterial({side:T.BackSide,depthWrite:false,fog:false,uniforms:{},vertexShader:'varying vec3 v;void main(){v=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 v;void main(){float y=normalize(v).y;vec3 hz=vec3(.96,.89,.76),mid=vec3(.80,.86,.86),top=vec3(.50,.68,.82);vec3 c=mix(hz,mid,smoothstep(0.,.22,y));c=mix(c,top,smoothstep(.2,.75,y));gl_FragColor=vec4(c,1.);}'}));sky.name='r8a-sky';sky.renderOrder=-2;root.add(sky);
 if(plaza)boundary(s);
}
// Plaza boundary: the paving used to stop in mid-air on three sides. A 粉墙黛瓦 enclosure with openings
// at the three exits; outside each opening the lane continues into the fields.
function boundary(s){const root=new T.Group();root.name='r8a-boundary';s.group.add(root);const box=new T.BoxGeometry(1,1,1),parts=[],E=25.4;
 const add=(color,x,y,z,sx,sy,sz,ry=0,rx=0)=>parts.push({geo:box,color,at:[x,y,z],scale:[sx,sy,sz],rot:[rx,ry,0]});
 const seg=(x0,z0,x1,z1)=>{const L=Math.hypot(x1-x0,z1-z0),mat=new T.Matrix4().makeTranslation((x0+x1)/2,0,(z0+z1)/2).multiply(new T.Matrix4().makeRotationY(-Math.atan2(z1-z0,x1-x0)));
  const loc=(color,x,y,z,sx,sy,sz,rx=0)=>parts.push({geo:box,color,at:[x,y,z],scale:[sx,sy,sz],rot:[rx,0,0],mat});
  loc('#8e897d',0,.2,0,L,.4,.62);loc('#ece5d6',0,1.45,0,L-.02,2.5,.4);
  for(const side of [-1,1])loc('#4d585a',0,2.84,side*.2,L+.3,.09,.52,side*.42);
  loc('#3e4849',0,3.0,0,L+.34,.13,.16);
  for(let t=3.1;t<L-1.5;t+=5.4+((t*7)%2.2))loc('#e2d9c7',t-L/2,1.42,0,.6,2.56,.5);};
 const gap=2.5;
 // south wall with the 里门 lane opening at x=0; east/west with 集市 / 茶会 openings at z=0
 seg(-E,E,-gap,E);seg(gap,E,E,E);seg(E,-22.6,E,-gap);seg(E,gap,E,E);seg(-E,-22.6,-E,-gap);seg(-E,gap,-E,E);seg(-E,-22.6,-13.7,-22.6);seg(13.7,-22.6,E,-22.6);
 for(const [x,z,ry] of [[-gap,E,0],[gap,E,0],[E,-gap,Math.PI/2],[E,gap,Math.PI/2],[-E,-gap,Math.PI/2],[-E,gap,Math.PI/2]]){add('#d9cfbc',x,1.6,z,.8,3.2,.8,ry);add('#4d585a',x,3.3,z,1.2,.18,1.2,ry);}
 for(const [x,z,sx,sz] of [[0,E+8,4.4,16],[E+8,0,16,4.4],[-E-8,0,16,4.4]])add('#cfc5ad',x,-.035,z,sx,.07,sz);
 const m=baked(root,'r8a-enclosure',parts);m.castShadow=false;
 // the two north return walls stand inside the walk limit (z -24): solid from the wall to the limit
 s.blocks.push({x:-24.5,X:-13.6,z:-24.5,Z:-22.22,r8a:'enclosure'},{x:13.6,X:24.5,z:-24.5,Z:-22.22,r8a:'enclosure'});
 changes.push({scene:'plaza',object:'plaza enclosure wall (粉墙黛瓦) with exit openings + lanes beyond',from:null,to:'x/z ±25.4'});
}
function approach(){
 const s=W3.spaces.gate,root=new T.Group();root.name='r8a-approach';s.group.add(root);
 const box=new T.BoxGeometry(1,1,1),parts=[];
 const add=(color,x,y,z,sx,sy,sz,rx=0)=>parts.push({geo:box,color,at:[x,y,z],scale:[sx,sy,sz],rot:[rx,0,0]});
 // r8a: the approach used to end in flush "step" plates against the south wall. It now ends in a small
 // forecourt before a proper 照壁 (screen wall) on the gate axis — the 牌坊 and the screen face each other.
 for(const [x,z] of [[-.78,11.4],[.78,11.4],[-2.2,11.9],[2.2,11.9],[-.78,12.15],[.78,12.15]])add('#d6ccb7',x,.025,z,x*x>2?1.3:1.4,.05,x*x>2?1.1:.6);
 // 照壁: stone plinth, plaster body, grey-brick frame and pilasters, tiled cap with ridge and lifted ends.
 const Z=13.3;add('#8e897d',0,.24,Z,7.6,.48,1.0);add('#9a958a',0,.52,Z,7.3,.08,.9);
 add('#ece5d6',0,1.95,Z,6.9,2.8,.62);
 for(const x of [-3.3,3.3])add('#7f837d',x,1.95,Z,.42,2.84,.7);
 for(const [y,h] of [[.86,.14],[3.06,.14]])add('#868a83',0,y,Z-.32,6.2,h,.06);
 for(const x of [-2.55,2.55])add('#868a83',x,1.96,Z-.32,.14,2.1,.06);
 add('#5a6061',0,3.42,Z,7.4,.12,1.02);
 for(const side of [-1,1])add('#4d585a',0,3.62,Z+side*.27,7.6,.09,.62,side*.5);
 add('#3e4849',0,3.84,Z,7.7,.16,.18);for(const x of [-3.92,3.92])add('#3e4849',x,3.95,Z,.32,.3,.2);
 // planters either side of the screen
 const sph=new T.SphereGeometry(1,9,6);for(const [x,k] of [[-4.7,0],[4.7,1]]){add('#8e897d',x,.3,Z-.25,1.1,.6,1.1);add('#6f6a5e',x,.62,Z-.25,1.0,.05,1.0);
  parts.push({geo:sph,color:k?'#6f8f58':'#7a9a5e',at:[x,1.02,Z-.25],scale:[.5,.44,.48]},{geo:sph,color:'#68874f',at:[x+(k?-.18:.2),1.32,Z-.3],scale:[.3,.3,.3]});}
 // rest bench beside the approach, parallel to the path, facing it
 add('#8d6c4d',-6.1,.52,10.2,.7,.16,2.6);for(const dx of [-.3,.3])add('#7d5f43',-6.1+dx,.33,10.2,.06,.22,2.4);
 for(const z of [9.2,11.2])add('#8d6c4d',-6.1,.23,z,.55,.46,.18);
 baked(root,'r8a-approach-court',parts);
 // screen panel: a painted landscape with a secular four-character inscription
 const c=document.createElement('canvas');c.width=1024;c.height=384;const g=c.getContext('2d');
 g.fillStyle='#ece2c8';g.fillRect(0,0,1024,384);const lay=(col,base,amp,seed)=>{g.fillStyle=col;g.beginPath();g.moveTo(0,384);for(let x=0;x<=1024;x+=8){const y=base-amp*(.55*Math.sin(x*.006+seed)+.3*Math.sin(x*.017+seed*2)+.15*Math.sin(x*.041+seed*3));g.lineTo(x,y);}g.lineTo(1024,384);g.fill();};
 lay('rgba(120,140,130,.35)',250,60,1);lay('rgba(90,110,100,.5)',300,45,2.3);lay('rgba(70,88,80,.7)',350,30,4.1);
 g.fillStyle='#3a3530';g.font='bold 92px "STKaiti","KaiTi","Songti SC",serif';g.textAlign='center';g.textBaseline='middle';g.fillText('邻里和美',512,128);
 g.fillStyle='#b5483b';g.fillRect(760,196,44,44);g.fillStyle='#ece2c8';g.font='bold 22px serif';g.fillText('福',782,219);
 const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;const panel=new T.Mesh(new T.PlaneGeometry(4.9,1.84),new T.MeshLambertMaterial({map:tex}));
 panel.position.set(0,1.96,Z-.336);panel.rotation.y=Math.PI;panel.name='r8a-screen-panel';root.add(panel);
 s.blocks.push({x:-3.8,X:3.8,z:Z-.5,Z:14.6,r8a:'照壁'},{x:-5.25,X:-4.15,z:Z-.8,Z:Z+.3,r8a:'planter'},{x:4.15,X:5.25,z:Z-.8,Z:Z+.3,r8a:'planter'},{x:-6.5,X:-5.7,z:8.9,Z:11.5,r8a:'bench'});
 changes.push({scene:'gate',object:'flush approach "steps" against the wall + off-axis slab screen',from:[[0,0,10.95],[-5.8,0,5.5]],to:null},
  {scene:'gate',object:'照壁 (screen wall, 邻里和美 landscape panel) on the gate axis with forecourt + planters',from:null,to:[0,0,13.3]},
  {scene:'gate',object:'rest bench',from:[-6,0,3.1],to:[-6.1,0,10.2]});
}

function trimPostFlowers(s){
 s.group.updateMatrixWorld(true);s.group.traverse(m=>{if(!m.isInstancedMesh)return;const mat=new T.Matrix4();let dirty=false;
 for(let i=0;i<m.count;i++){m.getMatrixAt(i,mat);const pos=new T.Vector3().setFromMatrixPosition(mat).applyMatrix4(m.matrixWorld);if(pos.y<.6&&pos.y>-.2&&s.blocks.some(b=>b.Z-b.z<.8&&b.X-b.x<.8&&pos.x>b.x-.17&&pos.x<b.X+.17&&pos.z>b.z-.17&&pos.z<b.Z+.17)){
 // Tiny plants only; trunks and stone lamp bases retain their geometry.
 const scale=new T.Vector3(),q=new T.Quaternion(),p=new T.Vector3();mat.decompose(p,q,scale);if(Math.max(scale.x,scale.z)<.3&&scale.y<.6){mat.makeScale(0,0,0);m.setMatrixAt(i,mat);dirty=true;}}
 }if(dirty){m.instanceMatrix.needsUpdate=true;m.computeBoundingSphere?.();}
 });
}
function deduplicate(s){
 s.group.traverse(m=>{if(!m.isInstancedMesh)return;const seen=new Set(),mat=new T.Matrix4();let n=0;
 for(let i=0;i<m.count;i++){m.getMatrixAt(i,mat);const key=mat.elements.map(v=>Math.round(v*10000)).join(',');if(seen.has(key)){changes.push({scene:s===W3.spaces.plaza?'plaza':'gate',object:'duplicate instance',from:[mat.elements[12],mat.elements[13],mat.elements[14]],to:null});continue;}seen.add(key);if(n!==i)m.setMatrixAt(n,mat);n++;}
 if(n!==m.count){m.count=n;m.instanceMatrix.needsUpdate=true;m.computeBoundingSphere?.();}
 });
}
function pruneParts(s,test=box=>box.max.z< -22.9&&box.max.y>1){
 s.group.updateMatrixWorld(true);s.group.traverse(m=>{if(!m.isMesh||!m.geometry?.attributes?.position)return;
 if(m.isInstancedMesh){const mat=new T.Matrix4(),b=m.geometry.boundingBox||(m.geometry.computeBoundingBox(),m.geometry.boundingBox);let live=0,changed=false;
 for(let i=0;i<m.count;i++){m.getMatrixAt(i,mat);const box=b.clone().applyMatrix4(m.matrixWorld.clone().multiply(mat));if(test(box,m)){mat.makeScale(0,0,0);m.setMatrixAt(i,mat);changed=true;}else live++;}
 if(changed){m.instanceMatrix.needsUpdate=true;m.computeBoundingSphere?.();}if(!live)m.visible=false;return;}
 const g=m.geometry,p=g.attributes.position,drop=new Set(),v=new T.Vector3();
 for(const ids of components(g)){const box=new T.Box3();for(const i of ids)box.expandByPoint(v.fromBufferAttribute(p,i).applyMatrix4(m.matrixWorld));if(test(box,m))ids.forEach(i=>drop.add(i));}
 if(!drop.size)return;if(drop.size===p.count){m.visible=false;return;}
 const ix=g.index,keep=[];for(let i=0;i<(ix?ix.count:p.count);i+=3){const a=ix?ix.getX(i):i;if(!drop.has(a))keep.push(a,ix?ix.getX(i+1):i+1,ix?ix.getX(i+2):i+2);}
 m.geometry=g.clone();m.geometry.setIndex(keep);m.geometry.computeBoundingBox();m.geometry.computeBoundingSphere();
 });
}
function plazaLayout(){
 const rootSoil=new T.Mesh(new T.CircleGeometry(3.35,32).rotateX(-Math.PI/2),new T.MeshLambertMaterial({color:'#927858'}));rootSoil.name='r8a-root-soil';rootSoil.position.y=.065;W3.spaces.plaza.group.add(rootSoil);
 pruneParts(W3.spaces.plaza,(box,m)=>{for(let p=m;p;p=p.parent)if(p.name==='r7-wish-tree'||p.name==='r7f-wish-tags'||p.name==='r7f-flower-bed')return false;const c=box.getCenter(new T.Vector3()),sz=box.getSize(new T.Vector3());return box.max.y<.5&&Math.max(sz.x,sz.z)<2&&Math.hypot(c.x,c.z)<3.2;});

 const s=W3.spaces.plaza;
 // Old scenery used two superposed mountain layers. Replace the bulky local
 // cones/balls with the distant horizon, retaining the playable perimeter.
 s.group.updateMatrixWorld(true);s.group.traverse(m=>{if(!m.isMesh||m.isInstancedMesh)return;const b=new T.Box3().setFromObject(m);if(b.max.z< -23&&b.max.y>1)m.visible=false;});
 // Old remapping split the third stall between two destinations. Build each
 // stall once, as a complete assembly with one coherent visual footprint.
 const root=new T.Group();root.name='r8a-stalls';s.group.add(root);
 const box=new T.BoxGeometry(1,1,1),parts=[];
 for(const [x,z]of [[-16,8],[16,8],[16,-8]]){
 const add=(color,dx,y,dz,sx,sy,sz)=>parts.push({geo:box,color,at:[x+dx,y,z+dz],scale:[sx,sy,sz]});
 add('#855d3c',0,.65,0,3,1.3,1.6);
 for(const dx of [-1.4,1.4])for(const dz of [-.65,.65])add('#66503b',dx,1.45,dz,.12,2.9,.12);
 for(let i=0;i<8;i++)add(i%2?'#e9dcc0':'#b7604c',-1.575+i*.45,2.98,0,.45,.16,2.3);
 // Small serving tray rests on the counter, with no buried/floating stock.
 add('#c2a674',0,1.34,0,1.2,.08,.7);
 }
 baked(root,'r8a-stall-assemblies',parts);
 // Give the north bed's potted shrub its own space outside the stone edging.
 relocate(s.group,-2,-15.7,-4,-14.5,.65);for(const b of s.blocks)if(Math.hypot((b.x+b.X)/2+2,(b.z+b.Z)/2+15.7)<.3){b.x-=2;b.X-=2;b.z+=1.2;b.Z+=1.2;}
 changes.push({scene:'plaza',object:'north potted shrub',from:[-2,0,-15.7],to:[-4,0,-14.5]});
 // Move shade trees away from counter roofs and the tag rack, with their blocks.
 const moves=[[-18,-8,-20,-12],[-18,8,-20,3],[18,-8,20,-12],[18,12,20,16]];
 for(const [x,z,X,Z]of moves){relocate(s.group,x,z,X,Z,1.9);for(const b of s.blocks){if(Math.hypot((b.x+b.X)/2-x,(b.z+b.Z)/2-z)<.7){b.x+=X-x;b.X+=X-x;b.z+=Z-z;b.Z+=Z-z;}}changes.push({scene:'plaza',object:'shade tree',from:[x,0,z],to:[X,0,Z]});}
 // The cat's face/ears and body must move as one animal, not as two clusters.
 // Legacy animal decoration is baked separately; reconcile it in the audit pass.
 s.blocks=s.blocks.filter(b=>!(b.x>15&&b.X<19&&b.z>10&&b.Z<12));
}

function logicalBoxes(s){
 const out=[],v=new T.Vector3(),mat=new T.Matrix4();s.group.updateMatrixWorld(true);
 s.group.traverse(m=>{if(!m.isMesh||m.material?.opacity===0||!visible(m,s.group))return;
 for(let p=m;p&&p!==s.group;p=p.parent)if(p.name==='r8a-distance'||p.name==='r7-wish-tree'||p.name==='r7f-wish-tags'||p.name==='r7f-flower-bed')return;
 if(m.isInstancedMesh){if(!m.geometry.boundingBox)m.geometry.computeBoundingBox();for(let i=0;i<m.count;i++){m.getMatrixAt(i,mat);out.push({box:m.geometry.boundingBox.clone().applyMatrix4(m.matrixWorld.clone().multiply(mat)),mesh:m});}}
 else for(const ids of components(m.geometry)){const box=new T.Box3();for(const i of ids)box.expandByPoint(v.fromBufferAttribute(m.geometry.attributes.position,i).applyMatrix4(m.matrixWorld));out.push({box,mesh:m});}
 });return out;
}
function reconcile(s,name){
 const rows=logicalBoxes(s),water=s.blocks.filter(b=>[11,18].some(x=>Math.abs((b.x+b.X)/2-x)<.1)&&Math.abs(b.X-b.x-1.25)<.1);
 s.blocks=s.blocks.filter(b=>{
 if(water.includes(b))return true;
 if(b.x<=-1.5&&b.X>=1.5&&b.z<=-1.5&&b.Z>=1.5)return true;
 const exists=rows.some(({box:a})=>a.min.y<1.7&&a.max.y>.4&&a.min.x<b.X&&a.max.x>b.x&&a.min.z<b.Z&&a.max.z>b.z);
 if(!exists)changes.push({scene:name,object:'invisible collider',from:[b.x,b.X,b.z,b.Z],to:null});return exists;
 });
 for(const {box:b,mesh:m}of rows){if(!isFinite(b.min.x)||!isFinite(b.max.x))continue;const sz=b.getSize(new T.Vector3()),c=b.getCenter(new T.Vector3());
 if(b.min.y>.35||b.max.y<.65||Math.min(sz.x,sz.z)<.2||Math.max(sz.x,sz.z)>8||Math.abs(c.x)>s.limit.x-.3||Math.abs(c.z)>s.limit.z-.3)continue;
 if(s.blocks.some(a=>c.x>=a.x-.05&&c.x<=a.X+.05&&c.z>=a.z-.05&&c.z<=a.Z+.05))continue;
 const block={x:b.min.x,X:b.max.x,z:b.min.z,Z:b.max.z,r8a:'visual'};s.blocks.push(block);changes.push({scene:name,object:'missing collider',from:null,to:[block.x,block.X,block.z,block.Z]});
 }
 if(name==='plaza'){s.blocks=s.blocks.filter(b=>!((b.x+b.X)/2>10.7&&(b.x+b.X)/2<14.1&&(b.z+b.Z)/2< -14.5&&(b.z+b.Z)/2> -18));s.blocks.push({x:10.8,X:14,z:-17.7,Z:-14.7,r8a:'bamboo bed'});s.blocks=s.blocks.filter(b=>!(b.x===-1.5&&b.X===1.5&&b.z===-1.5));s.blocks.push({x:-3.1,X:3.1,z:-3,Z:2.2,r8a:'tree roots'});}
}


// r8a: object-by-object fixes found by the prop audit (qa/r8-tools/audit2) and close-up shots.
function ancestor(m,name){for(let p=m;p;p=p.parent)if(p.name===name)return true;return false;}
function hex(m){return m.material?.color?.getHexString?.()||'';}
function shiftParts(s,test,d){
 s.group.updateMatrixWorld(true);const v=new T.Vector3(),mat=new T.Matrix4();
 s.group.traverse(m=>{if(!m.isMesh||m.isSprite||!m.geometry?.attributes?.position)return;
  if(m.isInstancedMesh){const b=m.geometry.boundingBox||(m.geometry.computeBoundingBox(),m.geometry.boundingBox);let ch=false;
   for(let i=0;i<m.count;i++){m.getMatrixAt(i,mat);const box=b.clone().applyMatrix4(m.matrixWorld.clone().multiply(mat));if(!test(box,m))continue;
    const local=new T.Vector3(...d).applyMatrix4(m.matrixWorld.clone().invert()).sub(new T.Vector3().applyMatrix4(m.matrixWorld.clone().invert()));mat.elements[12]+=local.x;mat.elements[13]+=local.y;mat.elements[14]+=local.z;m.setMatrixAt(i,mat);ch=true;}
   if(ch){m.instanceMatrix.needsUpdate=true;m.computeBoundingSphere?.();m.computeBoundingBox?.();}return;}
  const g=m.geometry,p=g.attributes.position;let dirty=false,dst=null;const inv=m.matrixWorld.clone().invert(),a=new T.Vector3(...d).applyMatrix4(inv).sub(new T.Vector3().applyMatrix4(inv));
  for(const ids of components(g)){const box=new T.Box3();for(const i of ids)box.expandByPoint(v.fromBufferAttribute(p,i).applyMatrix4(m.matrixWorld));if(!test(box,m))continue;
   if(!dirty){m.geometry=g.clone();dst=m.geometry.attributes.position;dirty=true;}for(const i of ids)dst.setXYZ(i,p.getX(i)+a.x,p.getY(i)+a.y,p.getZ(i)+a.z);}
  if(dirty){dst.needsUpdate=true;m.geometry.computeBoundingBox();m.geometry.computeBoundingSphere();pieces.set(m.geometry,components(g));}
 });
}
// World-space affine edit of whole pieces: make(box) returns a Matrix4 applied in world space.
function xformParts(s,test,make){
 s.group.updateMatrixWorld(true);const v=new T.Vector3(),mat=new T.Matrix4();
 s.group.traverse(m=>{if(!m.isMesh||m.isSprite||!m.geometry?.attributes?.position)return;const mw=m.matrixWorld.clone(),inv=mw.clone().invert();
  if(m.isInstancedMesh){const b=m.geometry.boundingBox||(m.geometry.computeBoundingBox(),m.geometry.boundingBox);let ch=false;
   for(let i=0;i<m.count;i++){m.getMatrixAt(i,mat);const box=b.clone().applyMatrix4(mw.clone().multiply(mat));if(!test(box,m))continue;
    m.setMatrixAt(i,inv.clone().multiply(make(box)).multiply(mw).multiply(mat));ch=true;}
   if(ch){m.instanceMatrix.needsUpdate=true;m.computeBoundingSphere?.();m.computeBoundingBox?.();}return;}
  const g=m.geometry,p=g.attributes.position;let dirty=false,dst=null;
  for(const ids of components(g)){const box=new T.Box3();for(const i of ids)box.expandByPoint(v.fromBufferAttribute(p,i).applyMatrix4(mw));if(!test(box,m))continue;
   const M=inv.clone().multiply(make(box)).multiply(mw);if(!dirty){m.geometry=g.clone();dst=m.geometry.attributes.position;dirty=true;}
   for(const i of ids){v.fromBufferAttribute(p,i).applyMatrix4(M);dst.setXYZ(i,v.x,v.y,v.z);}}
  if(dirty){dst.needsUpdate=true;m.geometry.deleteAttribute?.('normal');m.geometry.computeVertexNormals();m.geometry.computeBoundingBox();m.geometry.computeBoundingSphere();pieces.set(m.geometry,components(g));}
 });
}
// Re-span a piece vertically to [y0,y1] (seat a post on its base / under its cap).
const spanY=(y0,y1)=>b=>{const k=(y1-y0)/Math.max(.001,b.max.y-b.min.y);return new T.Matrix4().makeTranslation(0,y0,0).multiply(new T.Matrix4().makeScale(1,k,1)).multiply(new T.Matrix4().makeTranslation(0,-b.min.y,0));};
// Low tree crowns (head height) get a collider over the inner 70% of their footprint so nobody walks into the foliage.
function crownBlocks(s,name){const rows=logicalBoxes(s);let n=0;
 for(const {box:b,mesh:m} of rows){if(!isFinite(b.min.x))continue;const c=m.material?.color;if(!c||m.material?.transparent)continue;const hsl={};c.getHSL(hsl);
  const sz=b.getSize(new T.Vector3()),ctr=b.getCenter(new T.Vector3());
  if(!(hsl.h>.17&&hsl.h<.45&&hsl.s>.18)||b.min.y<.55||b.min.y>1.9||Math.min(sz.x,sz.z)<.9||sz.y<.5)continue;
  if(Math.abs(ctr.x)>s.limit.x+.5||Math.abs(ctr.z)>s.limit.z+.5)continue;
  const bx={x:ctr.x-sz.x*.35,X:ctr.x+sz.x*.35,z:ctr.z-sz.z*.35,Z:ctr.z+sz.z*.35,r8a:'tree crown'};
  if(s.blocks.some(a=>a.x<=bx.x&&a.X>=bx.X&&a.z<=bx.z&&a.Z>=bx.Z))continue;s.blocks.push(bx);n++;}
 if(n)changes.push({scene:name,object:`low tree crowns: ${n} foliage colliders (player walked into crowns at head height)`,from:null,to:'inner 70% footprint'});}
const near=(box,x,z,r)=>{const c=box.getCenter(new T.Vector3());return Math.hypot(c.x-x,c.z-z)<r;};
function matOf(s,test){let out=null;s.group.traverse(m=>{if(!out&&m.isMesh&&!m.isSprite&&test(m))out=m.material;});return out;}
function plazaFixes(){
 const s=W3.spaces.plaza;
 // Dougong stacks left at the old wall line (z≈-11.7) after the wall moved north: they float 3.4 m up with no column.
 pruneParts(s,(b,m)=>m.isInstancedMesh&&!ancestor(m,'art3-plaza')&&b.min.y>3.3&&b.max.y<3.9&&b.min.z>-12.4&&b.max.z<-11);
 changes.push({scene:'plaza',object:'orphan bracket stacks ×7 (x=-12…12, y 3.4–3.8, z -11.7)',from:[0,3.6,-11.7],to:null});
 // Dark hooks hanging under the exit signs hold nothing.
 for(const sc of [s,W3.spaces.gate])pruneParts(sc,(b,m)=>hex(m)==='6e4d2e'&&b.min.y>2.3&&b.max.y<3.15&&b.getSize(new T.Vector3()).x<.6);
 changes.push({scene:'plaza',object:'empty hooks under 里门/集市/茶会 signs',from:'y 2.35–3.09',to:null},{scene:'gate',object:'empty hooks under 大厅广场 sign',from:'y 2.35–3.09',to:null});
 // A brown box floated 1.5 m above the north flower bed (left from the old centre post).
 pruneParts(s,(b,m)=>ancestor(m,'r7f-flower-bed')&&b.min.y>1.2);
 changes.push({scene:'plaza',object:'floating box above north flower bed',from:[0,1.62,-15.2],to:null});
 // Old stall fringe and a shelf plank left behind under the new stall awnings.
 pruneParts(s,(b,m)=>!ancestor(m,'r8a-stalls')&&!ancestor(m,'r8a-distance')&&b.min.y>2.4&&b.max.y<2.85&&b.getSize(new T.Vector3()).x<.15&&b.getSize(new T.Vector3()).z<.15&&[[-16,8],[16,8],[16,-8],[-18,4]].some(([x,z])=>near(b,x,z,3.2)));
 pruneParts(s,(b,m)=>!ancestor(m,'r8a-stalls')&&!ancestor(m,'r8a-distance')&&b.min.y>1.7&&b.max.y<1.9&&b.getSize(new T.Vector3()).y<.1&&[[-16,8],[16,8],[16,-8]].some(([x,z])=>near(b,x,z,2)));
 changes.push({scene:'plaza',object:'old stall fringe + shelf plank floating under new awnings',from:'(-16,2.6,9.1)',to:null});
 // Low plants must not grow through stall counters, potted shrubs or lamp bases.
 s.r8aClear=[[-17.7,7,-14.3,9],[14.3,7,17.7,9],[14.3,-9,17.7,-7],...[[-3,6],[3,6],[-3,-7],[3,-7],[-4,-14.5]].map(([x,z])=>[x-.56,z-.56,x+.56,z+.56]),...[[-2.6,8],[2.6,8],[-2.6,-4],[2.6,-4]].map(([x,z])=>[x-.48,z-.48,x+.48,z+.48])];
 // Path lamps south of the tree touched the ring rail (r≈9.4 vs ring 10): move them 1 m inward; seat lamp heads on their posts (12 cm gap).
 for(const sx of [-2.6,2.6]){relocate(s.group,sx,9,sx,8,.75);for(const b of s.blocks)if(Math.hypot((b.x+b.X)/2-sx,(b.z+b.Z)/2-9)<.5){b.z-=1;b.Z-=1;}changes.push({scene:'plaza',object:'path lamp',from:[sx,0,9],to:[sx,0,8]});}
 shiftParts(s,(b,m)=>b.min.y>1.04&&b.max.y<1.9&&b.getSize(new T.Vector3()).x<1.3&&[[-2.6,8],[2.6,8],[-2.6,-4],[2.6,-4]].some(([x,z])=>near(b,x,z,.7))&&!ancestor(m,'r7d-tree-ring'),[0,-.11,0]);
 // Red ball lanterns by the 心田小院 gate hung in front of the eave line (z -19.8, eave ends -20.4): move under the eave and give them cords.
 shiftParts(s,(b,m)=>hex(m)==='cc5035'&&b.min.y>2&&b.max.z>-20.2&&b.min.z<-19.4,[0,0,-1.1]);
 const cord=new T.BoxGeometry(1,1,1),cm=new T.MeshLambertMaterial({color:'#4a3524'}),rows=[[-4.5,3.4,-20.9,.03,.66,.03],[4.5,3.4,-20.9,.03,.66,.03],[-6,3.66,-21.1,.03,.14,.03],[6,3.66,-21.1,.03,.14,.03],[-9.5,3.66,-21.1,.03,.14,.03],[9.5,3.66,-21.1,.03,.14,.03]];
 const cords=new T.InstancedMesh(cord,cm,rows.length);cords.name='r8a-lantern-cords';rows.forEach((r,i)=>{const o=new T.Object3D();o.position.set(r[0],r[1],r[2]);o.scale.set(r[3],r[4],r[5]);o.updateMatrix();cords.setMatrixAt(i,o.matrix);});s.group.add(cords);
 changes.push({scene:'plaza',object:'red lanterns at 心田小院 gate',from:[4.5,2.65,-19.8],to:[4.5,2.65,-20.9]},{scene:'plaza',object:'wall lantern chains extended to the eave',from:'top 3.60',to:'top 3.73'});
 // The two north lions stood 58 cm above the paving (their old pedestals were dropped with the legacy statues): give them plinths.
 {const st=matOf(s,m=>ancestor(m,'art3-plaza')&&/bluestone/.test(m.material?.name||''))||new T.MeshLambertMaterial({color:'#9a9a90'});const pl=new T.InstancedMesh(new T.BoxGeometry(1,1,1),st,2),o=new T.Object3D();pl.name='r8a-lion-plinths';
  [[-5.6,-18.7],[5.6,-18.7]].forEach(([x,z],i)=>{o.position.set(x,.29,z);o.scale.set(1.3,.58,2);o.updateMatrix();pl.setMatrixAt(i,o.matrix);if(!s.blocks.some(b=>x>b.x&&x<b.X&&z>b.z&&z<b.Z))s.blocks.push({x:x-.65,X:x+.65,z:z-1,Z:z+1,r8a:'lion plinth'});});s.group.add(pl);
  changes.push({scene:'plaza',object:'north lions: stone plinths added (were floating 0.58)',from:[5.6,0.58,-18.7],to:[5.6,0,-18.7]});}
 // Potted shrubs: the crown sank 34 cm into its pot (rim .51). Lift crown + blossoms so the foliage sits on the soil line.
 shiftParts(s,(b,m)=>!m.isInstancedMesh&&b.min.y>.1&&b.max.y<1.3&&[[-3,6],[3,6],[-3,-7],[3,-7],[-4,-14.5]].some(([x,z])=>near(b,x,z,.62)),[0,.3,0]);
 changes.push({scene:'plaza',object:'potted shrubs ×5: crown lifted out of the pot',from:'crown bottom .17',to:'.47 (pot rim .51)'});
 // Banner poles ran through their stone bases (0–.4): start the pole on the base top.
 xformParts(s,(b,m)=>/wood/.test(m.material?.name||'')&&b.getSize(new T.Vector3()).y>5.5&&b.getSize(new T.Vector3()).x<.3&&[[-7,-16.5],[7,-16.5]].some(([x,z])=>near(b,x,z,.3)),spanY(.39,6));
 // Stream bridge: bank rocks pushed up through the deck ends; the hand-rail posts had no collider.
 pruneParts(s,(b,m)=>m.isInstancedMesh&&hex(m)==='b8b59b'&&b.max.x>16.7&&b.min.x<19.3&&b.max.z>2.05&&b.min.z<3.95&&b.max.y<.35);
 s.blocks.push({x:16.62,X:19.38,z:1.92,Z:2.2,r8a:'bridge rail'},{x:16.62,X:19.38,z:3.8,Z:4.08,r8a:'bridge rail'});
 changes.push({scene:'plaza',object:'stream bridge: 6 rocks through deck removed; rail colliders',from:null,to:'deck clear 1.6 m'});
 // Wall lantern arms were sunk 30 cm into the north wall: pull them out to its face.
 shiftParts(s,(b,m)=>m.isInstancedMesh&&b.min.y>3.3&&b.max.y<3.6&&b.min.z<-21.7&&b.max.z>-21.6&&b.max.z<-21.3&&[6,10].some(x=>Math.abs(Math.abs(b.getCenter(new T.Vector3()).x)-x)<.3),[0,0,.27]);
 // Corner shade trees: crown hangs to 1.2 m, so walking into it put the head in the foliage; trunk ran 80 cm into the crown.
 for(const [x,z] of [[-20,-12],[-20,3],[20,-12],[20,16]])s.blocks.push({x:x-1.12,X:x+1.12,z:z-.98,Z:z+.98,r8a:'shade tree crown'});
 xformParts(s,(b,m)=>!m.isInstancedMesh&&Math.abs(b.max.y-2)<.03&&b.min.y<.03&&b.getSize(new T.Vector3()).x<.6&&[[-20,-12],[-20,3],[20,-12],[20,16]].some(([x,z])=>near(b,x,z,.3)),spanY(0,1.25));
 changes.push({scene:'plaza',object:'corner shade trees ×4: crown colliders, trunk seated just inside the crown',from:'trunk top 2.0',to:'1.25'});
 // Blossoms on the potted shrubs were buried in the crown; bring them to its surface.
 shiftParts(s,(b,m)=>!m.isInstancedMesh&&b.min.y>.9&&b.max.y<1.5&&b.getSize(new T.Vector3()).x<.3&&[[-3,6],[3,6],[-3,-7],[3,-7],[-4,-14.5]].some(([x,z])=>near(b,x,z,.62)),[0,.22,0]);
 // Flat cloud discs hovering over the plaza read as floating plates; the r8a horizon has real clouds.
 pruneParts(s,(b,m)=>!ancestor(m,'r8a-distance')&&hex(m)==='f5e8cd'&&b.min.y>8);
 changes.push({scene:'plaza',object:'flat cloud discs over the plaza (read as floating plates)',from:'y 11–15',to:null});
 // South half was an empty sheet of paving: give it everyday uses along the approach — a shade tree with a
 // bench off the 里门 path, the gardener's well, a stone table, and planting along the new south wall.
 {const root=new T.Group();root.name='r8a-plaza-south';s.group.add(root);const box=new T.BoxGeometry(1,1,1),cyl=new T.CylinderGeometry(1,1,1,10),sph=new T.SphereGeometry(1,9,6),P=[];
  const add=(geo,color,at,scale,rot)=>P.push({geo,color,at,scale,rot:rot||[0,0,0]});
  // shade tree + bench (bench faces the path)
  add(cyl,'#6b4f3a',[-9.6,1.2,18.1],[.22,2.4,.22]);add(cyl,'#6b4f3a',[-9.35,2.3,17.9],[.1,.9,.1],[.5,0,-.4]);
  for(const [dx,dy,dz,r,c] of [[0,3.25,0,1.55,'#6f8f58'],[.9,2.85,.5,1.05,'#7d9a5e'],[-.8,2.95,-.45,1.1,'#62804f'],[.2,3.9,-.3,.95,'#86a266']])add(sph,c,[-9.6+dx,dy,18.1+dz],[r,r*.82,r]);
  add(box,'#9a948a',[-7.3,.42,16.6],[.62,.1,2.2]);for(const z of [15.8,17.4])add(box,'#8a847a',[-7.3,.2,z],[.5,.4,.3]);
  // well (gardener's water) with a little roof and a bucket
  const W=[10.6,16.2];add(cyl,'#8e897d',[W[0],.38,W[1]],[.72,.76,.72]);add(cyl,'#4f6b73',[W[0],.77,W[1]],[.56,.02,.56]);
  for(const dx of [-.62,.62])add(box,'#6b5444',[W[0]+dx,1.25,W[1]],[.1,1.7,.1]);add(box,'#6b5444',[W[0],1.95,W[1]],[1.4,.1,.1]);
  for(const side of [-1,1])add(box,'#4d585a',[W[0],2.16,W[1]+side*.3],[1.6,.06,.7],[side*.55,0,0]);add(cyl,'#7a5a40',[W[0]+.2,1.0,W[1]],[.14,.2,.14]);
  // stone table + drum stools (a resting spot by the tea path)
  add(cyl,'#9a958a',[-13.9,.38,20.1],[.55,.76,.55]);add(cyl,'#a7a297',[-13.9,.8,20.1],[.8,.08,.8]);
  for(const [dx,dz] of [[1.1,.2],[-.6,.95],[-.55,-.95]])add(cyl,'#9a958a',[-13.9+dx,.24,20.1+dz],[.27,.48,.27]);
  // planting along the south wall, broken into irregular runs
  for(const [x0,x1] of [[-19.5,-15.2],[-11.8,-6.5],[6.2,9.8],[13.5,19.2]]){add(box,'#8e897d',[(x0+x1)/2,.22,24.65],[x1-x0,.44,.9]);
   for(let x=x0+.5;x<x1-.3;x+=.9+((x*13)%5)*.08)add(sph,['#6f8f58','#7d9a5e','#5f7c55'][Math.floor(Math.abs(x*7))%3],[x,.62+((x*3)%2)*.08,24.65],[.42,.36,.36]);}
  baked(root,'r8a-plaza-south-props',P);
  s.blocks.push({x:-9.95,X:-9.25,z:17.75,Z:18.45,r8a:'shade tree'},{x:-7.62,X:-6.98,z:15.45,Z:17.75,r8a:'bench'},{x:W[0]-.8,X:W[0]+.8,z:W[1]-.8,Z:W[1]+.8,r8a:'well'},
   {x:-14.75,X:-13.05,z:19.25,Z:20.95,r8a:'stone table'},{x:-12.98,X:-12.42,z:20.02,Z:20.58,r8a:'stool'},{x:-14.78,X:-14.22,z:20.77,Z:21.33,r8a:'stool'},{x:-14.73,X:-14.17,z:18.87,Z:19.43,r8a:'stool'});
  changes.push({scene:'plaza',object:'south half: shade tree + bench, well, stone table + stools, wall planting',from:null,to:[[-9.6,18.1],[10.6,16.2],[-13.9,20.1],'z 24.65']});}
 // The gardener NPC had no collider.
 s.blocks.push({x:-11.75,X:-10.75,z:12.75,Z:13.6,r8a:'gardener'});
 // Exit-frame roofs hovered 6 cm above their posts.
 for(const sc of [s])shiftParts(sc,(b,m)=>/roofTile/.test(m.material?.name||'')&&Math.abs(b.min.y-3.39)<.02&&b.getSize(new T.Vector3()).x<4.5,[0,-.06,0]);
}
function hallFixes(){const s=W3.spaces.hall;
 // Copper lamp (r7-compliance, 0.8 m base at 2,2) had no collider.
 const lamp=s.group.getObjectByName('r7-copper-lamp');if(lamp){s.group.updateMatrixWorld(true);const b=new T.Box3().setFromObject(lamp);if(isFinite(b.min.x)&&!s.blocks.some(a=>a.x<=b.min.x&&a.X>=b.max.x&&a.z<=b.min.z&&a.Z>=b.max.z)){s.blocks.push({x:b.min.x-.05,X:b.max.x+.05,z:b.min.z-.05,Z:b.max.z+.05,r8a:'copper lamp'});changes.push({scene:'hall',object:'copper lamp collider',from:null,to:[b.min.x,b.max.x,b.min.z,b.max.z]});}}
}
function gateFixes(){
 const s=W3.spaces.gate;
 // Courtyard pines: the lowest crown tier hung at 1.4–1.9 m, i.e. through the player's head, and the camera
 // ended up inside the skirt. Lift each pine's tiers together so the lowest sits at 2.35 m (trunks reach 3.7 m+).
 {const art=s.group.getObjectByName('art3-gate'),trunks=[],crowns=[];
  if(art)art.traverse(m=>{if(!m.isInstancedMesh)return;const g=m.geometry;if(!g.boundingBox)g.computeBoundingBox();
   for(let i=0;i<m.count;i++){const im=new T.Matrix4();m.getMatrixAt(i,im);const b=g.boundingBox.clone().applyMatrix4(im.clone().premultiply(m.matrixWorld)),sz=b.getSize(new T.Vector3());
    if(g.type==='CylinderGeometry'&&sz.y>3&&sz.x<.8)trunks.push(b.getCenter(new T.Vector3()));
    else if(g.type==='SphereGeometry'&&sz.x>1.2&&sz.y<1.2&&b.min.y>1&&b.min.y<5.5)crowns.push({m,i,im,b});}});
  let lifted=0;for(const t of trunks){const mine=crowns.filter(c=>Math.hypot((c.b.min.x+c.b.max.x)/2-t.x,(c.b.min.z+c.b.max.z)/2-t.z)<1.2);if(!mine.length)continue;
   const low=Math.min(...mine.map(c=>c.b.min.y)),dy=2.35-low;if(dy<=.02)continue;
   for(const c of mine){c.im.elements[13]+=dy;c.m.setMatrixAt(c.i,c.im);c.m.instanceMatrix.needsUpdate=true;c.m.userData.r8Lifted=true;}lifted++;}
  art.traverse(m=>{if(m.userData.r8Lifted){m.computeBoundingSphere?.();m.computeBoundingBox?.();}});
  if(lifted)changes.push({scene:'gate',object:`courtyard pines (${lifted}): crown tiers lifted so the lowest clears head height`,from:'lowest tier 1.38–1.92 m',to:'2.35 m'});}
 // The 牌坊 centre bay: side lintels end at x=±5.0 but there were no inner columns, so the centre roof,
 // frieze and bracket row floated over the opening. Add the two inner columns and the centre lintel.
 const lac=matOf(s,m=>ancestor(m,'art3-gate')&&/lacquer/.test(m.material?.name||''))||new T.MeshLambertMaterial({color:'#a8362a'});
 const stone=matOf(s,m=>ancestor(m,'art3-gate')&&/bluestone/.test(m.material?.name||''))||new T.MeshLambertMaterial({color:'#9a9a90'});
 const box=new T.BoxGeometry(1,1,1),g=new T.Group();g.name='r8a-paifang-centre';s.group.add(g);
 const col=new T.InstancedMesh(box,lac,3),o=new T.Object3D();
 [[-4.15,2.32,-5,.46,3.96,.46],[4.15,2.32,-5,.46,3.96,.46],[0,4.15,-5.15,8.76,.3,1.6]].forEach((r,i)=>{o.position.set(r[0],r[1],r[2]);o.scale.set(r[3],r[4],r[5]);o.updateMatrix();col.setMatrixAt(i,o.matrix);});g.add(col);
 const base=new T.InstancedMesh(box,stone,2);[[-4.15,.17,-5],[4.15,.17,-5]].forEach((r,i)=>{o.position.set(...r);o.scale.set(.74,.34,.74);o.updateMatrix();base.setMatrixAt(i,o.matrix);});g.add(base);
 // Side-roof inner ridge ornaments sat exactly where the new inner columns rise; the centre roof hovered 6 cm over its brackets.
 pruneParts(s,(b,m)=>ancestor(m,'art3-gate')&&hex(m)==='2f3b3b'&&Math.abs(b.getCenter(new T.Vector3()).x)>4.38&&Math.abs(b.getCenter(new T.Vector3()).x)<4.98&&b.min.y>3.9&&b.max.y<4.8);
 shiftParts(s,(b,m)=>ancestor(m,'art3-gate')&&b.min.y>5.27&&b.max.y<7.2&&Math.abs(b.getCenter(new T.Vector3()).x)<7.3&&b.min.z>-7&&b.max.z<-3,[0,-.05,0]);
 // A distant pavilion roof floated 2.6 m above the hill behind the wall, with a flight of steps leading to it: removed (the r8a horizon replaces it).
 pruneParts(s,(b,m)=>ancestor(m,'art3-gate')&&b.min.z<-27&&b.min.y>7.5);
 pruneParts(s,(b,m)=>ancestor(m,'art3-gate')&&/plaster/.test(m.material?.name||'')&&b.max.z<-21.3&&b.min.y>.5&&b.max.x-b.min.x<3.5);
 changes.push({scene:'gate',object:'floating distant pavilion roofs + hillside steps',from:[0,9.4,-33.4],to:null},{scene:'gate',object:'牌坊 centre roof seated on its bracket row',from:'y 5.30',to:'y 5.25'});
 shiftParts(s,(b,m)=>/roofTile/.test(m.material?.name||'')&&Math.abs(b.min.y-3.39)<.03&&b.getSize(new T.Vector3()).x<4.5,[0,-.06,0]);
 s.blocks.push({x:-4.55,X:-3.75,z:-5.4,Z:-4.6,r8a:'paifang column'},{x:3.75,X:4.55,z:-5.4,Z:-4.6,r8a:'paifang column'});
 // Side roofs dipped 17 cm below the column caps (cap top 3.48, roof underside 3.31): lift the side-bay roofs and their ridge pieces.
 xformParts(s,(b,m)=>!ancestor(m,'r8a-paifang-centre')&&b.min.y>3.28&&b.min.y<4.15&&b.max.y<4.45&&b.max.y>3.55&&b.min.z>-6.5&&b.max.z<-3.5&&(()=>{const x=Math.abs(b.getCenter(new T.Vector3()).x);return x>4.3&&x<8.4;})()&&!(b.getSize(new T.Vector3()).x<.7&&b.getSize(new T.Vector3()).y<.15),b=>new T.Matrix4().makeTranslation(0,.17,0));
 xformParts(s,(b,m)=>m.isInstancedMesh&&hex(m)==='2f3b3b'&&b.min.y>3.9&&b.min.y<4.1&&(()=>{const x=Math.abs(b.getCenter(new T.Vector3()).x);return x>7.4&&x<8.4;})(),b=>new T.Matrix4().makeTranslation(0,.17,0));
 pruneParts(s,(b,m)=>!ancestor(m,'r8a-distance')&&hex(m)==='f5e8cd'&&b.min.y>8);
 // Outer columns ran through their plinths: start them on the plinth top.
 xformParts(s,(b,m)=>m.isInstancedMesh&&ancestor(m,'art3-gate')&&b.min.y<.05&&Math.abs(b.max.y-3.4)<.05&&Math.abs(Math.abs(b.getCenter(new T.Vector3()).x)-7.5)<.1&&near(b,b.getCenter(new T.Vector3()).x,-5,.2),spanY(.4,3.4));
 changes.push({scene:'gate',object:'牌坊 inner columns + centre lintel (centre roof was floating)',from:null,to:[[-4.15,0,-5],[4.15,0,-5]]},{scene:'gate',object:'side-bay roofs lifted onto column caps; outer columns seated on plinths',from:'roof 3.31',to:'3.48'});
}
// r8a layout/scenery hooks.
function dress(){if(!W3?.spaces?.plaza||W3.r8a)return;W3.r8a=true;pruneParts(W3.spaces.plaza);pruneParts(W3.spaces.gate);pruneParts(W3.spaces.plaza,(box,m)=>{let art=false;for(let p=m;p;p=p.parent)if(p.name==='art3-plaza')art=true;const c=box.getCenter(new T.Vector3());return art&&Math.hypot(c.x,c.z+15.2)<1.6;});plazaLayout();prepareCanopy();horizon(W3.spaces.plaza,'plaza');horizon(W3.spaces.gate,'gate');approach();trimPostFlowers(W3.spaces.gate);deduplicate(W3.spaces.plaza);deduplicate(W3.spaces.gate);}

function fixScene(name){const s=W3.spaces[name];if(!s||s.r8aFixed)return;s.r8aFixed=true;
 if(name==='hall')hallFixes();
 if(!['plaza','gate'].includes(name))return;
 if(name==='plaza')plazaFixes();else gateFixes();
 pruneParts(s,(b,m)=>m.isInstancedMesh&&b.max.y<.6&&Math.max(b.max.x-b.min.x,b.max.z-b.min.z)<.5&&(s.r8aClear||[]).some(([x,z,X,Z])=>{const c=b.getCenter(new T.Vector3());return c.x>x&&c.x<X&&c.z>z&&c.z<Z;}));
 reconcile(s,name);crownBlocks(s,name);s.r8CameraBoxes=logicalBoxes(s).filter(({box:b,mesh:m})=>{if(m.userData.wallSign||m.userData.r41Label)return false;const z=b.getSize(new T.Vector3());return Math.min(z.x,z.z)>.05&&(z.y>.45||(b.min.y>2&&z.y>.08));});}
const init=initWorld;initWorld=function(){const r=init.apply(this,arguments);dress();return r;};
const spawn=r3Spawn;r3Spawn=function(n,p){
 // r8a: arrival views. Through the 里门 you arrive just outside the 牌坊 and look back at it (establishing view,
 // camera in the open court; it used to sit behind the 牌坊 and drop under its lintel). Back in the plaza, arrive
 // in front of the south exit frame so it is not between the camera and the player.
 if(n==='gate'&&(p==='plaza'||!p))return [0,-.8,0];
 if(n==='plaza'&&p==='gate')return [0,12.6,0];
 if(n==='plaza'){if(p==='market')return [20.5,0,-Math.PI/2];if(!['yard','tea','home','gate'].includes(p))return [0,12.6,0];}return spawn.apply(this,arguments);};
const enter=worldEnter;worldEnter=function(){entry=null;const r=enter.apply(this,arguments);dress();fixScene(W3.active);entry={scene:W3.active,position:W3.player.position.clone()};state=null;worldCamera(1);return r;};
/* r8a: free title 游方客 → 行客 (id free_youfangke unchanged; legacy name mapped in r7g STORED/TITLE_OFF). avatar.js is codex2's: rename its palette at runtime. */
{const ren=()=>{const p=window.TG_AVATAR?.palette?.title;if(Array.isArray(p)){const i=p.indexOf('游方客');if(i>=0)p[i]='行客';}
  try{if(typeof S!=='undefined'&&S?.avatar?.title==='游方客')S.avatar.title='行客';}catch(e){}};ren();window.addEventListener('load',ren);setTimeout(ren,0);}
/* r8a buttons-audit H: (1) the 缘堂 demo lock kept its .show class (and focus could stay in its hidden passcode
   input) after leaving 缘堂, so worldBlocked() stayed true and the yard never offered prompts again. Clear the lock
   and blur any field on every scene change, and only let the lock block while 缘堂 is the active scene.
   (2) the offline demo lock (only shown when TG_ACCESS is absent; deployed builds skip it) no longer prints its code.
   (3) the 🎐 button inherited pointer-events:none from .scene and could not be tapped. */
{const prevGo=go;go=function(){try{const gl=document.getElementById('gateLock');if(gl)gl.classList.remove('show');const ae=document.activeElement;if(ae&&/^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName))ae.blur();}catch(e){}return prevGo.apply(this,arguments);};
 worldBlocked=function(){const gl=document.getElementById('gateLock'),ae=document.activeElement;
  return !!window.TG_PLAN||switching||document.getElementById('modal').classList.contains('show')||(!!gl&&gl.classList.contains('show')&&W3?.active==='hall'&&gl.getClientRects().length>0)||(!!ae&&/^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName)&&ae.getClientRects().length>0);};
 const hint=[...document.querySelectorAll('#gateLock .muted')].find(e=>/8888/.test(e.textContent));if(hint)hint.remove();
 const lockTxt=()=>{const h=document.querySelector('#gateLock h3');if(h)h.textContent='缘堂';const p=document.querySelector('#gateLock p.muted');if(p&&/口令/.test(p.textContent))p.textContent='在院子里收获 3 份作物即可进入（也可输入口令）';const g=document.getElementById('lockGo');if(g)g.textContent='进入缘堂';const f=[...document.querySelectorAll('#gateLock p.muted')].find(e=>/短信/.test(e.textContent));if(f)f.textContent='';};lockTxt();
 const toastRaw=window.toast;if(typeof toastRaw==='function'){toast=function(msg,...r){if(typeof msg==='string'&&/演示口令/.test(msg))msg='口令不对，可以先去院子里收获作物';if(typeof msg==='string')msg=msg.replace('欢迎进入祠堂','欢迎来到缘堂');return toastRaw.call(this,msg,...r);};}
 const st=document.createElement('style');st.textContent='#hall.active #muyu{pointer-events:auto;z-index:12;min-width:44px;min-height:44px;display:flex!important;align-items:center;justify-content:center}';document.head.append(st);
 if(typeof R3_STYLES!=='undefined'&&R3_STYLES.palace&&/宫殿/.test(R3_STYLES.palace.name))R3_STYLES.palace.name='朱红厅堂';}
window.TG_R8={version:'r8a',lib:{pruneParts,shiftParts,xformParts,spanY,logicalBoxes,reconcile,crownBlocks,components,baked,horizon,rng,colored,mergeColored,near,hex,ancestor,matOf,cameraMeshes,firstHit,indoor},cameraOwns:true,replaceStalls:true,changes,relocate,components,firstHit:(from,to)=>firstHit(W3.spaces[W3.active],new T.Vector3(...from),new T.Vector3(...to)),logicalBoxes:()=>logicalBoxes(W3.spaces[W3.active]),cameraMeshes:()=>cameraMeshes(W3.spaces[W3.active])};
})();

/* r8a.1 — 缘堂 entry is a pure tutorial gate (来福's decision): no passcode field and no digit code anywhere.
   Not yet harvested 3 times → a gentle hint the player can close (back to the yard); once the condition is met
   the hall opens automatically (enterHall already auto-unlocks at UNLOCK_HARVEST). TG_ACCESS / r3SkipDemoGate untouched. */
(function(){
 const $q=s=>document.querySelector(s),gl=$q('#gateLock');if(!gl)return;
 const inp=$q('#passInput');if(inp){inp.style.display='none';inp.disabled=true;inp.tabIndex=-1;inp.setAttribute('aria-hidden','true');}
 const goBtn=$q('#lockGo');if(goBtn)goBtn.style.display='none';
 const set=()=>{const h=$q('#gateLock h3');if(h)h.textContent='缘堂还没开门';
  [...gl.querySelectorAll('p.muted,div.muted')].forEach(e=>{if(e.id==='lockProgTxt')return;if(/口令|8888|短信|演示/.test(e.textContent))e.remove();});
  let p=$q('#r8a1Hint');if(!p){p=document.createElement('p');p.id='r8a1Hint';p.className='muted';const card=$q('#lockCard'),doors=card&&card.querySelector('h3');if(doors)doors.after(p);else gl.prepend(p);}
  p.textContent='先在小院收 3 次菜，缘堂就会为你打开';
  const back=$q('#lockBack');if(back)back.textContent='回小院';};
 set();
 // passcode entry is gone: Enter/“进入” can no longer unlock; only the harvest condition does.
 tryUnlock=function(){if(typeof r3SkipDemoGate==='function'&&r3SkipDemoGate()){gl.classList.remove('show');return;}
  if(S.harvestTotal>=UNLOCK_HARVEST){S.unlocked=true;try{tgFeedback('unlock');}catch(e){}save();gl.classList.remove('show');toast('缘堂为你打开了');try{renderYard();}catch(e){}}};
 const sg=showGate;showGate=function(){const r=sg.apply(this,arguments);set();if(inp)inp.blur();return r;};
 // tap the dim backdrop (outside the card) or press Esc = 回小院
 gl.addEventListener('click',e=>{if(e.target===gl&&gl.classList.contains('show'))$q('#lockBack')?.click();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&gl.classList.contains('show'))$q('#lockBack')?.click();});
})();

/* r8a.2 — fixes from codex2's r8a re-check (qa/r8-audit/r8a-recheck.md, qa/r8a-recheck/buttons.r8a.md).
   Camera: see worldCamera above (trunk never tilted over, collision pull-in rate-limited, 0.7 m/frame hard cap).
   This block: 🎐 on-screen in landscape, gate card, every dead button answers, overlays close on backdrop/Esc,
   overlapping 3D prompts pulled apart, 44 px hit areas. Economy, IDs, save key and RPCs untouched. */
(function(){
 const $q=s=>document.querySelector(s),say=m=>{try{toast(m);}catch(e){}};
 const css=document.createElement('style');css.id='r8a2-css';css.textContent=`
#hall.active #muyu{top:calc(var(--safe-top,0px) + min(445px,100vh - 160px))!important}
@media (orientation:landscape) and (max-height:540px){#hall.active #muyu{top:auto!important;bottom:calc(env(safe-area-inset-bottom,0px) + 18px)!important;right:calc(env(safe-area-inset-right,0px) + 24px)!important;left:auto!important}}
#gateLock{position:fixed!important;inset:0!important;z-index:1000!important;padding:max(20px,env(safe-area-inset-top)) max(20px,env(safe-area-inset-right)) max(20px,env(safe-area-inset-bottom)) max(20px,env(safe-area-inset-left))!important}
#gateLock #lockBack{min-height:var(--tg-hit,44px);min-width:148px;padding:0 24px;font-size:15px}
#r41Waypoints button{min-height:var(--tg-hit,44px)!important;font-size:13px!important}
#r7MenuToggle{min-height:var(--tg-hit,44px)!important;min-width:var(--tg-hit,44px)!important}
#sheet .btn,#sheet .inv-item,#sheet .r3-tabs button,#sheet .dirs button,#r6Placement .btn,#r7Drawer .btn{min-height:var(--tg-hit,44px)}
#sheet textarea,.tgfb-root textarea{min-height:88px}
#sheet>.close[data-close]{min-width:var(--tg-hit,44px);min-height:var(--tg-hit,44px)}
#sheet select,#sheet input:not([type=checkbox]):not([type=radio]){min-height:var(--tg-hit,44px)}
.r6-pond-tabs .btn.r8a2-on{background:#c9a24a!important;color:#3a2410!important;border-color:#a8822e!important;cursor:default}
#toast{max-width:min(92vw,520px)}
`;document.head.append(css);

 // ---- 家庭: offline / not signed in, it used to close the menu and do nothing.
 document.addEventListener('click',e=>{const b=e.target.closest?.('#r7Family');if(!b||typeof window.TG_FAMILY?.open==='function')return;
  e.stopImmediatePropagation();e.preventDefault();try{closeModal();}catch(_){}
  openModal('<h2>家庭</h2><p>家庭要登录并联网后使用：邀请家人、一起照看小院、共乘牛车。</p><p class="muted">现在是本地存档。登录后就能创建或加入家庭。</p><p class="center" style="display:flex;gap:10px;justify-content:center"><button class="btn" id="r8a2Login">去登录</button><button class="btn ghost" id="r8a2Later">知道了</button></p>');
  const L=$q('#r8a2Login');if(L)L.onclick=()=>{closeModal();const a=$q('#btnAuth');if(a&&a.offsetParent)a.click();else say('登录需要联网');};
  const K=$q('#r8a2Later');if(K)K.onclick=()=>closeModal();},true);

 // ---- 🪙 pill: when the shop is already open it re-rendered the same sheet; now it toggles the shop closed.
 document.addEventListener('click',e=>{const b=e.target.closest?.('#pillCoins');if(!b||b.disabled)return;
  if($q('#modal')?.classList.contains('show')&&$q('#sheet .r3-tabs')){e.stopImmediatePropagation();closeModal();toast('商铺已收起');}},true);
 // ---- ✨ pill: same message as before, but always readable (landscape toast sat under the HUD).
 // (text is rewritten to 善缘/点灯/摇风铃 by r7-compliance; nothing to change here besides the toast width above)

 // ---- 抽一首诗: the result appeared only after a 2.6 s shake → instant, within one frame.
 const VERSES=[['明月松间照，清泉石上流。','王维'],['采菊东篱下，悠然见南山。','陶渊明'],['绿树村边合，青山郭外斜。','孟浩然'],['海内存知己，天涯若比邻。','王勃'],['行到水穷处，坐看云起时。','王维'],['草长莺飞二月天，拂堤杨柳醉春烟。','高鼎'],['小荷才露尖尖角，早有蜻蜓立上头。','杨万里'],['春眠不觉晓，处处闻啼鸟。','孟浩然'],['等闲识得东风面，万紫千红总是春。','朱熹'],['竹外桃花三两枝，春江水暖鸭先知。','苏轼'],['人闲桂花落，夜静春山空。','王维'],['山重水复疑无路，柳暗花明又一村。','陆游']];
 function poem(){const box=$q('#qianResult');if(!box)return;let i=Math.floor(Math.random()*VERSES.length);if(i===S.r8a2Poem)i=(i+1)%VERSES.length;S.r8a2Poem=i;
  try{tgFeedback('qian');}catch(e){}$q('#tube')?.classList.remove('shaking');document.querySelectorAll('#tubeWrap .outstick').forEach(n=>n.remove());
  const [v,who]=VERSES[i];box.innerHTML=`<div class="qian"><div class="no">今日诗句</div><div class="poem">${v}</div><p style="font-size:13px;color:#9a7a50">—— ${who}</p><p>慢慢来，把眼前的小事做好，也记得照顾自己。</p></div><p class="center"><button class="btn ghost" id="qianAgain">再读一句</button></p>`;
  const b=$q('#qianBtn');if(b)b.disabled=false;requestAnimationFrame(()=>box.scrollIntoView?.({block:'nearest'}));}
 document.addEventListener('click',e=>{const b=e.target.closest?.('#qianBtn,#qianAgain');if(!b)return;e.stopImmediatePropagation();e.preventDefault();poem();},true);

 // ---- 赏景小记: the birth-year picker was a fortune-telling leftover and did nothing visible — removed.
 const om=openModal;openModal=function(){const r=om.apply(this,arguments);try{post();}catch(e){}return r;};
 function post(){const y=$q('#fengYear');if(y){const row=y.closest('.form-row')||y.parentElement;if(row)row.style.display='none';y.tabIndex=-1;
   // r7d keeps rewriting the first <p> after the title, so show our own line and hide that one
   const intro=$q('#sheet h2 + p');if(intro&&!$q('#r8a2FengIntro')){intro.style.display='none';const d=document.createElement('div');d.id='r8a2FengIntro';d.className='center';d.style.cssText='font-size:13px;color:#7a5a3a;margin:6px 0 10px';d.textContent='选一个院子朝向，写下今天的赏景小记。';intro.after(d);}}
  // 莲池 tabs: show which one is open (tapping the open tab looked dead)
  const tab=window.r8a2PondTab||'koi';document.querySelectorAll('#sheet .r6-pond-tabs [data-pond]').forEach(b=>{const on=b.dataset.pond===tab;b.classList.toggle('r8a2-on',on);b.setAttribute('aria-pressed',String(on));b.disabled=on;});}
 if(typeof window.r6PondOpen==='function'){const po=window.r6PondOpen;window.r6PondOpen=function(tab='koi'){window.r8a2PondTab=tab;return po.apply(this,arguments);};}

 document.addEventListener('click',e=>{if(!e.target.closest?.('#fengBtn'))return;const clean=()=>document.querySelectorAll('#fengResult p.center[style*="20px"],#fengResult p.center[style*="7a5a3a"]').forEach(n=>n.remove()); /* birth-year heading + 性格关键词 (derived from the year) */setTimeout(clean,0);setTimeout(clean,120);},true);
 // ---- 摆放心意: tapping a produce you don't have now says so (and where to get it).
 document.addEventListener('click',e=>{const b=e.target.closest?.('#sheet [data-r6-offer]');if(!b)return;const id=b.dataset.r6Offer;
  const bag=(typeof CROP_BY_ID!=='undefined'&&CROP_BY_ID[id])||(typeof R3_PRODUCE!=='undefined'&&R3_PRODUCE.some(c=>c.id===id))?S.inventory:S.backpack;
  if(!(bag&&bag[id]>0)){e.stopImmediatePropagation();const name=b.textContent.replace(/·.*$/,'').trim();say(`还没有${name}：先去心田小院收获，再来摆放`);b.classList.add('r8a2-empty');}},true);

 // ---- 茶会 留笺: empty note did nothing; a posted note had no confirmation.
 document.addEventListener('click',e=>{const b=e.target.closest?.('#r6Send');if(!b)return;const i=$q('#r6Message'),t=(i?.value||'').trim();
  if(!t){e.stopImmediatePropagation();say('先写一句再留笺');i?.focus();return;}
  const n=(S.tea?.messages||[]).length;setTimeout(()=>{if((S.tea?.messages||[]).length>n||!$q('#r6Message')||$q('#r6Message').value==='')say('留笺已贴上墙');},400);},true);

 // ---- 立体布置: 升高/降低/收回 with nothing selected gave no sign; Esc and a second tap on empty ground finish.
 document.addEventListener('click',e=>{const b=e.target.closest?.('#r6PlaceLower,#r6PlaceRaise,#r6PlaceReturn,#r6PlaceRotate');const p=W3?.r6Plan;if(!b||!p)return;
  if(b.id==='r6PlaceReturn'){if(p.selected<0){e.stopImmediatePropagation();say('先点一件已摆好的物品，再收回');}else setTimeout(()=>say('已收回背包'),30);return;}
  setTimeout(()=>{const q=W3.r6Plan;if(!q)return;const list=S.decor[q.scene]||[];
   if(b.id==='r6PlaceRotate'){say(q.selected>=0?'已旋转 90°':'下一件物品将旋转 90° 摆放');return;}
   if(q.selected>=0){const v=list[q.selected];say(`${r3Item(v?.id)?.name||'物品'} 高度 ${(v?.y||0).toFixed(1)} 米`);}else say(`放置高度 ${q.height>=0?'+':''}${q.height.toFixed(1)} 米 · 先在下方选一件物品`);},30);},true);
 const finish=()=>{const d=$q('#r6PlaceDone');if(d)d.click();};
 document.addEventListener('keydown',e=>{if(e.key!=='Escape')return;if(W3?.r6Plan&&$q('#r6Placement')){e.preventDefault();finish();return;}
  const dr=$q('#r7Drawer');if(dr&&!dr.hidden){dr.hidden=true;$q('#r7MenuToggle')?.setAttribute('aria-expanded','false');}});
 let emptyTap=0;
 function hookCanvas(){if(window.r8a2Taps)return;window.r8a2Taps=true;let down=null;
  addEventListener('pointerdown',e=>{down=W3?.r6Plan&&e.target===W3.canvas?{x:e.clientX,y:e.clientY,t:performance.now()}:null;},true);
  addEventListener('pointerup',e=>{const p=W3?.r6Plan,d=down;down=null;if(!p||!d||e.target!==W3.canvas||Math.hypot(e.clientX-d.x,e.clientY-d.y)>10||p.pick||p.selected>=0)return;
   // a tap that selects nothing = a tap on the "backdrop" of placement mode: first one hints, second one finishes
   setTimeout(()=>{const q=W3.r6Plan;if(!q||q.selected>=0||q.pick)return;const now=performance.now();if(now-emptyTap<2500){emptyTap=0;finish();}else{emptyTap=now;say('再点一次空白处结束布置（或点「完成」）');}},30);},true);}
 // ---- tool drawer: closes on a tap outside it (and on Esc, above)
 document.addEventListener('pointerdown',e=>{const dr=$q('#r7Drawer');if(!dr||dr.hidden)return;if(e.target.closest?.('#r7Drawer,#r7MenuToggle,#modal,#gateLock'))return;dr.hidden=true;$q('#r7MenuToggle')?.setAttribute('aria-expanded','false');},true);

 // ---- 3D prompts that stole each other's spot
 function separate(name){const s=W3?.spaces?.[name];if(!s)return;
  if(name==='hall'&&!s.r8a2){s.r8a2=true;// 摇风铃 sat 1.8 m from 前往书房: the auto-exit fires before the exit prompt could ever win
   const g=s.group.getObjectByName('r7-garden-chime');if(g){g.position.z+=-3.5;g.updateMatrixWorld(true);}
   for(const it of s.items)if(it.label==='摇风铃'&&Math.abs(it.x+4)<.2&&Math.abs(it.z-3)<.2){it.z=-.5;it.range=1.6;}
   (window.TG_R8?.changes||[]).push?.({scene:'hall',object:'摇风铃 (chime + prompt) away from 前往书房',from:'(-4,2) / prompt (-4,3)',to:'(-4,-1.5) / prompt (-4,-0.5)'});}
  if(name==='zen'){// legacy r3 seat prompts 「坐下」 duplicated the r7b cushions 「坐下喝茶」 on the same spots
   const tea=s.items.filter(i=>i.label==='坐下喝茶');s.items=s.items.filter(i=>!(i.r4Furniture&&i.label==='坐下'&&tea.some(t=>Math.hypot(t.x-i.x,t.z-i.z)<1.3)));}}
 const sync=worldSyncDecor;worldSyncDecor=function(){const r=sync.apply(this,arguments);try{separate(W3.active);}catch(e){}return r;};
 const en=worldEnter;worldEnter=function(){const r=en.apply(this,arguments);try{hookCanvas();separate(W3.active);}catch(e){}return r;};
 window.TG_R8A2={version:'r8a.2'};
})();
