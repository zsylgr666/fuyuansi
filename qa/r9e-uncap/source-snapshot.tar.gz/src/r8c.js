/* r8c-0 (codex2 r8b H, null.trim pageerror after the 捏脸 panel): three.js runs getProgramInfoLog()/getShaderInfoLog().trim();
   on a lost WebGL context (the 捏脸 preview renderer is disposed with forceContextLoss, and SwiftShader can drop a context) these
   return null → "Cannot read properties of null (reading 'trim')". Null-safe: a lost context yields '' instead of throwing. */
(()=>{for(const C of [window.WebGL2RenderingContext,window.WebGLRenderingContext])if(C&&!C.prototype.__r8cLog){C.prototype.__r8cLog=true;
 for(const k of ['getProgramInfoLog','getShaderInfoLog','getShaderSource']){const f=C.prototype[k];if(f)C.prototype[k]=function(){const r=f.apply(this,arguments);return r==null?'':r;};}}})();
/* r8c-0b (r8c.1): the runtime 诗笺 rewrite was removed — r7c/r7d/world3d now carry 「每日诗笺」 at source. */
/* r8c.js — 福缘里 r8c sidecar (runs after r8b.js). Overrides codex2 behaviour at runtime only; no codex2 file, backend,
   economy, ID, save key or RPC is touched.
   1. Draw calls ("一定要流畅"):
      a) Static render batching: every static, opaque mesh/instanced mesh of the active scene that shares a material
         signature (type, maps, side, shading, emissive, shadow flags …) is drawn through ONE merged render proxy per
         signature; the material colour (× vertex colour × instance colour) is baked into a colour attribute.
         The source meshes stay in the scene graph untouched (raycasts, colliders, interaction points, audits, game code
         all keep seeing them) — they are only skipped by the renderer's frustum test (userData.r8cHide).
         Every frame the sources are checked (parent, visibility chain, material, geometry, matrix, colours, instance
         buffers); any change un-batches that proxy, marks the changed source dynamic and re-batches the rest later.
      b) Avatars (player, NPCs, remote players): the 7–8 rigid parts sharing TG_AVATAR's material are drawn as one
         rigidly-skinned SkinnedMesh whose bones are the part meshes themselves (same animation, 1 call + 1 shadow call
         instead of 8 + 8). Rebuilt when a part's geometry / visibility changes (outfit update, sit/ride pose).
*/
(function(){
if(window.TG_R8C)return;
const T=THREE;const R8C=window.TG_R8C={stats:{},changes:[],off:/[?&]r8cnobatch/.test(location.search)};
// ---- renderer-only hide: frustum test says "outside" for hidden sources (raycasts are unaffected) ----
{const FP=T.Frustum.prototype,io=FP.intersectsObject;FP.intersectsObject=function(o){if(o.userData.r8cHide)return false;return io.call(this,o);};}
function hide(o){if(o.userData.r8cHide)return;o.userData.r8cHide=true;o.userData.r8cFC=o.frustumCulled;o.frustumCulled=true;}
function show(o){if(!o.userData.r8cHide)return;o.userData.r8cHide=false;o.frustumCulled=o.userData.r8cFC;delete o.userData.r8cFC;}

// ===================== a) static batching =====================
const SKIPU=['tgNpc','npc','tgAvatar','r6Ride','r6Passenger','r6Ghost','r6Hk','r6Fade','r41Label','wallSign','r6Lanterns','r8cDyn','npcNoOcclude','r7TreeSoft','__text','r6Label','r8cBatch','r8cLamp','r8cFade'];
const SKIPN=/avatar|npc|player|remote|animal|koi|fish|bird|butterfly|r6Ride|mount|smoke|particle|petal|cloud|water|r7-wish-tree|r7f-wish-tags|r8a-mist|r8a-sky/i;
const OKMAT=new Set(['MeshLambertMaterial','MeshStandardMaterial','MeshPhongMaterial','MeshBasicMaterial','MeshToonMaterial','MeshPhysicalMaterial']);
const OBC=T.Material.prototype.onBeforeCompile,OBR=T.Object3D.prototype.onBeforeRender;
const MAPS=['map','normalMap','roughnessMap','metalnessMap','emissiveMap','alphaMap','bumpMap','envMap','specularMap','displacementMap','gradientMap','matcap','clearcoatMap'];
function skipNode(o,s){if(o===W3.player||o===s.animalGroup)return true;const u=o.userData||{};for(const k of SKIPU)if(u[k])return true;return SKIPN.test(o.name||'');}
function matKey(m,o){if(!m||Array.isArray(m)||!OKMAT.has(m.type)||m.visible===false||m.transparent||m.opacity<1||m.colorWrite===false||m.vertexAlpha||m.alphaHash)return null;
 const ok=obcKey(m);if(ok===null||m.aoMap||m.lightMap||!defOK(m)||m.clippingPlanes)return null;
 const k=[m.type,m.side,m.flatShading?1:0,m.alphaTest,m.fog?1:0,m.depthTest?1:0,m.depthWrite?1:0,m.polygonOffset?[m.polygonOffsetFactor,m.polygonOffsetUnits].join('/'):0,m.toneMapped?1:0,m.wireframe?1:0,m.blending,m.dithering?1:0,
  m.emissive?m.emissive.getHexString()+'*'+m.emissiveIntensity:'',m.roughness??'',m.metalness??'',m.shininess??'',m.specular?m.specular.getHexString():'',m.reflectivity??'',m.envMapIntensity??'',m.normalScale?m.normalScale.x+','+m.normalScale.y:'',m.bumpScale??'',
  o.castShadow?1:0,o.receiveShadow?1:0,o.renderOrder,ok];
 for(const n of MAPS)k.push(m[n]?m[n].uuid:'');return k.join('|');}
// shader patches that are safe to batch: realism.js world-space box UV (depends on world position/normal only)
function obcKey(m){if(m.onBeforeCompile===OBC)return '';const u=m.userData?.tgUniforms;if(u&&m.userData.tgWorldUV!=null&&m.customProgramCacheKey?.()==='tgWorldUV1')return 'wuv'+u.tgUVScale.value+':'+u.tgFlow.value.x+','+u.tgFlow.value.y;return null;}
const DEF={};function defOK(m){const d=m.defines||{};const ref=DEF[m.type]||(DEF[m.type]=JSON.stringify(new T[m.type]().defines||{}));return JSON.stringify(d)===ref;}
function needsUV(m){return MAPS.some(n=>n!=='envMap'&&n!=='matcap'&&m[n]);}
function colSnap(m){return (m.color?m.color.r+','+m.color.g+','+m.color.b:'')+'|'+(m.emissive?m.emissive.getHexString()+m.emissiveIntensity:'')+'|'+m.opacity+'|'+m.transparent+'|'+m.visible+'|'+m.version;}
function candidates(s){const out=[];
 const walk=o=>{if(!o.visible)return;if(o!==s.group&&skipNode(o,s))return;
  if(o.isMesh&&!o.isSkinnedMesh&&!o.isSprite){const g=o.geometry,m=o.material;
   if(g&&g.attributes?.position&&g.attributes.normal&&!g.morphAttributes?.position&&g.drawRange.count===Infinity&&g.drawRange.start===0&&o.layers.mask===1&&o.onBeforeRender===OBR&&!o.morphTargetInfluences){
    const key=matKey(m,o);const n=g.attributes.position.count*(o.isInstancedMesh?o.count:1);
    if(key&&n>0&&n<=120000&&!(needsUV(m)&&!g.attributes.uv)&&!(m.vertexColors&&g.attributes.color&&g.attributes.color.itemSize===4&&m.transparent))out.push({o,key});}}
  for(const c of o.children)walk(c);};
 walk(s.group);return out;}
function snapOf(o){o.updateWorldMatrix(true,false);return {parent:o.parent,mat:o.material,geo:o.geometry,mw:Float64Array.from(o.matrixWorld.elements),col:colSnap(o.material),pv:o.geometry.attributes.position.version,
 im:o.isInstancedMesh?o.instanceMatrix.version+':'+o.count+':'+(o.instanceColor?o.instanceColor.version:'-'):'',vis:visTo(o)};}
function visTo(o){let n='';for(let p=o;p;p=p.parent){if(!p.visible)return 'x';if(p.userData?.r8cSpace)break;}return 'v';}
function same(o,a){if(o.parent!==a.parent||o.material!==a.mat||o.geometry!==a.geo)return false;
 const e=o.matrixWorld.elements;for(let i=0;i<16;i++)if(Math.abs(e[i]-a.mw[i])>1e-6)return false;
 if(o.geometry.attributes.position.version!==a.pv)return false;if(colSnap(o.material)!==a.col)return false;
 if(o.isInstancedMesh&&(o.instanceMatrix.version+':'+o.count+':'+(o.instanceColor?o.instanceColor.version:'-'))!==a.im)return false;
 return visTo(o)===a.vis;}
const _m=new T.Matrix4(),_n=new T.Matrix3(),_v=new T.Vector3(),_c=new T.Color(),_ic=new T.Color();
function build(s,list){// list: [{o,key}] same key
 s.group.updateMatrixWorld(true);const inv=s.group.matrixWorld.clone().invert();const m0=list[0].o.material,uv=needsUV(m0);
 let nv=0,ni=0;const parts=[];
 for(const {o} of list){const g=o.geometry,cnt=o.isInstancedMesh?o.count:1,pc=g.attributes.position.count,ic=g.index?g.index.count:pc;
  for(let k=0;k<cnt;k++){_m.multiplyMatrices(inv,o.matrixWorld);if(o.isInstancedMesh){const im=new T.Matrix4();o.getMatrixAt(k,im);_m.multiply(im);}
   if(o.isInstancedMesh){const e=_m.elements;if(!isFinite(e[0])||_m.determinant()===0)continue;}
   parts.push({o,k,M:_m.clone()});nv+=pc;ni+=ic;}}
 if(nv===0)return null;
 const wuv=m0.onBeforeCompile!==OBC,WN=wuv?new Float32Array(nv*3):null;const P=new Float32Array(nv*3),N=new Float32Array(nv*3),C=new Float32Array(nv*3),U=uv?new Float32Array(nv*2):null,I=nv>65535?new Uint32Array(ni):new Uint16Array(ni);
 let vo=0,io=0;
 for(const {o,k,M} of parts){const g=o.geometry,pos=g.attributes.position,nor=g.attributes.normal,col=(o.material.vertexColors&&g.attributes.color)||null,u=g.attributes.uv;const m=o.material;
  _n.getNormalMatrix(M);const flip=M.determinant()<0;_c.copy(m.color||_c.set(1,1,1));if(o.isInstancedMesh&&o.instanceColor){o.getColorAt(k,_ic);_c.multiply(_ic);}
  const base=vo;
  for(let i=0;i<pos.count;i++){_v.fromBufferAttribute(pos,i).applyMatrix4(M);P[vo*3]=_v.x;P[vo*3+1]=_v.y;P[vo*3+2]=_v.z;
   if(nor){if(WN){_v.fromBufferAttribute(nor,i).transformDirection(M);WN[vo*3]=_v.x;WN[vo*3+1]=_v.y;WN[vo*3+2]=_v.z;}_v.fromBufferAttribute(nor,i).applyMatrix3(_n).normalize();N[vo*3]=_v.x;N[vo*3+1]=_v.y;N[vo*3+2]=_v.z;}
   let r=_c.r,gg=_c.g,b=_c.b;if(col){r*=col.getX(i);gg*=col.getY(i);b*=col.getZ(i);}C[vo*3]=r;C[vo*3+1]=gg;C[vo*3+2]=b;
   if(U&&u){U[vo*2]=u.getX(i);U[vo*2+1]=u.getY(i);}vo++;}
  const ix=g.index,cnt=ix?ix.count:pos.count;
  for(let t=0;t<cnt;t+=3){const a=ix?ix.getX(t):t,b2=ix?ix.getX(t+1):t+1,c2=ix?ix.getX(t+2):t+2;I[io++]=base+a;if(flip){I[io++]=base+c2;I[io++]=base+b2;}else{I[io++]=base+b2;I[io++]=base+c2;}}
 }
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(P,3));geo.setAttribute('normal',new T.BufferAttribute(N,3));geo.setAttribute('color',new T.BufferAttribute(C,3));if(U)geo.setAttribute('uv',new T.BufferAttribute(U,2));if(WN)geo.setAttribute('tgUVN',new T.BufferAttribute(WN,3));
 geo.setIndex(new T.BufferAttribute(I.subarray(0,io),1));geo.computeBoundingBox();geo.computeBoundingSphere();
 const mat=m0.clone();if(m0.onBeforeCompile!==OBC){const ob=m0.onBeforeCompile,ck=m0.customProgramCacheKey;
  // realism's box projection picks the axis from mat3(modelMatrix)*normal of the ORIGINAL mesh (scale included): feed it that direction
  mat.onBeforeCompile=function(sh,r){ob.call(this,sh,r);sh.vertexShader='attribute vec3 tgUVN;\n'+sh.vertexShader.replace('normalize(mat3(tgM)*objectNormal)','normalize(mat3(tgM)*tgUVN)');};
  mat.customProgramCacheKey=()=>String(ck?.())+'-r8cUVN';mat.userData.tgUniforms=m0.userData.tgUniforms;}mat.vertexColors=true;if(mat.color)mat.color.setRGB(1,1,1);mat.name='r8c-batch';
 const px=new T.Mesh(geo,mat);px.name='r8c-batch';px.castShadow=list[0].o.castShadow;px.receiveShadow=list[0].o.receiveShadow;px.renderOrder=list[0].o.renderOrder;
 px.userData={r8cBatch:true,npcNoOcclude:true,r6Merged:true};px.raycast=()=>{};px.matrixAutoUpdate=false;
 return px;}
function batchScene(s,name){if(R8C.off)return;s.group.userData.r8cSpace=true;
 const st=s.r8c||(s.r8c={batches:[],pend:null,t0:performance.now()});
 const cand=candidates(s).filter(c=>!c.o.userData.r8cIn);
 const groups=new Map();for(const c of cand){if(!groups.has(c.key))groups.set(c.key,[]);groups.get(c.key).push(c);}
 let made=0,srcs=0;
 for(const [key,list] of groups){if(list.length<2&&!(list[0].o.isInstancedMesh&&false))continue;
  const px=build(s,list);if(!px)continue;s.group.add(px);px.updateMatrixWorld(true);
  const recs=list.map(({o})=>{const r={o,snap:snapOf(o)};o.userData.r8cIn=true;hide(o);return r;});
  st.batches.push({px,recs,key});made++;srcs+=list.length;}
 R8C.stats[name]={batches:st.batches.length,sources:st.batches.reduce((a,b)=>a+b.recs.length,0),last:{made,srcs}};}
function unbatch(s,b,why){const i=s.r8c.batches.indexOf(b);if(i>=0)s.r8c.batches.splice(i,1);b.px.parent?.remove(b.px);b.px.geometry.dispose();b.px.material.dispose();
 for(const r of b.recs){show(r.o);r.o.userData.r8cIn=false;}R8C.changes.push({t:Math.round(performance.now()),why});}
function unbatchAll(s){if(!s?.r8c)return;for(const b of [...s.r8c.batches])unbatch(s,b,'reset');}
R8C.diag=()=>{const s=W3.spaces[W3.active],out={};const inc=new Set(candidates(s).map(c=>c.o));
 s.group.traverse(o=>{if(!o.isMesh||o.userData.r8cIn||o.userData.r8cBatch)return;let r;
  if(inc.has(o))r='cand-single';else{let sk=null;for(let p=o;p&&p!==s.group;p=p.parent)if(skipNode(p,s)){sk='skip:'+(p.name||Object.keys(p.userData).filter(k=>SKIPU.includes(k)).join());break;}
   const m=o.material;r=sk||(Array.isArray(m)?'multimat':!OKMAT.has(m.type)?'type:'+m.type:m.transparent?'transparent':obcKey(m)===null?'obc:'+(m.customProgramCacheKey?.()||'?'):!defOK(m)?'defines':!o.geometry.attributes.normal?'nonormal':o.layers.mask!==1?'layers':o.onBeforeRender!==OBR?'obr':!o.visible?'invisible':'other:'+[o.geometry.drawRange.count,!!o.geometry.morphAttributes?.position,o.geometry.attributes.position.count*(o.count||1),needsUV(m)&&!o.geometry.attributes.uv,o.isSkinnedMesh].join());}
  out[r]=(out[r]||0)+1;});return out;};
// A/B switch for QA: draw the original meshes instead of the proxies (no rebuild, same frame state)
R8C.ab=on=>{for(const s of Object.values(W3.spaces))for(const b of s.r8c?.batches||[]){b.px.visible=!on;for(const r of b.recs)on?show(r.o):hide(r.o);}
 for(const g of AV){const u=g.userData;if(u.r8cSkin)u.r8cSkin.visible=!on;for(const o of u.r8cParts||[])on?show(o):hide(o);}R8C.abOff=on;};
R8C.unbatchAll=()=>{for(const s of Object.values(W3.spaces))unbatchAll(s);};
function check(s){const st=s.r8c;if(!st)return;
 for(const b of [...st.batches]){for(const r of b.recs){if(!same(r.o,r.snap)){r.o.userData.r8cDyn=true;unbatch(s,b,(r.o.name||r.o.type)+' changed');st.pend={at:performance.now()+1500,snaps:null};break;}}}}
// stability window: candidates snapshotted, re-checked 0.8 s later; only unchanged ones are batched
function tick(){const w=W3;if(!w?.active||R8C.off||R8C.abOff)return;const s=w.spaces[w.active];if(!s?.group)return;const now=performance.now();
 if(R8C.lastActive!==w.active){R8C.lastActive=w.active;R8C.enterAt=now;if(s.r8c)s.r8c.pend={at:now+700,snaps:null};}
 if(!s.r8c){s.r8c={batches:[],pend:{at:now+700,snaps:null}};}
 check(s);const p=s.r8c.pend;
 if(p&&now>=p.at){if(!p.snaps){p.snaps=new Map();for(const c of candidates(s))if(!c.o.userData.r8cIn)p.snaps.set(c.o,snapOf(c.o));p.at=now+800;}
  else{for(const [o,sn] of p.snaps)if(!same(o,sn))o.userData.r8cDyn=true;s.r8c.pend=null;batchScene(s,w.active);}}
}

// ===================== b) avatar skinning =====================
const AV=new Set();
function avatarParts(g,MAT){const out=[];g.traverse(o=>{if(o.isMesh&&!o.isSkinnedMesh&&o.material===MAT&&o.geometry?.attributes?.position)out.push(o);});return out;}
function avSig(g,parts){let s='';for(const o of parts){let v=true;for(let p=o;p&&p!==g;p=p.parent)if(!p.visible){v=false;break;}s+=o.uuid.slice(0,8)+o.geometry.uuid.slice(0,8)+(v?1:0)+(o.castShadow?1:0)+(o.receiveShadow?1:0)+o.geometry.attributes.position.version+';';}return s;}
function avBuild(g,MAT){const u=g.userData;if(u.r8cSkin){g.remove(u.r8cSkin);u.r8cSkin.geometry.dispose();u.r8cSkin.skeleton?.dispose();u.r8cSkin=null;}
 for(const o of u.r8cParts||[])show(o);
 const parts=avatarParts(g,MAT);u.r8cParts=[];u.r8cSig=avSig(g,parts);
 const vis=parts.filter(o=>{for(let p=o;p&&p!==g;p=p.parent)if(!p.visible)return false;return true;});if(vis.length<2)return;
 g.updateMatrixWorld(true);const inv=g.matrixWorld.clone().invert();let nv=0,ni=0;
 for(const o of vis){const gg=o.geometry;nv+=gg.attributes.position.count;ni+=gg.index?gg.index.count:gg.attributes.position.count;}
 const P=new Float32Array(nv*3),N=new Float32Array(nv*3),C=new Float32Array(nv*3),SI=new Uint16Array(nv*4),SW=new Float32Array(nv*4),I=nv>65535?new Uint32Array(ni):new Uint16Array(ni);
 let vo=0,io=0;const M=new T.Matrix4(),NM=new T.Matrix3();const bones=[],inverses=[];
 vis.forEach((o,bi)=>{const gg=o.geometry,pos=gg.attributes.position,nor=gg.attributes.normal,col=gg.attributes.color;M.multiplyMatrices(inv,o.matrixWorld);NM.getNormalMatrix(M);const flip=M.determinant()<0;const base=vo;
  for(let i=0;i<pos.count;i++){_v.fromBufferAttribute(pos,i).applyMatrix4(M);P.set([_v.x,_v.y,_v.z],vo*3);if(nor){_v.fromBufferAttribute(nor,i).applyMatrix3(NM).normalize();N.set([_v.x,_v.y,_v.z],vo*3);}
   if(col)C.set([col.getX(i),col.getY(i),col.getZ(i)],vo*3);else C.set([1,1,1],vo*3);SI[vo*4]=bi;SW[vo*4]=1;vo++;}
  const ix=gg.index,cnt=ix?ix.count:pos.count;for(let t=0;t<cnt;t+=3){const a=ix?ix.getX(t):t,b=ix?ix.getX(t+1):t+1,c=ix?ix.getX(t+2):t+2;I[io++]=base+a;if(flip){I[io++]=base+c;I[io++]=base+b;}else{I[io++]=base+b;I[io++]=base+c;}}
  bones.push(o);inverses.push(o.matrixWorld.clone().invert());});
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(P,3));geo.setAttribute('normal',new T.BufferAttribute(N,3));geo.setAttribute('color',new T.BufferAttribute(C,3));
 geo.setAttribute('skinIndex',new T.Uint16BufferAttribute(SI,4));geo.setAttribute('skinWeight',new T.Float32BufferAttribute(SW,4));geo.setIndex(new T.BufferAttribute(I.subarray(0,io),1));geo.computeBoundingSphere();
 const sk=new T.SkinnedMesh(geo,MAT);sk.name='r8c-avatar-skin';sk.userData={r8cBatch:true,npcNoOcclude:true};sk.raycast=()=>{};
 sk.castShadow=vis.some(o=>o.castShadow);sk.receiveShadow=vis.some(o=>o.receiveShadow);g.add(sk);u.r8cSkin=sk;sk.updateMatrixWorld(true);
 sk.bind(new T.Skeleton(bones,inverses),sk.matrixWorld.clone());
 sk.boundingSphere=geo.boundingSphere.clone();sk.boundingSphere.radius+=.8; // limbs swing/sit within this
 for(const o of vis){hide(o);u.r8cParts.push(o);}AV.add(g);}
function avTick(){const A=window.TG_AVATAR;if(!A?.material||R8C.off||R8C.abOff)return;const MAT=A.material();const w=W3,s=w.spaces[w.active];if(!s)return;
 const roots=[];const find=o=>{if(o.userData?.tgAvatar){roots.push(o);return;}for(const c of o.children)find(c);};if(w.player)find(w.player);find(s.group);
 for(const g of roots){const parts=avatarParts(g,MAT);if(g.userData.r8cSig!==avSig(g,parts))avBuild(g,MAT);}
 for(const g of AV){if(!g.parent){const u=g.userData;for(const o of u.r8cParts||[])show(o);AV.delete(g);}}}
R8C.avatarOff=()=>{for(const g of AV){const u=g.userData;if(u.r8cSkin)g.remove(u.r8cSkin);for(const o of u.r8cParts||[])show(o);}};

// ===================== 2. 缘堂 / 静室 / 书房 interiors =====================
// a) complete shell: ceiling just above the wall tops, an outer lining behind the wall panels (closes corner/door-side gaps),
//    and a short vestibule behind every doorway ending in a lit paper screen — no sky is visible from any camera position.
//    Shell pieces never cast shadows (the rooms keep their current lighting) and sit outside the walk limit (no colliders).
const ROOMS={
 hall:{H:5.2,doors:[{side:'z+',c:0,w:4,h:3.4},{side:'x+',c:3.375,w:1.25,h:3.4},{side:'x-',c:3.375,w:1.25,h:3.4},{side:'z-',c:4.5,w:1,h:3.4}]},
 zen:{H:4.2,doors:[{side:'x-',c:0,w:3.1,h:3.3}]},
 study:{H:4.2,doors:[{side:'x+',c:0,w:3.1,h:3.3}]}};
function wallMat(s,H){let best=null;s.group.traverse(m=>{if(best||!m.isMesh||m.userData.r8cShell||!m.material?.map)return;for(let q=m;q&&q!==s.group;q=q.parent)if(!q.visible)return;const b=new T.Box3().setFromObject(m);if(Math.abs(b.max.y-H)<.06&&b.min.y<.05&&(Math.max(-b.min.x,b.max.x)>5.8||Math.max(-b.min.z,b.max.z)>7.8))best=m.material;});return best;}
function shell(s,name){const R=ROOMS[name];if(!R||s.group.getObjectByName('r8c-room-shell'))return;const H=R.H;
 const wm=wallMat(s,H)||new T.MeshLambertMaterial({color:'#b89a72'});const fm=s.floor?.material||wm;
 const paper=new T.MeshBasicMaterial({color:'#efe2c0'}),lat=new T.MeshLambertMaterial({color:'#5e4634'});
 const g=new T.Group();g.name='r8c-room-shell';const add=(mat,x0,x1,y0,y1,z0,z1)=>{const m=new T.Mesh(new T.BoxGeometry(x1-x0,y1-y0,z1-z0),mat);m.position.set((x0+x1)/2,(y0+y1)/2,(z0+z1)/2);m.castShadow=false;m.receiveShadow=true;m.userData.r8cShell=true;g.add(m);return m;};
 const X=6.18,Z=8.18,t=.08;
 // r8c.1: the 缘堂 ceiling (5.2 m, lit only from below by the hemisphere) read almost black → hall-only ceiling material:
 // same texture, a warm emissive lift from its own map (no new light, no geometry change; at most +1 draw call)
 let cm=wm;if(name==='hall'&&wm.emissive){cm=wm.clone();cm.emissive=new T.Color('#7a6142');cm.emissiveMap=wm.map||null;cm.emissiveIntensity=.6;if('roughness' in cm)cm.roughness=Math.min(1,(wm.roughness??1));cm.name='r8c-hall-ceiling';}
 add(cm,-X-t,X+t,H+.02,H+.14,-Z-t,Z+t); // ceiling
 {const L=s.limit;add(fm,-X-t,X+t,-.3,0,L.z-.01,Z+t);add(fm,-X-t,X+t,-.3,0,-Z-t,-L.z+.01);add(fm,L.x-.01,X+t,-.3,0,-L.z,L.z);add(fm,-X-t,-L.x+.01,-.3,0,-L.z,L.z);} // floor ring under the lining
 const sides={'x+':{n:'x',sg:1,len:Z},'x-':{n:'x',sg:-1,len:Z},'z+':{n:'z',sg:1,len:X},'z-':{n:'z',sg:-1,len:X}};
 for(const [k,sd] of Object.entries(sides)){const ds=R.doors.filter(d=>d.side===k).sort((a,b)=>a.c-b.c);let at=-sd.len-t;const seg=(a,b,y0,y1)=>{if(b-a<.01)return;if(sd.n==='x'){const x=sd.sg*X;add(wm,Math.min(x,x+sd.sg*t),Math.max(x,x+sd.sg*t),y0,y1,a,b);}else{const z=sd.sg*Z;add(wm,a,b,y0,y1,Math.min(z,z+sd.sg*t),Math.max(z,z+sd.sg*t));}};
  for(const d of ds){const a=d.c-d.w/2,b=d.c+d.w/2;seg(at,a,0,H+.02);seg(a,b,d.h,H+.02);at=b;vestibule(d,sd);}
  seg(at,sd.len+t,0,H+.02);}
 function vestibule(d,sd){const D=2.2,a=d.c-d.w/2-.1,b=d.c+d.w/2+.1,o=sd.n==='x'?X+t:Z+t,e=o+D; // pieces touch, never overlap
  const P=(u0,u1,y0,y1,v0,v1,mat)=>{ // u: along the outward normal (signed), v: along the wall
   const lo=Math.min(sd.sg*u0,sd.sg*u1),hi=Math.max(sd.sg*u0,sd.sg*u1);if(sd.n==='x')add(mat,lo,hi,y0,y1,v0,v1);else add(mat,v0,v1,y0,y1,lo,hi);};
  P(o,e,-.3,0,a-.08,b+.08,fm);P(o,e,0,d.h+.1,a-.08,a,wm);P(o,e,0,d.h+.1,b,b+.08,wm);P(o,e,d.h,d.h+.1,a,b,wm);
  P(e,e+.06,0,d.h+.1,a-.08,b+.08,paper);
  for(let i=1;i<4;i++){const v=a+(b-a)*i/4;P(e-.04,e,0,d.h,v-.025,v+.025,lat);}
  for(const yy of [d.h*.33,d.h*.66]){P(e-.04,e,yy-.025,yy+.025,a,a+(b-a)/4-.025,lat);for(let i=1;i<4;i++){const v0=a+(b-a)*i/4+.025,v1=a+(b-a)*(i+1)/4-(i<3?.025:0);P(e-.04,e,yy-.025,yy+.025,v0,v1,lat);}}}
 s.group.add(g);g.updateMatrixWorld(true);R8C.changes.push({scene:name,what:'room shell (ceiling, lining, '+R.doors.length+' vestibules)'});}
// b) furniture: colliders that match what you see, lamps split out of the merged furnishing so they can fade (never a camera
//    collider), merged furnishing excluded from the indoor camera boom (walls/ceiling still are).
function splitTris(m,pred){const g=m.geometry,P=g.attributes.position,ix=g.index,n=ix?ix.count:P.count,keep=[],take=[];const v=new T.Vector3();
 for(let t=0;t<n;t+=3){const a=ix?ix.getX(t):t,b=ix?ix.getX(t+1):t+1,c=ix?ix.getX(t+2):t+2;v.set((P.getX(a)+P.getX(b)+P.getX(c))/3,(P.getY(a)+P.getY(b)+P.getY(c))/3,(P.getZ(a)+P.getZ(b)+P.getZ(c))/3);(pred(v)?take:keep).push(a,b,c);}
 if(!take.length)return null;
 const sub=ids=>{const map=new Map(),out={};const names=Object.keys(g.attributes);for(const k of names)out[k]=[];const idx=[];for(const i of ids){let j=map.get(i);if(j===undefined){j=map.size;map.set(i,j);for(const k of names){const A=g.attributes[k];for(let c=0;c<A.itemSize;c++)out[k].push(A.array[i*A.itemSize+c]);}}idx.push(j);}return {out,idx,names};};
 const mk=(r,geo)=>{for(const k of r.names){const A=g.attributes[k];geo.setAttribute(k,new T.BufferAttribute(new A.array.constructor(r.out[k]),A.itemSize,A.normalized));}geo.setIndex(r.idx);geo.computeBoundingBox();geo.computeBoundingSphere();return geo;};
 const lamp=mk(sub(take),new T.BufferGeometry());mk(sub(keep),g); // the furnishing keeps its geometry object (in place), lamp triangles removed
 return lamp;}
const LAMPS=[[-3.8,-2],[3.8,-2]];
function furnish(s,name){if(name!=='zen'&&name!=='study')return;const fg=s.group.getObjectByName('r6-'+name+'-furnishing');const fm=fg?.children.find(m=>m.isMesh);if(!fm||fm.userData.r8cFix)return;fm.userData.r8cFix=true;
 fg.updateMatrixWorld(true);const inv=fm.matrixWorld.clone().invert(),wv=new T.Vector3();
 const inLamp=v=>{wv.copy(v).applyMatrix4(fm.matrixWorld);return wv.y<2.6&&LAMPS.some(([x,z])=>Math.abs(wv.x-x)<.45&&Math.abs(wv.z-z)<.45);};
 // desk / table footprint from what is drawn (study) — the old collider was 2.1×1.6 m for a 1.3×0.8 m desk (STUDY-006 air wall)
 let desk=null;if(name==='study'){const b=new T.Box3(),P=fm.geometry.attributes.position;for(let i=0;i<P.count;i++){wv.fromBufferAttribute(P,i).applyMatrix4(fm.matrixWorld);if(Math.abs(wv.x)<1.2&&wv.z>-3.9&&wv.z<-2.1&&wv.y>.15&&wv.y<1.35)(R8C.deskPts||(R8C.deskPts=[])).push([+wv.x.toFixed(2),+wv.y.toFixed(2),+wv.z.toFixed(2)]);}const pts=R8C.deskPts||[];const top=pts.reduce((m,p)=>p[1]>m&&p[1]<1.02?p[1]:m,0);for(const p of pts)if(Math.abs(p[1]-top)<.03)b.expandByPoint(new T.Vector3(p[0],p[1],p[2]));R8C.deskTop=top;if(!b.isEmpty())desk=b;}
 for(const [lx,lz] of LAMPS){const lg=splitTris(fm,v=>{wv.copy(v).applyMatrix4(fm.matrixWorld);return wv.y<2.6&&Math.abs(wv.x-lx)<.45&&Math.abs(wv.z-lz)<.45;});
  if(lg){const lamp=new T.Mesh(lg,fm.material.clone());lamp.name='r8c-lamp';lamp.castShadow=fm.castShadow;lamp.receiveShadow=fm.receiveShadow;lamp.userData.r8cFade=true;lamp.userData.r8cNoCam=true;lamp.userData.r8cLamp=true;fg.add(lamp);}}
 if(name==='study'){const dg=splitTris(fm,v=>{wv.copy(v).applyMatrix4(fm.matrixWorld);return Math.abs(wv.x)<1.02&&wv.z>-3.78&&wv.z<-2.22&&wv.y>.115&&wv.y<1.035;});
  if(dg){const dm=new T.Mesh(dg,fm.material);dm.name='r8c-desk';dm.castShadow=fm.castShadow;dm.receiveShadow=fm.receiveShadow;dm.userData.r8cNoCam=true;fg.add(dm);dg.computeBoundingBox();const bb=dg.boundingBox.clone().applyMatrix4(fm.matrixWorld);R8C.deskBox=[bb.min.toArray(),bb.max.toArray()].map(a=>a.map(v=>+v.toFixed(2)));desk=bb;}}
 for(const o of [fm,s.group.getObjectByName('r7b-tea-study')?.children.find(m=>m.isMesh&&!m.material.map)].filter(Boolean))o.userData.r8cNoCam=true;
 // colliders
 const B=s.blocks;
 for(const [x,z] of LAMPS)B.push({x:x-.42,X:x+.42,z:z-.42,Z:z+.42,label:'r8c lamp'});
 for(const b of B)if(b.z===-6.2&&b.Z===-5.2&&Math.abs(b.X-b.x-2.2)<.01){b.z=-7.9;b.label='r8c shelf (to the wall)';}
 if(name==='zen'){for(const x of [-1.5,1.5])for(const z of [-2.8,-1])B.push({x:x-.44,X:x+.44,z:z-.4,Z:z+.4,label:'r8c stool'});B.push({x:-.88,X:.88,z:-6.08,Z:-5.32,label:'r8c side table'});
  // stools face the tea table (r7b passed the outward yaw)
  for(const it of s.items)if(it.label==='坐下喝茶'&&!it.r8cSeat){const x=it.x,z=it.z,rot=x<0?Math.PI/2:-Math.PI/2;it.run=()=>r4Use({id:'cushion',x,z,rot,depth:.86},'zen');it.r8cSeat=true;}}
 if(name==='study'&&desk){const i=B.findIndex(b=>b.x===-1.05&&b.X===1.05&&b.z===-3.8&&b.Z===-2.2);const nb={x:desk.min.x-.02,X:desk.max.x+.02,z:desk.min.z-.02,Z:desk.max.z+.02,label:'r8c desk (drawn footprint)'};if(i>=0)B[i]=nb;else B.push(nb);
  // 案前临帖: sit on the cushion facing the desk first, then open the practice sheet
  for(const it of s.items)if(/案前/.test(it.label)&&!it.r8cSeat){const open=it.run;it.r8cSeat=true;it.run=()=>{r4Use({id:'cushion',x:0,z:-1.5,rot:Math.PI,depth:.5},'study');const t0=performance.now();const wait=()=>{const st=window.TG_R8B_SEAT?.();if(st?.phase==='sat'||performance.now()-t0>3500){open();return;}if(!st&&performance.now()-t0>400){open();return;}requestAnimationFrame(wait);};requestAnimationFrame(wait);};}}
 R8C.changes.push({scene:name,what:'furniture colliders, lamps split (fade, no camera), desk block '+(desk?desk.min.toArray().map(v=>v.toFixed(2))+'..'+desk.max.toArray().map(v=>v.toFixed(2)):'-')});}
// d) [disabled — the art3 boxes are the lions' face and front legs; removing them is a visual regression] PLAZA-001 (codex2 r8b H, pre-existing): art3's old box-lion legs/muzzle/eyes sit inside and in front of the r6 stone lions → collapse those instances
function plazaLions(s){if(s.r8cLions)return;const g=s.group.getObjectByName('art3-plaza');if(!g)return;s.r8cLions=0;const M=new T.Matrix4(),v=new T.Vector3(),q=new T.Quaternion(),sc=new T.Vector3(),Z=new T.Matrix4().makeScale(0,0,0);g.updateMatrixWorld(true);
 g.traverse(o=>{if(!o.isInstancedMesh)return;let ch=false;for(let i=0;i<o.count;i++){o.getMatrixAt(i,M);M.clone().premultiply(o.matrixWorld).decompose(v,q,sc);if(Math.abs(Math.abs(v.x)-5.6)<.5&&v.z>-18.6&&v.z<-17.85&&v.y>.6&&v.y<2.3&&Math.max(sc.x,sc.y,sc.z)<.9){o.setMatrixAt(i,Z);ch=true;s.r8cLions++;}}if(ch){o.instanceMatrix.needsUpdate=true;o.computeBoundingSphere?.();o.computeBoundingBox?.();}});
 R8C.changes.push({scene:'plaza',what:'old art3 lion parts collapsed: '+s.r8cLions});}
function rooms(){const w=W3,n=w?.active,s=w?.spaces?.[n];if(!s||!ROOMS[n])return;try{shell(s,n);}catch(e){console.warn('r8c shell',e);R8C.errR=String(e);}try{furnish(s,n);}catch(e){console.warn('r8c furnish',e);R8C.errF=String(e);}}
{const en=worldEnter;worldEnter=function(){const r=en.apply(this,arguments);rooms();return r;};}

// c) indoor camera: when the boom would be squeezed by a wall (< 2.6 m horizontal), ease the yaw towards the nearest
//    direction with room behind the player, so the eye never collapses to the head / near plane.
function availH(n,x,z,yaw){const L=W3.spaces[n].limit,ax=L.x-.55,az=L.z-.55,dx=Math.sin(yaw),dz=Math.cos(yaw);let t=99;
 if(dx>1e-4)t=Math.min(t,(ax-x)/dx);else if(dx<-1e-4)t=Math.min(t,(-ax-x)/dx);if(dz>1e-4)t=Math.min(t,(az-z)/dz);else if(dz<-1e-4)t=Math.min(t,(-az-z)/dz);return Math.max(0,t);}
{const cam=worldCamera;let lastT=0;worldCamera=function(a){const w=W3;try{const n=w?.active;if(n&&ROOMS[n]&&S.view!=='fp'&&!w.r6Plan&&!(typeof r6IsRiding==='function'&&r6IsRiding())){
  const p=w.player.position,need=Math.min(w.radius*Math.cos(w.pitch),2.6),now=performance.now(),dt=a===1?1:Math.min(.1,Math.max(.001,(now-(lastT||now))/1000));lastT=now;
  if(availH(n,p.x,p.z,w.yaw)<need){let best=null;for(let k=1;k<=18&&!best;k++)for(const sg of [1,-1]){const y=w.yaw+sg*k*Math.PI/18;if(availH(n,p.x,p.z,y)>=need){best=y;break;}}
   if(best==null){let bv=-1;for(let k=0;k<36;k++){const y=k*Math.PI/18,v=availH(n,p.x,p.z,y);if(v>bv){bv=v;best=y;}}}
   const d=Math.atan2(Math.sin(best-w.yaw),Math.cos(best-w.yaw));w.yaw+=d*(a===1?1:1-Math.exp(-dt*4));w.r8cYawSwing=(w.r8cYawSwing||0)+1;}}}catch(e){}
 return cam.apply(this,arguments);};}
// 3) r8c.1 wish tags at the old plaza tree (TG_WISH / r7f untouched; camera POSITION untouched → tree-trace unaffected):
//    a) after a tag is hung, the view eases (≈0.8 s, smoothstep, rate-limited) to frame the new tag clear of the HUD,
//       holds, and eases back once the player moves / drags the view (or after 8 s);
//    b) within the tree radius the default view leans gently toward the canopy so some tags are in view;
//    c) HUD / direction-sign hit areas never sit over a visible tag (faded + pointer-events:none while they overlap).
const TAGS={focus:null,k:0,bias:0,known:null,lastHud:0,hudOff:new Set()};R8C.tags=TAGS;
const TREE=new T.Vector3(0,0,0),TREE_R=8.5,HUDSEL='#topbar button,#topbar [class*=pill],#topbar .pill,#coins,#r41Waypoints button,#r7MenuToggle';// r8d (M-1): joystick never fades / never loses input
function tagMesh(){return W3?.spaces?.plaza?.group?.getObjectByName('r7f-tag-mesh');}
function tagPoints(m){const out=[],M=new T.Matrix4(),v=new T.Vector3();m.updateMatrixWorld();for(let i=0;i<m.count;i++){m.getMatrixAt(i,M);v.setFromMatrixPosition(M).applyMatrix4(m.matrixWorld);out.push(v.clone());}return out;}
function watchHang(){const m=tagMesh();if(!m)return;const pts=tagPoints(m);
 if(TAGS.known&&pts.length>TAGS.known.length&&W3.active==='plaza'){const fresh=pts.filter(p=>!TAGS.known.some(q=>q.distanceTo(p)<.3));const t=fresh[fresh.length-1]||pts[pts.length-1];
  if(t){const pl=W3.player.position;TAGS.focus={pos:t.clone(),from:pl.clone(),yaw:W3.yaw,t:0,release:false};R8C.lastHang={tag:t.toArray().map(v=>+v.toFixed(2)),at:Date.now()};}}
 TAGS.known=pts;}
function hudRects(){return [...document.querySelectorAll(HUDSEL)].filter(e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden').map(e=>({e,r:e.getBoundingClientRect()}));}
const sm=x=>x<=0?0:x>=1?1:x*x*(3-2*x);
function lookQ(cam,pt){const m=new T.Matrix4().lookAt(cam.position,pt,cam.up);return new T.Quaternion().setFromRotationMatrix(m);}
function frameTags(){const w=W3,cam=w.camera;if(w.active!=='plaza'||S.view==='fp'){TAGS.focus=null;TAGS.k=0;TAGS.bias=0;return;}
 const now=performance.now(),wall=TAGS.at?(now-TAGS.at)/1000:1/60;TAGS.at=now;const dt=Math.min(.25,Math.max(.001,Math.max(w.r8CameraDt||0,Math.min(wall,.25)))),p=w.player.position,head=new T.Vector3(p.x,p.y+1.45,p.z);
 // a) focus on the newly hung tag
 const F=TAGS.focus;if(F){F.t+=dt;const moved=Math.hypot(p.x-F.from.x,p.z-F.from.z)>.35||Math.abs(w.joy?.x||0)+Math.abs(w.joy?.y||0)>.05||!!w.target||Math.abs(Math.atan2(Math.sin(w.yaw-F.yaw),Math.cos(w.yaw-F.yaw)))>.12;if(moved||F.t>8)F.release=true;}
 const goal=F&&!F.release?1:0,rate=1/.8; // full swing in 0.8 s
 TAGS.k=Math.max(0,Math.min(1,TAGS.k+Math.sign(goal-TAGS.k)*Math.min(Math.abs(goal-TAGS.k),rate*dt)));if(F&&F.release&&TAGS.k<=0)TAGS.focus=null;
 // b) canopy bias near the tree (eased by distance, rate-limited)
 const d=Math.hypot(p.x-TREE.x,p.z-TREE.z),bGoal=d<TREE_R?sm((TREE_R-d)/2.5):0;TAGS.bias+=Math.sign(bGoal-TAGS.bias)*Math.min(Math.abs(bGoal-TAGS.bias),.8*dt);
 if(TAGS.k<=0&&TAGS.bias<=0)return;
 const q0=cam.quaternion.clone(),fwd=new T.Vector3(0,0,-1).applyQuaternion(q0),L=cam.position.distanceTo(head);const base=cam.position.clone().addScaledVector(fwd,L); // what r8 looked at
 let q=q0;
 if(TAGS.bias>0){const up=base.clone();up.y+=1.3;q=q0.clone().slerp(lookQ(cam,up),.55*TAGS.bias);} // lean toward the canopy, player stays in frame
 if(TAGS.k>0&&TAGS.focus){const tag=TAGS.focus.pos;let a=.62; // aim between head and tag (tag upper-middle of the screen, player lower part)
  const aim=head.clone().lerp(tag,a);q=q.clone().slerp(lookQ(cam,aim),sm(TAGS.k));}
 cam.quaternion.copy(q);cam.updateMatrixWorld();}
function hudClear(){const now=performance.now();if(now-TAGS.lastHud<200)return;TAGS.lastHud=now;const w=W3,m=tagMesh();const off=new Set();
 if(w?.active==='plaza'&&m&&m.count&&Math.hypot(w.player.position.x-TREE.x,w.player.position.z-TREE.z)<TREE_R+4){const cam=w.camera,cv=w.renderer.domElement.getBoundingClientRect(),fr=new T.Frustum().setFromProjectionMatrix(new T.Matrix4().multiplyMatrices(cam.projectionMatrix,cam.matrixWorldInverse));
  const scr=tagPoints(m).filter(v=>fr.containsPoint(v)).map(v=>{const n=v.clone().project(cam);return [cv.left+(n.x+1)/2*cv.width,cv.top+(1-n.y)/2*cv.height];});
  for(const {e,r} of hudRects())if(scr.some(([x,y])=>x>r.left-4&&x<r.right+4&&y>r.top-4&&y<r.bottom+4))off.add(e);}// r8d (M-1): tighter margin (was 22/26 px); r8d1 (M-2): 4 px
 for(const e of TAGS.hudOff)if(!off.has(e)){e.style.opacity=e.dataset.r8cOp||'';e.style.pointerEvents=e.dataset.r8cPe||'';delete e.dataset.r8cTagClear;}
 for(const e of off)if(!TAGS.hudOff.has(e)){e.dataset.r8cOp=e.style.opacity;e.dataset.r8cPe=e.style.pointerEvents;e.dataset.r8cTagClear='1';e.style.transition='opacity .25s';e.style.opacity='.5';}// r8d (M-1): top bar fades but stays tappable; r8d1 (M-2): every HUD element (signs too) only fades, never loses taps
 TAGS.hudOff=off;}
{const cam=worldCamera;worldCamera=function(){const r=cam.apply(this,arguments);try{watchHang();frameTags();}catch(e){R8C.errT=String(e);}return r;};}
R8C.tagScreen=()=>{const w=W3,m=tagMesh();if(!m)return null;const cv=w.renderer.domElement.getBoundingClientRect();return tagPoints(m).map(v=>{const n=v.clone().project(w.camera);return {w:v.toArray().map(x=>+x.toFixed(2)),x:Math.round(cv.left+(n.x+1)/2*cv.width),y:Math.round(cv.top+(1-n.y)/2*cv.height),inView:Math.abs(n.x)<=1&&Math.abs(n.y)<=1&&n.z<1};});};
R8C.hudRects=()=>hudRects().map(({e,r})=>({id:e.id||e.className||e.tagName,r:[r.left,r.top,r.right,r.bottom].map(Math.round),cleared:!!e.dataset.r8cTagClear}));
// r8d: pre-warm hook — batch a (silently entered) space now instead of after the 1.5 s stability window.
// Sources that later turn out dynamic are still caught by check() on a real visit (unbatched, as before).
R8C.batchNow=name=>{const s=W3?.spaces?.[name];if(!s?.group||R8C.off)return 0;if(!s.r8c)s.r8c={batches:[],pend:null};batchScene(s,name);s.r8c.pend=null;return s.r8c.batches.length;};
// ---- frame hook ----
const anim=tgAnimate;tgAnimate=function(ts,dt){const out=anim.apply(this,arguments);try{rooms();}catch(e){}try{tick();}catch(e){console.warn('r8c batch',e);R8C.err=String(e);}try{hudClear();}catch(e){R8C.errH=String(e);}try{avTick();}catch(e){console.warn('r8c avatar',e);R8C.errA=String(e);}return out;};
})();
