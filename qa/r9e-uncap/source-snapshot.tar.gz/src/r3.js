/* r3 foundation: migration, scene connections, and extension points. */
function sanitizeR3(d){
 const object=v=>v&&typeof v==='object'&&!Array.isArray(v);
 d.coins=Number.isFinite(Number(d.coins))?Math.max(0,Number(d.coins)):0;
 if(!object(d.backpack))d.backpack={};
 const defaults=defaultState().shrine;
 if(!object(d.shrine))d.shrine={};
 if(!['wood','palace','zen'].includes(d.shrine.style))d.shrine.style='wood';
 const plaques=Array.isArray(d.shrine.plaques)?d.shrine.plaques:[];
 d.shrine.plaques=Array.from({length:Math.max(3,plaques.length)},(_,i)=>({name:typeof plaques[i]?.name==='string'?plaques[i].name:defaults.plaques[i%3].name,img:typeof plaques[i]?.img==='string'?plaques[i].img:''}));
 if(!object(d.decor))d.decor={};
 r3NormalizeDecor(d);
 if(typeof d.ownerId!=='string')d.ownerId='self';
 r3SanitizeAnimals(d);
}
// Showcase records use catalog ids; normalization also runs before r4 home migration.
function r3NormalizeDecor(d){
 if(!d.decor||typeof d.decor!=='object'||Array.isArray(d.decor))d.decor={};
 const ids=new Set((window.TG_CATALOG||[]).map(v=>v.id));
 for(const scene of Object.keys(d.decor))d.decor[scene]=(Array.isArray(d.decor[scene])?d.decor[scene]:[]).filter(v=>v&&typeof v==='object'&&ids.has(v.id)).map(v=>({...v,x:Number(v.x),z:Number(v.z),rot:v.rot==null?0:Number(v.rot)})).filter(v=>[v.x,v.z,v.rot].every(Number.isFinite));
}
function r3Indoor(name){return ['hall','zen','study'].includes(name);}
function r3Spawn(name,previous){
 const table={plaza:{yard:[0,-2,Math.PI],gate:[0,2,0],market:[12.5,0,Math.PI/2],home:[-11,0,-Math.PI/2]},yard:{hall:[-6.7,10.2,0],plaza:[-6.7,10.2,0]},hall:{yard:[0,.2,0],zen:[4.5,3,Math.PI/2],study:[-4.5,3,-Math.PI/2],lotus:[4,-6,Math.PI]},gate:{plaza:[0,-5,Math.PI]},market:{plaza:[-6,0,-Math.PI/2]},home:{plaza:[6,0,Math.PI/2]},zen:{hall:[-4.4,0,-Math.PI/2]},study:{hall:[4.4,0,Math.PI/2]},lotus:{hall:[0,6.2,0]}};
 return table[name]?.[previous]||({plaza:[0,2,0],yard:[-6.7,10.2,0],hall:[0,.2,0],zen:[0,3,0],study:[0,3,0],lotus:[0,6.2,0],home:[0,2,0]}[name])||[0,8,0];
}
function r3Build(){
 const w=W3;
 for(const name of ['gate','market','lotus','home','zen','study']){
  const indoor=r3Indoor(name),s=w.spaces[name]={group:new THREE.Group(),blocks:[],items:[],exits:[],limit:indoor?{x:6,z:8}:{x:14.6,z:14.6}};
  w.scene.add(s.group);s.group.visible=false;
  s.floor=worldBox(s,0,-.15,0,indoor?12:30,.3,indoor?16:30,indoor?'#9a7854':name==='lotus'?'#90a875':'#c4b795');
 }
 // Remove only the original hall perimeter, preserving altar and all interactive furniture.
 const h=w.spaces.hall;
 for(const m of [...h.group.children])if(m.geometry===w.geometries.box&&m.position.y===2.7){h.group.remove(m);}
 h.blocks=h.blocks.filter(b=>!(b.x===-6.15||b.x===5.85||b.z===-8.15||b.z===7.85));
 function wall(s,x,z,a,c){worldBox(s,x,2.1,z,a,4.2,c,'#b6a483',true);}
 // Hall openings: side doors at z=3; north door beside, rather than behind, the altar.
 for(const x of [-6,6]){wall(h,x,-3.25,.3,9.5);wall(h,x,6.25,.3,3.5);}
 wall(h,-1.75,-8,8.5,.3);wall(h,5.75,-8,.5,.3);
 for(const x of [-4,4])wall(h,x,8,4,.3);
 function door(s,to,x,z,angle=0){
  const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=angle;s.group.add(g);
  for(const dx of [-1.65,1.65]){worldMesh(g,'box','#733f2e',dx,1.6,0,.26,3.2,.55);worldMesh(g,'box','#d0b88e',dx,.15,0,.6,.3,.85);}
  worldMesh(g,'box','#8e4931',0,3.1,0,3.7,.45,.65);worldMesh(g,'box','#445b59',0,3.5,0,4.3,.22,1.2);
  worldMesh(g,'box','#c2ad83',0,.035,0,3.1,.07,.8);
  const title=window.TG_SCENES.find(v=>v.id===to)?.name||'心田小院';
  worldLabel(g,title,0,3.1,.36,2.5);worldLabel(g,title,0,3.1,-.36,2.5);g.children[g.children.length-1].rotation.y=Math.PI;
  // Posts are collidable, the threshold is traversable.
  for(const dx of [-1.65,1.65]){const px=x+Math.cos(angle)*dx,pz=z-Math.sin(angle)*dx;s.blocks.push({x:px-.2,X:px+.2,z:pz-.2,Z:pz+.2});}
  if(!s.exits.some(e=>e.to===to&&e.x===x&&e.z===z)){s.exits.push({x,z,to});worldInteract(s,x,z,'前往'+title,()=>go(to),2.2);}
 }
 const p=w.spaces.plaza;
 door(p,'gate',0,14);door(w.spaces.gate,'plaza',0,-12);
 door(p,'market',14,0,Math.PI/2);door(w.spaces.market,'plaza',-14,0,Math.PI/2);
 door(p,'yard',-14,0,Math.PI/2);p.exits[p.exits.length-1].r4East=true;p.items[p.items.length-1].run=()=>{window.r4EastArrival=true;go('yard');};door(w.spaces.yard,'plaza',14,0,Math.PI/2);
 door(h,'yard',0,7.5,Math.PI);door(h,'zen',5.6,3,Math.PI/2);door(h,'study',-5.6,3,-Math.PI/2);door(h,'lotus',4,-7.5);
 door(w.spaces.zen,'hall',-5.6,0,-Math.PI/2);door(w.spaces.study,'hall',5.6,0,Math.PI/2);door(w.spaces.lotus,'hall',0,14,Math.PI);
 for(const name of ['gate','market','lotus','home','zen','study']){
  const s=w.spaces[name],{x,z}=s.limit;
  // Perimeter segments leave generous central entrances on each side.
  for(const side of [-1,1])for(const part of [-1,1]){
   wall(s,side*x,part*(z/2+1),.3,z-2.8);
   wall(s,part*(x/2+1),side*z,x-2.8,.3);
  }
 }
 const gate=w.spaces.gate;
 for(const x of [-8,8])worldMesh(gate.group,'cone','#62815a',x,2,4,2,4,2);
 const market=w.spaces.market;
 for(const [i,x]of [-7,0,7].entries()){
  worldBox(market,x,.7,-5,4,1.4,2,'#95633d',true);worldBox(market,x,3,-5,4.8,.25,3,i%2?'#ad6149':'#688e7c');
  worldLabel(market.group,['花木铺','家具铺','灯彩铺'][i],x,2.4,-3.5,2.8);worldInteract(market,x,-2,'逛逛商铺',openShop);market.items[market.items.length-1].r3Edit=true;
 }
 const lotus=w.spaces.lotus;
 worldMesh(lotus.group,'cylinder','#6bafad',0,.02,-2,7,.08,6);lotus.blocks.push({x:-7,X:7,z:-8,Z:4});
 const pads=[],flowers=[],rocks=[];
 for(let i=0;i<22;i++){const a=i*2.4,r=2+i%5*.8,x=Math.cos(a)*r,z=-2+Math.sin(a)*r*.8;pads.push([x,.12,z,.5,.035,.42]);if(i%3===0)flowers.push([x,.28,z,.22,.23,.22]);}
 for(let i=0;i<30;i++){const a=i/30*Math.PI*2;rocks.push([Math.cos(a)*7.2,.18,-2+Math.sin(a)*6.2,.5,.3,.4]);}
 tgInstances(lotus.group,new THREE.SphereGeometry(1,8,5),worldMat('#588e59'),pads);tgInstances(lotus.group,new THREE.SphereGeometry(1,8,5),worldMat('#e7a8b4'),flowers);tgInstances(lotus.group,new THREE.DodecahedronGeometry(1),worldMat('#92998d'),rocks);
 worldLabel(lotus.group,'荷塘',0,2, -10,3);
 const home=w.spaces.yard;
 worldBox(home,8,1.6,2,8,3.2,4,'#e0ccb0',true);worldBox(home,8,3.4,2,8.8,.3,4.8,'#4a625d');worldLabel(home.group,'心安小筑',8,2.7,4.1,3);
 for(const name of ['zen','study']){
  const s=w.spaces[name];worldLabel(s.group,name==='zen'?'静坐歇心':'书香养性',0,3.4,-7.7,3);
  if(name==='zen'){
   worldBox(s,0,.025,-2,5,.05,4,'#9a9b73');for(const x of [-1.5,1.5])worldMesh(s.group,'cylinder','#b49a63',x,.35,-2,.7,.25,.7);
   worldBox(s,0,.65,-5,3,1.3,1,'#855537',true);
  }else{
   worldBox(s,0,1,-3,4,.25,1.7,'#704c36',true);for(const x of [-1.6,1.6])worldBox(s,x,.5,-3,.2,1,.9,'#704c36');
   const books=[];for(const x of [-4,4]){worldBox(s,x,1.8,-6,2,3.6,1,'#684931',true);for(let j=0;j<18;j++)books.push([x-.7+(j%6)*.28,.7+Math.floor(j/6),-5.4,.19,.65,.3]);}
   tgInstances(s.group,new THREE.BoxGeometry(1,1,1),worldMat('#7b9285'),books);worldBox(s,.5,1.18,-3,1,.05,.7,'#e7dbbd');
  }
 }
 worldInteract(h,-3,5,'整修缘堂',openShrineStudio,1.5);h.items[h.items.length-1].r3Edit=true;
 r3PrepareShrine(h);
 r3PolishScenes();
}

/* r3 systems. All economy transactions remain local state + the frozen save hook. */
window.TG_CATALOG=[
 {id:'wood-table',name:'木桌',cat:'furniture',price:60,w:2,d:1.5,emoji:'🪑'},
 {id:'bench',name:'条凳',cat:'furniture',price:30,w:2,d:.5,emoji:'🪑'},
 {id:'cabinet',name:'柜橱',cat:'furniture',price:100,w:1.5,d:1,emoji:'🗄️'},
 {id:'daybed',name:'卧榻',cat:'furniture',price:160,w:2.5,d:1.5,emoji:'🛏️'},
 {id:'altar-table',name:'条案',cat:'furniture',price:90,w:2,d:1,emoji:'🕯️'},
 {id:'vase',name:'花瓶',cat:'decor',price:25,w:.5,d:.5,emoji:'🏺'},
 {id:'lantern',name:'灯笼',cat:'decor',price:40,w:.5,d:.5,emoji:'🏮'},
 {id:'bonsai',name:'盆景',cat:'decor',price:55,w:1,d:1,emoji:'🪴'},
 {id:'screen',name:'屏风',cat:'decor',price:80,w:2,d:.5,emoji:'🖼️'},
 {id:'cushion',name:'坐垫',cat:'decor',price:20,w:1,d:1,emoji:'🟤'},
 {id:'fruit-plate',name:'果盘',cat:'offering',price:35,w:1,d:.5,emoji:'🍑'},
 {id:'incense-set',name:'灯组',cat:'offering',price:45,w:.5,d:.5,emoji:'🕯️'},
 {id:'tea-cup',name:'清茶盏',cat:'offering',price:20,w:.5,d:.5,emoji:'🍵'}
];
function r3Item(id){return window.TG_CATALOG.find(v=>v.id===id);}
function r3Esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function r3DecorScene(id){return ['hall','yard','zen','study'].includes(id);}
function r3Commit(){renderTop();save();}
function openShop(tab='furniture'){
 if(r3DenyVisit())return;
 if(!['furniture','decor','offering','sell','animals'].includes(tab))tab='furniture';
 const cats=[['furniture','家具'],['decor','装饰'],['offering','缘堂陈设'],['animals','牲畜'],['sell','卖作物/产物']];
 const rows=tab==='sell'?[...CROPS.map(c=>({...c,sell:c.sell})),...R3_PRODUCE].filter(c=>(S.inventory[c.id]||0)>0).map(c=>`<div class="r3-row"><span class="r3-emoji">${c.emoji}</span><span><b>${c.name}</b><small>库存 ${S.inventory[c.id]} · 单价 🪙 ${c.sell}</small></span><button class="btn" data-sell="${c.id}">卖 1</button><button class="btn ghost" data-sell-all="${c.id}">全卖</button></div>`).join(''):tab==='animals'?R3_ANIMAL_SHOP.map(c=>`<div class="r3-row"><span class="r3-emoji">${c.emoji}</span><span><b>${c.name}</b><small>${c.pen===null?'小院自由活动':'入住'+R3_PENS[c.pen].name} · ${S.animals.filter(a=>a.kind===c.id).length}/${c.cap}<br>${c.desc}</small></span><button class="btn" data-animal="${c.id}">🪙 ${c.price} 领养</button></div>`).join(''):window.TG_CATALOG.filter(c=>c.cat===tab).map(c=>`<div class="r3-row"><span class="r3-emoji">${c.emoji}</span><span><b>${c.name}</b><small>${c.w} × ${c.d} 米 · 背包 ${S.backpack[c.id]||0}<br>${r3Esc(c.desc||'可在房间中布置')}</small></span><button class="btn" data-buy="${c.id}">🪙 ${c.price} 购买</button></div>`).join('');
 openModal(`<h2>🏮 集市商铺</h2><p class="r3-balance">铜钱 🪙 ${S.coins}</p><nav class="r3-tabs">${cats.map(([id,name])=>`<button class="btn ${id===tab?'':'ghost'}" data-tab="${id}">${name}</button>`).join('')}</nav>${rows||'<p class="center">背包里还没有作物，去小院收获吧。</p>'}`);
 $('#sheet').querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>openShop(b.dataset.tab));
 $('#sheet').querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>{if(r3DenyVisit())return;const c=r3Item(b.dataset.buy);if(S.coins<c.price)return toast('铜钱不足，出售作物可赚取铜钱');S.coins-=c.price;S.backpack[c.id]=(S.backpack[c.id]||0)+1;window.r9OnShopBuy?.(c.id);r3Commit();if(window.TG_PLAN)r3PlanTray();openShop(tab);toast('已买入'+c.name);});
 $('#sheet').querySelectorAll('[data-animal]').forEach(b=>b.onclick=()=>{if(r3BuyAnimal(b.dataset.animal))openShop('animals');});
 function sell(id,all){if(r3DenyVisit())return;const c=CROP_BY_ID[id]||r3ProduceItem(id),count=S.inventory[id]||0;if(!c||count<=0)return;const n=all?count:1;S.inventory[id]-=n;S.coins+=n*(c.sell??(c.value||1)*8);r3Commit();openShop('sell');toast(`已售出 ${c.name} ×${n}`);}
 $('#sheet').querySelectorAll('[data-sell]').forEach(b=>b.onclick=()=>sell(b.dataset.sell,false));$('#sheet').querySelectorAll('[data-sell-all]').forEach(b=>b.onclick=()=>sell(b.dataset.sellAll,true));
}
function r3OpenBackpack(){
 const items=window.TG_CATALOG.filter(c=>(S.backpack[c.id]||0)>0);
 openModal(`<h2>🧺 背包</h2><h3>作物</h3>${inventoryHTML(false)}${r3ProduceInventoryHTML()}<h3>家具与物品</h3>${items.map(c=>`<div class="r3-row"><span>${c.emoji} ${c.name}</span><b>× ${S.backpack[c.id]}</b></div>`).join('')||'<p>还没有物品，去集市逛逛吧。</p>'}<div class="r3-actions"><button class="btn" id="r3Shop">去商店</button>${r3DecorScene(current)?'<button class="btn" id="r3Arrange">布置房间</button>':''}</div>`);
 $('#r3Shop').onclick=()=>openShop();if($('#r3Arrange'))$('#r3Arrange').onclick=()=>enterPlacement(current);window.r9BackpackHook?.();
}
// The original listener remains installed; this listener renders the extended inventory last.
$('#pillInv').addEventListener('click',r3OpenBackpack);$('#pillCoins').addEventListener('click',()=>openShop());

var R3_STYLES={wood:{name:'古朴木作',cost:0,wall:'#b6a483',wood:'#674332',gold:'#c6a34c',tile:'#3b2722'},palace:{name:'朱红宫殿',cost:120,wall:'#a9382d',wood:'#8f2e26',gold:'#e5be54',tile:'#624c36'},zen:{name:'竹石素雅',cost:80,wall:'#dfdfd3',wood:'#918776',gold:'#798080',tile:'#737c7c'}};
if(typeof window.TG_SHRINE_UPLOAD!=='function')window.TG_SHRINE_UPLOAD=async function(file){
 if(!file||!file.type.startsWith('image/'))throw Error('请选择图片');
 const url=URL.createObjectURL(file);try{const img=await new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=()=>reject(Error('图片无法读取'));i.src=url;});const scale=Math.min(1,256/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));const ctx=c.getContext('2d');ctx.fillStyle='#f5e8d4';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(img,0,0,c.width,c.height);return c.toDataURL('image/jpeg',.7);}finally{URL.revokeObjectURL(url);}
};
function openShrineStudio(){
 if(r3DenyVisit())return;
 const shrine=S.shrine;shrine.owned=Array.from(new Set(['wood',shrine.style,...(Array.isArray(shrine.owned)?shrine.owned:[])]));
 openModal(`<h2>🛕 整修缘堂</h2><p class="r3-balance">铜钱 🪙 ${S.coins} · 木饰已解锁可免费使用 · 出售作物可赚铜钱</p><div class="r3-styles">${Object.entries(R3_STYLES).map(([id,v])=>`<button class="r3-style ${shrine.style===id?'selected':''}" data-style="${id}" style="--wall:${v.wall};--wood:${v.wood};--gold:${v.gold}"><i>缘</i><b>${v.name}</b><small>${shrine.style===id?'使用中':shrine.owned.includes(id)?'免费切换':'🪙 '+v.cost}</small></button>`).join('')}</div><p id="r41StyleStatus" aria-live="polite">点击样式免费预览</p><button class="btn" id="r41BuyStyle" hidden></button><h3>家风匾额</h3><p>可填写家风文字，或上传一张全家福。</p>${shrine.plaques.map((p,i)=>`<div class="r3-plaque-row"><div class="r3-plaque-preview" data-preview="${i}" data-raw>${r3Esc(p.name)}</div><div><label>姓名 <input data-name="${i}" maxlength="18" value="${r3Esc(p.name)}" placeholder="家人姓名"></label><label>画像 <input type="file" data-upload="${i}" accept="image/*"></label><label>或图片地址 <input data-image="${i}" type="url" value="${r3Esc(p.img.startsWith('data:')?'':p.img)}" placeholder="https://…"></label><small data-status="${i}">${p.img?'已保存画像':'使用可爱默认画像'}</small></div></div>`).join('')}`);
 window.r41PreviewStyle=null;
 onModalClose=()=>{window.r41PreviewStyle=null;worldSyncShrine();};
 $('#sheet').querySelectorAll('[data-style]').forEach(b=>b.onclick=()=>{if(r3DenyVisit())return;const id=b.dataset.style,v=R3_STYLES[id],owned=shrine.owned.includes(id);window.r41PreviewStyle=id;worldSyncShrine();$('#sheet').querySelectorAll('[data-style]').forEach(el=>el.classList.toggle('selected',el===b));const buy=$('#r41BuyStyle');buy.hidden=owned;$('#r41StyleStatus').textContent=owned?'已免费使用'+v.name:'预览：'+v.name+' · 尚未购买';if(owned){shrine.style=id;r3Commit();}buy.textContent='购买并使用 🪙 '+v.cost;buy.onclick=()=>{if(r3DenyVisit())return;if(S.coins<v.cost){$('#r41StyleStatus').textContent='铜钱不足，出售作物可赚铜钱';return;}S.coins-=v.cost;shrine.style=id;shrine.owned.push(id);window.r41PreviewStyle=null;r3Commit();worldSyncShrine();openShrineStudio();};});
 $('#sheet').querySelectorAll('[data-name]').forEach(input=>input.oninput=()=>{if(r3DenyVisit())return;const i=+input.dataset.name;shrine.plaques[i].name=input.value.slice(0,18);$('#sheet').querySelector(`[data-preview="${i}"]`).textContent=input.value;r3Commit();worldSyncShrine();});
 $('#sheet').querySelectorAll('[data-image]').forEach(input=>input.onchange=()=>{if(r3DenyVisit())return;const i=+input.dataset.image,url=input.value.trim();if(url&&!/^https?:\/\//i.test(url))return toast('请输入 http 或 https 图片地址');shrine.plaques[i].img=url;r3Commit();worldSyncShrine();});
 $('#sheet').querySelectorAll('[data-upload]').forEach(input=>input.onchange=async()=>{if(r3DenyVisit())return;const file=input.files[0];if(!file)return;input.disabled=true;try{const data=await window.TG_SHRINE_UPLOAD(file);if(r3DenyVisit()||S.shrine!==shrine)return;if(typeof data!=='string')throw Error('上传接口没有返回图片地址');shrine.plaques[+input.dataset.upload].img=data;r3Commit();worldSyncShrine();const status=input.parentElement.parentElement.querySelector('[data-status]');if(status)status.textContent='画像已保存';toast('画像已保存');}catch(e){toast(e.message||'图片上传失败');}finally{input.disabled=false;}});
}
function r3PrepareShrine(h){
 // Clone only architecture materials before static batching; never recolor a shared world material.
 h.shrineMaterials=[];const clones=new Map();
 h.group.traverse(m=>{if((m.userData.r41Label||m.userData.wallSign)&&m.position.z===-7.05){m.visible=false;m.userData.r3OldTablet=true;}if(!m.isMesh||!m.material?.color)return;const p=m.position,architecture=m===h.floor||(m.parent===h.group&&(p.y>=4.1||(Math.abs(p.x)>=5.9&&p.y>1)||(p.z<=-7.9&&p.y>1)||(Math.abs(p.x)===4&&p.y===2.5)));
 if(architecture){const original=m.material;let mat=clones.get(original);if(!mat){mat=original.clone();clones.set(original,mat);h.shrineMaterials.push({mat,base:original.color.clone(),kind:m===h.floor?'wood':p.y>=5.4?'tile':p.y>=4?'gold':'wall'});}m.material=mat;}
 // Hide the old name strips, retain the original wooden tablets and pedestals.
 if(m.parent===h.group&&p.z===-7.05){m.visible=false;m.userData.r3OldTablet=true;}
 });
 h.plaqueGroup=new THREE.Group();h.group.add(h.plaqueGroup);
}
function r3PlaqueTexture(p,texture,valid){
 const c=texture.image,ctx=c.getContext('2d');ctx.fillStyle='#38291f';ctx.fillRect(0,0,256,512);ctx.strokeStyle='#dbb963';ctx.lineWidth=9;ctx.strokeRect(8,8,240,496);
 // Always draw the fallback first, including when a URL fails or lacks CORS.
 ctx.fillStyle='#e8ba83';ctx.beginPath();ctx.arc(128,111,57,0,Math.PI*2);ctx.fill();ctx.fillStyle='#3b2a20';ctx.beginPath();ctx.arc(128,104,60,Math.PI*1.02,Math.PI*1.98);ctx.fill();ctx.beginPath();ctx.arc(128,52,17,0,Math.PI*2);ctx.fill();/* r8d3: hair + bun on the default face */ctx.fillStyle='#e6a249';ctx.beginPath();ctx.ellipse(128,183,67,28,0,Math.PI,Math.PI*2);ctx.fill();ctx.fillStyle='#453025';for(const x of [108,148]){ctx.beginPath();ctx.arc(x,109,5,0,Math.PI*2);ctx.fill();}ctx.beginPath();ctx.arc(128,126,16,.15,Math.PI-.15);ctx.strokeStyle='#9f5f42';ctx.lineWidth=3;ctx.stroke();/* r8d3: forehead dots removed */
 const name=[...(p.name||'家人')].slice(0,18);ctx.fillStyle='#ffe5a2';ctx.textAlign='center';ctx.textBaseline='middle';const step=Math.min(43,270/name.length);ctx.font=`bold ${Math.min(38,step)}px serif`;const ft=window.r7NativeFillText||ctx.fillText;/* r8d3: player-entered names are drawn verbatim (native fillText: no r7 rewrite, no r7g title display) */name.forEach((ch,i)=>ft.call(ctx,ch,128,235+i*step));texture.needsUpdate=true;
 if(p.img){const image=new Image();image.crossOrigin='anonymous';image.onload=()=>{if(!valid())return;ctx.save();ctx.beginPath();ctx.arc(128,111,57,0,Math.PI*2);ctx.clip();const ratio=Math.max(114/image.width,114/image.height);ctx.drawImage(image,128-image.width*ratio/2,111-image.height*ratio/2,image.width*ratio,image.height*ratio);ctx.restore();texture.needsUpdate=true;};image.onerror=()=>{};image.src=p.img;}
}
function worldSyncShrine(){
 const h=W3?.spaces?.hall;if(!h?.plaqueGroup)return;const key=JSON.stringify(S.shrine)+(window.r41PreviewStyle||'');if(h.shrineKey===key)return;h.shrineKey=key;const style=R3_STYLES[window.r41PreviewStyle||S.shrine.style]||R3_STYLES.wood;
 h.shrineMaterials.forEach(({mat,base,kind})=>{mat.color.copy((window.r41PreviewStyle||S.shrine.style)==='wood'?base:new THREE.Color(style[kind]));});
 h.plaqueGroup.children.forEach(m=>{m.material.map?.dispose();m.material.dispose();m.geometry.dispose();});worldClear(h.plaqueGroup);
 S.shrine.plaques.slice(0,6).forEach((p,i)=>{const c=document.createElement('canvas');c.width=256;c.height=512;const t=new THREE.CanvasTexture(c);r3PlaqueTexture(p,t,()=>h.shrineKey===key);const m=new THREE.Mesh(new THREE.PlaneGeometry(1.18,2.36),new THREE.MeshBasicMaterial({map:t}));m.position.set((i-1)*1.8,2.95,-7.025);h.plaqueGroup.add(m);});
}

function r3Bounds(item){const c=r3Item(item.id);if(!c)return null;const turn=Math.abs(Math.round(item.rot/(Math.PI/2)))%2,w=turn?c.d:c.w,d=turn?c.w:c.d;return {x:item.x-w/2,X:item.x+w/2,z:item.z-d/2,Z:item.z+d/2};}
function r3Overlap(a,b){const eps=.001;return a.x<b.X-eps&&a.X>b.x+eps&&a.z<b.Z-eps&&a.Z>b.z+eps;}
function r3DoorZones(space){return space.exits.map(e=>{const side=Math.abs(e.x/space.limit.x)>Math.abs(e.z/space.limit.z)?'x':'z',sign=Math.sign(e[side])||1,L=space.limit[side],center=sign*(L-.8);return side==='x'?{x:center-.8,X:center+.8,z:e.z-1.55,Z:e.z+1.55,e,side}:{x:e.x-1.55,X:e.x+1.55,z:center-.8,Z:center+.8,e,side};});}
function r3PlacementError(sceneId,item,ignore=-1,restoring=false){
 const space=W3?.spaces[sceneId],b=r3Bounds(item);if(!space||!b)return '未知物品';const L=space.limit;
 if(b.x< -L.x+.2||b.X>L.x-.2||b.z< -L.z+.2||b.Z>L.z-.2)return '不能越过墙面，请移到房间内';
 if(r3DoorZones(space).some(zone=>r3Overlap(b,zone)))return '门前需要留出 1.6 米通道';
 if((S.decor[sceneId]||[]).some((v,i)=>i!==ignore&&r3Bounds(v)&&r3Overlap(b,r3Bounds(v))))return '与其他家具重叠了';
 if(!restoring&&sceneId==='yard'&&R3_PENS.some(p=>r3Overlap(b,p)))return '牧栏内要留给小动物活动';
 if(space.blocks.some(v=>!v.r3Decor&&!(restoring&&v.r3Pen)&&r3Overlap(b,v)))return '这里有墙或固定设施，请换个位置';
 return '';
}
function enterPlacement(sceneId){
 if(sceneId==='home')sceneId='yard';
 if(r3DenyVisit())return;
 if(!r3DecorScene(sceneId)||W3?.active!==sceneId)return toast('请先进入要布置的房间');
 if(window.TG_PLAN)return;closeModal();worldStop();S.decor[sceneId]||=[];
 const p=window.TG_PLAN={sceneId,selected:-1,pick:null,rot:0,drag:null,ghost:null};
 const view=$('#planView');view.hidden=false;document.body.classList.add('r3-planning');
 view.innerHTML=`<header><div><b>布置 · ${r3Esc(window.TG_SCENES.find(v=>v.id===sceneId).name)}</b><small>点选背包物品，再点地面放置 · 拖动家具移动</small></div><button class="btn" id="planDone">完成</button></header><div class="r3-plan-stage"><canvas id="planCanvas" aria-label="可拖动家具的房间平面图"></canvas></div><div class="r3-plan-controls"><span id="planSelection">请选择物品</span><button class="btn ghost" id="planRotate">旋转 90°</button><button class="btn ghost" id="planReturn">收回背包</button></div><div id="planTray"></div><p class="r3-plan-help">网格 0.5 米 · 斜线区为门前禁放区 · 灰色为固定设施</p>`;
 const canvas=$('#planCanvas');
 function point(e){const rect=canvas.getBoundingClientRect(),t=p.transform;return {x:Math.round(((e.clientX-rect.left-t.ox)/t.scale)*2)/2,z:Math.round(((e.clientY-rect.top-t.oz)/t.scale)*2)/2};}
 function candidate(e){const at=point(e);return p.drag?.index>=0?{...S.decor[sceneId][p.drag.index],x:at.x-p.drag.dx,z:at.z-p.drag.dz}:{id:p.pick,x:at.x,z:at.z,rot:p.rot};}
 canvas.onpointerdown=e=>{if(r3DenyVisit()||window.TG_PLAN!==p)return;e.preventDefault();const at=point(e),list=S.decor[sceneId];let hit=-1;for(let i=list.length-1;i>=0;i--){const b=r3Bounds(list[i]);if(b&&at.x>=b.x&&at.x<=b.X&&at.z>=b.z&&at.z<=b.Z){hit=i;break;}}
 if(hit>=0){p.selected=hit;p.pick=null;p.rot=list[hit].rot;p.drag={index:hit,dx:at.x-list[hit].x,dz:at.z-list[hit].z};}else if(p.pick){p.selected=-1;p.drag={index:-1,dx:0,dz:0};}else{p.selected=-1;p.drag=null;}
 if(p.drag){canvas.setPointerCapture(e.pointerId);p.ghost=candidate(e);}r3PlanTray();r3DrawPlan();};
 canvas.onpointermove=e=>{if(!p.drag)return;e.preventDefault();p.ghost=candidate(e);r3DrawPlan();};
 canvas.onpointerup=e=>{if(r3DenyVisit()||window.TG_PLAN!==p)return;if(!p.drag)return;const item=candidate(e),index=p.drag.index,error=r3PlacementError(sceneId,item,index);if(error)toast(error);else if(index>=0)S.decor[sceneId][index]=item;else if((S.backpack[item.id]||0)>0){S.backpack[item.id]--;S.decor[sceneId].push(item);p.selected=S.decor[sceneId].length-1;p.pick=null;}p.drag=null;p.ghost=null;r3PlanTray();r3DrawPlan();};
 canvas.onpointercancel=()=>{p.drag=null;p.ghost=null;r3DrawPlan();};
 $('#planRotate').onclick=()=>{if(r3DenyVisit()||window.TG_PLAN!==p)return;if(p.selected>=0){const item={...S.decor[sceneId][p.selected],rot:(S.decor[sceneId][p.selected].rot+Math.PI/2)%(Math.PI*2)},error=r3PlacementError(sceneId,item,p.selected);if(error)return toast(error);S.decor[sceneId][p.selected]=item;p.rot=item.rot;}else if(p.pick)p.rot=(p.rot+Math.PI/2)%(Math.PI*2);else return toast('请先选择物品');r3DrawPlan();};
 $('#planReturn').onclick=()=>{if(r3DenyVisit()||window.TG_PLAN!==p)return;if(p.selected<0)return toast('请先点选已放置的物品');const [item]=S.decor[sceneId].splice(p.selected,1);S.backpack[item.id]=(S.backpack[item.id]||0)+1;p.selected=-1;r3PlanTray();r3DrawPlan();};
 $('#planDone').onclick=r3FinishPlan;
 p.observer=new ResizeObserver(r3DrawPlan);p.observer.observe(canvas);r3PlanTray();r3DrawPlan();
}
function r3FinishPlan(){if(r3DenyVisit()){r3DiscardPlan();return;}const p=window.TG_PLAN;if(!p)return;p.observer.disconnect();window.TG_PLAN=null;$('#planView').hidden=true;document.body.classList.remove('r3-planning');r3Commit();worldSyncDecor();worldStop();toast('布置已保存');}
function r3PlanTray(){
 const p=window.TG_PLAN;if(!p)return;const items=window.TG_CATALOG.filter(c=>c.w&&c.d&&(S.backpack[c.id]||0)>0);
 $('#planTray').innerHTML=items.map(c=>`<button class="r3-tray-item ${p.pick===c.id?'selected':''}" data-item="${c.id}"><span>${c.emoji}</span>${c.name}<small>×${S.backpack[c.id]} · ${c.w}×${c.d}</small></button>`).join('')||'<span>背包空了，可收回家具或完成后去商店购买。</span>';
 $('#planSelection').textContent=p.pick?r3Item(p.pick).name:p.selected>=0?r3Item(S.decor[p.sceneId][p.selected].id)?.name||'家具':'请选择物品';
 $('#planTray').insertAdjacentHTML('afterbegin','<button class="btn" id="r41PlanShop">购置家具</button>');$('#r41PlanShop').onclick=()=>{if(!r3DenyVisit())openShop('furniture');};
 $('#planTray').querySelectorAll('[data-item]').forEach(b=>b.onclick=()=>{p.pick=b.dataset.item;p.selected=-1;p.rot=0;r3PlanTray();r3DrawPlan();});
}
function r3DrawPlan(){
 const p=window.TG_PLAN,canvas=$('#planCanvas');if(!p||!canvas)return;const rect=canvas.getBoundingClientRect();if(!rect.width||!rect.height)return;
 const dpr=Math.min(2,devicePixelRatio||1);canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);const ctx=canvas.getContext('2d');ctx.scale(dpr,dpr);ctx.clearRect(0,0,rect.width,rect.height);
 const s=W3.spaces[p.sceneId],L=s.limit,scale=Math.min((rect.width-38)/(L.x*2),(rect.height-46)/(L.z*2)),ox=rect.width/2,oz=rect.height/2;p.transform={scale,ox,oz};
 const px=x=>ox+x*scale,pz=z=>oz+z*scale;
 function box(b,fill,stroke){ctx.fillStyle=fill;ctx.fillRect(px(b.x),pz(b.z),(b.X-b.x)*scale,(b.Z-b.z)*scale);if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.strokeRect(px(b.x),pz(b.z),(b.X-b.x)*scale,(b.Z-b.z)*scale);}}
 box({x:-L.x,X:L.x,z:-L.z,Z:L.z},'#f7eedb');ctx.lineWidth=.5;ctx.strokeStyle='#d8ceb8';ctx.beginPath();for(let x=-L.x;x<=L.x;x+=.5){ctx.moveTo(px(x),pz(-L.z));ctx.lineTo(px(x),pz(L.z));}for(let z=-L.z;z<=L.z;z+=.5){ctx.moveTo(px(-L.x),pz(z));ctx.lineTo(px(L.x),pz(z));}ctx.stroke();
 s.blocks.filter(v=>!v.r3Decor).forEach(v=>box(v,'#887f7188'));
 ctx.strokeStyle='#6a5037';ctx.lineWidth=5;ctx.strokeRect(px(-L.x),pz(-L.z),L.x*2*scale,L.z*2*scale);
 for(const zone of r3DoorZones(s)){box(zone,'#e7ac8644','#bc8064');ctx.save();ctx.beginPath();ctx.rect(px(zone.x),pz(zone.z),(zone.X-zone.x)*scale,(zone.Z-zone.z)*scale);ctx.clip();ctx.strokeStyle='#bd8f6b';ctx.lineWidth=1;for(let n=-rect.height;n<rect.width+rect.height;n+=8){ctx.beginPath();ctx.moveTo(n,0);ctx.lineTo(n+rect.height,rect.height);ctx.stroke();}ctx.restore();
 ctx.strokeStyle='#f7eedb';ctx.lineWidth=7;ctx.beginPath();if(zone.side==='x'){const x=Math.sign(zone.e.x)*L.x;ctx.moveTo(px(x),pz(zone.z));ctx.lineTo(px(x),pz(zone.Z));}else{const z=Math.sign(zone.e.z)*L.z;ctx.moveTo(px(zone.x),pz(z));ctx.lineTo(px(zone.X),pz(z));}ctx.stroke();ctx.fillStyle='#75482c';ctx.font='10px sans-serif';ctx.textAlign='center';const label='门·'+(window.TG_SCENES.find(v=>v.id===zone.e.to)?.name||'');const tw=ctx.measureText(label).width;ctx.fillText(label,Math.max(tw/2+8,Math.min(rect.width-tw/2-8,px((zone.x+zone.X)/2))),Math.max(16,Math.min(rect.height-12,pz((zone.z+zone.Z)/2))));}
 ctx.fillStyle='#786346';ctx.font='10px sans-serif';ctx.textAlign='center';ctx.fillText('北墙',ox,pz(-L.z)-10);ctx.fillText('南墙',ox,pz(L.z)+16);
 function draw(item,selected,ghost){const b=r3Bounds(item),c=r3Item(item.id);if(!b)return;box(b,ghost?(r3PlacementError(p.sceneId,item,p.drag?.index)?'#d86d6d99':'#75ae8e99'):selected?'#dcb86e':'#d6c39d',selected?'#745027':'#9d855c');ctx.save();ctx.translate(px(item.x),pz(item.z));ctx.rotate(-item.rot);ctx.fillStyle='#392d22';ctx.textAlign='center';ctx.font=`${Math.max(8,Math.min(12,scale*.45))}px sans-serif`;ctx.fillText(c.name,0,3);ctx.fillText('↑',0,-Math.min(12,scale*.4));ctx.restore();}
 (S.decor[p.sceneId]||[]).forEach((v,i)=>draw(v,i===p.selected,false));if(p.ghost)draw(p.ghost,true,true);
}

// Furniture uses shared world geometries and materials, then one InstancedMesh per pair.
function r3Furniture(parent,item){
 const c=r3Item(item.id);if(!c)return;const g=new THREE.Group();g.position.set(item.x,0,item.z);g.rotation.y=item.rot;parent.add(g);
 const wood='#886043',dark='#624532',gold='#c5a15a',cloth='#a59973';
 const mesh=(type,color,x,y,z,a,b,d)=>worldMesh(g,type,color,x,y,z,a,b,d);
 const box=(x,y,z,a,b,d,color=wood)=>mesh('box',color,x,y,z,a,b,d);
 const legs=(w,d,h)=>{for(const x of [-1,1])for(const z of [-1,1])box(x*(w/2-.12),h/2,z*(d/2-.12),.15,h,.15,dark);};
 switch(item.id){
 case 'wood-table':box(0,.95,0,2,.16,1.5);legs(2,1.5,.9);break;
 case 'rocking-chair':box(0,.55,0,1.1,.14,1.1);box(0,1.05,-.5,1.1,1,.12);for(const x of [-.48,.48]){box(x,.28,0,.12,.5,1);box(x,.08,0,.16,.16,1.5);box(x,.85,0,.12,.12,1.15);}break;
 case 'bench':box(0,.5,0,2,.12,.5);legs(2,.5,.48);break;
 case 'cabinet':box(0,1,0,1.5,2,1);for(const x of [-.37,.37]){box(x,1,.51,.68,1.7,.035,dark);mesh('ball',gold,x/3,1,.55,.035,.04,.025);}box(0,2.05,0,1.5,.1,1);break;
 case 'daybed':box(0,.35,0,2.5,.7,1.5);box(0,.75,0,2.3,.15,1.3,cloth);box(0,1,-.67,2.5,.65,.15,dark);for(const x of [-1.16,1.16])box(x,.9,0,.16,.65,1.5);box(-.75,.89,0,.55,.2,.9,'#d5c8a3');break;
 case 'altar-table':box(0,1,0,2,.15,1,dark);legs(2,1,.95);box(0,.8,.44,1.8,.3,.08,gold);break;
 case 'vase':mesh('ball','#83aaa5',0,.38,0,.22,.32,.22);mesh('cylinder','#83aaa5',0,.72,0,.11,.24,.11);break;
 case 'lantern':box(0,.08,0,.5,.16,.5,dark);box(0,.7,0,.05,1.3,.05,dark);mesh('ball','#e8ad68',0,1,0,.24,.38,.24);box(0,1.37,0,.38,.06,.38,gold);break;
 case 'bonsai':box(0,.18,0,.85,.32,.7,dark);mesh('cylinder',wood,0,.55,0,.09,.6,.09);for(const [x,y,z]of [[0,1,0],[-.22,.85,.1],[.2,1.15,-.1]])mesh('ball','#6f9162',x,y,z,.28,.22,.27);break;
 case 'screen':for(const x of [-.64,0,.64]){box(x,1.1,0,.62,2.2,.12,dark);box(x,1.15,.07,.5,1.85,.02,'#d7cba9');box(x,1.1,.085,.04,1.4,.02,'#759179');}break;
 case 'cushion':mesh('cylinder',cloth,0,.14,0,.48,.28,.48);mesh('cylinder','#b7ac87',0,.29,0,.36,.025,.36);break;
 case 'fruit-plate':mesh('cylinder',gold,0,.1,0,.45,.1,.22);for(const x of [-.22,0,.22])mesh('ball','#df9e73',x,.24,0,.12,.13,.12);break;
 case 'incense-set':box(0,.12,0,.45,.24,.4,gold);for(const x of [-.12,0,.12])mesh('cylinder','#a95939',x,.5,0,.015,.65,.015);break;
 case 'tea-cup':mesh('cylinder','#afc2b0',0,.16,0,.18,.3,.18);mesh('cylinder','#766e40',0,.315,0,.14,.012,.14);break;
 }
}
function r3BatchDecor(group){
 const batches=new Map();group.traverse(m=>{if(!m.isMesh)return;m.updateWorldMatrix(true,false);const k=m.geometry.uuid+':'+m.material.uuid;if(!batches.has(k))batches.set(k,[]);batches.get(k).push(m);});
 const inverse=new THREE.Matrix4().copy(group.matrixWorld).invert(),built=[];
 for(const arr of batches.values()){const inst=new THREE.InstancedMesh(arr[0].geometry,arr[0].material,arr.length);arr.forEach((m,i)=>inst.setMatrixAt(i,new THREE.Matrix4().multiplyMatrices(inverse,m.matrixWorld)));inst.castShadow=inst.receiveShadow=true;built.push(inst);}worldClear(group);built.forEach(m=>group.add(m));
}
function worldSyncDecor(){
 const w=W3,sceneId=w?.active;if(!r3DecorScene(sceneId))return;const space=w.spaces[sceneId],items=S.decor[sceneId]||[],key=JSON.stringify(items);if(space.decorKey===key)return;space.decorKey=key;
 if(!space.decorGroup){space.decorGroup=new THREE.Group();space.group.add(space.decorGroup);}space.decorGroup.children.forEach(m=>m.dispose?.());worldClear(space.decorGroup);space.blocks=space.blocks.filter(v=>!v.r3Decor);
 for(const item of items){const b=r3Bounds(item);if(!b||!r3Item(item.id)||![item.x,item.z].every(Number.isFinite))continue;r3Furniture(space.decorGroup,item);space.blocks.push({...b,r3Decor:true});}
 space.group.updateMatrixWorld(true);r3BatchDecor(space.decorGroup);
 // A restored save may place furniture over the current spawn. Recover onto a free half-grid cell.
 if(w.player&&!worldCanMove(w.player.position.x,w.player.position.z)){let best=null,dist=Infinity;for(let x=-space.limit.x+.5;x<space.limit.x;x+=.5)for(let z=-space.limit.z+.5;z<space.limit.z;z+=.5){const d=Math.hypot(x-w.player.position.x,z-w.player.position.z);if(d<dist&&worldCanMove(x,z)){dist=d;best={x,z};}}if(best){w.player.position.x=best.x;w.player.position.z=best.z;worldStop();}}
}

/* Pass 3: livestock, companion animals, produce, and courtyard gardens. */
var R3_PENS=[
 {id:'hen-yard',name:'咯咯鸡舍',x:-13,X:-8,z:6.5,Z:12},
 {id:'pasture',name:'青草牧栏',x:-7.5,X:-2.5,z:6.5,Z:12},
 {id:'pig-yard',name:'桃花猪栏',x:3.5,X:9,z:8,Z:13}
];
var R3_ANIMAL_SHOP=[
 {id:'chicken',name:'小鸡',emoji:'🐔',price:40,cap:4,pen:0,nickname:'小花',desc:'约 25 秒产一枚蛋'},
 {id:'cow',name:'奶牛',emoji:'🐄',price:120,cap:2,pen:1,nickname:'奶糖',desc:'约 40 秒产一份奶'},
 {id:'pig',name:'小猪',emoji:'🐷',price:80,cap:2,pen:2,nickname:'团团',desc:'圆滚滚的快乐伙伴'},
 {id:'sheep',name:'绵羊',emoji:'🐑',price:70,cap:2,pen:1,nickname:'棉花',desc:'喜欢在牧栏里吃青草'},
 {id:'dog',name:'小狗',emoji:'🐕',price:90,cap:2,pen:null,nickname:'阿黄',desc:'没有围栏，偶尔跟着你散步'},
 {id:'cat',name:'小猫',emoji:'🐈',price:70,cap:2,pen:null,nickname:'糯米',desc:'自由散步，也爱卧着晒太阳'}
];
var R3_PRODUCE=[{id:'egg',name:'蛋',emoji:'🥚',value:2,sell:16},{id:'milk',name:'奶',emoji:'🥛',value:4,sell:32}];
window.R3_PRODUCE=R3_PRODUCE;window.R3_ANIMAL_SHOP=R3_ANIMAL_SHOP;
function r3AnimalId(){return 'animal-'+(globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));}
function r3SanitizeAnimals(d){
 const now=Date.now(),seen=new Set(),kinds=R3_ANIMAL_SHOP.map(c=>c.id),pens={chicken:0,cow:1,pig:2,sheep:1,dog:null,cat:null},names={chicken:'小花',cow:'奶糖',pig:'团团',sheep:'棉花',dog:'阿黄',cat:'糯米'};
 d.animals=(Array.isArray(d.animals)?d.animals:[]).filter(a=>a&&typeof a==='object'&&kinds.includes(a.kind)).map(a=>{
  let id=typeof a.id==='string'&&a.id?a.id:r3AnimalId();if(seen.has(id))id=r3AnimalId();seen.add(id);
  const born=Number.isFinite(a.born)&&a.born>0?Math.min(now,a.born):now;
  return {...a,id,post:['garden','follow','home'].includes(a.post)?a.post:'home',kind:a.kind,name:typeof a.name==='string'&&a.name.trim()?a.name.trim().slice(0,18):(names[a.kind]||R3_ANIMAL_SHOP.find(c=>c.id===a.kind)?.nickname||a.kind),pen:a.pen===null?null:Number.isFinite(a.pen)?a.pen:(R3_ANIMAL_SHOP.find(c=>c.id===a.kind)?.pen??pens[a.kind]),born,lastCollect:Number.isFinite(a.lastCollect)&&a.lastCollect>=0?Math.min(now,a.lastCollect):born,lastPet:Number.isFinite(a.lastPet)&&a.lastPet>=0?Math.min(now,a.lastPet):0};
 });
}
function r3BuyAnimal(kind){
 if(r3DenyVisit())return;
 const c=R3_ANIMAL_SHOP.find(v=>v.id===kind);if(!c)return false;
 if(!Array.isArray(S.animals))S.animals=[];
 if(S.animals.filter(a=>a.kind===kind).length>=c.cap){toast(c.pen===null?'小院里这类伙伴已经住满啦':'这类动物的牧栏名额已满');return false;}
 if(S.coins<c.price){toast('铜钱不足，先出售一些作物吧');return false;}
 const now=Date.now();S.coins-=c.price;S.animals.push({id:r3AnimalId(),kind,name:c.nickname,pen:c.pen,born:now,lastCollect:now,lastPet:0,post:'home'});r3Commit();worldSyncAnimals();toast(`${c.emoji} ${c.nickname}已经入住自家小院`);return true;
}
function r3ProduceItem(id){return R3_PRODUCE?.find(v=>v.id===id);}
function r3AnimalProduce(animal){return animal.kind==='chicken'?{id:'egg',interval:25000}:animal.kind==='cow'?{id:'milk',interval:40000}:null;}
function r3ProduceReady(animal,now=Date.now()){const p=r3AnimalProduce(animal);return !!p&&now-(animal.lastCollect??animal.born)>=p.interval;}
function r3CollectOne(animal,now){if(!r3CanEdit())return null;const p=r3AnimalProduce(animal);if(!p||!r3ProduceReady(animal,now))return null;animal.lastCollect=now;S.inventory[p.id]=(S.inventory[p.id]||0)+1;return r3ProduceItem(p.id);}
function r3CollectProduce(){
 if(r3DenyVisit())return;
 if(W3?.active!=='yard')return;const now=Date.now(),counts={};for(const a of S.animals||[]){const p=r3CollectOne(a,now);if(p)counts[p.id]=(counts[p.id]||0)+1;}
 if(!Object.keys(counts).length)return toast('产物还在准备中：鸡蛋约 25 秒，牛奶约 40 秒');
 r3Commit();r3RefreshAnimalHUD();toast('收取 '+Object.entries(counts).map(([id,n])=>r3ProduceItem(id).emoji+r3ProduceItem(id).name+' ×'+n).join('、'));
}
function r3PetAnimal(id){
 if(W3?.active!=='yard'||worldBlocked())return;const animal=(S.animals||[]).find(a=>a.id===id);if(!animal)return;
 if(!r3CanEdit()){const key=(window.TG_VISIT?.ownerId||S.ownerId||'self')+':'+id,now=Date.now();if(now-(R3_VISIT_PETS.get(key)||0)<8000)return toast(animal.name+'正在开心地休息');R3_VISIT_PETS.set(key,now);addMerit(1);toast(animal.name+'蹭了蹭你的手，善缘 +1');return;}
 const now=Date.now(),produce=r3CollectOne(animal,now),ready=now-(animal.lastPet||0)>=8000;
 if(ready){animal.lastPet=now;addMerit(1);}
 if(ready||produce){r3Commit();r3RefreshAnimalHUD();}
 toast(`${animal.name}${ready?'蹭了蹭你的手，善缘 +1':'正在开心地休息，过一会儿再摸摸吧'}${produce?' · 收取 '+produce.emoji+produce.name:''}`);
}
function r3ProduceInventoryHTML(){const list=R3_PRODUCE.filter(p=>(S.inventory[p.id]||0)>0);return list.length?'<h3>小院产物</h3>'+list.map(p=>`<div class="r3-row"><span>${p.emoji} ${p.name}</span><b>× ${S.inventory[p.id]}</b></div>`).join(''):'';}
function r3AppendProduceOffers(){
 if(!$('#modal').classList.contains('show')||$('#r3ProduceOffers'))return;
 const holder=document.createElement('div');holder.id='r3ProduceOffers';holder.innerHTML=`<h3>小院产物</h3><div class="inv-grid">${R3_PRODUCE.map(p=>`<button class="inv-item ${(S.inventory[p.id]||0)>0?'clickable':'none'}" data-produce="${p.id}"><span class="e">${p.emoji}</span>${p.name} ×${S.inventory[p.id]||0}<br><small>善缘 +${p.value}</small></button>`).join('')}</div>`;
 $('#sheet').append(holder);holder.onclick=e=>{if(r3DenyVisit())return;const b=e.target.closest('[data-produce]');if(!b)return;const p=r3ProduceItem(b.dataset.produce);if(!(S.inventory[p.id]>0))return toast('还没有这份产物');S.inventory[p.id]--;S.offerings.push({crop:p.id,at:Date.now()});tgFeedback('offer');addMerit(p.value,$('#altar'));r3Commit();closeModal();renderHall();worldSyncHall();toast(`摆上 ${p.emoji}${p.name}，善缘 +${p.value}`);};
}
// Keep the original crop offering handler and its listener completely intact.
$('#btnOffer').addEventListener('click',r3AppendProduceOffers);
function r3HallProduce(group,offering,i){const p=r3ProduceItem(offering.crop);if(!p)return false;const x=(i-3)*.52;if(p.id==='egg')worldMesh(group,'ball','#f4e4bf',x,1.76,-5.7,.17,.25,.17);else {worldMesh(group,'cylinder','#d5e7dd',x,1.77,-5.7,.18,.3,.18);worldMesh(group,'cylinder','#fff5d8',x,1.93,-5.7,.15,.015,.15);}return true;}
function r3RefreshAnimalHUD(){const el=$('#r3AnimalStatus');if(!el)return;const animals=S.animals||[],ready=animals.filter(a=>r3ProduceReady(a)).length;el.textContent=animals.length?`${animals.length} 位小伙伴 · ${ready?ready+' 份产物可收取':'产物准备中'}`:'领养小伙伴，为小院添些热闹';}

function r3AnimalModel(kind){
 const root=new THREE.Group(),head=new THREE.Group();root.add(head);
 const bodyColor={chicken:'#f6e5c4',cow:'#f6e5c4',pig:'#e7aa9f',sheep:'#f6e5c4',dog:'#c99860',cat:'#c99860'}[kind],dark='#514233',pink='#e7aa9f',gold='#d8ac57';
 const m=(g,type,color,x,y,z,a,b,c)=>worldMesh(g,type,color,x,y,z,a,b,c);
 const small=kind==='chicken',cat=kind==='cat',pet=cat||kind==='dog',bodyY=small?.4:.65;
 m(root,'ball',bodyColor,0,bodyY,0,small?.32:pet?.34:.48,small?.32:pet?.33:.44,small?.38:pet?.57:.7);
 head.position.set(0,small?.66:pet?.87:.95,small?.28:pet?.43:.53);
 m(head,'ball',bodyColor,0,0,0,small?.23:pet?.28:.33,small?.24:pet?.29:.32,small?.24:pet?.29:.31);
 for(const x of [-1,1]){m(head,'ball',dark,x*(small?.09:.13),.04,small?.21:.265,.025,.035,.025);if(!small)m(head,cat?'cone':'ball',bodyColor,x*.22,.24,0,cat?.09:.14,cat?.24:.1,.09);}
 if(small){m(head,'cone','#ca6a52',0,.24,0,.1,.2,.1);const beak=m(head,'cone',gold,0,-.04,.27,.08,.18,.08);beak.rotation.x=Math.PI/2;for(const side of [-1,1])m(root,'ball',bodyColor,side*.27,.44,-.07,.12,.23,.25);}
 else if(kind==='pig'){m(head,'ball',pink,0,-.06,.29,.19,.12,.09);for(const x of [-.07,.07])m(head,'ball',dark,x,-.05,.37,.025,.03,.018);}
 else if(kind==='cow'){m(head,'ball',pink,0,-.12,.25,.24,.13,.13);for(const x of [-.24,.24])m(head,'cone',gold,x,.32,0,.065,.22,.065);for(const x of [-.27,.27])m(root,'ball',dark,x,.83,-.12,.22,.24,.3);}
 else if(kind==='sheep'){for(const [x,z]of [[-.24,-.3],[.24,-.3],[-.25,.2],[.25,.2],[0,-.56]])m(root,'ball',bodyColor,x,.8,z,.32,.3,.3);m(head,'ball',dark,0,-.02,.19,.2,.22,.14);}
 else{m(head,'ball',dark,0,-.07,.28,.06,.05,.04);if(kind==='dog')for(const x of [-.26,.26])m(head,'ball',dark,x,.03,0,.09,.25,.13);const tail=m(root,'cylinder',bodyColor,0,.8,-.65,.065,.5,.065);tail.rotation.x=cat?-.3:.65;}
 const legs=small?[-1,1]:[-1,1,-2,2];legs.forEach((n,i)=>m(root,'cylinder',small?gold:bodyColor,(n<0?-1:1)*(small?.13:pet?.22:.31),small?.12:.23,small?0:(i<2?-.38:.34),small?.035:.09,small?.24:.46,small?.035:.09));
 return {root,head};
}
function r3AnimalFree(x,z,r=.65){const s=W3.spaces.yard;return x> -13.4&&x<13.4&&z> -13.4&&z<13.4&&!R3_PENS.some(p=>x>p.x-r&&x<p.X+r&&z>p.z-r&&z<p.Z+r)&&!s.blocks.some(b=>x>b.x-r&&x<b.X+r&&z>b.z-r&&z<b.Z+r);}
function r3AnimalTarget(record){
 const pen=R3_PENS[record.animal.pen];if(pen){for(let i=0;i<32;i++){record.tx=pen.x+.9+Math.random()*(pen.X-pen.x-1.8);record.tz=pen.z+.9+Math.random()*(pen.Z-pen.z-1.8);if(!W3.spaces.yard.blocks.some(b=>b.r3Decor&&record.tx>b.x-.5&&record.tx<b.X+.5&&record.tz>b.z-.5&&record.tz<b.Z+.5))break;}}
 else{for(let i=0;i<32;i++){const x=-5.1+Math.random()*16,z=-3.5+Math.random()*15;if(r3AnimalFree(x,z)){record.tx=x;record.tz=z;break;}}}
 if(record.animal.kind==='dog'){const post=record.animal.post||'home';if(post!=='follow'){record.tx=(post==='garden'?-7:11.3)+Math.random()*.8-.4;record.tz=(post==='garden'?0:6.5)+Math.random()*.8-.4;}}
 record.until=2+Math.random()*4;record.rest=Math.random()<.3;
}
function worldSyncAnimals(){
 const w=W3,s=w?.spaces?.yard;if(!s)return;const animals=S.animals||[];
 // Runtime timestamps do not change meshes; adding/removing/renaming/re-penning does.
 const key=JSON.stringify(animals.map(a=>[a.id,a.kind,a.name,a.pen,a.born]));if(s.animalKey===key)return;s.animalKey=key;
 if(!s.animalGroup){s.animalGroup=new THREE.Group();s.group.add(s.animalGroup);}
 s.animalGroup.children.forEach(m=>m.dispose?.());worldClear(s.animalGroup);s.items=s.items.filter(v=>!v.r3Animal);
 const previous=new Map((s.animalRecords||[]).map(r=>[r.animal.id,r]));s.animalRecords=[];const batches=new Map();
 for(const a of animals){const model=r3AnimalModel(a.kind),old=previous.get(a.id),record={animal:a,...model,x:old?.x??0,z:old?.z??3,yaw:old?.yaw??0,phase:Math.random()*6,until:0,tx:0,tz:3,rest:false,parts:[]};r3AnimalTarget(record);const pen=R3_PENS[a.pen];if(!old){record.x=record.tx;record.z=record.tz;}if(!pen&&!r3AnimalFree(record.x,record.z)){record.x=record.tx;record.z=record.tz;}
 model.root.updateMatrixWorld(true);model.root.traverse(m=>{if(!m.isMesh)return;const k=m.geometry.uuid+':'+m.material.uuid;let b=batches.get(k);if(!b){b={geometry:m.geometry,material:m.material,parts:[]};batches.set(k,b);}const part={record,node:m,batch:b,index:b.parts.length};b.parts.push(part);record.parts.push(part);});
 const prompt={x:record.x,z:record.z,range:2.9,r3Animal:true,label:()=>`${!r3IsVisiting()&&r3ProduceReady(a)?'收取'+r3AnimalProduce(a).id.replace('egg','蛋').replace('milk','奶')+' · ':''}抚摸 ${a.name}`,run:()=>r3PetAnimal(a.id)};record.prompt=prompt;s.items.push(prompt);s.animalRecords.push(record);
 }
 s.animalBatches=[...batches.values()];for(const b of s.animalBatches){b.mesh=new THREE.InstancedMesh(b.geometry,b.material,b.parts.length);b.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);b.mesh.frustumCulled=false;b.mesh.castShadow=true;b.mesh.receiveShadow=true;s.animalGroup.add(b.mesh);}
 r3UpdateAnimalMatrices(0);r3RefreshAnimalHUD();
}
function r3UpdateAnimalMatrices(ts){const s=W3.spaces.yard;for(const r of s.animalRecords||[]){const walking=!r.rest&&Math.hypot(r.tx-r.x,r.tz-r.z)>.15;r.root.position.set(r.x,r.rest?.015:Math.abs(Math.sin(ts*.006+r.phase))*(walking?.045:.012),r.z);if(r.barkUntil>ts)r.root.position.y+=Math.abs(Math.sin(ts*.025))*.55;r.root.rotation.y=r.yaw;r.root.scale.y=r.root.userData.r5Kind?1:r.rest?.7:1;r.head.rotation.x=r.rest?Math.sin(ts*.002+r.phase)*.16:walking?0:Math.sin(ts*.004+r.phase)*.26;r.root.updateMatrixWorld(true);r.prompt.x=r.x;r.prompt.z=r.z;for(const p of r.parts)p.batch.mesh.setMatrixAt(p.index,p.node.matrixWorld);}for(const b of s.animalBatches||[])b.mesh.instanceMatrix.needsUpdate=true;}
function r3AnimateAnimals(ts,dt){
 const w=W3,s=w?.spaces?.yard;if(w?.active!=='yard'||!s)return;
 if(s.animalKey===undefined)worldSyncAnimals();if(worldBlocked())return;
 for(const r of s.animalRecords||[]){if(!R3_PENS[r.animal.pen]&&!r3AnimalFree(r.x,r.z)){r3AnimalTarget(r);r.x=r.tx;r.z=r.tz;}r.until-=dt;if(r.until<=0)r3AnimalTarget(r);const pet=!R3_PENS[r.animal.pen],player=w.player.position,dist=Math.hypot(player.x-r.x,player.z-r.z);
 if(pet&&(r.animal.kind!=='dog'||r.animal.post==='follow')&&!r.rest&&dist>1.8&&(r.animal.kind==='dog'||dist<7&&Math.sin(ts*.00022+r.phase)>.15)&&r3AnimalFree(player.x,player.z)){r.tx=player.x;r.tz=player.z;}
 if(pet&&dist<1.7&&Math.hypot(r.tx-player.x,r.tz-player.z)<1.8){r.tx=r.x;r.tz=r.z;}
 const dx=r.tx-r.x,dz=r.tz-r.z,len=Math.hypot(dx,dz);if(!r.rest&&len>.15){const speed=r.animal.kind==='chicken'?.6:pet?1.15:.65,step=Math.min(len,speed*Math.min(dt,.08)),x=r.x+dx/len*step,z=r.z+dz/len*step,pen=R3_PENS[r.animal.pen];
 const blocked=pet?!r3AnimalFree(x,z):x<pen.x+.7||x>pen.X-.7||z<pen.z+.7||z>pen.Z-.7||s.blocks.some(b=>b.r3Decor&&x>b.x-.5&&x<b.X+.5&&z>b.z-.5&&z<b.Z+.5);
 if(!blocked){r.x=x;r.z=z;r.yaw+=Math.atan2(Math.sin(Math.atan2(dx,dz)-r.yaw),Math.cos(Math.atan2(dx,dz)-r.yaw))*Math.min(1,dt*4);}else r.until=0;}
 }
 for(const r of s.animalRecords||[])if(r.barkUntil>ts)r.rest=false;
 r3UpdateAnimalMatrices(ts);if(ts-(s.animalHUDTime||0)>1000){s.animalHUDTime=ts;r3RefreshAnimalHUD();}
}

function r3PolishScenes(){
 const w=W3;
 function garden(id){const s=w.spaces[id],g=new THREE.Group();s.group.add(g);return {s,g};}
 function part(g,type,color,x,y,z,a,b,c){return worldMesh(g,type,color,x,y,z,a,b,c);}
 function tile(g,x,z,w=1.25,d=1.25){part(g,'box','#d4ceaf',x,.025,z,w,.06,d);}
 function lantern(g,x,z){part(g,'box','#806146',x,1.3,z,.11,2.6,.11);part(g,'box','#806146',x+.25,2.6,z,.65,.1,.15);part(g,'ball','#efc481',x+.48,2.24,z,.25,.35,.25);part(g,'box','#556e69',x+.48,2.58,z,.6,.12,.55);}
 function stoneLamp(g,x,z){part(g,'box','#9daca4',x,.12,z,.7,.24,.7);part(g,'box','#9daca4',x,.65,z,.22,1.1,.22);part(g,'box','#d7c696',x,1.22,z,.5,.5,.5);part(g,'cone','#68847b',x,1.61,z,.6,.45,.6);}
 function flowers(g,x,z,seed){for(let i=0;i<6;i++){const a=i*2.4+seed,r=.3+i%3*.18,xx=x+Math.cos(a)*r,zz=z+Math.sin(a)*r;part(g,'cone','#6f935e',xx,.17,zz,.12,.35,.12);part(g,'ball',seed%2?'#e8b5b1':'#dfce88',xx,.36,zz,.15,.12,.15);}}
 function tree(g,x,z){part(g,'cylinder','#806146',x,1.2,z,.18,2.4,.18);for(const [dx,y,dz]of [[0,2.7,0],[-.55,2.4,.1],[.55,2.6,-.1]])part(g,'ball','#6f935e',x+dx,y,z+dz,1,1.1,.9);}
 function solid(s,x,z,a,b,extra={}){s.blocks.push({x:x-a/2,X:x+a/2,z:z-b/2,Z:z+b/2,...extra});}
 function finish(s,g){s.group.updateMatrixWorld(true);r3BatchDecor(g);}
 // Mountain gate: a broad ceremonial path with low lantern gardens, clear through the paifang.
 {const {s,g}=garden('gate');s.floor.material=r3GrassMaterial();for(let z=-11;z<=11;z+=1.5)for(const x of [-.78,.78])tile(g,x,z,1.4,1.35);
 for(const x of [-3.3,3.3])for(const z of [-8,0,8]){lantern(g,x,z);flowers(g,x+Math.sign(x)*.7,z,Math.round(z+9));solid(s,x,z,.4,.4);}
 for(const x of [-10,10]){tree(g,x,6);tree(g,x,-8);solid(s,x,6,.6,.6);solid(s,x,-8,.6,.6);}
 finish(s,g);}
 // Market: paved promenade, goods on the counters, hanging lanterns and flowering tubs.
 {const {s,g}=garden('market');s.floor.material=tgArtTexture('stone');for(let x=-12;x<=12;x+=1.5)for(const z of [-.8,.8])tile(g,x,z,1.35,1.35);
 for(const x of [-7,0,7]){for(const dx of [-1.8,1.8]){part(g,'box','#806146',x+dx,1.8,-5,.12,2.6,.12);lantern(g,x+dx,-3.7);}
 for(let j=0;j<6;j++){const xx=x-.9+j*.36;part(g,'ball',x<0?'#6f935e':x>0?'#efc481':'#c99860',xx,1.58,-4.7,.16,.2,.16);}
 for(let j=0;j<5;j++)part(g,'box',j%2?'#d4ceaf':'#a86f55',x-1.8+j*.9,3.03,-4.25,.4,.04,1.1);}
 for(const x of [-10.5,10.5]){flowers(g,x,4,0);flowers(g,x,6,1);stoneLamp(g,x,2);solid(s,x,2,.7,.7);tree(g,x,9);solid(s,x,9,.6,.6);}
 finish(s,g);}
 // Lotus bank: stepping stones, waterside flowers, a small pavilion outside the pond footprint.
 {const {s,g}=garden('lotus');s.floor.material=r3GrassMaterial();for(let z=6;z<=12;z+=1.4)for(const x of [-.75,.75])tile(g,x,z,1.3,1.25);
 for(const side of [-1,1])for(let i=0;i<8;i++){const a=i/7*Math.PI,x=side*(7.8+Math.sin(a)*.4),z=-7+i*1.5;part(g,'box','#d4ceaf',x,.03,z,1.25,.08,1.35);if(i%2===0)flowers(g,x+side*1.2,z,i);}
 for(const x of [-3.4,3.4]){stoneLamp(g,x,7);solid(s,x,7,.7,.7);}for(const x of [-11,11]){tree(g,x,-9);solid(s,x,-9,.6,.6);}
 part(g,'box','#d4ceaf',10,.16,6,4,.3,4);for(const x of [8.5,11.5])for(const z of [4.5,7.5]){part(g,'cylinder','#806146',x,1.7,z,.12,3.2,.12);solid(s,x,z,.3,.3);}
 part(g,'box','#556e69',10,3.35,6,4.6,.25,4.6);part(g,'cone','#556e69',10,3.95,6,3.4,1,3.4);part(g,'box','#806146',10,.65,7.35,2.3,.15,.45);solid(s,10,7.35,2.3,.45);
 finish(s,g);}
 // Home: an east-west walk connects the gate to the central courtyard; house approach stays open.
 {const {s,g}=garden('yard');s.floor.material=r3GrassMaterial();for(let x=2;x<=13;x+=1.4)for(const z of [-.7,.7])tile(g,x,z,1.25,1.25);for(let z=4;z<=6;z+=1.4)tile(g,8,z,1.7,1.2);
 for(const x of [-2.2,2.2]){lantern(g,x,-4);flowers(g,x,-3,1);solid(s,x,-4,.4,.4);}
 for(const [x,z]of [[13,6],[10,12]]){tree(g,x,z);solid(s,x,z,.6,.6);flowers(g,x+1,z,1);}
 for(const p of R3_PENS){
  const mid=(p.x+p.X)/2,gap=1.8;
  part(g,'box','#a8ab79',mid,.015,(p.z+p.Z)/2,p.X-p.x,.05,p.Z-p.z);
  // North/east/west fences and two south sections leave a real entry gate for the monk.
  const segments=[[(p.x+p.X)/2,p.z,p.X-p.x,.16], [p.x,(p.z+p.Z)/2,.16,p.Z-p.z],[p.X,(p.z+p.Z)/2,.16,p.Z-p.z],[(p.x+mid-gap/2)/2,p.Z,mid-gap/2-p.x,.16],[(mid+gap/2+p.X)/2,p.Z,p.X-mid-gap/2,.16]];
  for(const [x,z,a,d]of segments){for(const y of [.4,.85])part(g,'box','#a9865e',x,y,z,a,.1,d);solid(s,x,z,a,d,{r3Pen:true});}
  for(const x of [p.x,p.X])for(let z=p.z;z<=p.Z;z+=1.3)part(g,'box','#806146',x,.55,z,.15,1.1,.15);
  for(let x=p.x;x<=p.X;x+=1.3)for(const z of [p.z,p.Z]){if(z===p.Z&&Math.abs(x-mid)<gap/2)continue;part(g,'box','#806146',x,.55,z,.15,1.1,.15);}
  for(const x of [mid-gap/2,mid+gap/2])part(g,'box','#806146',x,.6,p.Z,.18,1.2,.18);
  // Water bowls and hay at the perimeter; pen centers remain open for grazing.
  part(g,'cylinder','#9daca4',p.X-.55,.13,p.z+.5,.32,.25,.32);part(g,'cylinder','#8cbeb4',p.X-.55,.26,p.z+.5,.25,.015,.25);
  for(let i=0;i<10;i++)part(g,'cone','#6f935e',p.x+.6+(i%5)*.8,.16,p.z+.8+Math.floor(i/5)*1.1,.12,.32,.12);
  worldLabel(s.group,p.name,mid,1.45,p.Z+.02,2.2);
 }
 finish(s,g);
 }
}
// Add home-only animal controls without replacing the existing return / placement buttons.
{const tools=$('#home .r3-tools'),wrap=document.createElement('div');wrap.className='r3-animal-hud';wrap.innerHTML='<small id="r3AnimalStatus">领养小伙伴，为小院添些热闹</small><div><button class="big-btn wood" onclick="openShop(\'animals\')">🐾 领养</button><button class="big-btn wood" onclick="r3CollectProduce()">🥚 收取产物</button></div>';tools.before(wrap);}

function r3GrassMaterial(){
 const w=W3;if(w.materials['r3:grass'])return w.materials['r3:grass'];const c=document.createElement('canvas');c.width=c.height=128;const a=c.getContext('2d');a.fillStyle='#91a976';a.fillRect(0,0,128,128);for(let i=0;i<140;i++){const x=(i*47)%128,z=(i*31)%128;a.strokeStyle=i%2?'#839d69':'#9fb480';a.beginPath();a.moveTo(x,z);a.lineTo(x-1,z-3);a.moveTo(x,z);a.lineTo(x+2,z-2);a.stroke();}const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(14,14);return w.materials['r3:grass']=new THREE.MeshLambertMaterial({map:t});
}

/* Pass 4: visiting policy and backend state-swap rendering. */
var R3_VISIT_PETS=new Map();
function r3IsVisiting(){return !!(window.TG_VISIT||window.TG_ACCESS?.isVisiting?.());}
function r3SkipDemoGate(){return r3IsVisiting()||typeof window.TG_ACCESS?.canEnter==='function';}
function r3DenyVisit(){if(r3CanEdit())return false;toast('拜访中无法修改主人的庭院');return true;}
function r3DiscardPlan(){const p=window.TG_PLAN;if(!p)return;p.observer?.disconnect();window.TG_PLAN=null;$('#planView').hidden=true;document.body.classList.remove('r3-planning');}
// Only these shared-space fields are swapped by family/owner visits.
var r3OwnSpace=null,r3WasVisiting=false;
function r3SnapshotOwnSpace(state=S){
 if(r3IsVisiting())return;
 r3OwnSpace=JSON.parse(JSON.stringify({plots:state.plots,decor:state.decor,shrine:state.shrine,animals:state.animals}));
}
function r3SyncOwnSpace(){
 const visiting=r3IsVisiting(),started=!r3WasVisiting&&visiting,ended=r3WasVisiting&&!visiting;
 r3WasVisiting=visiting;
 if(ended&&r3OwnSpace){Object.assign(S,JSON.parse(JSON.stringify(r3OwnSpace)));return true;}
 if(!visiting)r3SnapshotOwnSpace();
 return started;
}
function r3ApplyVisitingUI(sync=true){
 if(sync&&r3SyncOwnSpace())window.TG_RERENDER();
 const visiting=!r3CanEdit();document.body.classList.toggle('r3-visiting',visiting);
 document.querySelectorAll('[onclick*="openShop"],[onclick*="openShrineStudio"],[onclick*="enterPlacement"],[onclick*="r3CollectProduce"]').forEach(b=>{b.dataset.r3Edit='';b.disabled=visiting;});
 $('#pillCoins').disabled=visiting;
 if(visiting)r3DiscardPlan();if(r3SkipDemoGate())$('#gateLock').classList.remove('show');
}
// Capture old DOM actions too: an already-open modal cannot modify a newly supplied owner snapshot.
document.addEventListener('click',e=>{
 if(r3CanEdit()||!e.target.closest('[data-r3-edit],#r3Shop,#r3Arrange,#resetBtn,#btnOffer,#btnIncense,#r3ProduceOffers,#plots .plot,#seedBar,#plantAll,#waterAll,#harvestAll,[data-buy],[data-sell],[data-sell-all],[data-animal],[data-style]'))return;
 const plot=e.target.closest('#plots .plot');if(plot&&S.plots[+plot.dataset.i]&&plotProgress(S.plots[+plot.dataset.i],Date.now())>=1)return;
 e.preventDefault();e.stopImmediatePropagation();r3DenyVisit();
},true);
window.TG_RERENDER=function(){
 // Never commit an editor bound to the preceding S after the backend replaces that snapshot.
 r3DiscardPlan();closeModal();r3ApplyVisitingUI(false);if(W3)worldStop();
 if(W3){W3.hallKey=undefined;for(const space of Object.values(W3.spaces||{})){space.decorKey=undefined;space.shrineKey=undefined;space.animalKey=undefined;}for(const c of W3.crops||[])c.key=undefined;}
 renderTop();if(current==='hall')renderHall();if(current==='yard')renderYard();
 worldSyncShrine();worldSyncDecor();worldSyncAnimals();worldSyncHall();worldSyncYard();r3RefreshAnimalHUD();
};
