/* r8d.js — smoothness pass (sidecar, loads last).
   1 shader / content pre-warm · 2 fade waits for rendered frames (helper) · 4 moving hysteresis + walk cadence
   + per-joint rate limiter (player, NPCs, animals) · panels close animation · 3D throttle behind sheets · toast queue.
   No save-key / ID / economy / RPC changes; codex2 modules untouched (wrapped from here). */
(function(){
const T=THREE,R8D=window.R8D={warm:{queue:null,done:[],skipped:[],ms:{},batches:{},phase:'idle'},frames:0,limit:{on:true,hits:0},toast:{q:[]}};
const D2R=Math.PI/180;

// ---------------- render counter (main canvas renders of the world scene) ----------------
let origRender=null;
function hookRender(){const r=W3?.renderer;if(!r||r.__r8d)return;r.__r8d=true;const orig=origRender=r.render.bind(r);
 r.render=function(scene,camera){
  if(scene===W3.scene&&r.getRenderTarget()===null){
   if(W3.r8dWarming){R8D.warm.suppressed=(R8D.warm.suppressed||0)+1;return;}// silent visit: never render (no sync shader status queries)
   if(pendingUpload&&inputQuiet()){const p=pendingUpload;pendingUpload=null;uploadStep(p.u);p.res();}
   if(throttled()){R8D.skipped3d=(R8D.skipped3d||0)+1;return;}
   const out=orig(scene,camera);R8D.frames++;if(R8D.frames===1)R8D.firstFrameMs=Math.round(performance.now());flushFrameWaits();return out;}
  return orig(scene,camera);};}
const waits=[];
function flushFrameWaits(){for(let i=waits.length-1;i>=0;i--){const w=waits[i];if(R8D.frames>=w.until){waits.splice(i,1);clearTimeout(w.to);try{w.cb();}catch(e){}}}}
// call cb after n more rendered frames of the world (fallback after maxMs)
window.r8dAfterFrames=function(n,cb,maxMs){const w={until:R8D.frames+Math.max(1,n|0),cb};let fired=false;const once=()=>{if(fired)return;fired=true;cb();};w.cb=once;w.to=setTimeout(()=>{const i=waits.indexOf(w);if(i>=0)waits.splice(i,1);once();},maxMs||900);waits.push(w);};

// ---------------- 3D throttle while a full sheet modal is open ----------------
let modalFrame=0;
function throttled(){const m=document.getElementById('modal');if(!m||!m.classList.contains('show'))return false;if(W3?.r8dNoThrottle)return false;
 return (++modalFrame%3)!==0;} // render every 3rd frame behind the dimmed sheet

// ---------------- 1. pre-warm: silent visits (content + r8c batches), compileAsync, pre-upload ----------------
const ORDER=['gate','hall','yard','market','tea','lotus','zen','study','plaza'];
let lastInput=0;for(const ev of ['pointerdown','pointermove','keydown','touchstart','wheel'])addEventListener(ev,()=>{lastInput=performance.now();},{passive:true,capture:true});
function idleOK(){const w=W3;if(!w?.active||w.r8dWarming)return false;
 if(performance.now()-lastInput<1500||document.hidden)return false;
 try{if(typeof switching!=='undefined'&&switching)return false;}catch(e){}
 if(document.getElementById('modal')?.classList.contains('show'))return false;
 if(w.r6Plan||w.pose!=='idle'||w.target||Math.hypot(w.vx||0,w.vz||0)>.05||Math.hypot(w.joy?.x||0,w.joy?.y||0)>.05||(w.keys&&w.keys.size))return false;
 try{if(typeof r6IsRiding==='function'&&r6IsRiding())return false;}catch(e){}
 try{if(window.TG_R8B_SEAT?.())return false;}catch(e){}
 return true;}
function snapState(){const w=W3;return {pos:w.player.position.clone(),ry:w.player.rotation.y,yaw:w.yaw,pitch:w.pitch,radius:w.radius,follow:w.follow.clone(),cp:w.camera.position.clone(),cq:w.camera.quaternion.clone(),vx:w.vx,vz:w.vz,
 east:window.r4EastArrival,exitInside:w.exitInside,exitLatch:w.exitLatch,cool:w.exitCooldownUntil,hash:location.hash,title:document.getElementById('sceneTitle')?.textContent};}
function restoreState(k){const w=W3;w.player.position.copy(k.pos);w.player.rotation.y=k.ry;w.yaw=k.yaw;w.pitch=k.pitch;w.radius=k.radius;w.follow.copy(k.follow);w.camera.position.copy(k.cp);w.camera.quaternion.copy(k.cq);w.camera.updateMatrixWorld();
 w.vx=k.vx;w.vz=k.vz;window.r4EastArrival=k.east;w.exitInside=k.exitInside;w.exitLatch=k.exitLatch;w.exitCooldownUntil=k.cool;
 if(location.hash!==k.hash)history.replaceState(null,'',k.hash);const st=document.getElementById('sceneTitle');if(st&&k.title!=null)st.textContent=k.title;}
function silentVisit(name){const w=W3,orig=w.active;if(name===orig||!w.spaces[name])return false;const t0=performance.now();
 const k=snapState(),altar=window.r5ProcessAltar;let ok=false;
 w.r8dWarming=true;window.r5ProcessAltar=()=>false;const sp=w.spaces[name],had=sp.r7Warm;sp.r7Warm=true;// r7b-ux whole-scene compile → replaced by the sliced compile below
 R8D.warm.compileQ=R8D.warm.compileQ||[];if(!had)R8D.warm.compileQ.push(name);
 try{worldEnter(name,orig);R8D.warm.msIn=R8D.warm.msIn||{};R8D.warm.msIn[name]=Math.round(performance.now()-t0);try{R8D.warm.batches[name]=window.TG_R8C?.batchNow?.(name)||0;}catch(e){R8D.warm.err=String(e);}ok=true;}
 catch(e){R8D.warm.err=name+': '+e;}
 finally{try{worldEnter(orig,name);}catch(e){R8D.warm.err2=String(e);}window.r5ProcessAltar=altar;restoreState(k);w.r8dWarming=false;try{window.TG_NPC?.hideBubbles?.();}catch(e){}}
 R8D.warm.ms[name]=Math.round(performance.now()-t0);return ok;}
// r8d v2 pre-warm (never blocks input):
//  · silent visits run with ALL renders suppressed → worldEnter only builds content and issues renderer.compile (r7b-ux), whose
//    compile/link commands go to the GPU process asynchronously (KHR_parallel_shader_compile is polled by compileAsync when present);
//    nothing queries program status on the main thread during warm-up.
//  · after a cool-down the space is "first-used" through a 1×1 px scissor inside the real frame, one top-level child at a time,
//    ≤ BUDGET ms per frame; any pointer/key input pauses the queue for 1.5 s.
//  · order: the scenes reachable from the current one first (nearest exit first), then breadth-first.
const BUDGET=6;let pendingUpload=null;
function nextOrder(){const w=W3,cur=w.active,seen=new Set([cur]),out=[];const p=w.player.position;
 let level=(w.spaces[cur]?.exits||[]).slice().sort((a,b)=>Math.hypot(a.x-p.x,a.z-p.z)-Math.hypot(b.x-p.x,b.z-p.z)).map(e=>e.to);
 while(level.length){const nxt=[];for(const n of level){if(seen.has(n)||!w.spaces[n])continue;seen.add(n);out.push(n);for(const e of w.spaces[n].exits||[])nxt.push(e.to);}level=nxt;}
 for(const n of ORDER)if(!seen.has(n)&&w.spaces[n]){seen.add(n);out.push(n);}return out;}
// per-object first use through layer 31 (same lights → same programs), ≤BUDGET ms and at most ONE never-used program per frame:
// on drivers without KHR_parallel_shader_compile the first status query of a program is atomic (it waits for the link), so this is the finest grain possible.
const usedProg=new Set();
function uploadStep(u){const w=W3,s=w.spaces[u.name],r=w.renderer;if(!s){u.done=true;return;}
 if(!u.list){u.list=[];u.j=0;const walk=o=>{if(!o.visible)return;if((o.isMesh||o.isPoints||o.isLine||o.isSprite)&&o.material)u.list.push(o);for(const c of o.children)walk(c);};for(const c of s.group.children)walk(c);}
 const vis={};for(const [n,sp] of Object.entries(w.spaces))vis[n]=sp.group.visible;const sky=w.sky?.visible;const lights=[];w.scene.traverse(o=>{if(o.isLight)lights.push(o);});
 const sc=r.getScissorTest(),sv=new T.Vector4();r.getScissor(sv);const cl=w.camera.layers.mask,sm=r.shadowMap.autoUpdate,sn=r.shadowMap.needsUpdate;const t0=performance.now();let n=0,fresh=0;
 try{for(const [k,sp] of Object.entries(w.spaces))sp.group.visible=k===u.name;if(w.sky)w.sky.visible=false;r.setScissorTest(true);r.setScissor(0,0,1,1);r.shadowMap.autoUpdate=false;r.shadowMap.needsUpdate=false;
  for(const l of lights)l.layers.enable(31);w.camera.layers.set(31);
  while(u.j<u.list.length&&(n===0||performance.now()-t0<BUDGET)){const o=u.list[u.j++];const ms=Array.isArray(o.material)?o.material:[o.material];
   const progs=ms.map(m=>r.properties.get(m).currentProgram).filter(Boolean);const isNew=!progs.length||progs.some(p=>!usedProg.has(p));
   if(isNew&&fresh>0){u.j--;break;}
   const fc=o.frustumCulled;o.frustumCulled=false;o.layers.enable(31);try{origRender(w.scene,w.camera);}finally{o.layers.disable(31);o.frustumCulled=fc;}
   for(const m of ms){const p=r.properties.get(m).currentProgram;if(p)usedProg.add(p);}if(isNew)fresh++;n++;}}
 catch(e){R8D.warm.errU=u.name+': '+e;u.j=u.list.length;}
 finally{w.camera.layers.mask=cl;for(const l of lights)l.layers.disable(31);r.setScissorTest(sc);r.setScissor(sv);r.shadowMap.autoUpdate=sm;r.shadowMap.needsUpdate=sn;for(const [k,sp] of Object.entries(w.spaces))sp.group.visible=vis[k];if(w.sky)w.sky.visible=sky;}
 const dt=performance.now()-t0;const W=R8D.warm;W.upMs[u.name]=(W.upMs[u.name]||0)+dt;W.upMax=Math.max(W.upMax||0,dt);W.upSteps=(W.upSteps||0)+1;(W.upHist=W.upHist||[]).push(Math.round(dt));if(u.j>=u.list.length)u.done=true;}
function withSpace(name,fn){const w=W3,vis={};for(const [n,sp] of Object.entries(w.spaces)){vis[n]=sp.group.visible;sp.group.visible=n===name;}
 try{return fn();}finally{for(const [n,sp] of Object.entries(w.spaces))sp.group.visible=vis[n];}}
// one slice of shader compile: one top-level child at a time, ≤BUDGET ms; programs are created + compile/link commands queued, never queried
function compileSlice(c){const w=W3,kids=w.spaces[c.name].group.children;const t0=performance.now();
 withSpace(c.name,()=>{while(c.i<kids.length&&(c.i===c.s||performance.now()-t0<BUDGET)){const k=kids[c.i++];if(k.visible)try{w.renderer.compile(k,w.camera,w.scene);}catch(e){R8D.warm.errC=String(e);}}});c.s=c.i;
 const dt=performance.now()-t0,W=R8D.warm;W.cMax=Math.max(W.cMax||0,dt);W.cMs=(W.cMs||0)+dt;W.cSlices=(W.cSlices||0)+1;return c.i>=kids.length;}
// non-blocking GPU completion wait (WebGL2 fence, polled, never clientWaitSync with a timeout)
async function gpuIdle(maxMs=8000){const gl=W3.renderer.getContext();if(!gl.fenceSync)return sleep(300);const f=gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE,0);gl.flush();const t0=performance.now();
 while(gl.getSyncParameter(f,gl.SYNC_STATUS)!==gl.SIGNALED&&performance.now()-t0<maxMs)await sleep(50);gl.deleteSync(f);const dt=performance.now()-t0;R8D.warm.fenceMs=(R8D.warm.fenceMs||0)+dt;R8D.warm.fenceMax=Math.max(R8D.warm.fenceMax||0,dt);}
function inputQuiet(){return performance.now()-lastInput>=1500&&!document.hidden;}
const sleep=ms=>new Promise(r=>setTimeout(r,ms)),idle=()=>new Promise(r=>(window.requestIdleCallback||setTimeout)(r,{timeout:250}));
function texOf(m,out){for(const k of ['map','normalMap','roughnessMap','metalnessMap','aoMap','emissiveMap','alphaMap','bumpMap','lightMap','envMap','specularMap','displacementMap'])if(m[k]?.isTexture)out.add(m[k]);}
// frame / long-task probes while warming
function probes(){const W=R8D.warm;W.maxFrame=0;W.frames=0;let last=performance.now();const tick=t=>{if(W.phase==='done'||W.phase==='error')return;const d=t-last;last=t;W.frames++;if(d>W.maxFrame){W.maxFrame=Math.round(d);}requestAnimationFrame(tick);};requestAnimationFrame(tick);
 try{W.longTasks=[];const po=new PerformanceObserver(l=>{for(const e of l.getEntries())if(W.phase!=='done')W.longTasks.push(Math.round(e.duration));});po.observe({entryTypes:['longtask']});W._po=po;}catch(e){}}
async function warm(){const W=R8D.warm;if(W.phase!=='idle')return;W.phase='visit';W.upMs={};const t0=performance.now();probes();
 const todo=nextOrder().filter(n=>!W3.spaces[n].r8dVisited);W.order=todo.slice();
 for(const n of todo){let tries=0;while(!idleOK()&&tries++<900)await sleep(120);
  if(!idleOK()){W.skipped.push(n);continue;}if(W3.active===n||W3.spaces[n].r8dVisited)continue;
  await idle();if(!idleOK()){W.skipped.push(n);continue;}
  if(silentVisit(n)){W3.spaces[n].r8dVisited=true;W.done.push(n);}
  for(const name of W.compileQ.splice(0)){const c={name,i:0,s:0};let fin=false;while(!fin){while(!inputQuiet()||switching)await sleep(200);await idle();if(!W3.spaces[name])break;fin=compileSlice(c);}}
  await gpuIdle();}
 W.phase='textures';{const r=W3.renderer,texs=new Set();W3.scene.traverse(o=>{const ms=Array.isArray(o.material)?o.material:o.material?[o.material]:[];for(const m of ms)texOf(m,texs);});
  const list=[...texs];let i=0;while(i<list.length){while(!inputQuiet())await sleep(200);await idle();const t=performance.now();while(i<list.length&&performance.now()-t<BUDGET){try{r.initTexture(list[i]);}catch(e){}i++;}}W.textures=list.length;}
 W.programs=W3.renderer.info.programs.length;
 W.phase='upload';await gpuIdle(20000);// GPU process has executed every queued compile/link
 for(const n of W.done){if(!W3.spaces[n]||n===W3.active)continue;const u={name:n,i:0,done:false};
  while(!u.done){while(!inputQuiet()||switching)await sleep(200);await new Promise(res=>{pendingUpload={u,res};setTimeout(res,1500);});pendingUpload=null;await gpuIdle(3000);}}
 W.programsAfter=W3.renderer.info.programs.length;W.totalMs=Math.round(performance.now()-t0);for(const k in W.upMs)W.upMs[k]=Math.round(W.upMs[k]);W.upMax=Math.round(W.upMax||0);W.phase='done';try{W._po?.disconnect();delete W._po;}catch(e){}}
R8D.warmNow=warm;
// ---------------- 1b. hall lantern lights: one light setup for every scene ----------------
// Only the hall has point lights (3, restored with the v13 hall), so every material seen in the hall AND elsewhere needed a second
// program variant (numPointLights 3 vs 0). The 3 lights now live at scene level in every scene, at full intensity in the hall
// and intensity 0 elsewhere: same program key everywhere → the variants collapse; zero-intensity lights add exactly 0, so no scene changes look.
// r8d: OFF by default — measured play-frame cost of 3 point lights in every scene (SwiftShader, portrait): market 67→83, tea 150→233, lotus 50→100 ms
// median vs 39 fewer programs that the pre-warm already compiles off the critical path. Opt in with R8D_OPTS={sharedLights:true}.
const SL={on:!!(window.R8D_OPTS&&R8D_OPTS.sharedLights===true),lights:[]};R8D.sharedLights=SL;
function shareLights(){if(!SL.on)return;const w=W3,h=w?.spaces?.hall;if(!h)return;const found=[];h.group.traverse(o=>{if(o.isPointLight&&!o.r8dShared)found.push(o);});
 for(const l of found){l.r8dShared=true;l.r8dI=l.intensity;w.scene.attach(l);SL.lights.push(l);}
 const inHall=w.active==='hall';for(const l of SL.lights)l.intensity=inHall?l.r8dI:0;}
R8D.shareLights=shareLights;

{const en=worldEnter;worldEnter=function(name){const r=en.apply(this,arguments);try{shareLights();}catch(e){R8D.slErr=String(e);}try{const a=W3?.active;if(a&&W3.spaces[a])W3.spaces[a].r8dVisited=true;}catch(e){}if(!W3.r8dWarming)limitReset();return r;};}

// ---------------- 4. moving hysteresis + walk cadence ----------------
const MV={x:0,z:0,sp:0,on:false,init:false};
function moveTick(dt){const w=W3,p=w.player.position;if(!MV.init||dt<=0||dt>.5){MV.x=p.x;MV.z=p.z;MV.init=true;MV.sp=0;return;}
 const d=Math.hypot(p.x-MV.x,p.z-MV.z);MV.x=p.x;MV.z=p.z;const v=d>1.5?0:d/dt;MV.sp+=(v-MV.sp)*(1-Math.exp(-dt/.06));
 const input=Math.hypot(w.joy?.x||0,w.joy?.y||0)>.08||!!w.target||(w.keys&&w.keys.size>0);
 if(!MV.on&&MV.sp>.45)MV.on=true;else if(MV.on&&(MV.sp<.15||(!input&&MV.sp<.3)))MV.on=false;
 w.r8dMoving=MV.on;w.r8dSpeed=MV.sp;}
function wrapAvatar(){const A=window.TG_AVATAR;if(!A?.animate||A.animate.__r8d)return;const an=A.animate;
 const f=function(g,state,t){const w=W3;if(g&&w&&g===w.r6Avatar&&typeof t==='number'){const u=g.userData;
   if(u.r8dLastT==null){u.r8dLastT=t;u.r8dClock=t;}let dt=t-u.r8dLastT;u.r8dLastT=t;if(!(dt>0&&dt<250))dt=0;
   const rate=state==='walk'?Math.min(1.4,Math.max(.9,Math.sqrt((w.r8dSpeed||1.77)/1.77))):1;/* r8d: 1.0 at walk speed (matches r8c1 cadence), ~√ scaling for run */u.r8dClock+=dt*rate;return an.call(this,g,state,u.r8dClock);}
  return an.apply(this,arguments);};f.__r8d=true;A.animate=f;}

// ---------------- per-joint rate limiter (player, NPCs, animals) ----------------
// Runs after every pose writer of the frame (worldSyncDecor hook, just before render). Walk/idle cycles stay below
// the limits (≤3°/frame at 60 fps), so only pops (state switches, seat/bed snaps, gesture swaps) are spread out.
const ROT=440*D2R,POS=1.4,YAW=600*D2R,ST=new Map();let tracked=[],trackedAt=0,trackedScene=null,lastTs=0;
function limitReset(){ST.clear();tracked=[];trackedAt=0;R8D.limit.reset=(R8D.limit.reset||0)+1;}
function collect(){const w=W3,out=[];const P=w.r6Avatar?.userData?.parts;
 if(P)for(const k of ['rig','torsoJ','headJ','armLJ','armRJ','legL','legR','capeJ'])if(P[k])out.push(P[k]);
 if(w.body)out.push(w.body);
 try{for(const n of window.TG_NPC?.list?.()||[]){const m=n.model;if(!m||!m.parent)continue;let vis=true;for(let q=m;q;q=q.parent)if(q.visible===false){vis=false;break;}if(!vis)continue;const pp=m.userData?.parts;if(pp)for(const k of ['rig','torsoJ','headJ','armLJ','armRJ','legL','legR','capeJ'])if(pp[k])out.push(pp[k]);}}catch(e){}
 if(w.active==='yard')for(const r of w.spaces.yard?.animalRecords||[]){let n=0;r.root.traverse(c=>{if(c!==r.root&&n<28&&(c.children.length||/leg|arm|head|tail|wing|neck|ear|body|fin/i.test(c.name||''))){out.push(c);n++;}});}
 return out;}
function limitTick(ts){if(!R8D.limit.on)return;const w=W3;if(!w?.active)return;
 const dt=lastTs?Math.min(.1,Math.max(0,(ts-lastTs)/1000)):0;lastTs=ts;if(dt<=0)return;
 if(trackedScene!==w.active||ts-trackedAt>1000){if(trackedScene!==w.active)ST.clear();tracked=collect();trackedAt=ts;trackedScene=w.active;}
 const maxA=ROT*dt,maxP=POS*dt;
 for(const o of tracked){let s=ST.get(o);if(!s){s={q:o.quaternion.clone(),p:o.position.clone()};ST.set(o,s);continue;}
  const a=s.q.angleTo(o.quaternion);if(a>maxA&&a<3.1){s.q.rotateTowards(o.quaternion,maxA);o.quaternion.copy(s.q);R8D.limit.hits++;}else s.q.copy(o.quaternion);
  const d=s.p.distanceTo(o.position);if(d>maxP&&d<1.2){s.p.lerp(o.position,maxP/d);o.position.copy(s.p);}else s.p.copy(o.position);}
 // player root yaw (teleports reset via worldEnter)
 const pl=w.player;let s=ST.get(pl);if(!s){ST.set(pl,s={y:pl.rotation.y,x:pl.position.x,z:pl.position.z});}
 else{if(Math.hypot(pl.position.x-s.x,pl.position.z-s.z)>1.2)s.y=pl.rotation.y;const da=Math.atan2(Math.sin(pl.rotation.y-s.y),Math.cos(pl.rotation.y-s.y)),m=YAW*dt;
  if(Math.abs(da)>m){pl.rotation.y=s.y+Math.sign(da)*m;}s.y=pl.rotation.y;s.x=pl.position.x;s.z=pl.position.z;}}

// ---------------- frame hooks ----------------
{const an=tgAnimate;tgAnimate=function(ts,dt){try{hookRender();wrapAvatar();moveTick(dt||0);}catch(e){R8D.errM=String(e);}return an.apply(this,arguments);};}
{const sd=typeof worldSyncDecor==='function'?worldSyncDecor:null;worldSyncDecor=function(){const r=sd?sd.apply(this,arguments):undefined;try{limitTick(performance.now());}catch(e){R8D.errL=String(e);}return r;};}

// ---------------- panels: close animation ----------------
{const css=document.createElement('style');css.textContent=
 '#modal.r8d-closing{display:flex!important;pointer-events:none;animation:r8dFadeOut .18s ease-in forwards}#modal.r8d-closing #sheet{animation:r8dSlideDown .18s ease-in forwards}'+
 '@keyframes r8dFadeOut{to{opacity:0}}@keyframes r8dSlideDown{to{transform:translateY(40%)}}'+
 '#toast.r8d-swap{transition:opacity .16s,transform .16s}';document.head.appendChild(css);}
{const cm=closeModal;let tm=0;window.closeModal=closeModal=function(){const m=document.getElementById('modal');const wasOpen=m?.classList.contains('show');const r=cm.apply(this,arguments);
  if(wasOpen&&m&&!m.classList.contains('show')){m.classList.remove('r8d-closing');void m.offsetWidth;m.classList.add('r8d-closing');clearTimeout(tm);tm=setTimeout(()=>m.classList.remove('r8d-closing'),200);}modalFrame=0;return r;};
 const om=openModal;window.openModal=openModal=function(){const m=document.getElementById('modal');m?.classList.remove('r8d-closing');modalFrame=0;return om.apply(this,arguments);};}
document.getElementById('modal')?.addEventListener('animationend',e=>{if(e.animationName==='r8dFadeOut')e.currentTarget.classList.remove('r8d-closing');});

// ---------------- toast queue (min 1.1 s each when more are waiting, cross-fade between messages) ----------------
{const el=()=>document.getElementById('toast');const Q=R8D.toast.q;let showing=false,shownAt=0,timer=0,last='';
 function show(msg){const t=el();if(!t)return;showing=true;shownAt=performance.now();last=msg;t.textContent=msg;t.classList.add('show');clearTimeout(timer);timer=setTimeout(next,Q.length?1100:1800);}
 function next(){const t=el();if(!Q.length){t?.classList.remove('show');showing=false;return;}
  const msg=Q.shift();t.classList.add('r8d-swap');t.classList.remove('show');setTimeout(()=>{t.classList.remove('r8d-swap');show(msg);},170);}
 // r8d1 (M-N2): every queued message first runs through the previous toast chain (r7 rewrite, r7-compliance 炷香→点灯 / 回向,
 // r7b-ux offline notice, r8 口令 / 祠堂 rewrites); the chain's display at the bottom (ui-kit toast) is captured instead of shown.
 // null = the chain handled it itself (TG_UI overlay toast) → nothing to queue.
 const chain=toast;function filt(m){let out=null;const prev=window.__tgToastCapture;window.__tgToastCapture=s=>{out=s;};try{chain(m);}catch(e){out=m;}finally{window.__tgToastCapture=prev;}if(out!=null&&window.r7Rewrite)try{out=window.r7Rewrite(out);}catch(e){}return out;}
 R8D.toast.filter=filt;
 window.toast=toast=function(msg){msg=filt(String(msg));if(msg==null||msg==='')return;if(!showing){show(msg);return;}
  if(msg===last&&!Q.length){clearTimeout(timer);timer=setTimeout(next,1800);return;}if(Q[Q.length-1]===msg)return;Q.push(msg);if(Q.length>3)Q.shift();
  const el2=performance.now()-shownAt;clearTimeout(timer);timer=setTimeout(next,Math.max(0,1100-el2));};}

// ---------------- boot ----------------
function boot(){if(!W3?.renderer||!W3.active){setTimeout(boot,300);return;}try{shareLights();}catch(e){R8D.slErr=String(e);}hookRender();wrapAvatar();setTimeout(()=>warm().catch(e=>{R8D.warm.errW=String(e);R8D.warm.phase='error';}),1500);}
boot();
})();
