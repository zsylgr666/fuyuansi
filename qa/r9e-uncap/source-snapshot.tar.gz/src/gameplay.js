
'use strict';
/* =========================================================
   一、静态数据（以后改玩法主要改这里）
   ========================================================= */
// 作物：growMs 为成熟所需毫秒（演示用，较快）；value 为上供获得的功德
const CROPS = [
  {id:'cabbage', name:'白菜', emoji:'🥬', growMs:20000, value:2},
  {id:'carrot',  name:'萝卜', emoji:'🥕', growMs:28000, value:3},
  {id:'tomato',  name:'番茄', emoji:'🍅', growMs:35000, value:4},
  {id:'corn',    name:'玉米', emoji:'🌽', growMs:42000, value:5},
  {id:'peach',   name:'仙桃', emoji:'🍑', growMs:50000, value:7},
  {id:'melon',   name:'西瓜', emoji:'🍉', growMs:60000, value:9},
];
const CROP_BY_ID = Object.fromEntries(CROPS.map(c => [c.id, c]));
const PLOT_COUNT = 12;
const WATER_BOOST = 0.25;      // 每次浇水推进 25% 生长进度
const WATER_COOLDOWN = 6000;   // 同一块地浇水冷却（毫秒）
const INCENSE_BURN_MS = 60000; // 一炷香燃烧时长
const INCENSE_SLOTS = 3;       // 铜灯最多同时插 3 炷
const UNLOCK_HARVEST = 3;      // 累计收获 3 份自动解锁缘堂
const DEMO_PASS = '8888';      // 仅演示用口令，不是真实密码

// r8c-clean（codex2，2026-11-14）：三个摊位原先的旧数据表已删除，换成中性的小院文字。
// 常量名 HEXAGRAMS / SIGNS / DIRECTIONS / DIR_TEXT / YI / JI 保留，供下方「今日心语 / 每日寄语 / 赏景小记」使用。
// 今日心语 64 句：[页名, 一句话]（第 n 页 = 摇 6 次铜钱得到的序号）
const HEART_LINES = [
 '慢慢走，把眼前这一步走踏实。','心平气和，事情会一件一件清楚起来。','先照顾好自己，再去帮忙别人。','遇到岔路，先停一停，再决定怎么走。',
 '今天适合读几页书，或把桌子整理一下。','不必着急，给自己留一点空闲。','和朋友说说话，心里会宽敞许多。','把小事做好，大的安排自然会来。',
 '天气好就出去走走，天气不好就歇一歇。','有人帮一把，记得说一声谢谢。','累了就休息，明天再继续。','守住自己的节奏，不必跟别人比。',
 '把想做的事写下来，一步一步做。','家里灯亮着，心里就暖。','笑一笑，许多烦恼会轻一些。','路还长，先走好今天这一段。',
 '喝一口水，再看看窗外。','少说一句气话，多留一点余地。','愿意动手的人，总比空想更踏实。','把窗打开，让风进来。',
 '选好一条路就认真走，不必反复改。','安静的下午，也值得被记住。','把桌子擦干净，心情也会干净一些。','给自己一点耐心，就像对待一棵树。',
 '有欢喜就分享，有困难就慢慢想办法。','不必把所有事情一次做完。','友邻近，路也不远。','花开有时，等一等也很好。',
 '把脚步放轻，把话说软。','今天适合写信，或给家里打个招呼。','看见好事，就学着做一点。','雨停之后，路会更好走。',
 '把旧的烦恼放下，腾出地方给新的计划。','午饭吃饱，人也有力气。','与人合作，先把各自的事说清楚。','不必完美，认真就很好。',
 '夜晚早点休息，明天会更清楚。','把花浇一浇，把椅子摆一摆。','听到不同的声音，先听完再说话。','把想去的地方记在本子上。',
 '小院里的光，够用一天。','对别人宽一点，对自己也宽一点。','做一点家务，心里会踏实。','把今天的收获收进篮子里。',
 '遇到难题，先把它分成小块。','站在树下，看看叶子怎么动。','把感谢说出来，比放在心里更暖。','走得慢一些，才看得见路边的花。',
 '有始有终，一件事做完再做下一件。','把温暖留给身边的人。','不必赶路，方向对就好。','把茶泡上，坐一会儿。',
 '愿意请教的人，进步会快一点。','把乱掉的线理顺，再继续织。','今天不必着急，安静一会儿也好。','把不用的东西收起来，房间会宽敞。',
 '把好天气用在散步上。','和家人一起吃一顿饭。','把心里的话说清楚，误会就会少。','树在这里，你也在这里，这样就很好。',
 '听一会儿风铃，再去做事。','给花草换一盆清水。','今天的事今天做完，晚上睡个好觉。','把一句好话送给身边的人。',
];
const HEXAGRAMS = HEART_LINES.map((t,i)=>['第'+(i+1)+'页', t]);
// 每日寄语 24 首：[保留字段, 诗句, 小记]（第一项只为兼容旧结构，不显示）
const SIGNS = [
 ['','春眠不觉晓，处处闻啼鸟。\n夜来风雨声，花落知多少。','睡个好觉，醒来听听窗外的鸟。'],
 ['','床前明月光，疑是地上霜。\n举头望明月，低头思故乡。','有空给家里打个电话。'],
 ['','白日依山尽，黄河入海流。\n欲穷千里目，更上一层楼。','想看得远一点，就再往上走一步。'],
 ['','红豆生南国，春来发几枝。\n愿君多采撷，此物最相思。','把想念说给想念的人听。'],
 ['','千山鸟飞绝，万径人踪灭。\n孤舟蓑笠翁，独钓寒江雪。','一个人安静一会儿，也很好。'],
 ['','锄禾日当午，汗滴禾下土。\n谁知盘中餐，粒粒皆辛苦。','好好吃饭，珍惜每一粒米。'],
 ['','离离原上草，一岁一枯荣。\n野火烧不尽，春风吹又生。','慢慢长，总会再绿起来。'],
 ['','空山新雨后，天气晚来秋。\n明月松间照，清泉石上流。','雨后出去走走，空气很好。'],
 ['','移舟泊烟渚，日暮客愁新。\n野旷天低树，江清月近人。','傍晚看看天，心会静下来。'],
 ['','独坐幽篁里，弹琴复长啸。\n深林人不知，明月来相照。','给自己留一点安静的时间。'],
 ['','向晚意不适，驱车登古原。\n夕阳无限好，只是近黄昏。','傍晚的光很好看，记得抬头。'],
 ['','君自故乡来，应知故乡事。\n来日绮窗前，寒梅著花未？','问一问老朋友近来可好。'],
 ['','松下问童子，言师采药去。\n只在此山中，云深不知处。','找不到答案时，先慢慢走。'],
 ['','绿蚁新醅酒，红泥小火炉。\n晚来天欲雪，能饮一杯无？','约朋友坐一坐，喝杯热茶。'],
 ['','春江潮水连海平，海上明月共潮生。\n滟滟随波千万里，何处春江无月明。','晚上抬头看看月亮。'],
 ['','两个黄鹂鸣翠柳，一行白鹭上青天。\n窗含西岭千秋雪，门泊东吴万里船。','开窗看看远处的风景。'],
 ['','好雨知时节，当春乃发生。\n随风潜入夜，润物细无声。','安静地做好一件小事。'],
 ['','竹外桃花三两枝，春江水暖鸭先知。\n蒌蒿满地芦芽短，正是河豚欲上时。','留意身边季节的变化。'],
 ['','小荷才露尖尖角，早有蜻蜓立上头。\n泉眼无声惜细流，树阴照水爱晴柔。','新开始都很小，慢慢来。'],
 ['','黄四娘家花满蹊，千朵万朵压枝低。\n留连戏蝶时时舞，自在娇莺恰恰啼。','去花多的地方走一走。'],
 ['','横看成岭侧成峰，远近高低各不同。\n不识庐山真面目，只缘身在此山中。','换个角度看看，也许更清楚。'],
 ['','山重水复疑无路，柳暗花明又一村。\n箫鼓追随春社近，衣冠简朴古风存。','路走着走着就开阔了。'],
 ['','毕竟西湖六月中，风光不与四时同。\n接天莲叶无穷碧，映日荷花别样红。','夏天去荷塘看看花。'],
 ['','人闲桂花落，夜静春山空。\n月出惊山鸟，时鸣春涧中。','闲下来的时候，听听夜里的声音。'],
];
// 赏景小记：院子朝向（'中' 为中间的小屋格，不可选）
const DIRECTIONS = ['西北','北','东北','西','中','东','西南','南','东南'];
const DIR_TEXT = {
  '北':'院子朝北，光线比较柔和，门口放一盆绿植很安静。','南':'院子朝南，光照充足，适合晒一晒太阳。',
  '东':'院子朝东，能见到晨光，适合早起散步。','西':'院子朝西，傍晚能看到晚霞，下午记得拉帘防晒。',
  '东南':'东南这一侧比较敞亮，适合放一张书桌。','西南':'西南这一侧比较暖，适合放全家福或暖色灯光。',
  '东北':'东北这一侧比较安静，适合放书柜。','西北':'西北这一侧保持整洁明亮，看着也舒服。',
};
// 赏景小记里随手一句（原 YI/JI 成对列表已取消，只留一句温和的小建议或景色）
const YI = ['去院子里走一走','给花浇一点水','读几页书','泡一壶茶','和朋友聊聊天','把桌子整理一下','早点休息','看看天上的云'];
const JI = ['看看树影怎么移动','听一听风铃的声音','数一数今天开了几朵花','看傍晚的晚霞','闻一闻雨后的泥土','看看池塘里的鱼'];

/* =========================================================
   二、状态与持久化（localStorage）
   ========================================================= */
const SAVE_KEY = 'templeGarden.v1';
function defaultState(){
  return {
    v:1,
    coins:50, backpack:{cushion:1,vase:1}, animals:[], shrine:{style:'wood',plaques:[{name:'家和业兴',img:''},{name:'福泽绵长',img:''},{name:'家和业兴',img:''}]},
    decor:{}, ownerId:'self',
    merit:0,                            // 善缘
    inventory:{},                       // 背包 { cropId: 数量 }
    plots:Array(PLOT_COUNT).fill(null), // 每块地 {crop, plantedAt, boost(0~1), lastWater} 或 null
    selectedSeed:'cabbage',
    harvestTotal:0,                     // 累计收获（用于自动解锁缘堂）
    unlocked:false,                     // 缘堂是否已解锁
    incense:{total:0, sticks:[]},       // sticks: 每炷香的点燃时间戳
    offerings:[],                       // 陈列台上的陈列 [{crop, at}]
    muyu:0,                             // 摇风铃次数
    scene:'plaza',
    lastSign:null,
    sellable:{}, sellSeeded:true,       // r9: 商铺买入、可半价卖回的件数；新存档无需补录
  };
}
window.TG_STORAGE=window.TG_STORAGE_ADAPTER||{
async load(){const r=localStorage.getItem(SAVE_KEY);return r?JSON.parse(r):null;},
async save(state){localStorage.setItem(SAVE_KEY,JSON.stringify(state));},
async clear(){localStorage.removeItem(SAVE_KEY);}};
function setStorageAdapter(adapter){window.TG_STORAGE=adapter;}
let S=defaultState();
function sanitizeLoaded(raw){try{
const d=Object.assign(defaultState(),raw||{});
// Only an absent record receives the starter grant; pre-economy saves retain zero.
if(raw!=null&&!Object.prototype.hasOwnProperty.call(raw,'coins'))d.coins=0;
if(raw!=null&&!Object.prototype.hasOwnProperty.call(raw,'backpack'))d.backpack={};
if(raw!=null&&!Object.prototype.hasOwnProperty.call(raw,'sellSeeded'))delete d.sellSeeded; // r9: legacy save -> one-time buy-back seed (r9-sell.js)
if(!Array.isArray(d.plots)||d.plots.length!==PLOT_COUNT)d.plots=Array(PLOT_COUNT).fill(null);
d.plots=d.plots.map(p=>p&&CROP_BY_ID[p.crop]?p:null);
if(!d.incense||!Array.isArray(d.incense.sticks))d.incense={total:0,sticks:[]};
if(!Array.isArray(d.offerings))d.offerings=[];
if(!d.inventory||typeof d.inventory!=='object')d.inventory={};
if(!CROP_BY_ID[d.selectedSeed])d.selectedSeed='cabbage';
sanitizeR3(d);sanitizeR4(d);
return d;}catch(e){return sanitizeLoadedError();}}
async function load(){try{return sanitizeLoaded(await window.TG_STORAGE.load());}catch(e){return sanitizeLoadedError();}}
function sanitizeLoadedError(){const d=defaultState();d.coins=0;d.backpack={};return d;}
window.TG_APPLY_REMOTE_STATE=function(raw){
 const scene=current,w=window.W3,active=w?.active,position=w?.player?.position.clone(),rotation=w?.player?.rotation.clone();
 const camera=w?{yaw:w.yaw,pitch:w.pitch,radius:w.radius}:null;
 S=sanitizeLoaded(raw);
 r3DiscardPlan();window.r6ExitPlacement?.();window.TG_AVATAR?.closePanel?.();closeModal();
 r3SnapshotOwnSpace();
 renderAll();window.TG_RERENDER?.();
 current=scene;S.scene=scene;
 if(w){w.active=active;if(position)w.player.position.copy(position);if(rotation)w.player.rotation.copy(rotation);Object.assign(w,camera);worldCamera();}
};
function save(){if(r3SyncOwnSpace())window.TG_RERENDER();if(r3IsVisiting()){if(r3CanEdit())try{Promise.resolve(window.TG_SPACE_SAVE?.({plots:S.plots,decor:S.decor,shrine:S.shrine,animals:S.animals,inventory:S.inventory,backpack:S.backpack,coins:S.coins,daily:S.daily,economyRev:S.economyRev})).catch(()=>{});}catch(e){}return;}try{Promise.resolve(window.TG_STORAGE.save(S)).catch(()=>{});}catch(e){}}

/* =========================================================
   三、工具函数
   ========================================================= */
const $ = (sel, root=document) => root.querySelector(sel);
const rand = n => Math.floor(Math.random()*n);
function seededRand(seed){ // 可复现的伪随机（赏景小记按 日期+朝向 固定）
  let s = seed >>> 0;
  return () => { s = (Math.imul(s,1664525) + 1013904223) >>> 0; return s/4294967296; };
}
function pickN(arr, n, rnd){ const a=arr.slice(), out=[]; while(out.length<n && a.length) out.push(a.splice(Math.floor(rnd()*a.length),1)[0]); return out; }
function invCount(){ return Object.values(S.inventory).reduce((a,b)=>a+b,0); }
let toastTimer;
function toast(msg){
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(()=>t.classList.remove('show'), 1800);
}
function floatText(text, x, y){ // 在屏幕坐标处冒出一行飘字
  const app = $('#app').getBoundingClientRect();
  const el = document.createElement('div'); el.className='float-txt'; el.textContent=text;
  el.style.left = (x-app.left-30)+'px'; el.style.top=(y-app.top-20)+'px';
  $('#app').appendChild(el); setTimeout(()=>el.remove(), 1200);
}
function centerOf(el){ const r=el.getBoundingClientRect(); return [r.left+r.width/2, r.top+r.height/2]; }
function bump(el){ el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); }
function addMerit(n, el){
  S.merit += n; save(); renderTop(); bump($('#pillMerit'));
  if(el){ const [x,y]=centerOf(el); floatText('善缘 +'+n, x, y); }
}
function vibrate(p){ try{ if(navigator.vibrate) navigator.vibrate(p); }catch(e){} }

/* =========================================================
   四、场景切换
   三维世界在 worldEnter 中按来源设置出生点。
   多人时可在 onEnter 里加入房间。
   ========================================================= */
window.TG_SCENES = [
  {id:'gate',name:'里门',public:true},
  {id:'plaza',name:'大厅广场',public:true},
  {id:'market',name:'集市',public:true},
  {id:'yard',name:'心田小院',public:false,steal:true,access:'steal-only'},
  {id:'lotus',name:'荷塘',public:true},
  {id:'hall',name:'缘堂',public:false},
  {id:'zen',name:'静室',public:false},
  {id:'study',name:'书房',public:false},
];
const SCENES = window.TG_SCENES.map(s=>s.id);
let current = null, switching = false;
let accessRequest=0;
async function go(name, instant){
  worldResize();
  if(name==='home'){window.r4EastArrival=true;name='yard';history.replaceState(null,'','#yard');}
  r3ApplyVisitingUI();
  if(!SCENES.includes(name) || name===current || switching) return;
  const request=++accessRequest;
  if(!window.TG_SCENES.find(s=>s.id===name).public){
    const ownerId=window.TG_VISIT?.ownerId || S.ownerId || 'self';
    const selfId=window.TG_AUTH?.userId || S.ownerId || 'self';
    let allowed=false;
    try{allowed=await (window.TG_ACCESS?.canEnter ? window.TG_ACCESS.canEnter(ownerId,name) : Promise.resolve(r3IsVisiting()?window.TG_SCENES.find(s=>s.id===name)?.steal===true:true));}catch(e){}
    if(request!==accessRequest)return;
    if(!allowed){toast('暂无权限进入');if(current)history.replaceState(null,'','#'+current);return false;}
  }
  if(request!==accessRequest||switching)return;
  const el = document.getElementById(name), previous = current;
  const apply = () => {
    document.querySelectorAll('.scene').forEach(s=>s.classList.remove('active'));
    el.classList.add('active'); current = name; if(!r3IsVisiting()){S.scene = name; save();}
    $('#sceneTitle').textContent = el.dataset.title;
    if(location.hash !== '#'+name) history.replaceState(null,'','#'+name);
    onEnter(name);
    if(typeof worldEnter==='function') worldEnter(name, previous);
    worldResize();
  };
  if(instant){ apply(); return; }
  switching = true;
  $('#fadeTxt').textContent = el.dataset.title.split(' · ').pop();
  $('#fade').classList.add('on');
  if(typeof worldStop==='function') worldStop();
  // r8d: swap only once the fade is opaque, and fade out only after the new scene has rendered 2 frames
  const fadeEl=$('#fade'), t0=performance.now();
  const reveal=()=>{ fadeEl.classList.remove('on'); setTimeout(()=>{ switching=false; }, 300); };
  const swap=()=>{ apply(); if(typeof window.r8dAfterFrames==='function') window.r8dAfterFrames(2, reveal, 900); else reveal(); };
  setTimeout(function wait(){ if(+getComputedStyle(fadeEl).opacity>=.97 || performance.now()-t0>700) swap(); else requestAnimationFrame(wait); }, 400);
}
function onEnter(name){
  r3ApplyVisitingUI();
  if(name==='yard') renderYard();
  if(name==='hall') enterHall();
  document.body.dataset.scene = name;
  if(typeof worldOnEnter==='function') worldOnEnter(name);
}

/* =========================================================
   五、顶栏 / 弹窗 / 背包 / 菜单
   ========================================================= */
function renderTop(){ $('#coinNum').textContent=S.coins; $('#meritNum').textContent = S.merit; $('#invNum').textContent = invCount(); }
let onModalClose = null;
function openModal(html){
  $('#sheet').innerHTML = '<button class="close" data-close aria-label="关闭">✕</button>'+html;
  $('#modal').classList.add('show'); $('#sheet').scrollTop=0;
}
function closeModal(){ $('#modal').classList.remove('show'); if(onModalClose){ onModalClose(); onModalClose=null; } }
$('#modal').addEventListener('click', e=>{ if(e.target.id==='modal' || e.target.closest('[data-close]')) closeModal(); });

function inventoryHTML(clickable){
  return '<div class="inv-grid">'+CROPS.map(c=>{
    const n = S.inventory[c.id]||0;
    return `<div class="inv-item ${n?'':'none'} ${clickable&&n?'clickable':''}" data-crop="${c.id}"><span class="e">${c.emoji}</span>${c.name} ×${n}${clickable?`<br><small>善缘 +${c.value}</small>`:''}</div>`;
  }).join('')+'</div>';
}
$('#pillInv').addEventListener('click', ()=>{
  openModal(`<h2>🧺 背包</h2>${inventoryHTML(false)}
   <p class="center" style="font-size:13px;color:#7a5a3a">收获的作物可以拿到缘堂摆放，积攒善缘。</p>
   <p class="center" style="font-size:13px">累计收获 ${S.harvestTotal} 份 · 已点灯 ${S.incense.total} 盏 · 摇风铃 ${S.muyu} 下</p>`);
});
$('#pillMerit').addEventListener('click', ()=>toast(`当前善缘 ${S.merit}：点灯 +1、摆放 +作物值、摇风铃 +1`));
$('#btnMenu').addEventListener('click', ()=>{
  openModal(`<h2>⚙️ 菜单</h2>
   <div class="card"><b>玩法说明</b><p>① 大厅：点摊位读今日心语、抽每日诗笺、写赏景小记；点里门进入院子。<br>② 院子：先选种子再点空地播种，点作物浇水加速，成熟后点击收获。<br>③ 缘堂：输入口令或累计收获 3 份作物解锁，进去点灯、摆放心意、摇风铃，积攒善缘。</p></div>
   <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
     ${window.TG_SCENES.map(s=>`<button class="btn ghost" data-go="${s.id}">${s.name}${s.public?'':' · 私人'}</button>`).join('')}
   </div>
   <p class="center" style="margin-top:16px"><button class="btn" id="resetBtn" style="background:#55606b;box-shadow:0 3px 0 #2a3036">重置全部进度</button></p>
   <p class="center" style="font-size:12px;color:#7a5a3a">进度保存在本机浏览器里 · 版本 v1</p>`);
  $('#sheet').querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{ closeModal(); go(b.dataset.go); });
  $('#resetBtn').onclick=async()=>{
    if(r3DenyVisit())return;
    if(r3IsVisiting())return toast('请返回自己的空间后重置');
    if(confirm('确定清空所有进度吗？')){
      await window.TG_STORAGE.clear(); S=defaultState(); save(); closeModal(); renderAll(); go('plaza'); toast('已重置');
    }
  };
});

/* =========================================================
   六、大厅 · 今日心语（摇 6 次铜钱，读一句话）
   r8c-clean：旧模板已改为中性文字；函数名与元素 id 保持不变。
   ========================================================= */
let guaLines = [], guaTimer = null, shakingCoins = false;
function hexFromBits(bits){ // bits: 6 位 → 第 1–64 页
  let no = 1; for(let i=0;i<6;i++) no += (bits[i]?1:0) << i;
  return {no, name:HEXAGRAMS[no-1][0], meaning:HEXAGRAMS[no-1][1], upper:{name:'',nature:''}, lower:{name:'',nature:''}};
}
function hexLinesHTML(lines){
  let h='<div class="hexa">';
  for(let i=0;i<6;i++){
    const v = lines[i];
    if(v===undefined){ h+='<div class="ln empty"><i></i></div>'; continue; }
    const yang = (v===7||v===9);
    h+=`<div class="ln ${yang?'yang':'yin'}">${yang?'<i></i>':'<i></i><i></i>'}</div>`;
  }
  return h+'</div>';
}
function grid64HTML(hit, hit2){
  return '<div class="grid64">'+HEXAGRAMS.map((h,i)=>`<div class="${i+1===hit?'hit':''} ${i+1===hit2?'hit2':''}">${i+1}</div>`).join('')+'</div>';
}
function openGua(){
  guaLines = []; shakingCoins = false; clearTimeout(guaTimer);
  openModal(`<h2>今日心语</h2>
    <p class="center" style="font-size:13px;color:#7a5a3a">轻轻摇几次铜钱，读一句今天的心语。</p>
    <div class="coins" id="coins"><div class="coin"><span>字</span></div><div class="coin"><span>背</span></div><div class="coin"><span>字</span></div></div>
    <div id="guaLines">${hexLinesHTML([])}</div>
    <p class="center" id="guaStep">第 1 / 6 次</p>
    <div style="display:flex;gap:10px;justify-content:center"><button class="btn" id="shakeBtn">🪙 摇一次</button><button class="btn ghost" id="autoBtn">一次读完</button></div>
    <div id="guaResult"></div>`);
  onModalClose = ()=>clearTimeout(guaTimer);
  $('#shakeBtn').onclick = shakeOnce;
  $('#autoBtn').onclick = ()=>{
    $('#autoBtn').disabled=true;
    (function loop(){ if(guaLines.length<6){ shakeOnce(); guaTimer=setTimeout(loop, 700);} })();
  };
}
function shakeOnce(){tgFeedback('coin');
  if(shakingCoins || guaLines.length>=6) return;
  shakingCoins=true; vibrate(30);
  const coins = [...document.querySelectorAll('#coins .coin')];
  const faces = coins.map(()=>Math.random()<0.5?3:2); // 3=字 2=背
  coins.forEach(c=>{ c.classList.remove('flip'); void c.offsetWidth; c.classList.add('flip'); });
  guaTimer = setTimeout(()=>{
    if(!$('#guaLines')) { shakingCoins=false; return; }
    coins.forEach((c,i)=>{ c.querySelector('span').textContent = faces[i]===3?'字':'背'; });
    guaLines.push(faces[0]+faces[1]+faces[2]);
    $('#guaLines').innerHTML = hexLinesHTML(guaLines);
    $('#guaStep').textContent = guaLines.length<6 ? `第 ${guaLines.length+1} / 6 次` : '心语已备';
    shakingCoins=false;
    if(guaLines.length===6) showGuaResult();
  }, 600);
}
function showGuaResult(){tgFeedback('result');
  $('#shakeBtn').disabled = true; $('#autoBtn').disabled = true;
  const bits = guaLines.map(v=>(v===7||v===9)?1:0);
  const main = hexFromBits(bits);
  $('#guaResult').innerHTML = `<div class="card">
    <div class="gua-name">今日心语 · ${main.name}</div>
    <p class="center" style="font-size:16px;margin:8px 0">${main.meaning}</p>
    <p style="font-size:12px;color:#9a7a50;margin-bottom:0">读一句就好，不必当作预测。</p></div>
    <p class="center" style="margin-top:12px"><button class="btn" id="againBtn">再读一句</button></p>`;
  $('#againBtn').onclick = openGua;
  setTimeout(()=>{ const r=$('#guaResult'); if(r) r.scrollIntoView({behavior:'smooth',block:'start'}); }, 60);
}

/* =========================================================
   七、大厅 · 每日寄语（抽一首诗）
   r8c-clean：旧模板已改为读诗；S.lastSign 存档字段保留。
   ========================================================= */
let qianTimers = [];
function clearQian(){ qianTimers.forEach(clearTimeout); qianTimers=[]; }
function openQian(){
  clearQian();
  const sticks = Array.from({length:9},()=>`<i style="height:${30+rand(20)}px"></i>`).join('');
  openModal(`<h2>每日寄语</h2>
    <p class="center" style="font-size:13px;color:#7a5a3a">读一句诗，给今天留一点从容。</p>
    <div class="tube-wrap" id="tubeWrap"><div class="tube" id="tube"><div class="sticks">${sticks}</div><div class="body">诗句</div></div></div>
    <p class="center"><button class="btn" id="qianBtn">抽一首诗</button></p>
    <div id="qianResult"></div>`);
  onModalClose = clearQian;
  $('#qianBtn').onclick = drawQian;
}
function drawQian(){tgFeedback('qian');
  const btn=$('#qianBtn'); btn.disabled=true; vibrate([40,40,40,40,40]);
  $('#qianResult').innerHTML='';
  const old = $('#tubeWrap .outstick'); if(old) old.remove();
  const tube=$('#tube'); tube.classList.add('shaking');
  const idx = rand(SIGNS.length);
  qianTimers.push(setTimeout(()=>{
    tube.classList.remove('shaking');
    const st=document.createElement('div'); st.className='outstick'; st.textContent='第'+(idx+1)+'首';
    $('#tubeWrap').appendChild(st);
    qianTimers.push(setTimeout(()=>{
      const [, poem, note] = SIGNS[idx];
      S.lastSign = idx; save();
      $('#qianResult').innerHTML = `<div class="qian">
        <div class="no">每日寄语 · 第 ${idx+1} 首</div>
        <div class="poem">${poem.replace('\n','<br>')}</div>
        <p style="text-align:left">${note}</p></div>
        <p class="center"><button class="btn ghost" id="qianAgain">再读一句</button></p>`;
      $('#qianAgain').onclick = drawQian;
      setTimeout(()=>{ const r=$('#qianResult'); if(r) r.scrollIntoView({behavior:'smooth',block:'nearest'}); },60);
    }, 800));
  }, 1400));
}

/* =========================================================
   八、大厅 · 赏景小记（选院子朝向，写一句当天的小记）
   r8c-clean：旧模板（年份推算、打分、配色、成对列表）已删除；
   #fengYear 仍保留（隐藏、不参与结果），兼容 r8/r8a2 的隐藏逻辑。
   ========================================================= */
let fengDir = '南';
function openFeng(){
  const now = new Date().getFullYear();
  let opts=''; for(let y=now; y>=1930; y--) opts+=`<option value="${y}" ${y===1995?'selected':''}>${y} 年</option>`;
  openModal(`<h2>赏景小记</h2>
    <p class="center" style="font-size:13px;color:#7a5a3a">选一个院子朝向，写下今天的赏景小记。</p>
    <div class="form-row" style="display:none"><label for="fengYear">年份</label><select id="fengYear" tabindex="-1">${opts}</select></div>
    <div class="center" style="font-size:13px">院子朝向</div>
    <div class="dirs" id="fengDirs">${DIRECTIONS.map(d=>d==='中'?'<button class="mid" disabled>🏡</button>':`<button data-d="${d}" class="${d===fengDir?'sel':''}">${d}</button>`).join('')}</div>
    <p class="center"><button class="btn" id="fengBtn">写一写</button></p>
    <div id="fengResult"></div>`);
  $('#fengDirs').querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{
    fengDir=b.dataset.d; $('#fengDirs').querySelectorAll('[data-d]').forEach(x=>x.classList.toggle('sel', x===b));
  });
  $('#fengBtn').onclick = showFeng;
}
function showFeng(){
  const d = new Date(); const daySeed = d.getFullYear()*10000+(d.getMonth()+1)*100+d.getDate();
  const rnd = seededRand(daySeed*31 + DIRECTIONS.indexOf(fengDir)*101);
  const pool = YI.concat(JI), line = pool[Math.floor(rnd()*pool.length)];
  $('#fengResult').innerHTML = `<div class="card">
    <p>${DIR_TEXT[fengDir]||('院子朝向是'+fengDir+'。')}</p>
    <p>今天可以${line}。</p>
    <p style="font-size:12px;color:#9a7a50;margin-bottom:0">小记每天更新，只作欣赏。</p></div>`;
  setTimeout(()=>{ const r=$('#fengResult'); if(r) r.scrollIntoView({behavior:'smooth',block:'nearest'}); },60);
}

/* =========================================================
   九、院子 · 种菜
   生长进度 = (现在 - 播种时间) / 生长时长 + 浇水加成；按真实时间计算，
   关掉页面再回来也会继续长。
   ========================================================= */
function plotProgress(p, now){
  if(!p) return 0;
  return Math.min(1, (now - p.plantedAt)/CROP_BY_ID[p.crop].growMs + (p.boost||0));
}
function stageOf(prog){ return prog>=1?3 : prog>=0.6?2 : prog>=0.25?1 : 0; } // 0种子 1发芽 2成长 3成熟
const STAGE_EMOJI = ['🫘','🌱','🌿'];

function renderSeedBar(){
  $('#seedBar').innerHTML = CROPS.map(c=>`<button class="seed ${S.selectedSeed===c.id?'sel':''}" data-seed="${c.id}"><span class="e">${c.emoji}</span>${c.name}<br><small>${c.growMs>=3600000?c.growMs/3600000+"小时":Math.round(c.growMs/60000)+"分钟"}</small></button>`).join('');
}
$('#seedBar').addEventListener('click', e=>{
  const b = e.target.closest('[data-seed]'); if(!b) return;
  S.selectedSeed = b.dataset.seed; save(); renderSeedBar();
  toast('已选 '+CROP_BY_ID[S.selectedSeed].name+' 种子，点空地播种');
});
function buildPlots(){
  let h=''; for(let i=0;i<PLOT_COUNT;i++) h+=`<div class="plot" data-i="${i}"><span class="crop"></span><span class="tip"></span><span class="badge"></span><div class="bar"><i></i></div></div>`;
  $('#plots').innerHTML = h;
}
function renderYard(){ const __yardStart=true;
  const now = Date.now();
  document.querySelectorAll('#plots .plot').forEach(el=>{
    const i = +el.dataset.i, p = S.plots[i];
    const cropEl=el.querySelector('.crop'), tip=el.querySelector('.tip'), bar=el.querySelector('.bar'), badge=el.querySelector('.badge');
    if(!p){
      el.className='plot empty'; cropEl.textContent='➕'; cropEl.className='crop'; cropEl.style.fontSize='';
      tip.textContent='空地'; bar.style.display='none'; badge.textContent='';
      return;
    }
    const c = CROP_BY_ID[p.crop], prog = plotProgress(p, now), st = stageOf(prog);
    const wet = p.lastWater && now - p.lastWater < WATER_COOLDOWN;
    el.className = 'plot'+(st===3?' ripe':'')+(wet?' wet':'');
    const txt = st===3 ? c.emoji : STAGE_EMOJI[st];
    if(cropEl.textContent!==txt) cropEl.textContent = txt;
    cropEl.className = 'crop'+(st===1||st===2?' grow':'');
    cropEl.style.fontSize = st===0?'20px': st===1?'26px': '';
    const left = Math.max(0, Math.ceil((1-prog)*c.growMs/1000));
    tip.textContent = st===3 ? c.name+' 可收获' : `${c.name} · ${left}秒`;
    bar.style.display = st===3?'none':''; bar.firstElementChild.style.width = (prog*100).toFixed(1)+'%';
    badge.textContent = st===3 ? '✨' : (wet ? '💧' : '');
  });
  $('#doorLock').textContent = S.unlocked ? '🔓' : '🔒';
}
$('#plots').addEventListener('click', e=>{
  const el = e.target.closest('.plot'); if(!el) return;
  const i = +el.dataset.i, p = S.plots[i], now = Date.now();
  if(!r3CanEdit()){if(p&&plotProgress(p,now)>=1)r4Steal(i,el);else r3DenyVisit();return;}
  if(!p){ // 空地 → 播种
    S.plots[i] = {crop:S.selectedSeed, plantedAt:now, boost:0, lastWater:0};
    save(); renderYard(); vibrate(15); plotEffect(el, '🌱');tgFeedback('plant');
    const [x,y]=centerOf(el); floatText('种下 '+CROP_BY_ID[S.selectedSeed].emoji, x, y);
    return;
  }
  if(plotProgress(p, now) >= 1){ harvest(i, el); return; } // 成熟 → 收获
  waterPlot(i, el, true);                                   // 生长中 → 浇水
});
function waterPlot(i, el, showMsg){
  const p = S.plots[i], now = Date.now();
  if(!p || plotProgress(p, now)>=1) return false;
  if(p.lastWater && now - p.lastWater < WATER_COOLDOWN){
    if(showMsg) toast('刚浇过水，'+Math.ceil((WATER_COOLDOWN-(now-p.lastWater))/1000)+' 秒后再浇');
    return false;
  }
  tgFeedback('water');p.boost = (p.boost||0) + WATER_BOOST; p.lastWater = now; save();
  if(el){ const d=document.createElement('div'); d.className='drop'; d.textContent='💧'; el.appendChild(d); setTimeout(()=>d.remove(),650); }
  renderYard(); return true;
}
function harvest(i, el){tgFeedback('harvest');
  const c = CROP_BY_ID[S.plots[i].crop];
  S.inventory[c.id] = (S.inventory[c.id]||0) + 3;
  S.plots[i] = null; S.harvestTotal++;
  let unlockedNow = false;
  if(!S.unlocked && S.harvestTotal >= UNLOCK_HARVEST){ S.unlocked = true; unlockedNow = true; }
  save(); renderYard(); renderTop(); vibrate(25); bump($('#pillInv'));
  if(el){ plotEffect(el, c.emoji, true); const [x,y]=centerOf(el); floatText('+3 '+c.emoji, x, y); }
  if(unlockedNow) setTimeout(()=>toast('🎉 收获满 3 份，缘堂已解锁！'), 400);
}
$('#harvestAll').addEventListener('click', ()=>{
  const now=Date.now(); let n=0;
  document.querySelectorAll('#plots .plot').forEach(el=>{ const i=+el.dataset.i; if(S.plots[i] && plotProgress(S.plots[i],now)>=1){ harvest(i, el); n++; } });
  if(!S.unlocked || n===0 || S.harvestTotal - n >= UNLOCK_HARVEST) toast(n ? `收获了 ${n} 份作物` : '还没有成熟的作物');
});
$('#waterAll').addEventListener('click', ()=>{
  let n=0; document.querySelectorAll('#plots .plot').forEach(el=>{ if(waterPlot(+el.dataset.i, el, false)) n++; });
  toast(n ? `给 ${n} 块地浇了水，生长加速` : '没有需要浇水的地（或还在冷却）');
});

/* =========================================================
   十、缘堂 · 门禁 / 点灯 / 摆放 / 庭铃
   ========================================================= */
function enterHall(){
  if(r3SkipDemoGate()){ $('#gateLock').classList.remove('show'); renderHall(); resizeSmoke(); startSmoke(); return; }
  // 已累计收获够数但还没解锁（例如旧存档）→ 自动解锁
  if(!S.unlocked && S.harvestTotal >= UNLOCK_HARVEST){ S.unlocked = true;tgFeedback('unlock'); save(); renderYard(); }
  renderHall();
  if(!S.unlocked) showGate(); else $('#gateLock').classList.remove('show');
  resizeSmoke(); startSmoke();
}
function showGate(){
  if(r3SkipDemoGate()){ $('#gateLock').classList.remove('show'); return; }
  const n = Math.min(S.harvestTotal, UNLOCK_HARVEST);
  $('#lockProg').style.width = (n/UNLOCK_HARVEST*100)+'%';
  $('#lockProgTxt').textContent = `已收获 ${n} / ${UNLOCK_HARVEST}`;
  $('#passInput').value=''; $('#gateLock').classList.add('show');
}
function tryUnlock(){
  if(r3SkipDemoGate()){ $('#gateLock').classList.remove('show'); return; }
  // 演示门禁：只在本地比较口令，不是真正的密码系统；以后在这里接短信验证
  if($('#passInput').value.trim() === DEMO_PASS){
    S.unlocked = true;tgFeedback('unlock'); save(); $('#passInput').blur();
    $('#gateLock').classList.remove('show'); toast('🌿 欢迎来到缘堂'); renderYard();
  }else{
    const c=$('#lockCard'); c.classList.remove('shake'); void c.offsetWidth; c.classList.add('shake'); vibrate(80);
    toast('口令不对，演示口令是 8888');
  }
}
$('#lockGo').addEventListener('click', tryUnlock);
$('#passInput').addEventListener('keydown', e=>{ if(e.key==='Enter') tryUnlock(); });
$('#lockBack').addEventListener('click', ()=>{ $('#passInput').blur(); go('yard'); });

function activeSticks(now){ return S.incense.sticks.filter(t=>now - t < INCENSE_BURN_MS); }
function renderHall(){
  const now = Date.now();
  const visibleSticks=activeSticks(now);
  if(!r3IsVisiting())S.incense.sticks = visibleSticks;
  $('#sticks').innerHTML = visibleSticks.map(t=>`<div class="stick" style="--burn:${((now-t)/INCENSE_BURN_MS*80).toFixed(1)}%"></div>`).join('');
  if(!r3IsVisiting())S.offerings = S.offerings.slice(-7); // 陈列台只展示最近 7 件
  const off = $('#offerings');
  const html = S.offerings.length ? S.offerings.slice(-7).map(o=>`<span>${(CROP_BY_ID[o.crop]||(typeof r3ProduceItem==='function'&&r3ProduceItem(o.crop)))?.emoji||'🍎'}</span>`).join('') : '<span class="empty">陈列台空空，去院子种点菜来摆放吧</span>';
  if(off.dataset.html !== html){ off.innerHTML = html; off.dataset.html = html; }
  $('#hallStats').innerHTML = `✨ 善缘 ${S.merit}<br>🏮 点灯 ${S.incense.total} 盏<br>🍑 陈列 ${S.offerings.length} 件<br>🎐 庭铃 ${S.muyu} 下`;
}
$('#btnIncense').addEventListener('click', ()=>{
  const now = Date.now();
  if(activeSticks(now).length >= INCENSE_SLOTS){ toast('灯台已满，请稍候'); return; }
  tgFeedback('incense');S.incense.sticks.push(now); S.incense.total++; save();
  addMerit(3, $('#burner')); renderHall(); $('#sticks').lastElementChild.classList.add('lighting'); vibrate(20);
  toast(`🌿 点亮第 ${S.incense.total} 盏灯，善缘 +1`);
});
$('#btnOffer').addEventListener('click', ()=>{
  if(!invCount()){ toast('背包里还没有作物，先去院子种菜吧'); return; }
  openModal(`<h2>🍑 摆放</h2><p class="center" style="font-size:13px;color:#7a5a3a">点作物把它供到陈列台上（会从背包里扣除）</p>${inventoryHTML(true)}`);
  $('#sheet').querySelector('.inv-grid').addEventListener('click', e=>{
    const it = e.target.closest('.inv-item.clickable'); if(!it) return;
    const id = it.dataset.crop, c = CROP_BY_ID[id];
    if(!S.inventory[id]) return;
    S.inventory[id]--; if(!S.inventory[id]) delete S.inventory[id];
    tgFeedback('offer');S.offerings.push({crop:id, at:Date.now()}); save();
    closeModal(); renderHall(); renderTop(); addMerit(c.value, $('#altar'));
    toast(`摆上 ${c.emoji}${c.name}，善缘 +${c.value}`);
  });
});
$('#muyu').addEventListener('click', ()=>{tgFeedback('muyu'); S.muyu++; vibrate(10); addMerit(1, $('#muyu')); renderHall(); });

/* 烟雾粒子（canvas）：从每炷香的香头冒出，只在祠堂场景运行 */
const smoke = $('#smoke'), sctx = smoke.getContext('2d');
let particles=[], smokeRAF=null, lastEmit=0;
function resizeSmoke(){
  const r = smoke.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio||1);
  smoke.width = Math.max(1, Math.round(r.width*dpr)); smoke.height = Math.max(1, Math.round(r.height*dpr));
  sctx.setTransform(dpr,0,0,dpr,0,0);
}
function startSmoke(){ if(!smokeRAF) smokeRAF = requestAnimationFrame(smokeLoop); }
function smokeLoop(ts){
  if(current!=='hall'){ smokeRAF=null; particles=[]; return; }
  const W = smoke.clientWidth, H = smoke.clientHeight;
  sctx.clearRect(0,0,W,H);
  if(ts - lastEmit > 70){
    lastEmit = ts;
    const base = smoke.getBoundingClientRect();
    document.querySelectorAll('#sticks .stick').forEach(st=>{
      const r = st.getBoundingClientRect();
      const burn = parseFloat(st.style.getPropertyValue('--burn'))||0;
      particles.push({x:r.left+r.width/2-base.left, y:r.top+r.height*burn/100-base.top-3,
        r:3, a:.55, vx:(Math.random()-.5)*.25, vy:-.6-Math.random()*.35, ph:Math.random()*6});
    });
  }
  particles = particles.filter(p=>p.a>0.015 && p.y>-40);
  for(const p of particles){
    p.ph += .045; p.x += p.vx + Math.sin(p.ph)*.4; p.y += p.vy; p.r += .13; p.a *= .985;
    const g = sctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r);
    g.addColorStop(0,`rgba(235,230,220,${p.a})`); g.addColorStop(1,'rgba(235,230,220,0)');
    sctx.fillStyle=g; sctx.beginPath(); sctx.arc(p.x,p.y,p.r,0,Math.PI*2); sctx.fill();
  }
  smokeRAF = requestAnimationFrame(smokeLoop);
}
window.addEventListener('resize', ()=>{ if(current==='hall') resizeSmoke(); });

/* =========================================================
   十一、事件绑定与主循环
   ========================================================= */
$('#legacyGate').addEventListener('click', ()=>go('yard'));
$('#toYard').addEventListener('click', ()=>go('yard'));
$('#stallGua').addEventListener('click', openGua);
$('#stallQian').addEventListener('click', openQian);
$('#stallFeng').addEventListener('click', openFeng);
$('#backToPlaza').addEventListener('click', ()=>go('plaza'));
$('#hallDoor').addEventListener('click', ()=>go('hall'));
$('#backFromHall').addEventListener('click', ()=>go('yard'));
window.addEventListener('hashchange', ()=>{ const h=location.hash.slice(1); if(h==='home'||SCENES.includes(h)) go(h); });

function renderAll(){ renderTop(); renderSeedBar(); renderYard(); renderHall();
  if(typeof worldSyncYard==='function') worldSyncYard();
  if(typeof worldSyncHall==='function') worldSyncHall();
}

// 每秒刷新：作物生长、香燃烧
setInterval(()=>{ r3ApplyVisitingUI();if(current==='yard'){ renderYard(); if(typeof worldSyncYard==='function') worldSyncYard(); } if(current==='hall'){ renderHall(); if(typeof worldSyncHall==='function') worldSyncHall(); } }, 1000);

/* plotEffect kept from v2 for planting/harvest juice */
function plotEffect(el,emoji,harvesting=false){const fx=document.createElement('span');fx.className='plot-fx'+(harvesting?' harvest':'');fx.textContent=emoji;el.appendChild(fx);setTimeout(()=>fx.remove(),850);}

// 启动：优先读网址里的 #场景（#plaza / #yard / #hall），否则从大厅开始
(async()=>{S=await load();r3SnapshotOwnSpace();buildPlots(); renderAll();
if(typeof initWorld==='function') initWorld(document.getElementById('view'));
const startHash = location.hash.slice(1);
await go((startHash==='home'||SCENES.includes(startHash)) ? startHash : SCENES.includes(S.scene)?S.scene:'plaza', true);
if(!current)go('plaza',true);})();
document.addEventListener('gesturestart', e=>e.preventDefault()); // 禁止 iOS 双指缩放
